# InCore-II 2.1-MAX recovered core (SourceGuardian runtime dump)

## Goal
Readable/runnable reconstruction of **all** encrypted PHP under `PocketMine-MP.phar` (user: 全部都可以逆向).

## Method
1. Patched official SG loader `ixed.8.0ts.lin` (expiry/error 09 + remote time bypass)
2. Load each encrypted PHP via `phar://` under qemu-x86_64 PHP 8.0 ZTS
3. Reflection stubs + native `opdump.so` opcode dump
4. `ops_txt_to_json.py` + `tools/decompile_ops.py` → PHP bodies
5. Full rebuild: `rebuild_all_decompiled.py`

## Coverage (2026-07-22)
| Metric | Value |
|--------|------:|
| PHAR PHP file list | **1303 / 1303** |
| opdump class files | **1277** |
| decompile ok | **1277 / 1277** |
| recovered_core `src/**/*.php` | **~1350+** (list + extras/aliases) |
| missing list files | **0** |

### Gap fills
- SPL interfaces / loggers: Genisys/MPMPES baseline where SG load order blocked dump
- `src/pocketmine/Enchantment.php`: class_alias shell → `item\enchantment\Enchantment`
- `src/spl/stubs/{leveldb,pthreads,weakref,yaml}.php`: PocketMine-SPL public stubs (extensions collide with real C classes)

## Quality fixes (important)
1. **CONST space truncation** (`ops_txt_to_json.py`): balanced-paren/`extract_kv_operands` so strings with spaces survive (e.g. StoneWall `Mossy Cobblestone Wall`).
2. **Compare → JMPZ temp slot** (`decompile_ops.normalize_slot`): `res=t18(96)` ≈ `T1` (`num - 80`); kills most bare `if ($tN)`.
3. **opdump 0.5.0 array expand**: walk LE `HashTable` → `array(N){0 => int(1), ...}`; nested parse fixed in `parse_array_body`.
4. **Array batch**: 327 classes re-opdumped from 0.4 `array(ptr=…)` → expanded; **0** remaining `array(ptr=` in ops; rebuild **0** `__array_ptr` in recovered_core.

## Layout
- `src/` recovered PHP (prefer over encrypted phar)
- resources/lang under original phar paths when merged
- tools: `dump_one.php`, `run_php_x86.sh`, `ops_txt_to_json.py`, `tools/decompile_ops.py`, `rebuild_all_decompiled.py`, `run_array_redump.sh`
- opdump ext: `opdump_ext/opdump.c` **0.5.0** (build with `-DCOMPILE_DL_OPDUMP=1` + fixed `libc.so` script under `tools/x86-libfix/`)

## Quality notes (remaining, not coverage blockers)
- Simple getters/setters: usually correct
- Large/complex classes (`Player`, `Server`, `Level`, `Block`, `Item`, …) may still have `$tN`, empty if bodies, best-effort foreach/switch
- Not a perfect 1:1 vendor source release — best-effort reconstruction from opcodes after SG decrypt
- Hybrid runnable package: common logic can still be cross-checked with Genisys 0.14.3; InCore-only keep recovered bodies

## Reproduce
```bash
cd tmp/incore-ii-sg-re-fresh
# single file
bash run_php_x86.sh dump_one.php PocketMine-MP.phar src/pocketmine/block/CoalOre.php dumps
python3 rebuild_all_decompiled.py
```

## Status
**Coverage: complete for PHAR PHP list.**  
**Readability: high for simple methods; improving for complex CF / large classes (ongoing).**


## Package stamp
- zip: InCore-II-2.1-MAX-recovered-latest.zip
- time: 2026-07-22T18:17:22+08:00
- transplants: PocketMine.php, BigTree.php, PluginLogger.php from runnable_pure
