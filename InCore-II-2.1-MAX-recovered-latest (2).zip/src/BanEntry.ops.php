<?php

class BanEntry.ops {
}
