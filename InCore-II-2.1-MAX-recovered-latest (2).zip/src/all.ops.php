<?php

class all.ops {
}
