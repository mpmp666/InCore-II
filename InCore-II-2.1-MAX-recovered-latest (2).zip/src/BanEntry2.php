<?php

namespace pocketmine\permission;

class BanEntry {
	public function __construct($name = null) {
		/* decompiled (structured CF) */
		$this->prop = func($name);
		new null();
		$this->prop = new null();
		return;
	}

	public function getName() {
		return $this->null;
	}

	public function getCreated() {
		return $this->null;
	}

	public function setCreated($date = null) {
		$this->meta = $date;
	}

	public function getSource() {
		return $this->null;
	}

	public function setSource($source = null) {
		$this->meta = $source;
	}

	public function getExpires() {
		return $this->null;
	}

	public function setExpires($date = null) {
		$this->meta = $date;
	}

	public function hasExpired() {
		/* decompiled (structured CF) */
		new null();
		$now = new null();
		if (($this->null === null)) {
			return null;
		} else {
			$this->prop = $now;
			return $now;
		}
	}

	public function getReason() {
		return $this->null;
	}

	public function setReason($reason = null) {
		$this->meta = $reason;
	}

	public function getString() {
		/* decompiled (structured CF) */
		$str = null;
		$str .= $this->method();
		$str .= null;
		$str .= $this->method()->method(self::$null);
		$str .= null;
		$str .= $this->method();
		$str .= null;
		if (($this->method() === null)) {
		} else {
		}
		$str .= $this->method()->method(self::$null);
		$str .= null;
		$str .= $this->method();
		return $str;
	}

	public function fromString($str = null) {
		/* decompiled (structured CF) */
		if ((func($str) < null)) {
			return null;
		} else {
			$str = func(null, func($str));
			new null(func(func($str)));
			$entry = new null(func(func($str)));
			if ((null < func($str))) {
				$entry->method(null::__construct(self::$null, func($str)));
				if ((null < func($str))) {
					$entry->method(func(func($str)));
					if ((null < func($str))) {
						$expire = func(func($str));
						if (((func($expire) !== null) && (null < func($expire)))) {
							$entry->method(null::__construct(self::$null, $expire));
						}
						if ((null < func($str))) {
							$entry->method(func(func($str)));
						}
					}
				}
			}
			return $entry;
		}
	}

}
