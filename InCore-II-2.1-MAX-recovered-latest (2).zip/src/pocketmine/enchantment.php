<?php

namespace pocketmine;

class enchantment {
}
