<?php

/**
 * Recovered from InCore-II SG dump.
 * Loading this path defines class_alias-style symbol pocketmine\enchantment
 * that is the same class as pocketmine\item\enchantment\Enchantment
 * (Reflection: same methods/consts; dump file path points to item/enchantment).
 */
namespace pocketmine;

// Prefer real class body under item\enchantment
if (!class_exists(\pocketmine\item\enchantment\Enchantment::class, false)) {
	// autoload / require sibling if available
	$__p = __DIR__ . '/item/enchantment/Enchantment.php';
	if (is_file($__p)) {
		require_once $__p;
	}
}

// Historical Genisys/InCore alias: lowercase short name "enchantment" in pocketmine ns
// was dumped as empty shell; runtime resolves pocketmine\Enchantment to item class.
if (class_exists(\pocketmine\item\enchantment\Enchantment::class, false)
	&& !class_exists(__NAMESPACE__ . '\\enchantment', false)) {
	class_alias(\pocketmine\item\enchantment\Enchantment::class, __NAMESPACE__ . '\\enchantment');
}

// Some code uses pocketmine\Enchantment (capital E) — PHP class names are case-insensitive
// so pocketmine\enchantment already covers it when loaded.
