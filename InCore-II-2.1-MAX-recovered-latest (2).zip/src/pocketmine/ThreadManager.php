<?php

namespace pocketmine;

class ThreadManager extends \Volatile {
	private static $instance = NULL;

	public static function init() {
			new \pocketmine\ThreadManager();
			self::$instance = new \pocketmine\ThreadManager();
			return null;
		}

	public static function getInstance() {
			return self::$instance;
		}

	public function add($thread = null) {
			/* decompiled (structured CF) */
			if (($thread instanceof \pocketmine\Thread || $thread instanceof \pocketmine\Worker)) {
				$this->prop = $thread;
			}
			return null;
		}

	public function remove($thread = null) {
			if (($thread instanceof \pocketmine\Thread || $thread instanceof \pocketmine\Worker)) {
			}
			return null;
		}

	public function getAll() {
			/* decompiled (structured CF) */
			$array = ['__array_ptr' => '2aaaac9fc9a0'];
			foreach ($this as $key => $thread) {
				$array[$key] = $thread;
				/* goto */
			}
			return $array;
		}

}
