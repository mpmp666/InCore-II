<?php

namespace pocketmine;

class OfflinePlayer implements \pocketmine\IPlayer {
	private $name = NULL;
	private $server = NULL;
	private $namedtag = NULL;

	public function __construct($server = null, $name = null) {
			/* decompiled (structured CF) */
			$this->server = $server;
			$this->name = $name;
			if (file_exists(((($this->server->getDataPath() . 'players/') . strtolower($this->getName())) . '.dat'))) {
				$this->namedtag = $this->server->getOfflinePlayerData($this->name);
			} else {
				$this->namedtag = null;
			}
			return;
		}

	public function isOnline() {
			return ($this->getPlayer() !== null);
		}

	public function getName() {
			return $this->name;
		}

	public function getServer() {
			return $this->server;
		}

	public function isOp() {
			return $this->server->isOp(strtolower($this->getName()));
		}

	public function setOp($value = null) {
			/* decompiled (structured CF) */
			if (($value === $this->isOp())) {
				return null;
			}
			if (($value === true)) {
				$this->server->addOp(strtolower($this->getName()));
			} else {
				$this->server->removeOp(strtolower($this->getName()));
			}
		}

	public function isBanned() {
			return $this->server->getNameBans()->isBanned(strtolower($this->getName()));
		}

	public function setBanned($value = null) {
			/* decompiled (structured CF) */
			if (($value === true)) {
				$this->server->getNameBans()->addBan($this->getName(), null, null, null);
			} else {
				$this->server->getNameBans()->remove($this->getName());
			}
			return null;
		}

	public function isWhitelisted() {
			return $this->server->isWhitelisted(strtolower($this->getName()));
		}

	public function setWhitelisted($value = null) {
			/* decompiled (structured CF) */
			if (($value === true)) {
				$this->server->addWhitelist(strtolower($this->getName()));
			} else {
				$this->server->removeWhitelist(strtolower($this->getName()));
			}
			return null;
		}

	public function getPlayer() {
			return $this->server->getPlayerExact($this->getName());
		}

	public function getFirstPlayed() {
			/* decompiled (structured CF) */
			if ($this->namedtag instanceof \pocketmine\nbt\tag\CompoundTag) {
			} else {
			}
			return null;
		}

	public function getLastPlayed() {
			/* decompiled (structured CF) */
			if ($this->namedtag instanceof \pocketmine\nbt\tag\CompoundTag) {
			} else {
			}
			return null;
		}

	public function hasPlayedBefore() {
			return $this->namedtag instanceof \pocketmine\nbt\tag\CompoundTag;
		}

	public function setMetadata($metadataKey = null, $metadataValue = null) {
			$this->server->getPlayerMetadata()->setMetadata($this, $metadataKey, $metadataValue);
			return null;
		}

	public function getMetadata($metadataKey = null) {
			return $this->server->getPlayerMetadata()->getMetadata($this, $metadataKey);
		}

	public function hasMetadata($metadataKey = null) {
			return $this->server->getPlayerMetadata()->hasMetadata($this, $metadataKey);
		}

	public function removeMetadata($metadataKey = null, $plugin = null) {
			$this->server->getPlayerMetadata()->removeMetadata($this, $metadataKey, $plugin);
			return null;
		}

}
