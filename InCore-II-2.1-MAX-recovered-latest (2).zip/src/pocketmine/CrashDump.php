<?php

namespace pocketmine;

class CrashDump {
	private $server = NULL;
	private $fp = NULL;
	private $time = NULL;
	private $data = array (
);
	private $encodedData = NULL;
	private $path = NULL;

	public function __construct($server = null) {
			/* decompiled (structured CF) */
			$this->time = time();
			$this->server = $server;
			$this->path = ((($this->server->getCrashPath() . 'CrashDump_') . date('D_M_j-H.i.s-T_Y', $this->time)) . '.log');
			$this->fp = fopen($this->path, 'wb');
			if (!(is_resource($this->fp))) {
				new \RuntimeException($this);
				throw new \RuntimeException($this);
			}
			$this->data['time'] = $this->time;
			$this->addLine((($this->server->getName() . $this) . date($this, $this->time)));
			$this->addLine();
			$this->baseCrash();
			$this->generalData();
			$this->pluginsData();
			$this->extraData();
			return;
		}

	public function getPath() {
			return $this->path;
		}

	public function getEncodedData() {
			return $this->encodedData;
		}

	public function getData() {
			return $this->data;
		}

	private function encodeData() {
			/* decompiled (structured CF) */
			$this->addLine();
			$this->addLine($this);
			$this->addLine();
			$this->addLine($this);
			$this->encodedData = zlib_encode(json_encode($this->data, \JSON_UNESCAPED_SLASHES), \ZLIB_ENCODING_DEFLATE, 9);
			foreach (str_split(base64_encode($this->encodedData), 76) as $line) {
				$this->addLine($line);
				/* goto */
			}
			$this->addLine($this);
			return null;
		}

	private function pluginsData() {
			/* decompiled (structured CF) */
			if (class_exists('pocketmine\\plugin\\PluginManager', false)) {
				$this->addLine();
				$this->addLine($this);
				$this->addLine("\xe5\x8a\xa0\xe8\xbd\xbd\xe7\x9a\x84\xe6\x8f\x92\xe4\xbb\xb6:");
				$this->data['plugins'] = ['__array_ptr' => '2aaaac9fc9a0'];
				foreach ($this->server->getPluginManager()->getPlugins() as $p) {
					$d = $p->getDescription();
					if (($d->getOrder() === \pocketmine\plugin\PluginLoadOrder::POSTWORLD)) {
					} else {
					}
					$this->data['plugins'][$d->getName()] = [$d->getName(), $d->getVersion(), $d->getAuthors(), $d->getCompatibleApis(), $p->isEnabled(), $d->getDepend(), $d->getSoftDepend(), $d->getMain(), 'STARTUP', $d->getWebsite()];
					$this->addLine((((((($d->getName() . $this) . $d->getVersion()) . $this) . implode($this, $d->getAuthors())) . $this) . implode($this, $d->getCompatibleApis())));
					/* goto */
				}
			}
			return null;
		}

	private function extraData() {
			/* decompiled (structured CF) */
			if (($this->server->getProperty('auto-report.send-settings', true) !== false)) {
				$this->data['parameters'] = ($arguments);
				$this->data['server.properties'] = file_get_contents(($this->server->getDataPath() . 'server.properties'));
				$this->data['server.properties'] = preg_replace('#^rcon\\.password=(.*)$#m', 'rcon.password=******', $this->data['server.properties']);
				$this->data['pocketmine.yml'] = file_get_contents(($this->server->getDataPath() . 'pocketmine.yml'));
			} else {
				$this->data['pocketmine.yml'] = '';
				$this->data['server.properties'] = '';
				$this->data['parameters'] = ['__array_ptr' => '2aaaac9fc9a0'];
			}
			$extensions = ['__array_ptr' => '2aaaac9fc9a0'];
			foreach (get_loaded_extensions() as $ext) {
				$extensions[$ext] = phpversion($ext);
				/* goto */
			}
			$this->data['extensions'] = $extensions;
			if (($this->server->getProperty('auto-report.send-phpinfo', true) !== false)) {
				ob_start();
				phpinfo();
				$this->data['phpinfo'] = ob_get_contents();
				ob_end_clean();
			}
			return null;
		}

	private function baseCrash() {
			/* decompiled (structured CF) */
			if ($t11) {
				$error = $lastExceptionError;
			} else {
				$error = (error_get_last());
				$error['trace'] = getTrace(3);
				$errorConversion = ['E_ERROR', 'E_WARNING', 'E_PARSE', 'E_NOTICE', 'E_CORE_ERROR', 'E_CORE_WARNING', 'E_COMPILE_ERROR', 'E_COMPILE_WARNING', 'E_USER_ERROR', 'E_USER_WARNING', 'E_USER_NOTICE', 'E_STRICT', 'E_RECOVERABLE_ERROR', 'E_DEPRECATED', 'E_USER_DEPRECATED'];
				$error['fullFile'] = $error['file'];
				$error['file'] = cleanPath($error['file']);
				if (isset($errorConversion[$error['type']])) {
				} else {
				}
				$error['type'] = $error['type'];
				$pos = strpos($error['message'], "\x0a");
				if (($pos !== false)) {
					$error['message'] = substr($error['message'], 0, $pos);
				}
			}
			if ($t55) {
				$this->data['lastError'] = $lastError;
			}
			$this->data['error'] = $error;
			$this->addLine(($this . $error['message']));
			$this->addLine(($this . $error['file']));
			$this->addLine(($this . $error['line']));
			$this->addLine(($this . $error['type']));
			if ((((strpos($error['file'], 'src/pocketmine/') === false) && (strpos($error['file'], 'src/raklib/') === false)) && file_exists($error['fullFile']))) {
				$this->addLine();
				$this->addLine($this);
				$this->addLine("\xe6\xad\xa4\xe6\xac\xa1\xe5\x87\xba\xe9\x94\x99\xe7\x94\xb1\xe6\x8f\x92\xe4\xbb\xb6\xe5\xbc\x95\xe8\xb5\xb7");
				$this->data['plugin'] = true;
				new \ReflectionClass('pocketmine\\plugin\\PluginBase');
				$reflection = new \ReflectionClass('pocketmine\\plugin\\PluginBase');
				$file = $reflection->getProperty('file');
				$file->setAccessible(true);
				foreach ($this->server->getPluginManager()->getPlugins() as $plugin) {
					$filePath = pocketmine\cleanPath($file->getValue($plugin));
					if ((strpos($error['file'], $filePath) === 0)) {
						$this->data['plugin'] = $plugin->getName();
						$this->addLine(($this . $plugin->getDescription()->getFullName()));
					} else {
						/* goto */
					}
				}
			} else {
				$this->data['plugin'] = false;
			}
			$this->addLine();
			$this->addLine('Code:');
			$this->data['code'] = ['__array_ptr' => '2aaaac9fc9a0'];
			if (($this->server->getProperty('auto-report.send-code', true) !== false)) {
				$file = file($error['fullFile'], \FILE_IGNORE_NEW_LINES);
				$l = max(0, ($error['line'] - 10));
				while (($l < $t145)) {
					$this->addLine(((('[' . ($l + 1)) . $this) . $file[$l]));
					$this->data['code'][($l + 1)] = $file[$l];
					$l++;
				}
			}
			$this->addLine();
			$this->addLine('Backtrace:');
			$this->data['trace'] = $error['trace'];
			foreach ($t150 as $line) {
				$this->addLine($line);
				/* goto */
			}
			$this->addLine();
			return null;
		}

	private function generalData() {
			/* decompiled (structured CF) */
			new \pocketmine\utils\VersionString();
			$version = new \pocketmine\utils\VersionString();
			$this->data['general'] = ['__array_ptr' => '2aaaac9fc9a0'];
			$this->data['general']['version'] = $version->get(false);
			$this->data['general']['build'] = $version->getBuild();
			$this->data['general']['protocol'] = \pocketmine\network\protocol\Info::CURRENT_PROTOCOL;
			$this->data['general']['api'] = \pocketmine\API_VERSION;
			$this->data['general']['git'] = \pocketmine\GIT_COMMIT;
			$this->data['general']['raklib'] = \raklib\RakLib::VERSION;
			$this->data['general']['uname'] = php_uname('a');
			$this->data['general']['php'] = phpversion();
			$this->data['general']['zend'] = zend_version();
			$this->data['general']['php_os'] = \PHP_OS;
			$this->data['general']['os'] = \pocketmine\utils\Utils::getOS();
			$this->addLine((((((((($this . $version->get(false)) . $this) . $version->getBuild()) . $this) . \pocketmine\network\protocol\Info::CURRENT_PROTOCOL) . $this) . \pocketmine\API_VERSION) . ']'));
			$this->addLine(($this . php_uname('a')));
			$this->addLine(($this . phpversion()));
			$this->addLine(($this . zend_version()));
			$this->addLine(((($this . \PHP_OS) . $this) . \pocketmine\utils\Utils::getOS()));
			return null;
		}

	public function addLine($line = null) {
			fwrite($this->fp, ($line . \PHP_EOL));
			return null;
		}

	public function add($str = null) {
			fwrite($this->fp, $str);
			return null;
		}

}
