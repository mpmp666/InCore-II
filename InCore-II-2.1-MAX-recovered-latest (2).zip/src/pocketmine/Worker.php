<?php

namespace pocketmine;

abstract class Worker extends \Worker {
	protected $classLoader = NULL;
	protected $isKilled = false;

	public function getClassLoader() {
			return $this->classLoader;
		}

	public function setClassLoader($loader = null) {
			/* decompiled (structured CF) */
			if (($loader === null)) {
				$loader = \pocketmine\Server::getInstance()->getLoader();
			}
			$this->classLoader = $loader;
			return null;
		}

	public function registerClassLoader() {
			/* decompiled (structured CF) */
			if (!(interface_exists('ClassLoader', false))) {
			}
			if (($this->classLoader !== null)) {
				$this->classLoader->register(true);
			}
			return null;
		}

	public function start($options = null) {
			/* decompiled (structured CF) */
			\pocketmine\ThreadManager::getInstance()->add($this);
			if (((!($this->isRunning()) && !($this->isJoined())) && !($this->isTerminated()))) {
				if (($this->getClassLoader() === null)) {
					$this->setClassLoader();
				}
				return parent::start($options);
			}
			return false;
		}

	public function quit() {
			/* decompiled (structured CF) */
			$this->isKilled = true;
			$this->notify();
			if ($this->isRunning()) {
				$this->shutdown();
				$this->notify();
				$this->unstack();
			} else {
				if (!($this->isJoined())) {
					if (!($this->isTerminated())) {
						$this->join();
					}
				}
			}
			\pocketmine\ThreadManager::getInstance()->remove($this);
			return null;
		}

	public function getThreadName() {
			new \ReflectionClass($this);
			return (new \ReflectionClass($this))->getShortName();
		}

}
