<?php

namespace pocketmine\event;

class TranslationContainer extends \pocketmine\event\TextContainer {
	protected $params = array (
);

	public function __construct($text = null, $params = null) {
			parent::__construct($text);
			$this->setParameters($params);
			return;
		}

	public function getParameters() {
			return $this->params;
		}

	public function getParameter($i = null) {
			/* decompiled (structured CF) */
			if (isset($this->params[$i])) {
			} else {
			}
			return null;
		}

	public function setParameter($i = null, $str = null) {
			/* decompiled (structured CF) */
			if ((($i < 0) || (count($this->params) < $i))) {
				new \InvalidArgumentException((($this . $this) . count($this->params)));
				throw new \InvalidArgumentException((($this . $this) . count($this->params)));
			}
			$this->params[($i)] = $str;
			return null;
		}

	public function setParameters($params = null) {
			/* decompiled (structured CF) */
			$i = 0;
			foreach ($params as $str) {
				$this->params[$i] = ($str);
				$i++;
				/* goto */
			}
			return null;
		}

}
