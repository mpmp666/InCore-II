<?php

namespace pocketmine\event;

abstract class Timings {
	public static $fullTickTimer = NULL;
	public static $serverTickTimer = NULL;
	public static $memoryManagerTimer = NULL;
	public static $garbageCollectorTimer = NULL;
	public static $playerListTimer = NULL;
	public static $playerNetworkTimer = NULL;
	public static $playerNetworkReceiveTimer = NULL;
	public static $playerChunkOrderTimer = NULL;
	public static $playerChunkSendTimer = NULL;
	public static $connectionTimer = NULL;
	public static $tickablesTimer = NULL;
	public static $schedulerTimer = NULL;
	public static $chunkIOTickTimer = NULL;
	public static $timeUpdateTimer = NULL;
	public static $serverCommandTimer = NULL;
	public static $worldSaveTimer = NULL;
	public static $generationTimer = NULL;
	public static $populationTimer = NULL;
	public static $generationCallbackTimer = NULL;
	public static $permissibleCalculationTimer = NULL;
	public static $permissionDefaultTimer = NULL;
	public static $entityMoveTimer = NULL;
	public static $tickEntityTimer = NULL;
	public static $activatedEntityTimer = NULL;
	public static $tickTileEntityTimer = NULL;
	public static $timerEntityBaseTick = NULL;
	public static $timerLivingEntityBaseTick = NULL;
	public static $timerEntityAI = NULL;
	public static $timerEntityAICollision = NULL;
	public static $timerEntityAIMove = NULL;
	public static $timerEntityTickRest = NULL;
	public static $schedulerSyncTimer = NULL;
	public static $schedulerAsyncTimer = NULL;
	public static $playerCommandTimer = NULL;
	public static $entityTypeTimingMap = array (
);
	public static $tileEntityTypeTimingMap = array (
);
	public static $packetReceiveTimingMap = array (
);
	public static $packetSendTimingMap = array (
);
	public static $pluginTaskTimingMap = array (
);

	public static function init() {
			/* decompiled (structured CF) */
			if (self::$serverTickTimer instanceof \pocketmine\event\TimingsHandler) {
				return null;
			}
			new \pocketmine\event\TimingsHandler($this);
			self::$fullTickTimer = new \pocketmine\event\TimingsHandler($this);
			new \pocketmine\event\TimingsHandler($this, self::$fullTickTimer);
			self::$serverTickTimer = new \pocketmine\event\TimingsHandler($this, self::$fullTickTimer);
			new \pocketmine\event\TimingsHandler($this);
			self::$memoryManagerTimer = new \pocketmine\event\TimingsHandler($this);
			new \pocketmine\event\TimingsHandler($this, self::$memoryManagerTimer);
			self::$garbageCollectorTimer = new \pocketmine\event\TimingsHandler($this, self::$memoryManagerTimer);
			new \pocketmine\event\TimingsHandler($this);
			self::$playerListTimer = new \pocketmine\event\TimingsHandler($this);
			new \pocketmine\event\TimingsHandler($this);
			self::$playerNetworkTimer = new \pocketmine\event\TimingsHandler($this);
			new \pocketmine\event\TimingsHandler($this);
			self::$playerNetworkReceiveTimer = new \pocketmine\event\TimingsHandler($this);
			new \pocketmine\event\TimingsHandler($this);
			self::$playerChunkOrderTimer = new \pocketmine\event\TimingsHandler($this);
			new \pocketmine\event\TimingsHandler($this);
			self::$playerChunkSendTimer = new \pocketmine\event\TimingsHandler($this);
			new \pocketmine\event\TimingsHandler($this);
			self::$connectionTimer = new \pocketmine\event\TimingsHandler($this);
			new \pocketmine\event\TimingsHandler('Tickables');
			self::$tickablesTimer = new \pocketmine\event\TimingsHandler('Tickables');
			new \pocketmine\event\TimingsHandler('Scheduler');
			self::$schedulerTimer = new \pocketmine\event\TimingsHandler('Scheduler');
			new \pocketmine\event\TimingsHandler('ChunkIOTick');
			self::$chunkIOTickTimer = new \pocketmine\event\TimingsHandler('ChunkIOTick');
			new \pocketmine\event\TimingsHandler($this);
			self::$timeUpdateTimer = new \pocketmine\event\TimingsHandler($this);
			new \pocketmine\event\TimingsHandler($this);
			self::$serverCommandTimer = new \pocketmine\event\TimingsHandler($this);
			new \pocketmine\event\TimingsHandler($this);
			self::$worldSaveTimer = new \pocketmine\event\TimingsHandler($this);
			new \pocketmine\event\TimingsHandler($this);
			self::$generationTimer = new \pocketmine\event\TimingsHandler($this);
			new \pocketmine\event\TimingsHandler($this);
			self::$populationTimer = new \pocketmine\event\TimingsHandler($this);
			new \pocketmine\event\TimingsHandler($this);
			self::$generationCallbackTimer = new \pocketmine\event\TimingsHandler($this);
			new \pocketmine\event\TimingsHandler($this);
			self::$permissibleCalculationTimer = new \pocketmine\event\TimingsHandler($this);
			new \pocketmine\event\TimingsHandler($this);
			self::$permissionDefaultTimer = new \pocketmine\event\TimingsHandler($this);
			new \pocketmine\event\TimingsHandler($this);
			self::$entityMoveTimer = new \pocketmine\event\TimingsHandler($this);
			new \pocketmine\event\TimingsHandler($this);
			self::$tickEntityTimer = new \pocketmine\event\TimingsHandler($this);
			new \pocketmine\event\TimingsHandler($this);
			self::$activatedEntityTimer = new \pocketmine\event\TimingsHandler($this);
			new \pocketmine\event\TimingsHandler($this);
			self::$tickTileEntityTimer = new \pocketmine\event\TimingsHandler($this);
			new \pocketmine\event\TimingsHandler($this);
			self::$timerEntityBaseTick = new \pocketmine\event\TimingsHandler($this);
			new \pocketmine\event\TimingsHandler($this);
			self::$timerLivingEntityBaseTick = new \pocketmine\event\TimingsHandler($this);
			new \pocketmine\event\TimingsHandler($this);
			self::$timerEntityAI = new \pocketmine\event\TimingsHandler($this);
			new \pocketmine\event\TimingsHandler($this);
			self::$timerEntityAICollision = new \pocketmine\event\TimingsHandler($this);
			new \pocketmine\event\TimingsHandler($this);
			self::$timerEntityAIMove = new \pocketmine\event\TimingsHandler($this);
			new \pocketmine\event\TimingsHandler($this);
			self::$timerEntityTickRest = new \pocketmine\event\TimingsHandler($this);
			new \pocketmine\event\TimingsHandler($this, \pocketmine\plugin\PluginManager::$pluginParentTimer);
			self::$schedulerSyncTimer = new \pocketmine\event\TimingsHandler($this, \pocketmine\plugin\PluginManager::$pluginParentTimer);
			new \pocketmine\event\TimingsHandler($this);
			self::$schedulerAsyncTimer = new \pocketmine\event\TimingsHandler($this);
			new \pocketmine\event\TimingsHandler($this);
			self::$playerCommandTimer = new \pocketmine\event\TimingsHandler($this);
		}

	public static function getPluginTaskTimings($task = null, $period = null) {
			/* decompiled (structured CF) */
			$ftask = $task->getTask();
			if (($ftask instanceof \pocketmine\scheduler\PluginTask && ($ftask->getOwner() !== null))) {
				$plugin = $ftask->getOwner()->getDescription()->getFullName();
			} else {
				if (($task->timingName !== null)) {
					$plugin = 'Scheduler';
				} else {
					$plugin = 'Unknown';
				}
			}
			$taskname = $task->getTaskName();
			$name = ((($this . $plugin) . $this) . $taskname);
			if ((0 < $period)) {
				$name .= (('(interval:' . $period) . ')');
			} else {
				$name .= '(Single)';
			}
			if (!(isset(self::$pluginTaskTimingMap[$name]))) {
				new \pocketmine\event\TimingsHandler($name, self::$schedulerSyncTimer);
				self::$pluginTaskTimingMap[$name] = new \pocketmine\event\TimingsHandler($name, self::$schedulerSyncTimer);
			}
			return self::$pluginTaskTimingMap[$name];
		}

	public static function getEntityTimings($entity = null) {
			/* decompiled (structured CF) */
			new \ReflectionClass($entity);
			$entityType = (new \ReflectionClass($entity))->getShortName();
			if (!(isset(self::$entityTypeTimingMap[$entityType]))) {
				if ($entity instanceof \pocketmine\Player) {
					new \pocketmine\event\TimingsHandler($this, self::$tickEntityTimer);
					self::$entityTypeTimingMap[$entityType] = new \pocketmine\event\TimingsHandler($this, self::$tickEntityTimer);
				} else {
					new \pocketmine\event\TimingsHandler(($this . $entityType), self::$tickEntityTimer);
					self::$entityTypeTimingMap[$entityType] = new \pocketmine\event\TimingsHandler(($this . $entityType), self::$tickEntityTimer);
				}
			}
			return self::$entityTypeTimingMap[$entityType];
		}

	public static function getTileEntityTimings($tile = null) {
			/* decompiled (structured CF) */
			new \ReflectionClass($tile);
			$tileType = (new \ReflectionClass($tile))->getShortName();
			if (!(isset(self::$tileEntityTypeTimingMap[$tileType]))) {
				new \pocketmine\event\TimingsHandler(($this . $tileType), self::$tickTileEntityTimer);
				self::$tileEntityTypeTimingMap[$tileType] = new \pocketmine\event\TimingsHandler(($this . $tileType), self::$tickTileEntityTimer);
			}
			return self::$tileEntityTypeTimingMap[$tileType];
		}

	public static function getReceiveDataPacketTimings($pk = null) {
			/* decompiled (structured CF) */
			if (!(isset(self::$packetReceiveTimingMap[$pk::NETWORK_ID]))) {
				new \ReflectionClass($pk);
				$pkName = (new \ReflectionClass($pk))->getShortName();
				new \pocketmine\event\TimingsHandler((((($this . $pkName) . $this) . dechex($pk::NETWORK_ID)) . ']'), self::$playerNetworkReceiveTimer);
				self::$packetReceiveTimingMap[$pk::NETWORK_ID] = new \pocketmine\event\TimingsHandler((((($this . $pkName) . $this) . dechex($pk::NETWORK_ID)) . ']'), self::$playerNetworkReceiveTimer);
			}
			return self::$packetReceiveTimingMap[$pk::NETWORK_ID];
		}

	public static function getSendDataPacketTimings($pk = null) {
			/* decompiled (structured CF) */
			if (!(isset(self::$packetSendTimingMap[$pk::NETWORK_ID]))) {
				new \ReflectionClass($pk);
				$pkName = (new \ReflectionClass($pk))->getShortName();
				new \pocketmine\event\TimingsHandler((((($this . $pkName) . $this) . dechex($pk::NETWORK_ID)) . ']'), self::$playerNetworkTimer);
				self::$packetSendTimingMap[$pk::NETWORK_ID] = new \pocketmine\event\TimingsHandler((((($this . $pkName) . $this) . dechex($pk::NETWORK_ID)) . ']'), self::$playerNetworkTimer);
			}
			return self::$packetSendTimingMap[$pk::NETWORK_ID];
		}

}
