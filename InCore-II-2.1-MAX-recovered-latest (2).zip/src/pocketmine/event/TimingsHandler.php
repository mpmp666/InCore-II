<?php

namespace pocketmine\event;

class TimingsHandler {
	private static $HANDLERS = array (
);
	private $name = NULL;
	private $parent = NULL;
	private $count = 0;
	private $curCount = 0;
	private $start = 0;
	private $timingDepth = 0;
	private $totalTime = 0;
	private $curTickTotal = 0;
	private $violations = 0;

	public function __construct($name = null, $parent = null) {
			/* decompiled (structured CF) */
			$this->name = $name;
			if (($parent !== null)) {
				$this->parent = $parent;
			}
			self::$HANDLERS[spl_object_hash($this)] = $this;
			return;
		}

	public static function printTimings($fp = null) {
			/* decompiled (structured CF) */
			fwrite($fp, ('Minecraft' . \PHP_EOL));
			foreach (self::$HANDLERS as $timings) {
				$time = $timings->totalTime;
				$count = $timings->count;
				if (($count === 0)) {
					/* goto */
				}
				$avg = ($time / $count);
				fwrite($fp, (((((((((($this . $timings->name) . $this) . round(($time * 1000000000))) . $this) . $count) . $this) . round(($avg * 1000000000))) . $this) . $timings->violations) . \PHP_EOL));
				/* goto */
			}
			fwrite($fp, (($this . \pocketmine\Server::getInstance()->getVersion()) . \PHP_EOL));
			fwrite($fp, (((($this . \pocketmine\Server::getInstance()->getName()) . $this) . \pocketmine\Server::getInstance()->getPocketMineVersion()) . \PHP_EOL));
			$entities = 0;
			$livingEntities = 0;
			foreach (\pocketmine\Server::getInstance()->getLevels() as $level) {
				$entities += count($level->getEntities());
				foreach ($level->getEntities() as $e) {
					if ($e instanceof \pocketmine\entity\Living) {
						$livingEntities++;
					}
					/* goto */
				}
				/* goto */
			}
			fwrite($fp, (($this . $entities) . \PHP_EOL));
			fwrite($fp, (($this . $livingEntities) . \PHP_EOL));
			return null;
		}

	public static function reload() {
			/* decompiled (structured CF) */
			if (\pocketmine\Server::getInstance()->getPluginManager()->useTimings()) {
				foreach (self::$HANDLERS as $timings) {
					$timings->reset();
					/* goto */
				}
				\pocketmine\command\defaults\TimingsCommand::$timingStart = microtime(true);
			}
			return null;
		}

	public static function tick($measure = null) {
			/* decompiled (structured CF) */
			if (\pocketmine\plugin\PluginManager::$useTimings) {
				if ($measure) {
					foreach (self::$HANDLERS as $timings) {
						if ((0.05 < $timings->curTickTotal)) {
							$timings->violations += round(($timings->curTickTotal / 0.05));
						}
						$timings->curTickTotal = 0;
						$timings->curCount = 0;
						$timings->timingDepth = 0;
						/* goto */
					}
				} else {
					foreach (self::$HANDLERS as $timings) {
						$timings->totalTime -= $timings->curTickTotal;
						$timings->count -= $timings->curCount;
						$timings->curTickTotal = 0;
						$timings->curCount = 0;
						$timings->timingDepth = 0;
						/* goto */
					}
				}
			}
			return null;
		}

	public function startTiming() {
			/* decompiled (structured CF) */
			if ((\pocketmine\plugin\PluginManager::$useTimings && ($t1 === 1))) {
				$this->start = microtime(true);
				if ((($this->parent !== null) && ($t8 === 1))) {
					$this->parent->start = $this->start;
				}
			}
			return null;
		}

	public function stopTiming() {
			/* decompiled (structured CF) */
			if (\pocketmine\plugin\PluginManager::$useTimings) {
				if ((($t2 !== 0) || ($this->start === 0))) {
					return null;
				}
				$diff = (microtime(true) - $this->start);
				$this->totalTime += $diff;
				$this->curTickTotal += $diff;
				$this->start = 0;
				if (($this->parent !== null)) {
					$this->parent->stopTiming();
				}
			}
		}

	public function reset() {
			$this->count = 0;
			$this->curCount = 0;
			$this->violations = 0;
			$this->curTickTotal = 0;
			$this->totalTime = 0;
			$this->start = 0;
			$this->timingDepth = 0;
		}

	public function remove() {
			return null;
		}

}
