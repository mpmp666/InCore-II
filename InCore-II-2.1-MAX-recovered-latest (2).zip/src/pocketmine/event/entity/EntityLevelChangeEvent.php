<?php

namespace pocketmine\event\entity;

class EntityLevelChangeEvent extends \pocketmine\event\entity\EntityEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	private $originLevel = NULL;
	private $targetLevel = NULL;

	public function __construct($entity = null, $originLevel = null, $targetLevel = null) {
			$this->entity = $entity;
			$this->originLevel = $originLevel;
			$this->targetLevel = $targetLevel;
		}

	public function getOrigin() {
			return $this->originLevel;
		}

	public function getTarget() {
			return $this->targetLevel;
		}

}
