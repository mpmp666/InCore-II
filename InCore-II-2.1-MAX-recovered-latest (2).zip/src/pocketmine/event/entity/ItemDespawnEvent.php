<?php

namespace pocketmine\event\entity;

class ItemDespawnEvent extends \pocketmine\event\entity\EntityEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;

	public function __construct($item = null) {
			$this->entity = $item;
		}

	public function getEntity() {
			return $this->entity;
		}

}
