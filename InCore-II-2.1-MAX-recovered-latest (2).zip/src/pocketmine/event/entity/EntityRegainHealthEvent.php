<?php

namespace pocketmine\event\entity;

class EntityRegainHealthEvent extends \pocketmine\event\entity\EntityEvent implements \pocketmine\event\Cancellable {
	public const CAUSE_REGEN = 0;
	public const CAUSE_EATING = 1;
	public const CAUSE_MAGIC = 2;
	public const CAUSE_CUSTOM = 3;
	public const CAUSE_SATURATION = 4;

	public static $handlerList = NULL;
	private $amount = NULL;
	private $reason = NULL;

	public function __construct($entity = null, $amount = null, $regainReason = null) {
			/* decompiled (structured CF) */
			$this->entity = $entity;
			$this->amount = $amount;
			$this->reason = ($regainReason);
			return;
		}

	public function getAmount() {
			return $this->amount;
		}

	public function setAmount($amount = null) {
			$this->amount = $amount;
		}

	public function getRegainReason() {
			return $this->reason;
		}

}
