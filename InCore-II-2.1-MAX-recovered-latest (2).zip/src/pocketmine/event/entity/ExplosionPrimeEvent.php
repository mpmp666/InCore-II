<?php

namespace pocketmine\event\entity;

class ExplosionPrimeEvent extends \pocketmine\event\entity\EntityEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	protected $force = NULL;
	private $blockBreaking = NULL;

	public function __construct($entity = null, $force = null) {
			$this->entity = $entity;
			$this->force = $force;
			$this->blockBreaking = true;
		}

	public function getForce() {
			return $this->force;
		}

	public function setForce($force = null) {
			$this->force = ($force);
			return null;
		}

	public function isBlockBreaking() {
			return $this->blockBreaking;
		}

	public function setBlockBreaking($affectsBlocks = null) {
			$this->blockBreaking = $affectsBlocks;
			return null;
		}

}
