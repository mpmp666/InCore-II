<?php

namespace pocketmine\event\entity;

class EntityCombustByEntityEvent extends \pocketmine\event\entity\EntityCombustEvent {
	protected $combuster = NULL;

	public function __construct($combuster = null, $combustee = null, $duration = null) {
			parent::__construct($combustee, $duration);
			$this->combuster = $combuster;
			return;
		}

	public function getCombuster() {
			return $this->combuster;
		}

}
