<?php

namespace pocketmine\event\entity;

class EntityDamageByBlockEvent extends \pocketmine\event\entity\EntityDamageEvent {
	private $damager = NULL;

	public function __construct($damager = null, $entity = null, $cause = null, $damage = null) {
			$this->damager = $damager;
			parent::__construct($entity, $cause, $damage);
			return;
		}

	public function getDamager() {
			return $this->damager;
		}

}
