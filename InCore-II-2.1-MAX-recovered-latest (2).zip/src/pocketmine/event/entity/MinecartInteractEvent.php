<?php

namespace pocketmine\event\entity;

class MinecartInteractEvent extends \pocketmine\event\entity\EntityEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;

	public function __construct($entity = null, $player = null) {
			$this->entity = $entity;
			$this->player = $player;
		}

}
