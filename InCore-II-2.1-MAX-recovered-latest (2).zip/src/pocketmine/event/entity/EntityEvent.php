<?php

namespace pocketmine\event\entity;

abstract class EntityEvent extends \pocketmine\event\Event {
	protected $entity = NULL;

	public function getEntity() {
			return $this->entity;
		}

}
