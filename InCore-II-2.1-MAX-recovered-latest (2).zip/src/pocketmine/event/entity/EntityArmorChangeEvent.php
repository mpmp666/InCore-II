<?php

namespace pocketmine\event\entity;

class EntityArmorChangeEvent extends \pocketmine\event\entity\EntityEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	private $oldItem = NULL;
	private $newItem = NULL;
	private $slot = NULL;

	public function __construct($entity = null, $oldItem = null, $newItem = null, $slot = null) {
			/* decompiled (structured CF) */
			$this->entity = $entity;
			$this->oldItem = $oldItem;
			$this->newItem = $newItem;
			$this->slot = ($slot);
			return;
		}

	public function getSlot() {
			return $this->slot;
		}

	public function getNewItem() {
			return $this->newItem;
		}

	public function setNewItem($item = null) {
			$this->newItem = $item;
		}

	public function getOldItem() {
			return $this->oldItem;
		}

}
