<?php

namespace pocketmine\event\entity;

class ItemSpawnEvent extends \pocketmine\event\entity\EntityEvent {
	public static $handlerList = NULL;

	public function __construct($item = null) {
			$this->entity = $item;
		}

	public function getEntity() {
			return $this->entity;
		}

}
