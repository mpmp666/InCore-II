<?php

namespace pocketmine\event\entity;

class EntityEatEvent extends \pocketmine\event\entity\EntityEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	private $foodSource = NULL;
	private $foodRestore = NULL;
	private $saturationRestore = NULL;
	private $residue = NULL;
	private $additionalEffects = NULL;

	public function __construct($entity = null, $foodSource = null) {
			/* decompiled (structured CF) */
			$this->entity = $entity;
			$this->foodSource = $foodSource;
			$this->foodRestore = $foodSource->getFoodRestore();
			$this->saturationRestore = $foodSource->getSaturationRestore();
			$this->residue = $foodSource->getResidue();
			$this->additionalEffects = $foodSource->getAdditionalEffects();
			return;
		}

	public function getFoodSource() {
			return $this->foodSource;
		}

	public function getFoodRestore() {
			return $this->foodRestore;
		}

	public function setFoodRestore($foodRestore = null) {
			$this->foodRestore = $foodRestore;
		}

	public function getSaturationRestore() {
			return $this->saturationRestore;
		}

	public function setSaturationRestore($saturationRestore = null) {
			$this->saturationRestore = $saturationRestore;
		}

	public function getResidue() {
			return $this->residue;
		}

	public function setResidue($residue = null) {
			$this->residue = $residue;
		}

	public function getAdditionalEffects() {
			return $this->additionalEffects;
		}

	public function setAdditionalEffects($additionalEffects = null) {
			/* decompiled (structured CF) */
			foreach ($additionalEffects as $effect) {
				if (!($effect instanceof \pocketmine\entity\Effect)) {
					new TypeError($this);
					throw new TypeError($this);
				}
				/* goto */
			}
			$this->additionalEffects = $additionalEffects;
			return null;
		}

}
