<?php

namespace pocketmine\event\entity;

class EntityDespawnEvent extends \pocketmine\event\entity\EntityEvent {
	public static $handlerList = NULL;
	private $entityType = NULL;

	public function __construct($entity = null) {
			$this->entity = $entity;
			$this->entityType = $entity::NETWORK_ID;
			return;
		}

	public function getType() {
			return $this->entityType;
		}

	public function isCreature() {
			return $this->entity instanceof \pocketmine\entity\Creature;
		}

	public function isHuman() {
			return $this->entity instanceof \pocketmine\entity\Human;
		}

	public function isProjectile() {
			return $this->entity instanceof \pocketmine\entity\Projectile;
		}

	public function isVehicle() {
			return $this->entity instanceof \pocketmine\entity\Vehicle;
		}

	public function isItem() {
			return $this->entity instanceof \pocketmine\entity\Item;
		}

}
