<?php

namespace pocketmine\event\entity;

class EntityMoveEvent extends \pocketmine\event\entity\EntityEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	private $pos = NULL;

	public function __construct($entity = null, $pos = null) {
			$this->entity = $entity;
			$this->pos = $pos;
		}

	public function getVector() {
			return $this->pos;
		}

}
