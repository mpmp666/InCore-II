<?php

namespace pocketmine\event\entity;

class EntityEatItemEvent extends \pocketmine\event\entity\EntityEatEvent {
	public function __construct($entity = null, $foodSource = null) {
			parent::__construct($entity, $foodSource);
			return;
		}

	public function getResidue() {
			return parent::getResidue();
		}

	public function setResidue($residue = null) {
			/* decompiled (structured CF) */
			if (!($residue instanceof \pocketmine\item\Item)) {
				new \InvalidArgumentException($this);
				throw new \InvalidArgumentException($this);
			}
			parent::setResidue($residue);
			return null;
		}

}
