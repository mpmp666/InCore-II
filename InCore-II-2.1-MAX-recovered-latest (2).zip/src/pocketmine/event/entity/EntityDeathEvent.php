<?php

namespace pocketmine\event\entity;

class EntityDeathEvent extends \pocketmine\event\entity\EntityEvent {
	public static $handlerList = NULL;
	private $drops = array (
);

	public function __construct($entity = null, $drops = null) {
			$this->entity = $entity;
			$this->drops = $drops;
		}

	public function getEntity() {
			return $this->entity;
		}

	public function getDrops() {
			return $this->drops;
		}

	public function setDrops($drops = null) {
			$this->drops = $drops;
		}

}
