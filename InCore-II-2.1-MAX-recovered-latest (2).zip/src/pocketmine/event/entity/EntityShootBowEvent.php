<?php

namespace pocketmine\event\entity;

class EntityShootBowEvent extends \pocketmine\event\entity\EntityEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	private $bow = NULL;
	private $projectile = NULL;
	private $force = NULL;

	public function __construct($shooter = null, $bow = null, $projectile = null, $force = null) {
			$this->entity = $shooter;
			$this->bow = $bow;
			$this->projectile = $projectile;
			$this->force = $force;
		}

	public function getEntity() {
			return $this->entity;
		}

	public function getBow() {
			return $this->bow;
		}

	public function getProjectile() {
			return $this->projectile;
		}

	public function setProjectile($projectile = null) {
			/* decompiled (structured CF) */
			if (($projectile !== $this->projectile)) {
				if ((count($this->projectile->getViewers()) === 0)) {
					$this->projectile->kill();
					$this->projectile->close();
				}
				$this->projectile = $projectile;
			}
			return null;
		}

	public function getForce() {
			return $this->force;
		}

	public function setForce($force = null) {
			$this->force = $force;
		}

}
