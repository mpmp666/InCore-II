<?php

namespace pocketmine\event\entity;

class EntityDamageByChildEntityEvent extends \pocketmine\event\entity\EntityDamageByEntityEvent {
	private $childEntity = NULL;

	public function __construct($damager = null, $childEntity = null, $entity = null, $cause = null, $damage = null, $knockBack = null) {
			$this->childEntity = $childEntity;
			parent::__construct($damager, $entity, $cause, $damage, $knockBack);
			return;
		}

	public function getChild() {
			return $this->childEntity;
		}

}
