<?php

namespace pocketmine\event\entity;

class CreeperPowerEvent extends \pocketmine\event\entity\EntityEvent implements \pocketmine\event\Cancellable {
	public const CAUSE_SET_ON = 0;
	public const CAUSE_SET_OFF = 1;
	public const CAUSE_LIGHTNING = 2;

	public static $handlerList = NULL;
	private $lightning = NULL;
	private $cause = NULL;

	public function __construct($creeper = null, $lightning = null, $cause = null) {
			$this->entity = $creeper;
			$this->lightning = $lightning;
			$this->cause = $cause;
		}

	public function getLightning() {
			return $this->lightning;
		}

	public function getCause() {
			return $this->cause;
		}

}
