<?php

namespace pocketmine\event\entity;

class EntityMotionEvent extends \pocketmine\event\entity\EntityEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	private $mot = NULL;

	public function __construct($entity = null, $mot = null) {
			$this->entity = $entity;
			$this->mot = $mot;
		}

	public function getVector() {
			return $this->mot;
		}

}
