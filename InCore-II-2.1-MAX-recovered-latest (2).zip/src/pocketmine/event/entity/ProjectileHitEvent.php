<?php

namespace pocketmine\event\entity;

class ProjectileHitEvent extends \pocketmine\event\entity\EntityEvent {
	public static $handlerList = NULL;

	public function __construct($entity = null) {
			$this->entity = $entity;
		}

	public function getEntity() {
			return $this->entity;
		}

}
