<?php

namespace pocketmine\event\entity;

class EntityDamageByEntityEvent extends \pocketmine\event\entity\EntityDamageEvent {
	private $damager = NULL;
	private $knockBack = NULL;

	public function __construct($damager = null, $entity = null, $cause = null, $damage = null, $knockBack = null) {
			/* decompiled (structured CF) */
			$this->damager = $damager;
			$this->knockBack = $knockBack;
			parent::__construct($entity, $cause, $damage);
			$this->addAttackerModifiers($damager);
			return;
		}

	protected function addAttackerModifiers($damager = null) {
			/* decompiled (structured CF) */
			if ($damager->hasEffect(\pocketmine\entity\Effect::STRENGTH)) {
				$this->setDamage((1 + (($damager->getEffect(\pocketmine\entity\Effect::STRENGTH)->getAmplifier() + 1) * 0.3)), self::MODIFIER_STRENGTH);
			}
			if ($damager->hasEffect(\pocketmine\entity\Effect::WEAKNESS)) {
				$eff_level = (1 - (($damager->getEffect(\pocketmine\entity\Effect::WEAKNESS)->getAmplifier() + 1) * 0.2));
				if (($eff_level < 0)) {
					$eff_level = 0;
				}
				$this->setDamage($eff_level, self::MODIFIER_WEAKNESS);
			}
			return null;
		}

	public function getDamager() {
			return $this->damager;
		}

	public function getKnockBack() {
			return $this->knockBack;
		}

	public function setKnockBack($knockBack = null) {
			$this->knockBack = $knockBack;
		}

}
