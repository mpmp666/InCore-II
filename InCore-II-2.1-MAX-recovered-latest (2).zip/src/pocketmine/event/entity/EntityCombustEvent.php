<?php

namespace pocketmine\event\entity;

class EntityCombustEvent extends \pocketmine\event\entity\EntityEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	protected $duration = NULL;

	public function __construct($combustee = null, $duration = null) {
			$this->entity = $combustee;
			$this->duration = $duration;
		}

	public function getDuration() {
			return $this->duration;
		}

	public function setDuration($duration = null) {
			$this->duration = ($duration);
			return null;
		}

}
