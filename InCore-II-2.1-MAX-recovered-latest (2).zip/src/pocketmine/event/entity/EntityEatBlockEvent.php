<?php

namespace pocketmine\event\entity;

class EntityEatBlockEvent extends \pocketmine\event\entity\EntityEatEvent {
	public function __construct($entity = null, $foodSource = null) {
			/* decompiled (structured CF) */
			if (!($foodSource instanceof \pocketmine\block\Block)) {
				new \InvalidArgumentException($this);
				throw new \InvalidArgumentException($this);
			}
			parent::__construct($entity, $foodSource);
			return;
		}

	public function getResidue() {
			return parent::getResidue();
		}

	public function setResidue($residue = null) {
			/* decompiled (structured CF) */
			if (!($residue instanceof \pocketmine\block\Block)) {
				new \InvalidArgumentException($this);
				throw new \InvalidArgumentException($this);
			}
			parent::setResidue($residue);
			return null;
		}

}
