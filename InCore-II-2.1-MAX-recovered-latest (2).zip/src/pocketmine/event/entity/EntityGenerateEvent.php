<?php

namespace pocketmine\event\entity;

class EntityGenerateEvent extends \pocketmine\event\entity\EntityEvent implements \pocketmine\event\Cancellable {
	public const CAUSE_AI_HOLDER = 0;
	public const CAUSE_MOB_SPAWNER = 1;

	public static $handlerList = NULL;
	private $position = NULL;
	private $cause = NULL;
	private $entityType = NULL;

	public function __construct($pos = null, $entityType = null, $cause = null) {
			$this->position = $pos;
			$this->entityType = $entityType;
			$this->cause = $cause;
		}

	public function getPosition() {
			return $this->position;
		}

	public function setPosition($pos = null) {
			$this->position = $pos;
		}

	public function getType() {
			return $this->entityType;
		}

	public function getCause() {
			return $this->cause;
		}

}
