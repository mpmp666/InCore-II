<?php

namespace pocketmine\event\entity;

class EntityTeleportEvent extends \pocketmine\event\entity\EntityEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	private $from = NULL;
	private $to = NULL;

	public function __construct($entity = null, $from = null, $to = null) {
			$this->entity = $entity;
			$this->from = $from;
			$this->to = $to;
		}

	public function getFrom() {
			return $this->from;
		}

	public function setFrom($from = null) {
			$this->from = $from;
		}

	public function getTo() {
			return $this->to;
		}

	public function setTo($to = null) {
			$this->to = $to;
		}

}
