<?php

namespace pocketmine\event\entity;

class ProjectileLaunchEvent extends \pocketmine\event\entity\EntityEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;

	public function __construct($entity = null) {
			$this->entity = $entity;
		}

	public function getEntity() {
			return $this->entity;
		}

}
