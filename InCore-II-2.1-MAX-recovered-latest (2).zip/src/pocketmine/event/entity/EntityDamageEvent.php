<?php

namespace pocketmine\event\entity;

class EntityDamageEvent extends \pocketmine\event\entity\EntityEvent implements \pocketmine\event\Cancellable {
	public const MODIFIER_BASE = 0;
	public const MODIFIER_RESISTANCE = 1;
	public const MODIFIER_ARMOR = 2;
	public const MODIFIER_PROTECTION = 3;
	public const MODIFIER_STRENGTH = 4;
	public const MODIFIER_WEAKNESS = 5;
	public const CAUSE_CONTACT = 0;
	public const CAUSE_ENTITY_ATTACK = 1;
	public const CAUSE_PROJECTILE = 2;
	public const CAUSE_SUFFOCATION = 3;
	public const CAUSE_FALL = 4;
	public const CAUSE_FIRE = 5;
	public const CAUSE_FIRE_TICK = 6;
	public const CAUSE_LAVA = 7;
	public const CAUSE_DROWNING = 8;
	public const CAUSE_BLOCK_EXPLOSION = 9;
	public const CAUSE_ENTITY_EXPLOSION = 10;
	public const CAUSE_VOID = 11;
	public const CAUSE_SUICIDE = 12;
	public const CAUSE_MAGIC = 13;
	public const CAUSE_CUSTOM = 14;
	public const CAUSE_STARVATION = 15;
	public const CAUSE_LIGHTNING = 16;

	public static $handlerList = NULL;
	private $cause = NULL;
	private $modifiers = NULL;
	private $originals = NULL;
	private $use_armors = array (
);

	public function __construct($entity = null, $cause = null, $damage = null) {
			/* decompiled (structured CF) */
			$this->entity = $entity;
			$this->cause = $cause;
			if (is_array($damage)) {
				$this->modifiers = $damage;
			} else {
				$this->modifiers = [$damage];
			}
			$this->originals = $this->modifiers;
			if (!(isset($this->modifiers[self::MODIFIER_BASE]))) {
				new \InvalidArgumentException($this);
				throw new \InvalidArgumentException($this);
			}
			if ((($cause !== self::CAUSE_VOID) && ($cause !== self::CAUSE_SUICIDE))) {
				if ($entity->hasEffect(\pocketmine\entity\Effect::DAMAGE_RESISTANCE)) {
					$RES_level = (1 - (($entity->getEffect(\pocketmine\entity\Effect::DAMAGE_RESISTANCE)->getAmplifier() + 1) * 0.2));
					if (($RES_level < 0)) {
						$RES_level = 0;
					}
					$this->setDamage($RES_level, self::MODIFIER_RESISTANCE);
				}
			}
			if (!(($cause == self::CAUSE_CONTACT))) {
				if (!(($cause == self::CAUSE_ENTITY_ATTACK))) {
					if (!(($cause == self::CAUSE_PROJECTILE))) {
						if (!(($cause == self::CAUSE_FIRE))) {
							if (!(($cause == self::CAUSE_LAVA))) {
								if (!(($cause == self::CAUSE_BLOCK_EXPLOSION))) {
									if (!(($cause == self::CAUSE_ENTITY_EXPLOSION))) {
										if (!(($cause == self::CAUSE_LIGHTNING))) {
											if (!(($cause == self::CAUSE_FALL))) {
												if (!(($cause == self::CAUSE_FIRE_TICK))) {
													if (!(($cause == self::CAUSE_SUFFOCATION))) {
														if (!(($cause == self::CAUSE_DROWNING))) {
															if (!(($cause == self::CAUSE_VOID))) {
																if (!(($cause == self::CAUSE_SUICIDE))) {
																	if (!(($cause == self::CAUSE_MAGIC))) {
																		if (!(($cause == self::CAUSE_CUSTOM))) {
																			if (!(($cause == self::CAUSE_STARVATION))) {
																				/* jump */
																				if ($entity instanceof \pocketmine\Player) {
																					$points = 0;
																					foreach ($entity->getInventory()->getArmorContents() as $i) {
																						if ($i->isArmor()) {
																							$points += $i->getArmorValue();
																						}
																						/* goto */
																					}
																					if (($points !== 0)) {
																						$this->setDamage((1 - ($points * 0.04)), self::MODIFIER_ARMOR);
																						$this->use_armors = $entity->getInventory()->getArmorContents();
																					}
																				}
																			} else {
																				/* jump */
																				/* jump */
																				/* jump */
																				/* jump */
																			}
																			if ((($entity instanceof \pocketmine\Player && ($cause !== self::CAUSE_VOID)) && ($cause !== self::CAUSE_SUICIDE))) {
																				$epf = 0;
																				foreach ($entity->getInventory()->getArmorContents() as $armor) {
																					if (!($armor->isArmor())) {
																						/* goto */
																					}
																					$epf += $armor->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_ARMOR_PROTECTION);
																					if (!(($cause == self::CAUSE_FIRE))) {
																						if (!(($cause == self::CAUSE_FIRE_TICK))) {
																							if (!(($cause == self::CAUSE_LAVA))) {
																								if (!(($cause == self::CAUSE_FALL))) {
																									if (!(($cause == self::CAUSE_BLOCK_EXPLOSION))) {
																										if (!(($cause == self::CAUSE_ENTITY_EXPLOSION))) {
																											if (!(($cause == self::CAUSE_PROJECTILE))) {
																											} else {
																												$epf += ($armor->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_ARMOR_FIRE_PROTECTION) * 2);
																												/* jump */
																												$epf += ($armor->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_ARMOR_FALL_PROTECTION) * 3);
																												/* jump */
																												$epf += ($armor->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_ARMOR_EXPLOSION_PROTECTION) * 2);
																												/* jump */
																												$epf += ($armor->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_ARMOR_PROJECTILE_PROTECTION) * 2);
																												/* jump */
																											}
																											/* goto */
																											if ((0 < $epf)) {
																												$epf = min(25, $epf);
																												$this->setDamage((1 - (min(20, ceil((($epf * mt_rand(50, 100)) / 100))) / 25)), self::MODIFIER_PROTECTION);
																											}
																											return;
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

	public function getCause() {
			return $this->cause;
		}

	public function getOriginalDamage($type = null) {
			/* decompiled (structured CF) */
			if (isset($this->originals[$type])) {
				return $this->originals[$type];
			}
			return 0;
		}

	public function getDamage($type = null) {
			/* decompiled (structured CF) */
			if (isset($this->modifiers[$type])) {
				return $this->modifiers[$type];
			}
			return 0;
		}

	public function setDamage($damage = null, $type = null) {
			$this->modifiers[$type] = $damage;
			return null;
		}

	public function isApplicable($type = null) {
			return isset($this->modifiers[$type]);
		}

	public function getFinalDamage() {
			/* decompiled (structured CF) */
			$damage = 1;
			foreach ($this->modifiers as $type => $d) {
				$damage *= $d;
				/* goto */
			}
			return $damage;
		}

	public function getUsedArmors() {
			return $this->use_armors;
		}

	public function useArmors() {
			/* decompiled (structured CF) */
			if ($this->entity instanceof \pocketmine\Player) {
				if (($this->entity->isSurvival() && $this->entity->isAlive())) {
					foreach ($this->use_armors as $index => $i) {
						if ($i->isArmor()) {
							$i->useOn($i);
							$this->entity->getInventory()->setArmorItem($index, $i);
						}
						/* goto */
					}
				}
				return true;
			}
			return false;
		}

}
