<?php

namespace pocketmine\event\entity;

class EntityExplodeEvent extends \pocketmine\event\entity\EntityEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	protected $position = NULL;
	protected $blocks = NULL;
	protected $yield = NULL;

	public function __construct($entity = null, $position = null, $blocks = null, $yield = null) {
			$this->entity = $entity;
			$this->position = $position;
			$this->blocks = $blocks;
			$this->yield = $yield;
		}

	public function getPosition() {
			return $this->position;
		}

	public function getBlockList() {
			return $this->blocks;
		}

	public function setBlockList($blocks = null) {
			$this->blocks = $blocks;
		}

	public function getYield() {
			return $this->yield;
		}

	public function setYield($yield = null) {
			$this->yield = $yield;
		}

}
