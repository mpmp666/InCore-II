<?php

namespace pocketmine\event\inventory;

class FurnaceSmeltEvent extends \pocketmine\event\block\BlockEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	private $furnace = NULL;
	private $source = NULL;
	private $result = NULL;

	public function __construct($furnace = null, $source = null, $result = null) {
			/* decompiled (structured CF) */
			parent::__construct($furnace->getBlock());
			$this->source = clone $source;
			$this->source->setCount(1);
			$this->result = $result;
			$this->furnace = $furnace;
			return;
		}

	public function getFurnace() {
			return $this->furnace;
		}

	public function getSource() {
			return $this->source;
		}

	public function getResult() {
			return $this->result;
		}

	public function setResult($result = null) {
			$this->result = $result;
		}

}
