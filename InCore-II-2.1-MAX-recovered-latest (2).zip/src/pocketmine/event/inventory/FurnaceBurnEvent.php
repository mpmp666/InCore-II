<?php

namespace pocketmine\event\inventory;

class FurnaceBurnEvent extends \pocketmine\event\block\BlockEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	private $furnace = NULL;
	private $fuel = NULL;
	private $burnTime = NULL;
	private $burning = true;

	public function __construct($furnace = null, $fuel = null, $burnTime = null) {
			/* decompiled (structured CF) */
			parent::__construct($furnace->getBlock());
			$this->fuel = $fuel;
			$this->burnTime = ($burnTime);
			$this->furnace = $furnace;
			return;
		}

	public function getFurnace() {
			return $this->furnace;
		}

	public function getFuel() {
			return $this->fuel;
		}

	public function getBurnTime() {
			return $this->burnTime;
		}

	public function setBurnTime($burnTime = null) {
			$this->burnTime = ($burnTime);
			return null;
		}

	public function isBurning() {
			return $this->burning;
		}

	public function setBurning($burning = null) {
			$this->burning = $burning;
			return null;
		}

}
