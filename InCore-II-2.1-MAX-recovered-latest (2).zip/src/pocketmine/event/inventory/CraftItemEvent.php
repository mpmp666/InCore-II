<?php

namespace pocketmine\event\inventory;

class CraftItemEvent extends \pocketmine\event\Event implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	private $input = array (
);
	private $recipe = NULL;
	private $player = NULL;

	public function __construct($player = null, $input = null, $recipe = null) {
			$this->player = $player;
			$this->input = $input;
			$this->recipe = $recipe;
		}

	public function getInput() {
			/* decompiled (structured CF) */
			$items = ['__array_ptr' => '2aaaac9fc9a0'];
			foreach ($items as $i => $item) {
				$items[$i] = clone $item;
				/* goto */
			}
			return $items;
		}

	public function getRecipe() {
			return $this->recipe;
		}

	public function getPlayer() {
			return $this->player;
		}

}
