<?php

namespace pocketmine\event\inventory;

class InventoryPickupItemEvent extends \pocketmine\event\inventory\InventoryEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	private $item = NULL;

	public function __construct($inventory = null, $item = null) {
			$this->item = $item;
			parent::__construct($inventory);
			return;
		}

	public function getItem() {
			return $this->item;
		}

}
