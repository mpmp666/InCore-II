<?php

namespace pocketmine\event\inventory;

class InventoryCloseEvent extends \pocketmine\event\inventory\InventoryEvent {
	public static $handlerList = NULL;
	private $who = NULL;

	public function __construct($inventory = null, $who = null) {
			$this->who = $who;
			parent::__construct($inventory);
			return;
		}

	public function getPlayer() {
			return $this->who;
		}

}
