<?php

namespace pocketmine\event\inventory;

abstract class InventoryEvent extends \pocketmine\event\Event {
	protected $inventory = NULL;

	public function __construct($inventory = null) {
			$this->inventory = $inventory;
		}

	public function getInventory() {
			return $this->inventory;
		}

	public function getViewers() {
			return $this->inventory->getViewers();
		}

}
