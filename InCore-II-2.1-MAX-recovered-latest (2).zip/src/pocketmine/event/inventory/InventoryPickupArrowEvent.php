<?php

namespace pocketmine\event\inventory;

class InventoryPickupArrowEvent extends \pocketmine\event\inventory\InventoryEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	private $arrow = NULL;

	public function __construct($inventory = null, $arrow = null) {
			$this->arrow = $arrow;
			parent::__construct($inventory);
			return;
		}

	public function getArrow() {
			return $this->arrow;
		}

}
