<?php

namespace pocketmine\event\inventory;

class InventoryTransactionEvent extends \pocketmine\event\Event implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	private $ts = NULL;

	public function __construct($ts = null) {
			$this->ts = $ts;
		}

	public function getTransaction() {
			return $this->ts;
		}

}
