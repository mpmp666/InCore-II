<?php

namespace pocketmine\event;

class HandlerList {
	private $handlers = NULL;
	private $handlerSlots = array (
);
	private static $allLists = array (
);

	public static function bakeAll() {
			/* decompiled (structured CF) */
			foreach (self::$allLists as $h) {
				$h->bake();
				/* goto */
			}
			return null;
		}

	public static function unregisterAll($object = null) {
			/* decompiled (structured CF) */
			if (($object instanceof \pocketmine\event\Listener || $object instanceof \pocketmine\plugin\Plugin)) {
				foreach (self::$allLists as $h) {
					$h->unregister($object);
					/* goto */
				}
			} else {
				foreach (self::$allLists as $h) {
					foreach ($h->handlerSlots as $key => $list) {
						$h->handlerSlots[$key] = ['__array_ptr' => '2aaaac9fc9a0'];
						/* goto */
					}
					$h->handlers = null;
					/* goto */
				}
			}
			return null;
		}

	public function __construct() {
			$this->handlerSlots = [['__array_ptr' => '2aaaac9fc9a0'], ['__array_ptr' => '2aaaac9fc9a0'], ['__array_ptr' => '2aaaac9fc9a0'], ['__array_ptr' => '2aaaac9fc9a0'], ['__array_ptr' => '2aaaac9fc9a0'], ['__array_ptr' => '2aaaac9fc9a0']];
			self::$allLists[] = $this;
			return;
		}

	public function register($listener = null) {
			/* decompiled (structured CF) */
			if ((($listener->getPriority() < \pocketmine\event\EventPriority::MONITOR) || (\pocketmine\event\EventPriority::LOWEST < $listener->getPriority()))) {
				return null;
			}
			if (isset($this->handlerSlots[$listener->getPriority()][spl_object_hash($listener)])) {
				new \InvalidStateException(($this . $listener->getPriority()));
				throw new \InvalidStateException(($this . $listener->getPriority()));
			}
			$this->handlers = null;
			$this->handlerSlots[$listener->getPriority()][spl_object_hash($listener)] = $listener;
		}

	public function registerAll($listeners = null) {
			/* decompiled (structured CF) */
			foreach ($listeners as $listener) {
				$this->register($listener);
				/* goto */
			}
			return null;
		}

	public function unregister($object = null) {
			/* decompiled (structured CF) */
			if (($object instanceof \pocketmine\plugin\Plugin || $object instanceof \pocketmine\event\Listener)) {
				$changed = false;
				foreach ($this->handlerSlots as $priority => $list) {
					foreach ($list as $hash => $listener) {
						if ((($object instanceof \pocketmine\plugin\Plugin && ($object === $listener->getPlugin())) || ($object instanceof \pocketmine\event\Listener && ($object === $listener->getListener())))) {
							$changed = true;
						}
						/* goto */
					}
					/* goto */
				}
				if (($changed === true)) {
					$this->handlers = null;
				}
			} else {
				if ($object instanceof \pocketmine\plugin\RegisteredListener) {
					if (isset($this->handlerSlots[$object->getPriority()][spl_object_hash($object)])) {
						$this->handlers = null;
					}
				}
			}
			return null;
		}

	public function bake() {
			/* decompiled (structured CF) */
			if (($this->handlers !== null)) {
				return null;
			}
			$entries = ['__array_ptr' => '2aaaac9fc9a0'];
			foreach ($this->handlerSlots as $list) {
				foreach ($list as $hash => $listener) {
					$entries[$hash] = $listener;
					/* goto */
				}
				/* goto */
			}
			$this->handlers = $entries;
		}

	public function getRegisteredListeners($plugin = null) {
			/* decompiled (structured CF) */
			if (($plugin !== null)) {
				$listeners = ['__array_ptr' => '2aaaac9fc9a0'];
				foreach ($this->getRegisteredListeners(null) as $hash => $listener) {
					if (($plugin === $listener->getPlugin())) {
						$listeners[$hash] = $plugin;
					}
					/* goto */
				}
				return $listeners;
			} else {
				while ((($handlers = $this->handlers) === null)) {
					$this->bake();
				}
				return $handlers;
			}
		}

	public static function getHandlerLists() {
			return self::$allLists;
		}

}
