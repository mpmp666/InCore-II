<?php

namespace pocketmine\event;

class LevelTimings {
	public $mobSpawn = NULL;
	public $doChunkUnload = NULL;
	public $doPortalForcer = NULL;
	public $doTickPending = NULL;
	public $doTickTiles = NULL;
	public $doVillages = NULL;
	public $doChunkMap = NULL;
	public $doChunkGC = NULL;
	public $doSounds = NULL;
	public $entityTick = NULL;
	public $tileEntityTick = NULL;
	public $tileEntityPending = NULL;
	public $tracker = NULL;
	public $doTick = NULL;
	public $tickEntities = NULL;
	public $syncChunkSendTimer = NULL;
	public $syncChunkSendPrepareTimer = NULL;
	public $syncChunkLoadTimer = NULL;
	public $syncChunkLoadDataTimer = NULL;
	public $syncChunkLoadStructuresTimer = NULL;
	public $syncChunkLoadEntitiesTimer = NULL;
	public $syncChunkLoadTileEntitiesTimer = NULL;
	public $syncChunkLoadTileTicksTimer = NULL;
	public $syncChunkLoadPostTimer = NULL;

	public function __construct($level = null) {
			/* decompiled (structured CF) */
			$name = ($level->getFolderName() . $this);
			new \pocketmine\event\TimingsHandler((($this . $name) . 'mobSpawn'));
			$this->mobSpawn = new \pocketmine\event\TimingsHandler((($this . $name) . 'mobSpawn'));
			new \pocketmine\event\TimingsHandler((($this . $name) . 'doChunkUnload'));
			$this->doChunkUnload = new \pocketmine\event\TimingsHandler((($this . $name) . 'doChunkUnload'));
			new \pocketmine\event\TimingsHandler((($this . $name) . 'doTickPending'));
			$this->doTickPending = new \pocketmine\event\TimingsHandler((($this . $name) . 'doTickPending'));
			new \pocketmine\event\TimingsHandler((($this . $name) . 'doTickTiles'));
			$this->doTickTiles = new \pocketmine\event\TimingsHandler((($this . $name) . 'doTickTiles'));
			new \pocketmine\event\TimingsHandler((($this . $name) . 'doVillages'));
			$this->doVillages = new \pocketmine\event\TimingsHandler((($this . $name) . 'doVillages'));
			new \pocketmine\event\TimingsHandler((($this . $name) . 'doChunkMap'));
			$this->doChunkMap = new \pocketmine\event\TimingsHandler((($this . $name) . 'doChunkMap'));
			new \pocketmine\event\TimingsHandler((($this . $name) . 'doSounds'));
			$this->doSounds = new \pocketmine\event\TimingsHandler((($this . $name) . 'doSounds'));
			new \pocketmine\event\TimingsHandler((($this . $name) . 'doChunkGC'));
			$this->doChunkGC = new \pocketmine\event\TimingsHandler((($this . $name) . 'doChunkGC'));
			new \pocketmine\event\TimingsHandler((($this . $name) . 'doPortalForcer'));
			$this->doPortalForcer = new \pocketmine\event\TimingsHandler((($this . $name) . 'doPortalForcer'));
			new \pocketmine\event\TimingsHandler((($this . $name) . 'entityTick'));
			$this->entityTick = new \pocketmine\event\TimingsHandler((($this . $name) . 'entityTick'));
			new \pocketmine\event\TimingsHandler((($this . $name) . 'tileEntityTick'));
			$this->tileEntityTick = new \pocketmine\event\TimingsHandler((($this . $name) . 'tileEntityTick'));
			new \pocketmine\event\TimingsHandler((($this . $name) . 'tileEntityPending'));
			$this->tileEntityPending = new \pocketmine\event\TimingsHandler((($this . $name) . 'tileEntityPending'));
			new \pocketmine\event\TimingsHandler((($this . $name) . 'syncChunkSend'));
			$this->syncChunkSendTimer = new \pocketmine\event\TimingsHandler((($this . $name) . 'syncChunkSend'));
			new \pocketmine\event\TimingsHandler((($this . $name) . 'syncChunkSendPrepare'));
			$this->syncChunkSendPrepareTimer = new \pocketmine\event\TimingsHandler((($this . $name) . 'syncChunkSendPrepare'));
			new \pocketmine\event\TimingsHandler((($this . $name) . 'syncChunkLoad'));
			$this->syncChunkLoadTimer = new \pocketmine\event\TimingsHandler((($this . $name) . 'syncChunkLoad'));
			new \pocketmine\event\TimingsHandler((($this . $name) . $this));
			$this->syncChunkLoadDataTimer = new \pocketmine\event\TimingsHandler((($this . $name) . $this));
			new \pocketmine\event\TimingsHandler((($this . $name) . $this));
			$this->syncChunkLoadStructuresTimer = new \pocketmine\event\TimingsHandler((($this . $name) . $this));
			new \pocketmine\event\TimingsHandler((($this . $name) . $this));
			$this->syncChunkLoadEntitiesTimer = new \pocketmine\event\TimingsHandler((($this . $name) . $this));
			new \pocketmine\event\TimingsHandler((($this . $name) . $this));
			$this->syncChunkLoadTileEntitiesTimer = new \pocketmine\event\TimingsHandler((($this . $name) . $this));
			new \pocketmine\event\TimingsHandler((($this . $name) . $this));
			$this->syncChunkLoadTileTicksTimer = new \pocketmine\event\TimingsHandler((($this . $name) . $this));
			new \pocketmine\event\TimingsHandler((($this . $name) . $this));
			$this->syncChunkLoadPostTimer = new \pocketmine\event\TimingsHandler((($this . $name) . $this));
			new \pocketmine\event\TimingsHandler(($name . 'tracker'));
			$this->tracker = new \pocketmine\event\TimingsHandler(($name . 'tracker'));
			new \pocketmine\event\TimingsHandler(($name . 'doTick'));
			$this->doTick = new \pocketmine\event\TimingsHandler(($name . 'doTick'));
			new \pocketmine\event\TimingsHandler(($name . 'tickEntities'));
			$this->tickEntities = new \pocketmine\event\TimingsHandler(($name . 'tickEntities'));
			return;
		}

}
