<?php

namespace pocketmine\event;

abstract class EventPriority {
	public const LOWEST = 5;
	public const LOW = 4;
	public const NORMAL = 3;
	public const HIGH = 2;
	public const HIGHEST = 1;
	public const MONITOR = 0;

	public static function fromString($priority = null) {
			/* decompiled (structured CF) */
			/* jump */
			switch (strtoupper(trim(($priority)))) {
				case 'LOWEST':
				return self::LOWEST;
				case 'LOW':
				return self::LOW;
				case 'NORMAL':
				return self::NORMAL;
				case 'HIGH':
				return self::HIGH;
				case 'HIGHEST':
				return self::HIGHEST;
				case 'MONITOR':
				return self::MONITOR;
				new \InvalidArgumentException(($this . $priority));
				throw new \InvalidArgumentException(($this . $priority));
			}
		}

}
