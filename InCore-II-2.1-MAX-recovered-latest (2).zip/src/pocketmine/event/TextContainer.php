<?php

namespace pocketmine\event;

class TextContainer implements \Stringable {
	protected $text = NULL;

	public function __construct($text = null) {
			$this->text = $text;
		}

	public function setText($text = null) {
			$this->text = $text;
		}

	public function getText() {
			return $this->text;
		}

	public function __toString() {
			return $this->getText();
		}

}
