<?php

namespace pocketmine\event\block;

class BlockFormEvent extends \pocketmine\event\block\BlockGrowEvent {
	public static $handlerList = NULL;

	public function __construct($block = null, $newState = null) {
			parent::__construct($block, $newState);
			return;
		}

}
