<?php

namespace pocketmine\event\block;

class BlockBurnEvent extends \pocketmine\event\block\BlockEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;

}
