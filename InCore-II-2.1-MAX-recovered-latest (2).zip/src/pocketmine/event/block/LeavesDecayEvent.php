<?php

namespace pocketmine\event\block;

class LeavesDecayEvent extends \pocketmine\event\block\BlockEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;

	public function __construct($block = null) {
			parent::__construct($block);
			return;
		}

}
