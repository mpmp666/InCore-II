<?php

namespace pocketmine\event\block;

class BlockGrowEvent extends \pocketmine\event\block\BlockEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	private $newState = NULL;

	public function __construct($block = null, $newState = null) {
			parent::__construct($block);
			$this->newState = $newState;
			return;
		}

	public function getNewState() {
			return $this->newState;
		}

}
