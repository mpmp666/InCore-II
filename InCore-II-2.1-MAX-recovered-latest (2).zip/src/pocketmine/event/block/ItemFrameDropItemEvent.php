<?php

namespace pocketmine\event\block;

class ItemFrameDropItemEvent extends \pocketmine\event\block\BlockEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	private $player = NULL;
	private $item = NULL;
	private $itemFrame = NULL;

	public function __construct($player = null, $block = null, $itemFrame = null, $item = null) {
			$this->player = $player;
			$this->block = $block;
			$this->itemFrame = $itemFrame;
			$this->item = $item;
		}

	public function getPlayer() {
			return $this->player;
		}

	public function getItemFrame() {
			return $this->itemFrame;
		}

	public function getItem() {
			return $this->item;
		}

}
