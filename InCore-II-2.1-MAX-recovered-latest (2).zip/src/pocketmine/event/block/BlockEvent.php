<?php

namespace pocketmine\event\block;

abstract class BlockEvent extends \pocketmine\event\Event {
	protected $block = NULL;

	public function __construct($block = null) {
			$this->block = $block;
		}

	public function getBlock() {
			return $this->block;
		}

}
