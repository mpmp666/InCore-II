<?php

namespace pocketmine\event\block;

class BlockSpreadEvent extends \pocketmine\event\block\BlockFormEvent {
	public static $handlerList = NULL;
	private $source = NULL;

	public function __construct($block = null, $source = null, $newState = null) {
			parent::__construct($block, $newState);
			$this->source = $source;
			return;
		}

	public function getSource() {
			return $this->source;
		}

}
