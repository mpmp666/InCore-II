<?php

namespace pocketmine\event\block;

class BlockPlaceEvent extends \pocketmine\event\block\BlockEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	protected $player = NULL;
	protected $item = NULL;
	protected $blockReplace = NULL;
	protected $blockAgainst = NULL;

	public function __construct($player = null, $blockPlace = null, $blockReplace = null, $blockAgainst = null, $item = null) {
			$this->block = $blockPlace;
			$this->blockReplace = $blockReplace;
			$this->blockAgainst = $blockAgainst;
			$this->item = $item;
			$this->player = $player;
		}

	public function getPlayer() {
			return $this->player;
		}

	public function getItem() {
			return $this->item;
		}

	public function getBlockReplaced() {
			return $this->blockReplace;
		}

	public function getBlockAgainst() {
			return $this->blockAgainst;
		}

}
