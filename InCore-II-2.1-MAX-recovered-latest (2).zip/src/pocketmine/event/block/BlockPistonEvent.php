<?php

namespace pocketmine\event\block;

class BlockPistonEvent extends \pocketmine\event\block\BlockEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	protected $direction = NULL;
	protected $blocks = NULL;
	protected $destroyedBlocks = NULL;
	protected $extending = NULL;

	public function __construct($piston = null, $direction = null, $blocks = null, $destroyedBlocks = null, $extending = null) {
			/* decompiled (structured CF) */
			parent::__construct($piston);
			$this->direction = ($direction);
			$this->blocks = $blocks;
			$this->destroyedBlocks = $destroyedBlocks;
			$this->extending = $extending;
			return;
		}

	public function getBlock() {
			return $this->block;
		}

	public function getDirection() {
			return $this->direction;
		}

	public function getBlocks() {
			return $this->blocks;
		}

	public function getDestroyedBlocks() {
			return $this->destroyedBlocks;
		}

	public function isExtending() {
			return $this->extending;
		}

}
