<?php

namespace pocketmine\event\block;

class BlockBreakEvent extends \pocketmine\event\block\BlockEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	protected $player = NULL;
	protected $item = NULL;
	protected $instaBreak = false;
	protected $blockDrops = array (
);

	public function __construct($player = null, $block = null, $item = null, $instaBreak = null) {
			/* decompiled (structured CF) */
			$this->block = $block;
			$this->item = $item;
			$this->player = $player;
			$this->instaBreak = $instaBreak;
			if ($player->isSurvival()) {
			} else {
			}
			$drops = ['__array_ptr' => '2aaaac9fc9a0'];
			if ((($drops != null) && is_numeric($drops[0]))) {
				$this->blockDrops[] = \pocketmine\item\Item::get($drops[0], $drops[1], $drops[2]);
			} else {
				foreach ($drops as $i) {
					$this->blockDrops[] = \pocketmine\item\Item::get($i[0], $i[1], $i[2]);
					/* goto */
				}
			}
			return;
		}

	public function getPlayer() {
			return $this->player;
		}

	public function getItem() {
			return $this->item;
		}

	public function getInstaBreak() {
			return $this->instaBreak;
		}

	public function getDrops() {
			return $this->blockDrops;
		}

	public function setDrops($drops = null) {
			$this->blockDrops = $drops;
		}

	public function setInstaBreak($instaBreak = null) {
			$this->instaBreak = $instaBreak;
			return null;
		}

}
