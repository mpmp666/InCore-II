<?php

namespace pocketmine\event\block;

class SignChangeEvent extends \pocketmine\event\block\BlockEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	private $player = NULL;
	private $lines = array (
);

	public function __construct($theBlock = null, $thePlayer = null, $theLines = null) {
			/* decompiled (structured CF) */
			parent::__construct($theBlock);
			$this->player = $thePlayer;
			$this->lines = $theLines;
			return;
		}

	public function getPlayer() {
			return $this->player;
		}

	public function getLines() {
			return $this->lines;
		}

	public function getLine($index = null) {
			return $this->lines[$index];
		}

	public function setLine($index = null, $line = null) {
			$this->lines[$index] = $line;
			return null;
		}

}
