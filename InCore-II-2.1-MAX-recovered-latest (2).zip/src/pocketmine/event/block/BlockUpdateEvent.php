<?php

namespace pocketmine\event\block;

class BlockUpdateEvent extends \pocketmine\event\block\BlockEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;

}
