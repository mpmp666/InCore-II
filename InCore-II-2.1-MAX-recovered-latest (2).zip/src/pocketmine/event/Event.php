<?php

namespace pocketmine\event;

abstract class Event {
	protected $eventName = NULL;
	private $isCancelled = false;

	public final function getEventName() {
			/* decompiled (structured CF) */
			if (($this->eventName === null)) {
			} else {
			}
			return $this->eventName;
		}

	public function isCancelled() {
			/* decompiled (structured CF) */
			if (!($this instanceof \pocketmine\event\Cancellable)) {
				new \BadMethodCallException($this);
				throw new \BadMethodCallException($this);
			}
			return ($this->isCancelled === true);
		}

	public function setCancelled($value = null) {
			/* decompiled (structured CF) */
			if (!($this instanceof \pocketmine\event\Cancellable)) {
				new \BadMethodCallException($this);
				throw new \BadMethodCallException($this);
			}
			$this->isCancelled = $value;
			return null;
		}

	public function getHandlers() {
			/* decompiled (structured CF) */
			if ((self::$handlerList === null)) {
				new \pocketmine\event\HandlerList();
				self::$handlerList = new \pocketmine\event\HandlerList();
			}
			return self::$handlerList;
		}

}
