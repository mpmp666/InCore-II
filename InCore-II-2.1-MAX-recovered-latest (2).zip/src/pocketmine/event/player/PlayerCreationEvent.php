<?php

namespace pocketmine\event\player;

class PlayerCreationEvent extends \pocketmine\event\Event {
	public static $handlerList = NULL;
	private $interface = NULL;
	private $clientId = NULL;
	private $address = NULL;
	private $port = NULL;
	private $baseClass = NULL;
	private $playerClass = NULL;

	public function __construct($interface = null, $baseClass = null, $playerClass = null, $clientId = null, $address = null, $port = null) {
			/* decompiled (structured CF) */
			$this->interface = $interface;
			$this->clientId = $clientId;
			$this->address = $address;
			$this->port = $port;
			if (!(is_a($baseClass, 'pocketmine\\Player', true))) {
				new \RuntimeException((($this . $this) . 'pocketmine\\Player'));
				throw new \RuntimeException((($this . $this) . 'pocketmine\\Player'));
			}
			$this->baseClass = $baseClass;
			if (!(is_a($playerClass, 'pocketmine\\Player', true))) {
				new \RuntimeException((($this . $this) . 'pocketmine\\Player'));
				throw new \RuntimeException((($this . $this) . 'pocketmine\\Player'));
			}
			$this->playerClass = $playerClass;
			return;
		}

	public function getInterface() {
			return $this->interface;
		}

	public function getAddress() {
			return $this->address;
		}

	public function getPort() {
			return $this->port;
		}

	public function getClientId() {
			return $this->clientId;
		}

	public function getBaseClass() {
			return $this->baseClass;
		}

	public function setBaseClass($class = null) {
			/* decompiled (structured CF) */
			if (!(is_a($class, $this->baseClass, true))) {
				new \RuntimeException((($this . $this) . $this->baseClass));
				throw new \RuntimeException((($this . $this) . $this->baseClass));
			}
			$this->baseClass = $class;
			return null;
		}

	public function getPlayerClass() {
			return $this->playerClass;
		}

	public function setPlayerClass($class = null) {
			/* decompiled (structured CF) */
			if (!(is_a($class, $this->baseClass, true))) {
				new \RuntimeException((($this . $this) . $this->baseClass));
				throw new \RuntimeException((($this . $this) . $this->baseClass));
			}
			$this->playerClass = $class;
			return null;
		}

}
