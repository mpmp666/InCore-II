<?php

namespace pocketmine\event\player;

class PlayerCommandPreprocessEvent extends \pocketmine\event\player\PlayerEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	protected $message = NULL;

	public function __construct($player = null, $message = null) {
			$this->player = $player;
			$this->message = $message;
		}

	public function getMessage() {
			return $this->message;
		}

	public function setMessage($message = null) {
			$this->message = $message;
		}

	public function setPlayer($player = null) {
			$this->player = $player;
		}

}
