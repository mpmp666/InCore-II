<?php

namespace pocketmine\event\player;

class PlayerInteractEvent extends \pocketmine\event\player\PlayerEvent implements \pocketmine\event\Cancellable {
	public const LEFT_CLICK_BLOCK = 0;
	public const RIGHT_CLICK_BLOCK = 1;
	public const LEFT_CLICK_AIR = 2;
	public const RIGHT_CLICK_AIR = 3;
	public const PHYSICAL = 4;

	public static $handlerList = NULL;
	protected $blockTouched = NULL;
	protected $touchVector = NULL;
	protected $blockFace = NULL;
	protected $item = NULL;
	protected $action = NULL;

	public function __construct($player = null, $item = null, $block = null, $face = null, $action = null) {
			/* decompiled (structured CF) */
			if ($block instanceof \pocketmine\block\Block) {
				$this->blockTouched = $block;
				new \pocketmine\math\Vector3(0, 0, 0);
				$this->touchVector = new \pocketmine\math\Vector3(0, 0, 0);
			} else {
				$this->touchVector = $block;
				new \pocketmine\level\Position(0, 0, 0, $player->level);
				$this->blockTouched = \pocketmine\block\Block::get(0, 0, new \pocketmine\level\Position(0, 0, 0, $player->level));
			}
			$this->player = $player;
			$this->item = $item;
			$this->blockFace = ($face);
			$this->action = ($action);
			return;
		}

	public function getAction() {
			return $this->action;
		}

	public function getItem() {
			return $this->item;
		}

	public function getBlock() {
			return $this->blockTouched;
		}

	public function getTouchVector() {
			return $this->touchVector;
		}

	public function getFace() {
			return $this->blockFace;
		}

}
