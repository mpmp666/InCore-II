<?php

namespace pocketmine\event\player;

class PlayerItemHeldEvent extends \pocketmine\event\player\PlayerEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	private $item = NULL;
	private $slot = NULL;
	private $inventorySlot = NULL;

	public function __construct($player = null, $item = null, $inventorySlot = null, $slot = null) {
			/* decompiled (structured CF) */
			$this->player = $player;
			$this->item = $item;
			$this->inventorySlot = ($inventorySlot);
			$this->slot = ($slot);
			return;
		}

	public function getSlot() {
			return $this->slot;
		}

	public function getInventorySlot() {
			return $this->inventorySlot;
		}

	public function getItem() {
			return $this->item;
		}

}
