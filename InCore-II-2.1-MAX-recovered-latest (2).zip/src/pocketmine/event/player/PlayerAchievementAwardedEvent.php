<?php

namespace pocketmine\event\player;

class PlayerAchievementAwardedEvent extends \pocketmine\event\player\PlayerEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	protected $achievement = NULL;

	public function __construct($player = null, $achievementId = null) {
			$this->player = $player;
			$this->achievement = $achievementId;
		}

	public function getAchievement() {
			return $this->achievement;
		}

}
