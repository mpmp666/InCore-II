<?php

namespace pocketmine\event\player;

abstract class PlayerBucketEvent extends \pocketmine\event\player\PlayerEvent implements \pocketmine\event\Cancellable {
	private $blockClicked = NULL;
	private $blockFace = NULL;
	private $bucket = NULL;
	private $item = NULL;

	public function __construct($who = null, $blockClicked = null, $blockFace = null, $bucket = null, $itemInHand = null) {
			/* decompiled (structured CF) */
			$this->player = $who;
			$this->blockClicked = $blockClicked;
			$this->blockFace = ($blockFace);
			$this->item = $itemInHand;
			$this->bucket = $bucket;
			return;
		}

	public function getBucket() {
			return $this->bucket;
		}

	public function getItem() {
			return $this->item;
		}

	public function setItem($item = null) {
			$this->item = $item;
		}

	public function getBlockClicked() {
			return $this->blockClicked;
		}

	public function getBlockFace() {
			return $this->blockFace;
		}

}
