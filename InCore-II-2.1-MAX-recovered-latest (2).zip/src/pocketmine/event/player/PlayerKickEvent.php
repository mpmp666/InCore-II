<?php

namespace pocketmine\event\player;

class PlayerKickEvent extends \pocketmine\event\player\PlayerEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	protected $quitMessage = NULL;
	protected $reason = NULL;

	public function __construct($player = null, $reason = null, $quitMessage = null) {
			$this->player = $player;
			$this->quitMessage = $quitMessage;
			$this->reason = $reason;
		}

	public function getReason() {
			return $this->reason;
		}

	public function setQuitMessage($quitMessage = null) {
			$this->quitMessage = $quitMessage;
		}

	public function getQuitMessage() {
			return $this->quitMessage;
		}

}
