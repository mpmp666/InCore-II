<?php

namespace pocketmine\event\player;

class PlayerDeathEvent extends \pocketmine\event\entity\EntityDeathEvent {
	public static $handlerList = NULL;
	private $deathMessage = NULL;
	private $keepInventory = false;
	private $keepExperience = false;

	public function __construct($entity = null, $drops = null, $deathMessage = null) {
			parent::__construct($entity, $drops);
			$this->deathMessage = $deathMessage;
			return;
		}

	public function getEntity() {
			return $this->entity;
		}

	public function getPlayer() {
			return $this->entity;
		}

	public function getDeathMessage() {
			return $this->deathMessage;
		}

	public function setDeathMessage($deathMessage = null) {
			$this->deathMessage = $deathMessage;
		}

	public function getKeepInventory() {
			return $this->keepInventory;
		}

	public function setKeepInventory($keepInventory = null) {
			$this->keepInventory = $keepInventory;
		}

	public function getKeepExperience() {
			return $this->keepExperience;
		}

	public function setKeepExperience($keepExperience = null) {
			$this->keepExperience = $keepExperience;
		}

}
