<?php

namespace pocketmine\event\player;

abstract class PlayerEvent extends \pocketmine\event\Event {
	protected $player = NULL;

	public function getPlayer() {
			return $this->player;
		}

}
