<?php

namespace pocketmine\event\player;

class PlayerExhaustEvent extends \pocketmine\event\player\PlayerEvent implements \pocketmine\event\Cancellable {
	public const CAUSE_ATTACK = 1;
	public const CAUSE_DAMAGE = 2;
	public const CAUSE_MINING = 3;
	public const CAUSE_HEALTH_REGEN = 4;
	public const CAUSE_POTION = 5;
	public const CAUSE_WALKING = 6;
	public const CAUSE_SNEAKING = 7;
	public const CAUSE_SWIMMING = 8;
	public const CAUSE_JUMPING = 10;
	public const CAUSE_CUSTOM = 11;
	public const CAUSE_FLAG_SPRINT = 65536;

	public static $handlerList = NULL;
	private $amount = NULL;

	public function __construct($human = null, $amount = null, $cause = null) {
			$this->player = $human;
			$this->amount = $amount;
		}

	public function getPlayer() {
			return $this->player;
		}

	public function getAmount() {
			return $this->amount;
		}

	public function setAmount($amount = null) {
			$this->amount = $amount;
		}

}
