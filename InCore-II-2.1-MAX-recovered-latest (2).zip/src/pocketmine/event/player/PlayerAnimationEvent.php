<?php

namespace pocketmine\event\player;

class PlayerAnimationEvent extends \pocketmine\event\player\PlayerEvent implements \pocketmine\event\Cancellable {
	public const ARM_SWING = 1;

	public static $handlerList = NULL;
	private $animationType = NULL;

	public function __construct($player = null, $animation = null) {
			$this->player = $player;
			$this->animationType = $animation;
		}

	public function getAnimationType() {
			return $this->animationType;
		}

}
