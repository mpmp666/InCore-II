<?php

namespace pocketmine\event\player;

class PlayerJoinEvent extends \pocketmine\event\player\PlayerEvent {
	public static $handlerList = NULL;
	protected $joinMessage = NULL;

	public function __construct($player = null, $joinMessage = null) {
			/* decompiled (structured CF) */
			$this->player = $player;
			$this->joinMessage = $joinMessage;
			if (($this->getPlayer()->isOp() && $this->getPlayer()->getServer()->getConfigString('adminjoin'))) {
				$name = $this->getPlayer()->getDisplayName();
				$message = (($this . $name) . $this);
				$this->getPlayer()->getServer()->broadcastMessage($message);
				$this->joinMessage = '';
			}
			return;
		}

	public function setJoinMessage($joinMessage = null) {
			$this->joinMessage = $joinMessage;
		}

	public function getJoinMessage() {
			return $this->joinMessage;
		}

}
