<?php

namespace pocketmine\event\player;

class PlayerExperienceChangeEvent extends \pocketmine\event\player\PlayerEvent implements \pocketmine\event\Cancellable {
	public const ADD_EXPERIENCE = 0;
	public const SET_EXPERIENCE = 1;

	public static $handlerList = NULL;
	public $exp = NULL;
	public $expLevel = NULL;
	public $action = NULL;

	public function __construct($player = null, $exp = null, $expLevel = null, $action = null) {
			$this->exp = $exp;
			$this->expLevel = $expLevel;
			$this->action = $action;
		}

	public function getAction() {
			return $this->action;
		}

	public function getExp() {
			return $this->exp;
		}

	public function getExpLevel() {
			return $this->expLevel;
		}

	public function setExp($exp = null) {
			$this->exp = $exp;
		}

	public function setExpLevel($level = null) {
			$this->expLevel = $level;
		}

}
