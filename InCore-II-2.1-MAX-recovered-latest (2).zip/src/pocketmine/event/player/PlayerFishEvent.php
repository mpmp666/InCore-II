<?php

namespace pocketmine\event\player;

class PlayerFishEvent extends \pocketmine\event\player\PlayerEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	private $item = NULL;
	private $hook = NULL;

	public function __construct($player = null, $item = null, $fishingHook = null) {
			$this->player = $player;
			$this->item = $item;
			$this->hook = $fishingHook;
		}

	public function getItem() {
			return clone $this->item;
		}

	public function setItem($item = null) {
			$this->item = clone $item;
		}

	public function getHook() {
			return $this->hook;
		}

}
