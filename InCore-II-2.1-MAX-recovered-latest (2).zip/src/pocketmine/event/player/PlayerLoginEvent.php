<?php

namespace pocketmine\event\player;

class PlayerLoginEvent extends \pocketmine\event\player\PlayerEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	protected $kickMessage = NULL;

	public function __construct($player = null, $kickMessage = null) {
			$this->player = $player;
			$this->kickMessage = $kickMessage;
		}

	public function setKickMessage($kickMessage = null) {
			$this->kickMessage = $kickMessage;
		}

	public function getKickMessage() {
			return $this->kickMessage;
		}

}
