<?php

namespace pocketmine\event\player;

class PlayerChatEvent extends \pocketmine\event\player\PlayerEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	protected $message = NULL;
	protected $format = NULL;
	protected $recipients = array (
);

	public function __construct($player = null, $message = null, $format = null, $recipients = null) {
			/* decompiled (structured CF) */
			$this->player = $player;
			$this->message = $message;
			$i = 0;
			while ((($pos = strpos($format, '%s')) !== false)) {
				$format = ((substr($format, 0, $pos) . ('{%' . '}')) . substr($format, ($pos + 2)));
				$i++;
			}
			$this->format = $format;
			if (($recipients === null)) {
				$this->recipients = \pocketmine\Server::getInstance()->getPluginManager()->getPermissionSubscriptions(\pocketmine\Server::BROADCAST_CHANNEL_USERS);
			} else {
				$this->recipients = $recipients;
			}
			return;
		}

	public function getMessage() {
			return $this->message;
		}

	public function setMessage($message = null) {
			$this->message = $message;
		}

	public function setPlayer($player = null) {
			$this->player = $player;
		}

	public function getFormat() {
			return $this->format;
		}

	public function setFormat($format = null) {
			/* decompiled (structured CF) */
			$i = 0;
			while ((($pos = strpos($format, '%s')) !== false)) {
				$format = ((substr($format, 0, $pos) . ('{%' . '}')) . substr($format, ($pos + 2)));
				$i++;
			}
			$this->format = $format;
			return null;
		}

	public function getRecipients() {
			return $this->recipients;
		}

	public function setRecipients($recipients = null) {
			$this->recipients = $recipients;
		}

}
