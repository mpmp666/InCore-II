<?php

namespace pocketmine\event\player;

class PlayerBucketEmptyEvent extends \pocketmine\event\player\PlayerBucketEvent {
	public static $handlerList = NULL;

	public function __construct($who = null, $blockClicked = null, $blockFace = null, $bucket = null, $itemInHand = null) {
			parent::__construct($who, $blockClicked, $blockFace, $bucket, $itemInHand);
			return;
		}

}
