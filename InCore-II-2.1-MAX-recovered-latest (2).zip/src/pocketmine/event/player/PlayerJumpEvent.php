<?php

namespace pocketmine\event\player;

class PlayerJumpEvent extends \pocketmine\event\player\PlayerEvent {
	public static $handlerList = NULL;

	public function __construct($player = null) {
			$this->player = $player;
		}

}
