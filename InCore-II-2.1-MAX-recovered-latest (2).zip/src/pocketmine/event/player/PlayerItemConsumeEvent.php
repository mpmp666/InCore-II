<?php

namespace pocketmine\event\player;

class PlayerItemConsumeEvent extends \pocketmine\event\player\PlayerEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	private $item = NULL;

	public function __construct($player = null, $item = null) {
			$this->player = $player;
			$this->item = $item;
		}

	public function getItem() {
			return clone $this->item;
		}

}
