<?php

namespace pocketmine\event\player;

class PlayerGameModeChangeEvent extends \pocketmine\event\player\PlayerEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	protected $gamemode = NULL;

	public function __construct($player = null, $newGamemode = null) {
			$this->player = $player;
			$this->gamemode = ($newGamemode);
			return;
		}

	public function getNewGamemode() {
			return $this->gamemode;
		}

}
