<?php

namespace pocketmine\event\player;

class PlayerDropItemEvent extends \pocketmine\event\player\PlayerEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	private $drop = NULL;

	public function __construct($player = null, $drop = null) {
			$this->player = $player;
			$this->drop = $drop;
		}

	public function getItem() {
			return $this->drop;
		}

}
