<?php

namespace pocketmine\event\player;

class PlayerHungerChangeEvent extends \pocketmine\event\player\PlayerEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	public $data = NULL;

	public function __construct($player = null, $data = null) {
			$this->data = $data;
			$this->player = $player;
		}

	public function getData() {
			return $this->data;
		}

	public function setData($data = null) {
			$this->data = $data;
		}

}
