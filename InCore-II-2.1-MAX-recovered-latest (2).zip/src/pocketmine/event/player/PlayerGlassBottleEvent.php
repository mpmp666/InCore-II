<?php

namespace pocketmine\event\player;

class PlayerGlassBottleEvent extends \pocketmine\event\player\PlayerEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	private $target = NULL;
	private $item = NULL;

	public function __construct($Player = null, $target = null, $itemInHand = null) {
			$this->player = $Player;
			$this->target = $target;
			$this->item = $itemInHand;
		}

	public function getItem() {
			return $this->item;
		}

	public function setItem($item = null) {
			$this->item = $item;
		}

	public function getBlock() {
			return $this->target;
		}

}
