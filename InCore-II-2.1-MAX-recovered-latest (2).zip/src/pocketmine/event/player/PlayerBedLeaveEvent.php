<?php

namespace pocketmine\event\player;

class PlayerBedLeaveEvent extends \pocketmine\event\player\PlayerEvent {
	public static $handlerList = NULL;
	private $bed = NULL;

	public function __construct($player = null, $bed = null) {
			$this->player = $player;
			$this->bed = $bed;
		}

	public function getBed() {
			return $this->bed;
		}

}
