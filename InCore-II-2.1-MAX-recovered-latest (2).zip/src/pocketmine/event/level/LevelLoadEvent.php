<?php

namespace pocketmine\event\level;

class LevelLoadEvent extends \pocketmine\event\level\LevelEvent {
	public static $handlerList = NULL;

}
