<?php

namespace pocketmine\event\level;

class ChunkUnloadEvent extends \pocketmine\event\level\ChunkEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;

}
