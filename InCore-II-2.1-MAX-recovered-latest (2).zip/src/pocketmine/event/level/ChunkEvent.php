<?php

namespace pocketmine\event\level;

abstract class ChunkEvent extends \pocketmine\event\level\LevelEvent {
	private $chunk = NULL;

	public function __construct($chunk = null) {
			parent::__construct($chunk->getProvider()->getLevel());
			$this->chunk = $chunk;
			return;
		}

	public function getChunk() {
			return $this->chunk;
		}

}
