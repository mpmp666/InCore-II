<?php

namespace pocketmine\event\level;

abstract class LevelEvent extends \pocketmine\event\Event {
	private $level = NULL;

	public function __construct($level = null) {
			$this->level = $level;
		}

	public function getLevel() {
			return $this->level;
		}

}
