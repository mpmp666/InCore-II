<?php

namespace pocketmine\event\level;

class LevelUnloadEvent extends \pocketmine\event\level\LevelEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;

}
