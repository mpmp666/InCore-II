<?php

namespace pocketmine\event\level;

class SpawnChangeEvent extends \pocketmine\event\level\LevelEvent {
	public static $handlerList = NULL;
	private $previousSpawn = NULL;

	public function __construct($level = null, $previousSpawn = null) {
			parent::__construct($level);
			$this->previousSpawn = $previousSpawn;
			return;
		}

	public function getPreviousSpawn() {
			return $this->previousSpawn;
		}

}
