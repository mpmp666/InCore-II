<?php

namespace pocketmine\event\level;

class LevelInitEvent extends \pocketmine\event\level\LevelEvent {
	public static $handlerList = NULL;

}
