<?php

namespace pocketmine\event\level;

class ChunkLoadEvent extends \pocketmine\event\level\ChunkEvent {
	public static $handlerList = NULL;
	private $newChunk = NULL;

	public function __construct($chunk = null, $newChunk = null) {
			parent::__construct($chunk);
			$this->newChunk = $newChunk;
			return;
		}

	public function isNewChunk() {
			return $this->newChunk;
		}

}
