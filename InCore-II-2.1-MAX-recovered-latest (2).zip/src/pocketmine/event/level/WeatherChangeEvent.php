<?php

namespace pocketmine\event\level;

class WeatherChangeEvent extends \pocketmine\event\level\LevelEvent implements \pocketmine\event\Cancellable {
	public static $handlerList = NULL;
	private $weather = NULL;
	private $duration = NULL;

	public function __construct($level = null, $weather = null, $duration = null) {
			/* decompiled (structured CF) */
			parent::__construct($level);
			$this->weather = $weather;
			$this->duration = $duration;
			return;
		}

	public function getWeather() {
			return $this->weather;
		}

	public function setWeather($weather = null) {
			$this->weather = $weather;
		}

	public function getDuration() {
			return $this->duration;
		}

	public function setDuration($duration = null) {
			$this->duration = $duration;
		}

}
