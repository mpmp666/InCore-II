<?php

namespace pocketmine\event\level;

class ChunkPopulateEvent extends \pocketmine\event\level\ChunkEvent {
	public static $handlerList = NULL;

}
