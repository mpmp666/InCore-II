<?php

namespace pocketmine\event\level;

class LevelSaveEvent extends \pocketmine\event\level\LevelEvent {
	public static $handlerList = NULL;

}
