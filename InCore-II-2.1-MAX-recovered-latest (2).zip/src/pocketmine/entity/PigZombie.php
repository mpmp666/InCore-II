<?php

namespace pocketmine\entity;

class PigZombie extends \pocketmine\entity\Monster {
	public const NETWORK_ID = 36;

	public $width = 0.6;
	public $length = 0.6;
	public $height = 1.8;
	public $drag = 0.2;
	public $gravity = 0.3;
	public $dropExp = array (
  0 => 5,
  1 => 5,
);
	private $hurt = 10;
	protected $weapon = NULL;

	public function getName() {
			return 'PigZombie';
		}

	public function initEntity() {
			/* decompiled (structured CF) */
			$this->setMaxHealth(20);
			new \pocketmine\entity\behavior\attackEnemyBehavior($this, ['__array_ptr' => '2aaaadd5d508'], true);
			$this->addBehavior(new \pocketmine\entity\behavior\attackEnemyBehavior($this, ['__array_ptr' => '2aaaadd5d508'], true));
			parent::initEntity();
			$equipment = \pocketmine\entity\VanillaMobEquipment::generatePigZombieEquipment($this->server->getDifficulty());
			$this->weapon = $equipment['weapon'];
			return null;
		}

	public function usesPm1eGroundAi() {
			return true;
		}

	public function getHurt() {
			return $this->hurt;
		}

	public function setHurt($hurt = null) {
			$this->hurt = $hurt;
		}

	public function getWeapon() {
			/* decompiled (structured CF) */
			if ($this->weapon instanceof \pocketmine\item\Item) {
			} else {
			}
			return \pocketmine\item\Item::get(\pocketmine\item\Item::GOLD_SWORD, 0, 1);
		}

	protected function handlesLootingDrops() {
			return true;
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->eid = $this->getId();
			$pk->type = 36;
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->yaw = $this->yaw;
			$pk->pitch = $this->pitch;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			new \pocketmine\network\protocol\MobEquipmentPacket();
			$pk = new \pocketmine\network\protocol\MobEquipmentPacket();
			$pk->eid = $this->getId();
			$pk->item = $this->getWeapon();
			$pk->slot = 0;
			$pk->selectedSlot = 0;
			$player->dataPacket($pk);
			return null;
		}

	public function getDrops() {
			/* decompiled (structured CF) */
			$looting = $this->getLastDamageLootingLevel();
			$drops = [\pocketmine\item\Item::get(\pocketmine\item\Item::ROTTEN_FLESH, 0, mt_rand(0, 1)), \pocketmine\item\Item::get(\pocketmine\item\Item::GOLD_NUGGET, 0, mt_rand(0, 1))];
			$drops = \pocketmine\entity\VanillaMobEquipment::applyLootingToCommonDrops($drops, $looting);
			if ((mt_rand(1, 1000) <= \pocketmine\entity\VanillaMobEquipment::rareDropChance($looting))) {
				$drops[] = \pocketmine\item\Item::get(\pocketmine\item\Item::GOLD_INGOT, 0, 1);
			}
			foreach (\pocketmine\entity\VanillaMobEquipment::maybeDropEquipment(['__array_ptr' => '2aaaac9fc9a0'], $this->getWeapon(), $looting) as $drop) {
				$drops[] = $drop;
				/* goto */
			}
			return $drops;
		}

}
