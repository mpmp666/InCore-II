<?php

namespace pocketmine\entity;

class Bat extends \pocketmine\entity\FlyingAnimal {
	public const NETWORK_ID = 19;
	public const DATA_IS_RESTING = 16;

	public $width = 0.6;
	public $length = 0.6;
	public $height = 0.6;
	public $flySpeed = 0.8;
	public $switchDirectionTicks = 100;

	public function getName() {
			return 'Bat';
		}

	public function initEntity() {
			$this->setMaxHealth(6);
			parent::initEntity();
			return null;
		}

	public function __construct($chunk = null, $nbt = null) {
			/* decompiled (structured CF) */
			if (!(isset($nbt->isResting))) {
				new \pocketmine\nbt\tag\ByteTag('isResting', 0);
				$nbt->isResting = new \pocketmine\nbt\tag\ByteTag('isResting', 0);
			}
			parent::__construct($chunk, $nbt);
			$this->setDataProperty(self::DATA_IS_RESTING, self::DATA_TYPE_BYTE, $this->isResting());
			return;
		}

	public function isResting() {
			return ($this->namedtag['isResting']);
		}

	public function setResting($resting = null) {
			/* decompiled (structured CF) */
			if ($resting) {
			} else {
			}
			new \pocketmine\nbt\tag\ByteTag('isResting', 0);
			$this->namedtag->isResting = new \pocketmine\nbt\tag\ByteTag('isResting', 0);
			return null;
		}

	public function onUpdate($currentTick = null) {
			/* decompiled (structured CF) */
			if ((12000 < $this->age)) {
				$this->kill();
			}
			return parent::onUpdate($currentTick);
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->eid = $this->getId();
			$pk->type = 19;
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->yaw = $this->yaw;
			$pk->pitch = $this->pitch;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

}
