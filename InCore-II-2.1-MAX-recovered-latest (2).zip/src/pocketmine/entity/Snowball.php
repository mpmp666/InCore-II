<?php

namespace pocketmine\entity;

class Snowball extends \pocketmine\entity\Projectile {
	public const NETWORK_ID = 81;

	public $width = 0.25;
	public $length = 0.25;
	public $height = 0.25;
	protected $gravity = 0.03;
	protected $drag = 0.01;

	public function __construct($chunk = null, $nbt = null, $shootingEntity = null) {
			parent::__construct($chunk, $nbt, $shootingEntity);
			return;
		}

	public function isEnderPearlSnowball() {
			return (isset($this->namedtag->EnderPearlSnowball) && (($this->namedtag['EnderPearlSnowball']) === 1));
		}

	public function onUpdate($currentTick = null) {
			/* decompiled (structured CF) */
			if ($this->closed) {
				return false;
			}
			$this->timings->startTiming();
			$hasUpdate = parent::onUpdate($currentTick);
			if (((1200 < $this->age) || $this->isCollided)) {
				if (($this->isCollided && $this->isEnderPearlSnowball())) {
					$this->teleportShooter();
				}
				$this->kill();
				$hasUpdate = true;
			}
			$this->timings->stopTiming();
			return $hasUpdate;
		}

	protected function onHitEntity($entityHit = null) {
			/* decompiled (structured CF) */
			if ($this->isEnderPearlSnowball()) {
				$this->teleportShooter();
				$this->kill();
				return true;
			}
			return false;
		}

	protected function teleportShooter() {
			/* decompiled (structured CF) */
			if (((!($this->shootingEntity instanceof \pocketmine\Player) || $this->shootingEntity->closed) || !($this->shootingEntity->isAlive()))) {
				return false;
			}
			new \pocketmine\math\Vector3($this->shootingEntity->x, $this->shootingEntity->y, $this->shootingEntity->z);
			$from = new \pocketmine\math\Vector3($this->shootingEntity->x, $this->shootingEntity->y, $this->shootingEntity->z);
			if ($this->shootingEntity->teleport($this)) {
				new \pocketmine\level\sound\EndermanTeleportSound($from);
				$this->getLevel()->addSound(new \pocketmine\level\sound\EndermanTeleportSound($from));
				new \pocketmine\level\sound\EndermanTeleportSound($this);
				$this->getLevel()->addSound(new \pocketmine\level\sound\EndermanTeleportSound($this));
				return true;
			}
			return false;
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->type = 81;
			$pk->eid = $this->getId();
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

}
