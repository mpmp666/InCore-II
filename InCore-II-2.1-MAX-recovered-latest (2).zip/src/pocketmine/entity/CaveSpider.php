<?php

namespace pocketmine\entity;

class CaveSpider extends \pocketmine\entity\Monster {
	public const NETWORK_ID = 40;

	public $width = 1;
	public $length = 1;
	public $height = 0.5;
	public $dropExp = array (
  0 => 5,
  1 => 5,
);
	private $hurt = 4;

	public function getName() {
			return;
		}

	public function initEntity() {
			/* decompiled (structured CF) */
			$this->setMaxHealth(12);
			new \pocketmine\entity\behavior\attackEnemyBehavior($this, ['__array_ptr' => '2aaaadd5d508'], true);
			$this->addBehavior(new \pocketmine\entity\behavior\attackEnemyBehavior($this, ['__array_ptr' => '2aaaadd5d508'], true));
			parent::initEntity();
			return null;
		}

	public function usesPm1eGroundAi() {
			return true;
		}

	public function getHurt() {
			return $this->hurt;
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->eid = $this->getId();
			$pk->type = 40;
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->yaw = $this->yaw;
			$pk->pitch = $this->pitch;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

	public function getDrops() {
			/* decompiled (structured CF) */
			$drops = ['__array_ptr' => '2aaaac9fc9a0'];
			if ((mt_rand(0, 2) < 1)) {
				$drops[] = \pocketmine\item\Item::get(\pocketmine\item\Item::SPIDER_EYE, 0, 1);
			} else {
				$drops[] = \pocketmine\item\Item::get(\pocketmine\item\Item::STRING, 0, 1);
			}
			return $drops;
		}

}
