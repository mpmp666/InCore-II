<?php

namespace pocketmine\entity;

class Enderman extends \pocketmine\entity\Monster {
	public const NETWORK_ID = 38;

	public $width = 0.3;
	public $length = 0.9;
	public $height = 1.8;
	public $dropExp = array (
  0 => 5,
  1 => 5,
);
	private $hurt = 7;

	public function initEntity() {
			/* decompiled (structured CF) */
			if (!(isset($this->namedtag->carriedData))) {
				new \pocketmine\nbt\tag\ShortTag('carriedData', 0);
				$this->namedtag->carriedData = new \pocketmine\nbt\tag\ShortTag('carriedData', 0);
				new \pocketmine\nbt\tag\ShortTag('carried', 0);
				$this->namedtag->carried = new \pocketmine\nbt\tag\ShortTag('carried', 0);
			}
			new \pocketmine\entity\behavior\attackEnemyBehavior($this, ['__array_ptr' => '2aaaac9fc9a0'], false);
			$this->addBehavior(new \pocketmine\entity\behavior\attackEnemyBehavior($this, ['__array_ptr' => '2aaaac9fc9a0'], false));
			parent::initEntity();
			$this->setTremble(false);
			return null;
		}

	public function usesPm1eGroundAi() {
			return true;
		}

	public function getName() {
			return 'Enderman';
		}

	public function getHurt() {
			return $this->hurt;
		}

	public function setHurt($hurt = null) {
			$this->hurt = $hurt;
		}

	public function setTremble($setting = null) {
			/* decompiled (structured CF) */
			if ($setting) {
			} else {
			}
			$this->setDataProperty(self::DATA_ENDERMAN_TREMBLE, self::DATA_TYPE_BYTE, 0);
			return null;
		}

	public function setBlockInHand($id = null, $meta = null) {
			/* decompiled (structured CF) */
			$this->setDataProperty(self::DATA_ENDERMAN_HELD_ITEM_ID, self::DATA_TYPE_SHORT, $id);
			$this->setDataProperty(self::DATA_ENDERMAN_HELD_ITEM_DAMAGE, self::DATA_TYPE_SHORT, $meta);
			new \pocketmine\nbt\tag\ShortTag('carriedData', $id);
			$this->namedtag->carriedData = new \pocketmine\nbt\tag\ShortTag('carriedData', $id);
			new \pocketmine\nbt\tag\ShortTag('carried', $meta);
			$this->namedtag->carried = new \pocketmine\nbt\tag\ShortTag('carried', $meta);
			return null;
		}

	public function getBlockInHand($id = null, $meta = null) {
			$id = $this->namedtag['carriedData'];
			$meta = $this->namedtag['carried'];
			return null;
		}

	public function entityBaseTick($tickDiff = null) {
			/* decompiled (structured CF) */
			$hasUpdate = parent::entityBaseTick($tickDiff);
			if ((($this->isAlive() && !($this->closed)) && $this->isEndermanWet())) {
				$hasUpdate = true;
				new \pocketmine\event\entity\EntityDamageEvent($this, \pocketmine\event\entity\EntityDamageEvent::CAUSE_CONTACT, 1);
				$ev = new \pocketmine\event\entity\EntityDamageEvent($this, \pocketmine\event\entity\EntityDamageEvent::CAUSE_CONTACT, 1);
				$this->attack($ev->getFinalDamage(), $ev);
				if (($this->isAlive() && !($this->closed))) {
					$this->tryTeleportAwayFromHazard(true);
				}
			}
			return $hasUpdate;
		}

	public function attack($damage = null, $source = null) {
			/* decompiled (structured CF) */
			$result = parent::attack($damage, $source);
			if ((((!($result) || $source->isCancelled()) || $this->closed) || !($this->isAlive()))) {
				return $result;
			}
			if ($source instanceof \pocketmine\event\entity\EntityDamageByEntityEvent) {
				$damager = $source->getDamager();
				if ($damager instanceof \pocketmine\Player) {
					$this->setPm1eRetaliationTarget($damager);
					$this->setTremble(true);
					new \pocketmine\math\Vector3($this->x, $this->y, $this->z);
					$this->tryTeleportNearTarget($damager, new \pocketmine\math\Vector3($this->x, $this->y, $this->z));
				}
			}
			return $result;
		}

	protected function isEndermanWet() {
			/* decompiled (structured CF) */
			if ($this->isInsideOfWater()) {
				return true;
			}
			foreach ($this->getBlocksAround() as $block) {
				if ($this->isWaterBlock($block)) {
					return true;
				}
				/* goto */
			}
			$x = (floor($this->x));
			$y = (floor($this->y));
			$z = (floor($this->z));
			$dy = 0;
			while (($dy <= $t27)) {
				if ($this->isWaterBlockAt($x, ($y + $dy), $z)) {
					return true;
				}
				$dy++;
			}
			return $this->isExposedToRain();
		}

	protected function isExposedToRain() {
			/* decompiled (structured CF) */
			$level = $this->getLevel();
			if ((!($level instanceof \pocketmine\level\Level) || ($level->getDimension() !== \pocketmine\level\Level::DIMENSION_NORMAL))) {
				return false;
			}
			new \pocketmine\math\Vector3((floor($this->x)), (floor(($this->y + $this->height))), (floor($this->z)));
			return ($this->isRainy($level) && $level->canBlockSeeSky(new \pocketmine\math\Vector3((floor($this->x)), (floor(($this->y + $this->height))), (floor($this->z)))));
		}

	protected function tryTeleportAwayFromHazard($mustAvoidRain = null) {
			/* decompiled (structured CF) */
			$level = $this->getLevel();
			if (!($level instanceof \pocketmine\level\Level)) {
				return false;
			}
			$i = 0;
			while (($i < 64)) {
				$target = $this->getRandomTeleportTarget($mustAvoidRain);
				if (!($target instanceof \pocketmine\math\Vector3)) {
				} else {
					new \pocketmine\math\Vector3($this->x, $this->y, $this->z);
					$from = new \pocketmine\math\Vector3($this->x, $this->y, $this->z);
					if ($this->teleport($target)) {
						new \pocketmine\level\sound\EndermanTeleportSound($from);
						$level->addSound(new \pocketmine\level\sound\EndermanTeleportSound($from));
						new \pocketmine\level\sound\EndermanTeleportSound($this);
						$level->addSound(new \pocketmine\level\sound\EndermanTeleportSound($this));
						return true;
					}
				}
				$i++;
			}
			return false;
		}

	protected function tryTeleportNearTarget($target = null, $origin = null) {
			/* decompiled (structured CF) */
			$level = $this->getLevel();
			if ((!($level instanceof \pocketmine\level\Level) || ($level !== $target->getLevel()))) {
				return false;
			}
			$mustAvoidRain = $this->isRainy($level);
			$i = 0;
			while (($i < 64)) {
				$pos = $this->getRandomTeleportTargetNear($target, $origin, $mustAvoidRain);
				if (!($pos instanceof \pocketmine\math\Vector3)) {
				} else {
					new \pocketmine\math\Vector3($this->x, $this->y, $this->z);
					$from = new \pocketmine\math\Vector3($this->x, $this->y, $this->z);
					if ($this->teleport($pos)) {
						new \pocketmine\level\sound\EndermanTeleportSound($from);
						$level->addSound(new \pocketmine\level\sound\EndermanTeleportSound($from));
						new \pocketmine\level\sound\EndermanTeleportSound($this);
						$level->addSound(new \pocketmine\level\sound\EndermanTeleportSound($this));
						return true;
					}
				}
				$i++;
			}
			return false;
		}

	protected function getRandomTeleportTarget($mustAvoidRain = null) {
			/* decompiled (structured CF) */
			$level = $this->getLevel();
			if (!($level instanceof \pocketmine\level\Level)) {
				return null;
			}
			$x = ((floor($this->x)) + mt_rand(-16, 16));
			$z = ((floor($this->z)) + mt_rand(-16, 16));
			return $this->getSurfaceTeleportTargetAt($x, $z, $mustAvoidRain);
		}

	protected function getRandomTeleportTargetNear($target = null, $origin = null, $mustAvoidRain = null) {
			/* decompiled (structured CF) */
			$level = $this->getLevel();
			if (!($level instanceof \pocketmine\level\Level)) {
				return null;
			}
			$targetX = (floor($target->x));
			$targetZ = (floor($target->z));
			$distance = mt_rand(3, 8);
			$angle = ((mt_rand(0, 359) * \M_PI) / 180);
			$x = ($targetX + (round(($distance * cos($angle)))));
			$z = ($targetZ + (round(($distance * sin($angle)))));
			$pos = $this->getSurfaceTeleportTargetAt($x, $z, $mustAvoidRain);
			if (!($pos instanceof \pocketmine\math\Vector3)) {
			}
			if ((256 < $origin->distanceSquared($pos))) {
			}
			return $pos;
		}

	protected function getSurfaceTeleportTargetAt($x = null, $z = null, $mustAvoidRain = null) {
			/* decompiled (structured CF) */
			$level = $this->getLevel();
			if (!($level instanceof \pocketmine\level\Level)) {
				return null;
			}
			$surfaceY = ($level->getHighestBlockAt($x, $z) + 1);
			new \pocketmine\math\Vector3(($x + 0.5), $surfaceY, ($z + 0.5));
			$pos = new \pocketmine\math\Vector3(($x + 0.5), $surfaceY, ($z + 0.5));
			if ($this->canEndermanTeleportTo($pos, $mustAvoidRain)) {
				return $pos;
			}
		}

	protected function canEndermanTeleportTo($pos = null, $mustAvoidRain = null) {
			/* decompiled (structured CF) */
			$level = $this->getLevel();
			if (!($level instanceof \pocketmine\level\Level)) {
				return false;
			}
			$x = (floor($pos->x));
			$y = (floor($pos->y));
			$z = (floor($pos->z));
			if ((($y < 1) || (\pocketmine\level\Level::Y_MAX <= ($y + 2)))) {
				return false;
			}
			new \pocketmine\math\Vector3($x, ($y - 1), $z);
			$floor = $level->getBlock(new \pocketmine\math\Vector3($x, ($y - 1), $z));
			if (!($floor->isTopFacingSurfaceSolid())) {
				return false;
			}
			$dy = 0;
			while (($dy <= $t49)) {
				new \pocketmine\math\Vector3($x, ($y + $dy), $z);
				$block = $level->getBlock(new \pocketmine\math\Vector3($x, ($y + $dy), $z));
				if (($this->isWaterBlock($block) || !($block->canPassThrough()))) {
					return false;
				}
				$dy++;
			}
			new \pocketmine\math\Vector3($x, (floor(($y + $this->height))), $z);
			if ((($mustAvoidRain && $this->isRainy($level)) && $level->canBlockSeeSky(new \pocketmine\math\Vector3($x, (floor(($y + $this->height))), $z)))) {
				return false;
			}
			return true;
		}

	protected function isRainy($level = null) {
			$weather = $level->getWeather();
			return (($weather !== null) && ($weather->isRainy() || $weather->isRainyThunder()));
		}

	protected function isWaterBlockAt($x = null, $y = null, $z = null) {
			/* decompiled (structured CF) */
			$level = $this->getLevel();
			if (((!($level instanceof \pocketmine\level\Level) || ($y < 0)) || (\pocketmine\level\Level::Y_MAX <= $y))) {
				return false;
			}
			new \pocketmine\math\Vector3($x, $y, $z);
			return $this->isWaterBlock($level->getBlock(new \pocketmine\math\Vector3($x, $y, $z)));
		}

	protected function isWaterBlock($block = null) {
			/* decompiled (structured CF) */
			if ($block instanceof \pocketmine\block\Water) {
				return true;
			}
			if (method_exists($block, 'getId')) {
			} else {
			}
			$id = null;
			return (($id === \pocketmine\block\Block::WATER) || ($id === \pocketmine\block\Block::STILL_WATER));
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->eid = $this->getId();
			$pk->type = 38;
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->yaw = $this->yaw;
			$pk->pitch = $this->pitch;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

	public function getDrops() {
			return [\pocketmine\item\Item::get(\pocketmine\item\Item::SNOWBALL, 1, 1)];
		}

}
