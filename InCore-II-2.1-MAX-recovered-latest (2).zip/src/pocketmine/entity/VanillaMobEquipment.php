<?php

namespace pocketmine\entity;

final class VanillaMobEquipment {
	public const SLOT_HELMET = 0;
	public const SLOT_CHESTPLATE = 1;
	public const SLOT_LEGGINGS = 2;
	public const SLOT_BOOTS = 3;

	private static $profiles = array (
  0 => 
  array (
    'armorChance' => 0,
    'weaponChance' => 0,
    'enchantChance' => 0,
    'maxEnchantLevel' => 0,
    'equipmentDropChance' => 0,
    'rareDropChance' => 0,
  ),
  1 => 
  array (
    'armorChance' => 12,
    'weaponChance' => 18,
    'enchantChance' => 16,
    'maxEnchantLevel' => 2,
    'equipmentDropChance' => 85,
    'rareDropChance' => 25,
  ),
  2 => 
  array (
    'armorChance' => 22,
    'weaponChance' => 32,
    'enchantChance' => 30,
    'maxEnchantLevel' => 3,
    'equipmentDropChance' => 85,
    'rareDropChance' => 25,
  ),
  3 => 
  array (
    'armorChance' => 35,
    'weaponChance' => 45,
    'enchantChance' => 45,
    'maxEnchantLevel' => 4,
    'equipmentDropChance' => 85,
    'rareDropChance' => 25,
  ),
);
	private static $armorSets = array (
  0 => 
  array (
    0 => 298,
    1 => 299,
    2 => 300,
    3 => 301,
  ),
  1 => 
  array (
    0 => 314,
    1 => 315,
    2 => 316,
    3 => 317,
  ),
  2 => 
  array (
    0 => 302,
    1 => 303,
    2 => 304,
    3 => 305,
  ),
  3 => 
  array (
    0 => 306,
    1 => 307,
    2 => 308,
    3 => 309,
  ),
  4 => 
  array (
    0 => 310,
    1 => 311,
    2 => 312,
    3 => 313,
  ),
);

	private function __construct() {
			// empty
		}

	public static function javaDifficulty($difficulty = null) {
			/* decompiled (structured CF) */
			$difficulty = ($difficulty);
			if (($difficulty < 0)) {
				return 0;
			}
			if ((3 < $difficulty)) {
				return 3;
			}
			return $difficulty;
		}

	public static function getProfile($difficulty = null) {
			return self::$profiles[self::javaDifficulty($difficulty)];
		}

	public static function emptyArmor() {
			return [\pocketmine\item\Item::get(\pocketmine\item\Item::AIR, 0, 0), \pocketmine\item\Item::get(\pocketmine\item\Item::AIR, 0, 0), \pocketmine\item\Item::get(\pocketmine\item\Item::AIR, 0, 0), \pocketmine\item\Item::get(\pocketmine\item\Item::AIR, 0, 0)];
		}

	public static function generateZombieEquipment($difficulty = null) {
			/* decompiled (structured CF) */
			$profile = self::getProfile($difficulty);
			$weapon = \pocketmine\item\Item::get(\pocketmine\item\Item::AIR, 0, 0);
			if (self::roll($profile['weaponChance'])) {
				$weapon = self::randomZombieWeapon($profile);
			}
			return [$weapon, self::randomArmor($profile)];
		}

	public static function generateSkeletonEquipment($difficulty = null) {
			/* decompiled (structured CF) */
			$profile = self::getProfile($difficulty);
			$weapon = \pocketmine\item\Item::get(\pocketmine\item\Item::BOW, 0, 1);
			self::damageSpawnedEquipment($weapon);
			if (self::roll($profile['enchantChance'])) {
				$weapon = self::enchantBow($weapon, $profile);
			}
			return [$weapon, self::randomArmor($profile)];
		}

	public static function generatePigZombieEquipment($difficulty = null) {
			/* decompiled (structured CF) */
			$profile = self::getProfile($difficulty);
			$weapon = \pocketmine\item\Item::get(\pocketmine\item\Item::GOLD_SWORD, 0, 1);
			self::damageSpawnedEquipment($weapon);
			if (self::roll($profile['enchantChance'])) {
				$weapon = self::enchantMeleeWeapon($weapon, $profile);
			}
			return [$weapon, self::emptyArmor()];
		}

	public static function applyLootingToCommonDrops($drops = null, $lootingLevel = null) {
			/* decompiled (structured CF) */
			$lootingLevel = self::clampLooting($lootingLevel);
			if (($lootingLevel <= 0)) {
				return $drops;
			}
			foreach ($drops as $item) {
				if (($item instanceof \pocketmine\item\Item && ($item->getId() !== \pocketmine\item\Item::AIR))) {
					$item->setCount(($item->getCount() + mt_rand(0, $lootingLevel)));
				}
				/* goto */
			}
			return $drops;
		}

	public static function rareDropChance($lootingLevel = null) {
			return min(1000, (self::$profiles[1]['rareDropChance'] + (self::clampLooting($lootingLevel) * 10)));
		}

	public static function equipmentDropChance($lootingLevel = null) {
			return min(1000, (self::$profiles[1]['equipmentDropChance'] + (self::clampLooting($lootingLevel) * 10)));
		}

	public static function maybeDropEquipment($armor = null, $weapon = null, $lootingLevel = null) {
			/* decompiled (structured CF) */
			$drops = ['__array_ptr' => '2aaaac9fc9a0'];
			$chance = self::equipmentDropChance($lootingLevel);
			if ((($weapon instanceof \pocketmine\item\Item && ($weapon->getId() !== \pocketmine\item\Item::AIR)) && self::roll($chance, 1000))) {
				$drops[] = clone $weapon;
			}
			foreach ($armor as $piece) {
				if ((($piece instanceof \pocketmine\item\Item && ($piece->getId() !== \pocketmine\item\Item::AIR)) && self::roll($chance, 1000))) {
					$drops[] = clone $piece;
				}
				/* goto */
			}
			return $drops;
		}

	public static function applyArmorReduction($damage = null, $armor = null, $cause = null) {
			/* decompiled (structured CF) */
			$armorPoints = 0;
			$enchantmentProtection = 0;
			foreach ($armor as $piece) {
				if ((!($piece instanceof \pocketmine\item\Item) || !($piece->isArmor()))) {
					/* goto */
				}
				$armorPoints += ($piece->getArmorValue());
				$enchantmentProtection += self::getProtectionPoints($piece, $cause);
				/* goto */
			}
			if ((($armorPoints <= 0) && ($enchantmentProtection <= 0))) {
				return $damage;
			}
			$reduced = ($damage * (1 - (min(20, $armorPoints) * 0.04)));
			if ((0 < $enchantmentProtection)) {
				$reduced *= (1 - (min(20, $enchantmentProtection) * 0.04));
			}
			return max(0, $reduced);
		}

	public static function getWeaponBaseDamage($item = null) {
			/* decompiled (structured CF) */
			if (!($item instanceof \pocketmine\item\Item)) {
				return 1;
			}
			switch ($item->getId()) {
				case \pocketmine\item\Item::WOODEN_SWORD:
				case \pocketmine\item\Item::GOLD_SWORD:
				return 4;
				case \pocketmine\item\Item::STONE_SWORD:
				return 5;
				case \pocketmine\item\Item::IRON_SWORD:
				return 6;
				case \pocketmine\item\Item::DIAMOND_SWORD:
				return 7;
				case \pocketmine\item\Item::WOODEN_AXE:
				case \pocketmine\item\Item::GOLD_AXE:
				return 3;
				case \pocketmine\item\Item::STONE_AXE:
				case \pocketmine\item\Item::IRON_AXE:
				case \pocketmine\item\Item::DIAMOND_AXE:
				return 5;
				case \pocketmine\item\Item::WOODEN_SHOVEL:
				case \pocketmine\item\Item::GOLD_SHOVEL:
				return 2;
				case \pocketmine\item\Item::STONE_SHOVEL:
				return 3;
				case \pocketmine\item\Item::IRON_SHOVEL:
				return 4;
				case \pocketmine\item\Item::DIAMOND_SHOVEL:
				return 5;
			}
		}

	public static function getLootingLevelFromEntity($entity = null) {
			/* decompiled (structured CF) */
			if (!($entity instanceof \pocketmine\entity\Human)) {
				return 0;
			}
			return self::clampLooting($entity->getInventory()->getItemInHand()->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_WEAPON_LOOTING));
		}

	private static function randomZombieWeapon($profile = null) {
			/* decompiled (structured CF) */
			$id = self::weightedRandom([35, 30, 20, 10, 5]);
			$item = \pocketmine\item\Item::get($id, 0, 1);
			self::damageSpawnedEquipment($item);
			if (self::roll($profile['enchantChance'])) {
				$item = self::enchantMeleeWeapon($item, $profile);
			}
			return $item;
		}

	private static function randomArmor($profile = null) {
			/* decompiled (structured CF) */
			$armor = self::emptyArmor();
			if (!(self::roll($profile['armorChance']))) {
				return $armor;
			}
			$set = self::$armorSets[self::weightedIndex(['__array_ptr' => '2aaaadd5d7e0'])];
			if (((35 <= $profile['armorChance']) && self::roll(1))) {
				$set = self::$armorSets[4];
			}
			$slotsToFill = mt_rand(1, 4);
			$i = 0;
			while (($i < $slotsToFill)) {
				$item = \pocketmine\item\Item::get($set[$i], 0, 1);
				self::damageSpawnedEquipment($item);
				if (self::roll($profile['enchantChance'])) {
					$item = self::enchantArmor($item, $profile);
				}
				$armor[$i] = $item;
				$i++;
			}
			return $armor;
		}

	private static function enchantArmor($item = null, $profile = null) {
			/* decompiled (structured CF) */
			$possible = [10, 5, 5, 5, 5, 1];
			if ((method_exists($item, 'isBoots') && $item->isBoots())) {
				$possible[\pocketmine\item\enchantment\Enchantment::TYPE_ARMOR_FALL_PROTECTION] = 3;
			}
			if ((method_exists($item, 'isHelmet') && $item->isHelmet())) {
				$possible[\pocketmine\item\enchantment\Enchantment::TYPE_WATER_BREATHING] = 1;
				$possible[\pocketmine\item\enchantment\Enchantment::TYPE_WATER_AFFINITY] = 1;
			}
			return self::addRandomEnchantments($item, $possible, $profile);
		}

	private static function enchantMeleeWeapon($item = null, $profile = null) {
			return self::addRandomEnchantments($item, [10, 5, 5, 5, 2, 2, 5], $profile);
		}

	private static function enchantBow($item = null, $profile = null) {
			return self::addRandomEnchantments($item, [10, 2, 2, 1, 5], $profile);
		}

	private static function addRandomEnchantments($item = null, $weightedEnchantments = null, $profile = null) {
			/* decompiled (structured CF) */
			if (self::roll(20)) {
			} else {
			}
			$count = 1;
			$used = ['__array_ptr' => '2aaaac9fc9a0'];
			$i = 0;
			while ((0 < count($weightedEnchantments))) {
				$id = self::weightedRandom($weightedEnchantments);
				if ((isset($used[$id]) || self::conflictsWithUsed($id, $used))) {
				} else {
					$used[$id] = true;
					$max = min(\pocketmine\item\enchantment\Enchantment::getEnchantMaxLevel($id), max(1, $profile['maxEnchantLevel']));
					$level = mt_rand(1, $max);
					$item->addEnchantment(\pocketmine\item\enchantment\Enchantment::getEnchantment($id)->setLevel($level));
				}
				$i++;
			}
			return $item;
		}

	private static function conflictsWithUsed($id = null, $used = null) {
			/* decompiled (structured CF) */
			$protection = [true, true, true, true];
			if (isset($protection[$id])) {
				foreach ($used as $usedId => $_) {
					if (isset($protection[$usedId])) {
						return true;
					}
					/* goto */
				}
			}
			$weaponDamage = [true, true, true];
			if (isset($weaponDamage[$id])) {
				foreach ($used as $usedId => $_) {
					if (isset($weaponDamage[$usedId])) {
						return true;
					}
					/* goto */
				}
			}
			return false;
		}

	private static function getProtectionPoints($item = null, $cause = null) {
			/* decompiled (structured CF) */
			$points = $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_ARMOR_PROTECTION);
			$points += $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_ARMOR_FIRE_PROTECTION);
			$points += $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_ARMOR_EXPLOSION_PROTECTION);
			$points += $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_ARMOR_PROJECTILE_PROTECTION);
			return min(20, $points);
		}

	private static function damageSpawnedEquipment($item = null) {
			/* decompiled (structured CF) */
			$max = $item->getMaxDurability();
			if ((!(is_int($max)) || ($max <= 0))) {
				return null;
			}
			$remaining = mt_rand(1, max(1, (($max * 0.25))));
			$item->setDamage(max(0, ($max - $remaining)));
		}

	private static function clampLooting($level = null) {
			return max(0, min(3, $level));
		}

	private static function roll($chance = null, $outOf = null) {
			/* decompiled (structured CF) */
			if (($chance <= 0)) {
				return false;
			}
			if (($outOf <= $chance)) {
				return true;
			}
			return (mt_rand(1, $outOf) <= $chance);
		}

	private static function weightedIndex($weights = null) {
			/* decompiled (structured CF) */
			$sum = array_sum($weights);
			$roll = mt_rand(1, $sum);
			foreach ($weights as $index => $weight) {
				$roll -= $weight;
				if (($roll <= 0)) {
					return ($index);
				}
				/* goto */
			}
			return (count($weights) - 1);
		}

	private static function weightedRandom($weights = null) {
			/* decompiled (structured CF) */
			$sum = array_sum($weights);
			$roll = mt_rand(1, $sum);
			foreach ($weights as $value => $weight) {
				$roll -= $weight;
				if (($roll <= 0)) {
					return ($value);
				}
				/* goto */
			}
			return (array_keys($weights)[0]);
		}

}
