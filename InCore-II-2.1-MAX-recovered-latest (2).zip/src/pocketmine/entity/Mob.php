<?php

namespace pocketmine\entity;

abstract class Mob extends \pocketmine\entity\Creature {
	protected $behaviors = array (
);
	protected $currentBehavior = NULL;
	public $random = NULL;
	protected $behaviorsEnabled = false;
	protected $pm1eMoveTarget = NULL;
	protected $pm1eGeneratedMoveTarget = false;
	protected $pm1eFollowTarget = NULL;
	protected $pm1eRetaliationTarget = NULL;
	protected $pm1eStayTime = 0;
	protected $pm1eMoveTime = 0;
	protected $pm1eMoveMultiplier = 1.0;
	protected $pm1eNoRotateTicks = 0;
	protected $pm1eKnockbackTicks = 0;

	public function initEntity() {
			/* decompiled (structured CF) */
			parent::initEntity();
			new \pocketmine\utils\Random();
			$this->random = new \pocketmine\utils\Random();
			$this->behaviorsEnabled = $this->level->getServer()->aiEnabled;
			$this->stepHeight = 0.6;
			return null;
		}

	public function getHorizDir() {
			/* decompiled (structured CF) */
			new \pocketmine\math\Vector3();
			$vec = new \pocketmine\math\Vector3();
			$pitch = 0;
			$yaw = $this->yaw;
			$vec->x = (cos($pitch) * (sin($yaw) * -1));
			$vec->y = (sin($pitch) * -1);
			$vec->z = (sin($yaw) * cos($pitch));
			return $vec->normalize();
		}

	public function onUpdate($tick = null) {
			/* decompiled (structured CF) */
			if ($this->usesPm1eGroundAi()) {
				return $this->onUpdatePm1e($tick);
			}
			$hasUpdate = parent::onUpdate($tick);
			if (($this->closed || !($this->isAlive()))) {
				return false;
			}
			if ($this->behaviorsEnabled) {
				$this->currentBehavior = $this->checkBehavior();
				if (($this->currentBehavior != null)) {
					$this->currentBehavior->onTick();
				}
			}
			return $hasUpdate;
		}

	public function usesPm1eGroundAi() {
			return false;
		}

	public function knockBack($attacker = null, $damage = null, $x = null, $z = null, $base = null) {
			/* decompiled (structured CF) */
			parent::knockBack($attacker, $damage, $x, $z, $base);
			if (($this->usesPm1eGroundAi() && (((1e-05 < abs($this->motionX)) || (1e-05 < abs($this->motionY))) || (1e-05 < abs($this->motionZ))))) {
				$this->pm1eKnockbackTicks = max($this->pm1eKnockbackTicks, 6);
				$this->pm1eNoRotateTicks = max($this->pm1eNoRotateTicks, 6);
			}
			return null;
		}

	protected function usesPm1eJumpingAi() {
			return false;
		}

	protected function getPm1eJumpStrength() {
			return 0.42;
		}

	public function setPm1eFollowTarget($target = null) {
			$this->pm1eFollowTarget = $target;
		}

	public function setPm1eRetaliationTarget($target = null) {
			/* decompiled (structured CF) */
			$this->pm1eRetaliationTarget = $target;
			$this->setPm1eFollowTarget($target);
			foreach ($this->behaviors as $behavior) {
				if (($behavior instanceof \pocketmine\entity\behavior\attackEnemyBehavior || $behavior instanceof \pocketmine\entity\behavior\ShootEnemyBehavior)) {
					$behavior->enemy = $target;
				}
				if ($behavior instanceof \pocketmine\entity\behavior\ShootPlayerBehavior) {
					$behavior->player = $target;
				}
				/* goto */
			}
			return null;
		}

	public function getPm1eFollowTarget() {
			return $this->pm1eFollowTarget;
		}

	public function getPm1eRetaliationTarget() {
			return $this->pm1eRetaliationTarget;
		}

	protected function findPm1eMobTarget($maxDistanceSquared = null) {
			/* decompiled (structured CF) */
			if ($this->pm1eRetaliationTarget instanceof \pocketmine\entity\Entity) {
				if ((($this->pm1eRetaliationTarget->closed || !($this->pm1eRetaliationTarget->isAlive())) || ($maxDistanceSquared < $this->distanceSquared($this->pm1eRetaliationTarget)))) {
					$this->setPm1eRetaliationTarget(null);
				} else {
					return $this->pm1eRetaliationTarget;
				}
			}
			$level = $this->getLevel();
			if (($level === null)) {
			}
			$closest = null;
			$bestDistance = $maxDistanceSquared;
			foreach ($level->getPlayers() as $player) {
				if ((method_exists($player, 'isSurvival') && method_exists($player, 'isAdventure'))) {
					if ((!($player->isSurvival()) && !($player->isAdventure()))) {
						/* goto */
					}
				}
				if ((property_exists($player, 'closed') && $player->closed)) {
					/* goto */
				}
				if ((method_exists($player, 'isAlive') && !($player->isAlive()))) {
					/* goto */
				}
				$distance = $this->distanceSquared($player);
				if (($distance <= $bestDistance)) {
					$bestDistance = $distance;
					$closest = $player;
				}
				/* goto */
			}
			return $closest;
		}

	public function setPm1eMoveTarget($target = null) {
			$this->pm1eMoveTarget = $target;
			$this->pm1eGeneratedMoveTarget = false;
		}

	public function getPm1eMoveTarget() {
			return $this->pm1eMoveTarget;
		}

	public function setPm1eMoveMultiplier($multiplier = null) {
			$this->pm1eMoveMultiplier = $multiplier;
		}

	public function setPm1eStayTime($ticks = null) {
			$this->pm1eStayTime = max(0, $ticks);
			return null;
		}

	public function setPm1eNoRotateTicks($ticks = null) {
			$this->pm1eNoRotateTicks = max(0, $ticks);
			return null;
		}

	public function clearPm1eIntent() {
			$this->pm1eFollowTarget = null;
			$this->pm1eRetaliationTarget = null;
			$this->pm1eMoveTarget = null;
			$this->pm1eGeneratedMoveTarget = false;
			$this->pm1eMoveMultiplier = 1;
			$this->pm1eNoRotateTicks = 0;
			$this->pm1eKnockbackTicks = 0;
		}

	protected function onUpdatePm1e($currentTick = null) {
			/* decompiled (structured CF) */
			if ($this->closed) {
				return false;
			}
			if ((0 < $this->attackingTick)) {
			}
			if ((!($this->isAlive()) && $this->hasSpawned)) {
				if ((20 <= $this->deadTicks)) {
					$this->despawnFromAll();
				}
				return true;
			}
			$tickDiff = ($currentTick - $this->lastUpdate);
			if (($tickDiff <= 0)) {
				return false;
			}
			$this->lastUpdate = $currentTick;
			$this->timings->startTiming();
			$hasUpdate = $this->entityBaseTick($tickDiff);
			if ($this->closed) {
				$this->timings->stopTiming();
				return $hasUpdate;
			}
			if ($this->isAlive()) {
				if ($this->behaviorsEnabled) {
					$this->currentBehavior = $this->checkBehavior();
					if (($this->currentBehavior !== null)) {
						$this->currentBehavior->onTick();
					}
				}
				$hasUpdate = ($this->tickPm1eGroundAi($tickDiff) || $hasUpdate);
				$this->updateMovement();
			}
			$this->timings->stopTiming();
			return (((($hasUpdate || !($this->onGround)) || (1e-05 < abs($this->motionX))) || (1e-05 < abs($this->motionY))) || (1e-05 < abs($this->motionZ)));
		}

	protected function tickPm1eGroundAi($tickDiff = null) {
			/* decompiled (structured CF) */
			$level = $this->getLevel();
			if (($level === null)) {
				return false;
			}
			$hasUpdate = false;
			$liquidType = $this->getPm1eLiquidType();
			$inLiquid = ($liquidType !== null);
			if ((0 < $this->pm1eNoRotateTicks)) {
				$this->pm1eNoRotateTicks = max(0, ($this->pm1eNoRotateTicks - $tickDiff));
			}
			$usingKnockbackMotion = ((0 < $this->pm1eKnockbackTicks) && (((1e-05 < abs($this->motionX)) || (1e-05 < abs($this->motionY))) || (1e-05 < abs($this->motionZ))));
			if ((0 < $this->pm1eKnockbackTicks)) {
				$this->pm1eKnockbackTicks = max(0, ($this->pm1eKnockbackTicks - $tickDiff));
			}
			if ((0 < $this->pm1eStayTime)) {
				$this->pm1eStayTime = max(0, ($this->pm1eStayTime - $tickDiff));
			}
			if ((0 < $this->pm1eMoveTime)) {
				$this->pm1eMoveTime = max(0, ($this->pm1eMoveTime - $tickDiff));
			}
			if (((!($this->pm1eFollowTarget instanceof \pocketmine\entity\Entity) || $this->pm1eFollowTarget->closed) || !($this->pm1eFollowTarget->isAlive()))) {
				$this->pm1eFollowTarget = null;
				if ((($this->pm1eRetaliationTarget !== null) && ((!($this->pm1eRetaliationTarget instanceof \pocketmine\entity\Entity) || $this->pm1eRetaliationTarget->closed) || !($this->pm1eRetaliationTarget->isAlive())))) {
					$this->pm1eRetaliationTarget = null;
				}
			}
			if (($this->pm1eFollowTarget === null)) {
				$this->refreshPm1eWanderTarget();
			}
			if (($this->pm1eFollowTarget !== null)) {
			} else {
			}
			$target = $this->pm1eMoveTarget;
			$movementMultiplier = abs($this->pm1eMoveMultiplier);
			if (($movementMultiplier < 0.001)) {
				$movementMultiplier = 0.001;
			}
			if (($this->pm1eMoveMultiplier < 0)) {
			} else {
			}
			$directionSign = 1;
			if ($usingKnockbackMotion) {
				$hasUpdate = true;
			} else {
				if ($target instanceof \pocketmine\math\Vector3) {
					$dx = ($target->x - $this->x);
					$dz = ($target->z - $this->z);
					$diff = (abs($dx) + abs($dz));
					$distanceSquared = (($dx * $dx) + ($dz * $dz));
					$stopDistance = (($this->width / 2) + 1);
					$stopDistanceSquared = ($stopDistance * $stopDistance);
					if ((($this->pm1eNoRotateTicks <= 0) && (0.001 < $diff))) {
						$this->yaw = ((atan2(($dx / $diff), ($dz / $diff)) * -1) * (180 / \M_PI));
					}
					if (((($diff <= 0.001) || (($this->pm1eFollowTarget === null) && (0 < $this->pm1eStayTime))) || ((0 < $directionSign) && ($distanceSquared <= $stopDistanceSquared)))) {
						$this->motionX = 0;
						$this->motionZ = 0;
					} else {
						$baseSpeed = ($movementMultiplier * $this->getPm1eBaseSpeed($liquidType));
						$this->motionX = (($baseSpeed * $directionSign) * ($dx / $diff));
						$this->motionZ = (($baseSpeed * $directionSign) * ($dz / $diff));
					}
				} else {
					$this->motionX = 0;
					$this->motionZ = 0;
				}
			}
			if ($inLiquid) {
				$jumped = false;
				if ((!($usingKnockbackMotion) || ($this->motionY <= 0))) {
					$this->motionY = max($this->motionY, $this->getPm1eLiquidBuoyancy());
				}
			} else {
				if ($this->usesPm1eJumpingAi()) {
				} else {
				}
				$jumped = (!($usingKnockbackMotion) && $this->checkPm1eJump());
				if (!($jumped)) {
					if ($this->onGround) {
						if ((!($usingKnockbackMotion) || ($this->motionY <= 0))) {
							$this->motionY = 0;
						}
					} else {
						$this->motionY -= $this->gravity;
					}
				}
			}
			$this->normalizePm1eGroundCollisionBox();
			$this->move($this->motionX, $this->motionY, $this->motionZ);
			$hasUpdate = true;
			$friction = (1 - $this->drag);
			if (($this->onGround && ((1e-05 < abs($this->motionX)) || (1e-05 < abs($this->motionZ))))) {
				$friction = ($friction * $this->getLevel()->getBlock($this->temporalVector->setComponents((floor($this->x)), (floor(($this->y - 1))), ((floor($this->z)) - 1)))->getFrictionFactor());
			}
			$this->motionX *= $friction;
			$this->motionZ *= $friction;
			if ($inLiquid) {
			} else {
			}
			$this->motionY *= (1 - $this->drag);
			if (($this->onGround && !($inLiquid))) {
				$this->motionY *= -0.5;
			}
			return $hasUpdate;
		}

	protected function normalizePm1eGroundCollisionBox() {
			/* decompiled (structured CF) */
			$changed = false;
			if (($this->width <= 0)) {
				$this->width = 0.6;
				$changed = true;
			}
			if (($this->height <= 0)) {
				$this->height = 1.8;
				$changed = true;
			}
			if ($changed) {
				$halfWidth = ($this->width / 2);
				$this->boundingBox->setBounds(($this->x - $halfWidth), $this->y, ($this->z - $halfWidth), ($this->x + $halfWidth), ($this->y + $this->height), ($this->z + $halfWidth));
			}
			return null;
		}

	protected function refreshPm1eWanderTarget() {
			/* decompiled (structured CF) */
			if (($this->pm1eMoveTarget instanceof \pocketmine\math\Vector3 && !($this->pm1eGeneratedMoveTarget))) {
				return null;
			}
			if ((0 < $this->pm1eStayTime)) {
				$this->pm1eMoveTarget = null;
				$this->pm1eGeneratedMoveTarget = false;
			}
			if ($this->pm1eMoveTarget instanceof \pocketmine\math\Vector3) {
				$dx = ($this->pm1eMoveTarget->x - $this->x);
				$dz = ($this->pm1eMoveTarget->z - $this->z);
				if ((((($dx * $dx) + ($dz * $dz)) <= 4) && (0 < $this->pm1eMoveTime))) {
				}
			}
			if (((0 < $this->pm1eMoveTime) && $this->pm1eMoveTarget instanceof \pocketmine\math\Vector3)) {
			}
			if ((mt_rand(1, 100) === 1)) {
				$this->pm1eStayTime = mt_rand(80, 200);
				$this->pm1eMoveTarget = null;
				$this->pm1eGeneratedMoveTarget = false;
			}
			$this->pm1eMoveTime = mt_rand(80, 200);
			new \pocketmine\math\Vector3(($this->x + mt_rand(-30, 30)), $this->y, ($this->z + mt_rand(-30, 30)));
			$this->pm1eMoveTarget = new \pocketmine\math\Vector3(($this->x + mt_rand(-30, 30)), $this->y, ($this->z + mt_rand(-30, 30)));
			$this->pm1eGeneratedMoveTarget = true;
		}

	protected function getPm1eBaseSpeed($liquidType = null) {
			/* decompiled (structured CF) */
			if (($liquidType === 'lava')) {
				return 0.02;
			}
			if (($liquidType === 'water')) {
				return 0.05;
			}
			return 0.15;
		}

	protected function getPm1eLiquidType() {
			/* decompiled (structured CF) */
			if ($this->isInsideOfWater()) {
				return 'water';
			}
			new \pocketmine\math\Vector3((floor($this->x)), (floor($this->y)), (floor($this->z)));
			$block = $this->getLevel()->getBlock(new \pocketmine\math\Vector3((floor($this->x)), (floor($this->y)), (floor($this->z))));
			if (method_exists($block, 'getId')) {
			} else {
			}
			$blockId = null;
			if ((($block instanceof \pocketmine\block\Lava || ($blockId === \pocketmine\block\Block::LAVA)) || ($blockId === \pocketmine\block\Block::STILL_LAVA))) {
				return 'lava';
			}
			if ((($block instanceof \pocketmine\block\Water || ($blockId === \pocketmine\block\Block::WATER)) || ($blockId === \pocketmine\block\Block::STILL_WATER))) {
				return 'water';
			}
			if ($block instanceof \pocketmine\block\Liquid) {
				return 'water';
			}
		}

	protected function getPm1eLiquidBuoyancy() {
			return ($this->gravity * 0.3);
		}

	protected function checkPm1eJump() {
			/* decompiled (structured CF) */
			if ((!($this->onGround) || (0 < $this->pm1eStayTime))) {
				return false;
			}
			$motionLengthSquared = (($this->motionX * $this->motionX) + ($this->motionZ * $this->motionZ));
			if (($motionLengthSquared <= 1e-07)) {
				return false;
			}
			if ((0 <= $this->motionX)) {
			} else {
			}
			$forwardX = (($this->x + (($this->width * -1) / 2)) + $this->motionX);
			if ((0 <= $this->motionZ)) {
			} else {
			}
			$forwardZ = (($this->z + (($this->width * -1) / 2)) + $this->motionZ);
			$nextX = (floor($forwardX));
			$nextY = (floor($this->y));
			$nextZ = (floor($forwardZ));
			new \pocketmine\math\Vector3($nextX, $nextY, $nextZ);
			$that = $this->getLevel()->getBlock(new \pocketmine\math\Vector3($nextX, $nextY, $nextZ));
			$horizontalFacing = $this->resolvePm1eHorizontalFacing();
			$blockX = $nextX;
			$blockY = $nextY;
			$blockZ = $nextZ;
			if ($that->canPassThrough()) {
				if (!(($horizontalFacing == \pocketmine\math\Vector3::SIDE_EAST))) {
					if (!(($horizontalFacing == \pocketmine\math\Vector3::SIDE_WEST))) {
						if (!(($horizontalFacing == \pocketmine\math\Vector3::SIDE_SOUTH))) {
							if (!(($horizontalFacing == \pocketmine\math\Vector3::SIDE_NORTH))) {
							} else {
								$blockX++;
								/* jump */
								$blockX--;
								/* jump */
								$blockZ++;
								/* jump */
								$blockZ--;
								/* jump */
							}
							new \pocketmine\math\Vector3($blockX, $blockY, $blockZ);
							$block = $this->getLevel()->getBlock(new \pocketmine\math\Vector3($blockX, $blockY, $blockZ));
							/* jump */
							$block = $that;
							new \pocketmine\math\Vector3($blockX, ($blockY - 1), $blockZ);
							$down = $this->getLevel()->getBlock(new \pocketmine\math\Vector3($blockX, ($blockY - 1), $blockZ));
							if ($this->shouldAvoidPm1eCliff($block, $down)) {
								new \pocketmine\math\Vector3($blockX, ($blockY - 2), $blockZ);
								$downTwo = $this->getLevel()->getBlock(new \pocketmine\math\Vector3($blockX, ($blockY - 2), $blockZ));
								if ($downTwo->canPassThrough()) {
									$this->pm1eStayTime = max($this->pm1eStayTime, 10);
									$this->motionX = 0;
									$this->motionZ = 0;
									return false;
								}
							}
							new \pocketmine\math\Vector3($blockX, ($blockY + 1), $blockZ);
							$blockUp = $this->getLevel()->getBlock(new \pocketmine\math\Vector3($blockX, ($blockY + 1), $blockZ));
							new \pocketmine\math\Vector3($blockX, ($blockY + 2), $blockZ);
							$blockUpUp = $this->getLevel()->getBlock(new \pocketmine\math\Vector3($blockX, ($blockY + 2), $blockZ));
							if ($this->isPm1eUnjumpableBarrier($block)) {
								$this->pm1eStayTime = max($this->pm1eStayTime, 10);
								$this->motionX = 0;
								$this->motionY = 0;
								$this->motionZ = 0;
								return false;
							}
							if ((((((!($block->canPassThrough()) && ($block->getBoundingBox() !== null)) && !($this->canPm1eStepOnto($block))) && !($block instanceof \pocketmine\block\SoulSand)) && $blockUp->canPassThrough()) && $blockUpUp->canPassThrough())) {
								if (($this->motionY < $this->getPm1eJumpStrength())) {
									$this->motionY = $this->getPm1eJumpStrength();
								} else {
									$this->motionY += ($this->gravity * 0.25);
								}
								return true;
							}
							return false;
						}
					}
				}
			}
		}

	protected function canPm1eStepOnto($block = null) {
			/* decompiled (structured CF) */
			$bb = $block->getBoundingBox();
			if (($bb === null)) {
				return true;
			}
			return ($bb->maxY <= (($this->y + $this->stepHeight) + 0.001));
		}

	protected function isPm1eUnjumpableBarrier($block = null) {
			return (($block->getBoundingBox() !== null) && ((($block instanceof \pocketmine\block\Fence || $block instanceof \pocketmine\block\FenceGate) || $block instanceof \pocketmine\block\StoneWall) || $block instanceof \pocketmine\block\NetherBrickFence));
		}

	protected function shouldAvoidPm1eCliff($block = null, $down = null) {
			return (((($this->pm1eFollowTarget === null) && !($this->pm1eMoveTarget instanceof \pocketmine\entity\Entity)) && $down->canPassThrough()) && $block->canPassThrough());
		}

	protected function resolvePm1eHorizontalFacing() {
			/* decompiled (structured CF) */
			if ((abs($this->motionZ) < abs($this->motionX))) {
				if ((0 < $this->motionX)) {
				} else {
				}
				return \pocketmine\math\Vector3::SIDE_WEST;
			}
			if ((0 < $this->motionZ)) {
			} else {
			}
			return \pocketmine\math\Vector3::SIDE_NORTH;
		}

	protected function checkPm1eJumpingJump() {
			/* decompiled (structured CF) */
			if ($this->isInsideOfWater()) {
				$this->motionY = ($this->gravity * 2);
				return true;
			}
			if (!($this->onGround)) {
				return false;
			}
			if (((1e-05 < abs($this->motionX)) || (1e-05 < abs($this->motionZ)))) {
				$this->motionY = $this->getPm1eJumpStrength();
				return true;
			}
			return false;
		}

	private function checkBehavior() {
			/* decompiled (structured CF) */
			foreach ($this->behaviors as $index => $behavior) {
				if (($behavior == $this->currentBehavior)) {
					if ($behavior->canContinue()) {
						return $behavior;
					}
					$behavior->onEnd();
					$this->currentBehavior = null;
				}
				if ($behavior->shouldStart()) {
					if ((($this->currentBehavior == null) || ($index < array_search($this->currentBehavior, $this->behaviors)))) {
						if (($this->currentBehavior != null)) {
							$this->currentBehavior->onEnd();
						}
						return $behavior;
					}
				}
				/* goto */
			}
		}

	public function getCurrentBehavior() {
			return $this->currentBehavior;
		}

	public function addBehavior($behavior = null) {
			$this->behaviors[] = $behavior;
			return null;
		}

	public function setBehavior($index = null, $b = null) {
			$this->behaviors[$index] = $b;
			return null;
		}

	public function removeBehavior($key = null) {
			return null;
		}

	public function isBehaviorsEnabled() {
			return $this->behaviorsEnabled;
		}

	public function setBehaviorsEnabled($value = null) {
			$this->behaviorsEnabled = $value;
		}

}
