<?php

namespace pocketmine\entity;

class Squid extends \pocketmine\entity\WaterAnimal {
	public const NETWORK_ID = 17;

	public $width = 0.95;
	public $length = 0.95;
	public $height = 0.95;
	public $dropExp = array (
  0 => 1,
  1 => 3,
);
	public $swimDirection = NULL;
	public $swimSpeed = 0.1;
	private $switchDirectionTicker = 0;

	public function initEntity() {
			parent::initEntity();
			$this->setMaxHealth(5);
			return null;
		}

	public function getName() {
			return 'Squid';
		}

	public function attack($damage = null, $source = null) {
			/* decompiled (structured CF) */
			parent::attack($damage, $source);
			if ($source->isCancelled()) {
				return null;
			}
			if ($source instanceof \pocketmine\event\entity\EntityDamageByEntityEvent) {
				$this->swimSpeed = (mt_rand(150, 350) / 2000);
				$e = $source->getDamager();
				new \pocketmine\math\Vector3(($this->x - $e->x), ($this->y - $e->y), ($this->z - $e->z));
				$this->swimDirection = (new \pocketmine\math\Vector3(($this->x - $e->x), ($this->y - $e->y), ($this->z - $e->z)))->normalize();
				new \pocketmine\network\protocol\EntityEventPacket();
				$pk = new \pocketmine\network\protocol\EntityEventPacket();
				$pk->eid = $this->getId();
				$pk->event = \pocketmine\network\protocol\EntityEventPacket::SQUID_INK_CLOUD;
				\pocketmine\Server::broadcastPacket($this->hasSpawned, $pk);
			}
		}

	private function generateRandomDirection() {
			new \pocketmine\math\Vector3((mt_rand(-1000, 1000) / 1000), (mt_rand(-500, 500) / 1000), (mt_rand(-1000, 1000) / 1000));
			return new \pocketmine\math\Vector3((mt_rand(-1000, 1000) / 1000), (mt_rand(-500, 500) / 1000), (mt_rand(-1000, 1000) / 1000));
		}

	public function onUpdate($currentTick = null) {
			/* decompiled (structured CF) */
			if (($this->closed !== false)) {
				return false;
			}
			if ((0 < $this->attackingTick)) {
			}
			if ((!($this->isAlive()) && $this->hasSpawned)) {
				if ((20 <= $this->deadTicks)) {
					$this->despawnFromAll();
				}
				return true;
			}
			$tickDiff = ($currentTick - $this->lastUpdate);
			if (($tickDiff <= 0)) {
				return false;
			}
			if (($t23 === 100)) {
				$this->switchDirectionTicker = 0;
				if ((mt_rand(0, 100) < 50)) {
					$this->swimDirection = null;
				}
			}
			$this->lastUpdate = $currentTick;
			$this->timings->startTiming();
			$hasUpdate = $this->entityBaseTick($tickDiff);
			if ($this->isAlive()) {
				if (((62 < $this->y) && ($this->swimDirection !== null))) {
					$this->swimDirection->y = -0.5;
				}
				$inWater = $this->isInsideOfWater();
				if (!($inWater)) {
					$this->motionY -= $this->gravity;
					$this->swimDirection = null;
				} else {
					if (($this->swimDirection !== null)) {
						if (((($t50 + $t52) + $t55) <= $this->swimDirection->lengthSquared())) {
							$this->motionX = ($this->swimDirection->x * $this->swimSpeed);
							$this->motionY = ($this->swimDirection->y * $this->swimSpeed);
							$this->motionZ = ($this->swimDirection->z * $this->swimSpeed);
						}
					} else {
						$this->swimDirection = $this->generateRandomDirection();
						$this->swimSpeed = (mt_rand(50, 100) / 2000);
					}
				}
				new \pocketmine\math\Vector3(($this->x + $this->motionX), ($this->y + $this->motionY), ($this->z + $this->motionZ));
				$expectedPos = new \pocketmine\math\Vector3(($this->x + $this->motionX), ($this->y + $this->motionY), ($this->z + $this->motionZ));
				$this->move($this->motionX, $this->motionY, $this->motionZ);
				if ((0 < $expectedPos->distanceSquared($this))) {
					$this->swimDirection = $this->generateRandomDirection();
					$this->swimSpeed = (mt_rand(50, 100) / 2000);
				}
				$friction = (1 - $this->drag);
				$this->motionX *= $friction;
				$this->motionY *= (1 - $this->drag);
				$this->motionZ *= $friction;
				$f = sqrt(($t113 + $t115));
				$this->yaw = (((atan2($this->motionX, $this->motionZ) * -1) * 180) / \M_PI);
				$this->pitch = (((atan2($f, $this->motionY) * -1) * 180) / \M_PI);
				if ($this->onGround) {
					$this->motionY *= -0.5;
				}
				$this->updateMovement();
			}
			$this->timings->stopTiming();
			return (((($hasUpdate || !($this->onGround)) || (1e-05 < abs($this->motionX))) || (1e-05 < abs($this->motionY))) || (1e-05 < abs($this->motionZ)));
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->eid = $this->getId();
			$pk->type = 17;
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->yaw = $this->yaw;
			$pk->pitch = $this->pitch;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

	public function getDrops() {
			return [\pocketmine\item\Item::get(\pocketmine\item\Item::DYE, 0, mt_rand(1, 3))];
		}

}
