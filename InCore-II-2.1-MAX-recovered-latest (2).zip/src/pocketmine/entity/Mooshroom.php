<?php

namespace pocketmine\entity;

class Mooshroom extends \pocketmine\entity\Animal {
	public const NETWORK_ID = 16;

	public $width = 0.3;
	public $length = 0.9;
	public $height = 1.8;

	public function getName() {
			return 'Mooshroom';
		}

	public function usesPm1eGroundAi() {
			return true;
		}

	protected function getBreedingItemIds() {
			return [\pocketmine\item\Item::WHEAT];
		}

	public function onInteract($player = null, $item = null) {
			/* decompiled (structured CF) */
			if ($this->isBaby()) {
				return parent::onInteract($player, $item);
			}
			if (($item->getId() === \pocketmine\item\Item::BOWL)) {
				return $this->replaceInteractionItem($player, $item, \pocketmine\item\Item::get(\pocketmine\item\Item::MUSHROOM_STEW, 0, 1));
			}
			if ((($item->getId() === \pocketmine\item\Item::BUCKET) && ($item->getDamage() === 0))) {
				return $this->replaceInteractionItem($player, $item, \pocketmine\item\Item::get(\pocketmine\item\Item::BUCKET, 1, 1));
			}
			return parent::onInteract($player, $item);
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->eid = $this->getId();
			$pk->type = 16;
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->yaw = $this->yaw;
			$pk->pitch = $this->pitch;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

	public function getDrops() {
			/* decompiled (structured CF) */
			$drops = [\pocketmine\item\Item::get(\pocketmine\item\Item::RED_MUSHROOM, 0, 2)];
			if (($this->lastDamageCause instanceof \pocketmine\event\entity\EntityDamageByEntityEvent && $this->lastDamageCause->getEntity() instanceof \pocketmine\Player)) {
				if ((mt_rand(0, 199) < 5)) {
					switch (mt_rand(0, 2)) {
						case 0:
						$drops[] = \pocketmine\item\Item::get(\pocketmine\item\Item::BROWN_MUSHROOM, 0, 1);
						break;
						case 1:
						$drops[] = \pocketmine\item\Item::get(\pocketmine\item\Item::CARROT, 0, 1);
						break;
						case 2:
						$drops[] = \pocketmine\item\Item::get(\pocketmine\item\Item::POTATO, 0, 1);
						break;
					}
				}
			}
			return $drops;
		}

}
