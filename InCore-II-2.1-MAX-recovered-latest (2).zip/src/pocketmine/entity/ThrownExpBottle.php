<?php

namespace pocketmine\entity;

class ThrownExpBottle extends \pocketmine\entity\Projectile {
	public const NETWORK_ID = 68;

	public $width = 0.25;
	public $length = 0.25;
	public $height = 0.25;
	protected $gravity = 0.1;
	protected $drag = 0.15;

	public function __construct($chunk = null, $nbt = null, $shootingEntity = null) {
			parent::__construct($chunk, $nbt, $shootingEntity);
			return;
		}

	public function onUpdate($currentTick = null) {
			/* decompiled (structured CF) */
			if ($this->closed) {
				return false;
			}
			$this->timings->startTiming();
			$hasUpdate = parent::onUpdate($currentTick);
			if (((1200 < $this->age) || $this->isCollided)) {
				$this->kill();
				$this->close();
				new \pocketmine\level\particle\SpellParticle($this, 46, 82, 153);
				$this->getLevel()->addParticle(new \pocketmine\level\particle\SpellParticle($this, 46, 82, 153));
				if ($this->getLevel()->getServer()->expEnabled) {
					$this->getLevel()->spawnXPOrb($this->add(0, -0.2, 0), mt_rand(1, 4));
					$this->getLevel()->spawnXPOrb($this->add(-0.1, -0.2, 0), mt_rand(1, 4));
					$this->getLevel()->spawnXPOrb($this->add(0, -0.2, -0.1), mt_rand(1, 4));
				}
				$hasUpdate = true;
			}
			$this->timings->stopTiming();
			return $hasUpdate;
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->type = 68;
			$pk->eid = $this->getId();
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

}
