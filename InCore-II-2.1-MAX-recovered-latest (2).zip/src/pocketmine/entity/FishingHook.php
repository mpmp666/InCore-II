<?php

namespace pocketmine\entity;

class FishingHook extends \pocketmine\entity\Projectile {
	public const NETWORK_ID = 77;

	public $width = 0.25;
	public $length = 0.25;
	public $height = 0.25;
	protected $gravity = 0.04;
	protected $drag = 0.05;
	public $lead = -1;
	public $data = 0;
	public $attractTimer = 0;
	public $coughtTimer = 0;
	private $hookedPlayer = NULL;
	private $fishApproachTicks = 0;
	private static $fishLoot = array (
  0 => 
  array (
    0 => 60,
    1 => 349,
    2 => 0,
    3 => 1,
  ),
  1 => 
  array (
    0 => 25,
    1 => 460,
    2 => 0,
    3 => 1,
  ),
  2 => 
  array (
    0 => 7,
    1 => 461,
    2 => 0,
    3 => 1,
  ),
  3 => 
  array (
    0 => 7,
    1 => 462,
    2 => 0,
    3 => 1,
  ),
);
	private static $junkLoot = array (
  0 => 
  array (
    0 => 281,
    1 => 0,
    2 => 1,
  ),
  1 => 
  array (
    0 => 334,
    1 => 0,
    2 => 1,
  ),
  2 => 
  array (
    0 => 301,
    1 => 0,
    2 => 1,
  ),
  3 => 
  array (
    0 => 367,
    1 => 0,
    2 => 1,
  ),
  4 => 
  array (
    0 => 280,
    1 => 0,
    2 => 1,
  ),
  5 => 
  array (
    0 => 287,
    1 => 0,
    2 => 1,
  ),
  6 => 
  array (
    0 => 374,
    1 => 0,
    2 => 1,
  ),
  7 => 
  array (
    0 => 352,
    1 => 0,
    2 => 1,
  ),
  8 => 
  array (
    0 => 351,
    1 => 0,
    2 => 1,
  ),
  9 => 
  array (
    0 => 131,
    1 => 0,
    2 => 1,
  ),
);
	private static $treasureLoot = array (
  0 => 
  array (
    0 => 261,
    1 => 0,
    2 => 1,
  ),
  1 => 
  array (
    0 => 264,
    1 => 0,
    2 => 1,
  ),
  2 => 
  array (
    0 => 346,
    1 => 0,
    2 => 1,
  ),
);

	public function initEntity() {
			/* decompiled (structured CF) */
			parent::initEntity();
			if (isset($this->namedtag->Data)) {
				$this->data = $this->namedtag['Data'];
			}
			return null;
		}

	public function __construct($chunk = null, $nbt = null, $shootingEntity = null) {
			/* decompiled (structured CF) */
			parent::__construct($chunk, $nbt, $shootingEntity);
			if ($shootingEntity instanceof \pocketmine\Player) {
				$this->setLeadHolderEid($shootingEntity->getId());
			}
			$this->resetFishingWait();
			return;
		}

	public function setData($id = null) {
			$this->data = $id;
		}

	public function getData() {
			return $this->data;
		}

	public function setLeadHolderEid($eid = null) {
			/* decompiled (structured CF) */
			$this->lead = ($eid);
			$this->setDataProperty(self::DATA_LEAD_HOLDER, self::DATA_TYPE_LONG, ($eid));
			$this->setDataProperty(self::DATA_LEAD, self::DATA_TYPE_LONG, 0);
			return null;
		}

	public function getHookedPlayer() {
			/* decompiled (structured CF) */
			if (((($this->hookedPlayer instanceof \pocketmine\Player && !($this->hookedPlayer->closed)) && $this->hookedPlayer->isAlive()) && ($this->hookedPlayer->getLevel() === $this->getLevel()))) {
				return $this->hookedPlayer;
			}
			$this->hookedPlayer = null;
		}

	public function hasHookedPlayer() {
			return $this->getHookedPlayer() instanceof \pocketmine\Player;
		}

	public function canCatchFish() {
			return (0 < $this->coughtTimer);
		}

	public function onUpdate($currentTick = null) {
			/* decompiled (structured CF) */
			if ($this->closed) {
				return false;
			}
			$this->timings->startTiming();
			if ($this->hasHookedPlayer()) {
				$tickDiff = ($currentTick - $this->lastUpdate);
				if ((($tickDiff <= 0) && !($this->justCreated))) {
					$this->timings->stopTiming();
					return true;
				}
				$this->lastUpdate = $currentTick;
				$hasUpdate = $this->entityBaseTick($tickDiff);
				if ($this->isAlive()) {
					$hasUpdate = $this->syncHookedPlayer();
				}
				$this->timings->stopTiming();
				return $hasUpdate;
			}
			$oldGravity = $this->gravity;
			if (($this->getWaterSurfaceY() !== null)) {
				$this->gravity = 0;
				$this->motionY = max(-0.05, min(0.05, $this->motionY));
			}
			$hasUpdate = parent::onUpdate($currentTick);
			$this->gravity = $oldGravity;
			if ($this->hasHookedPlayer()) {
				$this->timings->stopTiming();
				return true;
			}
			$this->addTrailParticle();
			if ($this->applyWaterBuoyancy()) {
				$hasUpdate = true;
				$this->tickFishingLogic();
			} else {
				if (($this->isCollided && ($this->keepMovement === true))) {
					$this->motionX = 0;
					$this->motionY = 0;
					$this->motionZ = 0;
					$this->motionChanged = true;
					$this->keepMovement = false;
					$hasUpdate = true;
				}
			}
			$this->timings->stopTiming();
			return $hasUpdate;
		}

	protected function onHitEntity($entityHit = null) {
			/* decompiled (structured CF) */
			if (($entityHit === $this->shootingEntity)) {
				return false;
			}
			if ($entityHit instanceof \pocketmine\Player) {
				new \pocketmine\event\entity\ProjectileHitEvent($this);
				$this->server->getPluginManager()->callEvent(new \pocketmine\event\entity\ProjectileHitEvent($this));
				return $this->attachToPlayer($entityHit);
			}
			return false;
		}

	private function resetFishingWait() {
			/* decompiled (structured CF) */
			$lure = $this->getRodEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_FISHING_LURE);
			$this->attractTimer = max(100, (mt_rand(100, 900) - ($lure * 100)));
			$this->fishApproachTicks = 0;
			$this->coughtTimer = 0;
			return null;
		}

	private function tickFishingLogic() {
			/* decompiled (structured CF) */
			if (!($this->shootingEntity instanceof \pocketmine\Player)) {
				$this->close();
				return null;
			}
			if ((0 < $this->coughtTimer)) {
				if (($this->coughtTimer <= 0)) {
					$this->resetFishingWait();
				}
			}
			if ((0 < $this->fishApproachTicks)) {
				$this->spawnApproachParticles();
				if (($this->fishApproachTicks <= 0)) {
					$this->coughtTimer = mt_rand(20, 40);
					$this->splashBite();
				}
			}
			if ((0 < $this->attractTimer)) {
				if (($this->attractTimer <= 0)) {
					$this->fishApproachTicks = mt_rand(20, 80);
				}
			}
		}

	private function attachToPlayer($player = null) {
			/* decompiled (structured CF) */
			if (($player === $this->shootingEntity)) {
				return false;
			}
			$this->hookedPlayer = $player;
			$this->keepMovement = false;
			$this->isCollided = false;
			$this->hadCollision = true;
			$this->motionX = 0;
			$this->motionY = 0;
			$this->motionZ = 0;
			$this->setPosition($this->getHookedPlayerPosition($player));
			$this->updateMovement();
			new \pocketmine\network\protocol\EntityEventPacket();
			$pk = new \pocketmine\network\protocol\EntityEventPacket();
			$pk->eid = $this->getId();
			$pk->event = \pocketmine\network\protocol\EntityEventPacket::FISH_HOOK_HOOK;
			$this->server->broadcastPacket($this->level->getPlayers(), $pk);
			return true;
		}

	private function syncHookedPlayer() {
			/* decompiled (structured CF) */
			$hookedPlayer = $this->getHookedPlayer();
			if (!($hookedPlayer instanceof \pocketmine\Player)) {
				if (($this->shootingEntity instanceof \pocketmine\Player && ($this->shootingEntity->getFishingHook() === $this))) {
					$this->shootingEntity->unlinkHookFromPlayer();
				} else {
					$this->close();
				}
				return false;
			}
			$this->motionX = 0;
			$this->motionY = 0;
			$this->motionZ = 0;
			$this->setPosition($this->getHookedPlayerPosition($hookedPlayer));
			$this->updateMovement();
			return true;
		}

	private function getHookedPlayerPosition($player = null) {
			new \pocketmine\math\Vector3($player->x, ($player->y + ($player->height * 0.5)), $player->z);
			return new \pocketmine\math\Vector3($player->x, ($player->y + ($player->height * 0.5)), $player->z);
		}

	private function pullHookedPlayer($player = null, $hookedPlayer = null) {
			/* decompiled (structured CF) */
			$dx = ($player->x - $hookedPlayer->x);
			$dy = (($player->y + ($player->height * 0.5)) - ($hookedPlayer->y + ($hookedPlayer->height * 0.5)));
			$dz = ($player->z - $hookedPlayer->z);
			$distance = sqrt((($dx * $dx) + ($dz * $dz)));
			if (($distance <= 0.0001)) {
				return null;
			}
			$motion = $hookedPlayer->getMotion();
			$horizontalPull = min(0.58, (0.22 + ($distance * 0.035)));
			$verticalPull = max(-0.025, min(0.035, ($dy * 0.012)));
			if ($hookedPlayer->isOnGround()) {
				$verticalPull = max(0.018, $verticalPull);
			}
			$motion->x = (($motion->x * 0.15) + ($horizontalPull * ($dx / $distance)));
			$motion->y = (($motion->y * 0.1) + $verticalPull);
			$motion->z = (($motion->z * 0.15) + ($horizontalPull * ($dz / $distance)));
			$motion->x = max(-0.58, min(0.58, $motion->x));
			$motion->y = max(-0.045, min(0.045, $motion->y));
			$motion->z = max(-0.58, min(0.58, $motion->z));
			$hookedPlayer->setMotion($motion);
		}

	private function getWaterSurfaceY() {
			/* decompiled (structured CF) */
			$block = $this->level->getBlock($this->temporalVector->setComponents((floor($this->x)), (floor($this->y)), (floor($this->z))));
			if (!($block instanceof \pocketmine\block\Water)) {
				return null;
			}
			return (($block->y + 1) - ($block->getFluidHeightPercent() - 0.1111111));
		}

	private function applyWaterBuoyancy() {
			/* decompiled (structured CF) */
			$surfaceY = $this->getWaterSurfaceY();
			if (($surfaceY === null)) {
				return false;
			}
			$targetY = ($surfaceY - 0.08);
			$offset = ($targetY - $this->y);
			$this->motionX *= 0.7;
			$this->motionZ *= 0.7;
			if ((abs($this->motionX) < 0.001)) {
				$this->motionX = 0;
			}
			if ((abs($this->motionZ) < 0.001)) {
				$this->motionZ = 0;
			}
			if ((abs($offset) < 0.015)) {
			} else {
			}
			$this->motionY = max(-0.025, min(0.035, ($offset * 0.18)));
			$this->motionChanged = true;
			return true;
		}

	private function addTrailParticle() {
			/* decompiled (structured CF) */
			if ((((((($this->ticksLived % 2) !== 0) || $this->hadCollision) || $this->isCollided) || ($this->getWaterSurfaceY() !== null)) || $this->hasHookedPlayer())) {
				return null;
			}
			new \pocketmine\level\particle\CriticalParticle($this->add((mt_rand(-10, 10) / 100), (($this->height / 2) + (mt_rand(-10, 10) / 100)), (mt_rand(-10, 10) / 100)));
			$this->level->addParticle(new \pocketmine\level\particle\CriticalParticle($this->add((mt_rand(-10, 10) / 100), (($this->height / 2) + (mt_rand(-10, 10) / 100)), (mt_rand(-10, 10) / 100))));
		}

	private function spawnApproachParticles() {
			/* decompiled (structured CF) */
			if ((($this->fishApproachTicks % 5) !== 0)) {
				return null;
			}
			$angle = (mt_rand(0, 628) / 100);
			$distance = max(0.4, ($this->fishApproachTicks / 20));
			new \pocketmine\math\Vector3(($this->x + ($distance * cos($angle))), ($this->y + 0.05), ($this->z + ($distance * sin($angle))));
			new \pocketmine\level\particle\WaterParticle(new \pocketmine\math\Vector3(($this->x + ($distance * cos($angle))), ($this->y + 0.05), ($this->z + ($distance * sin($angle)))));
			$this->level->addParticle(new \pocketmine\level\particle\WaterParticle(new \pocketmine\math\Vector3(($this->x + ($distance * cos($angle))), ($this->y + 0.05), ($this->z + ($distance * sin($angle))))));
		}

	private function splashBite() {
			/* decompiled (structured CF) */
			$i = 0;
			while (($i < 8)) {
				new \pocketmine\math\Vector3(($this->x + (mt_rand(-20, 20) / 100)), ($this->y + 0.1), ($this->z + (mt_rand(-20, 20) / 100)));
				new \pocketmine\level\particle\WaterParticle(new \pocketmine\math\Vector3(($this->x + (mt_rand(-20, 20) / 100)), ($this->y + 0.1), ($this->z + (mt_rand(-20, 20) / 100))));
				$this->level->addParticle(new \pocketmine\level\particle\WaterParticle(new \pocketmine\math\Vector3(($this->x + (mt_rand(-20, 20) / 100)), ($this->y + 0.1), ($this->z + (mt_rand(-20, 20) / 100)))));
				$i++;
			}
			new \pocketmine\math\Vector3($this->x, $this->y, $this->z);
			new \pocketmine\level\sound\SplashSound(new \pocketmine\math\Vector3($this->x, $this->y, $this->z));
			$this->level->addSound(new \pocketmine\level\sound\SplashSound(new \pocketmine\math\Vector3($this->x, $this->y, $this->z)));
			new \pocketmine\network\protocol\EntityEventPacket();
			$pk = new \pocketmine\network\protocol\EntityEventPacket();
			$pk->eid = $this->getId();
			$pk->event = \pocketmine\network\protocol\EntityEventPacket::FISH_HOOK_BUBBLE;
			$this->server->broadcastPacket($this->level->getPlayers(), $pk);
			return null;
		}

	private function getRodEnchantmentLevel($enchantmentId = null) {
			/* decompiled (structured CF) */
			if (!($this->shootingEntity instanceof \pocketmine\Player)) {
				return 0;
			}
			$rod = $this->shootingEntity->getInventory()->getItemInHand();
			if (($rod->getId() !== \pocketmine\item\Item::FISHING_ROD)) {
				return 0;
			}
			return $rod->getEnchantmentLevel($enchantmentId);
		}

	private function rollLoot() {
			/* decompiled (structured CF) */
			$luck = $this->getRodEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_FISHING_FORTUNE);
			$fish = 70;
			$treasure = max(1, (3 + ($luck * 2)));
			$junk = max(1, (27 - ($luck * 2)));
			$roll = mt_rand(1, (($fish + $treasure) + $junk));
			if (($roll <= $treasure)) {
				return $this->itemFromEntry(self::$treasureLoot[array_rand(self::$treasureLoot)]);
			}
			if (($roll <= ($treasure + $junk))) {
				return $this->itemFromEntry(self::$junkLoot[array_rand(self::$junkLoot)]);
			}
			return $this->rollFish();
		}

	private function rollFish() {
			/* decompiled (structured CF) */
			$total = 0;
			foreach (self::$fishLoot as $entry) {
				$total += $entry[0];
				/* goto */
			}
			$roll = mt_rand(1, $total);
			foreach (self::$fishLoot as $entry) {
				$roll -= $entry[0];
				if (($roll <= 0)) {
					return \pocketmine\item\Item::get($entry[1], $entry[2], $entry[3]);
				}
				/* goto */
			}
			return \pocketmine\item\Item::get(\pocketmine\item\Item::RAW_FISH, 0, 1);
		}

	private function itemFromEntry($entry = null) {
			return \pocketmine\item\Item::get($entry[0], $entry[1], $entry[2]);
		}

	private function consumeDurability($player = null, $caughtSomething = null) {
			/* decompiled (structured CF) */
			$itemInHand = $player->getInventory()->getItemInHand();
			if (($itemInHand->getId() !== \pocketmine\item\Item::FISHING_ROD)) {
				return null;
			}
			if ($caughtSomething) {
			} else {
			}
			$damage = 0;
			if (($damage <= 0)) {
			}
			$unbreakingLevel = min(3, $itemInHand->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_DURABILITY));
			if (((0 < $unbreakingLevel) && (mt_rand(1, ($unbreakingLevel + 1)) !== 1))) {
			}
			$itemInHand->setDamage(($itemInHand->getDamage() + $damage));
			$maxDurability = $itemInHand->getMaxDurability();
			if ((($maxDurability !== false) && ($maxDurability <= $itemInHand->getDamage()))) {
				$player->getInventory()->setItemInHand(\pocketmine\item\Item::get(\pocketmine\item\Item::AIR, 0, 0));
			} else {
				$player->getInventory()->setItemInHand($itemInHand);
			}
		}

	public function reelIn() {
			/* decompiled (structured CF) */
			if (!($this->shootingEntity instanceof \pocketmine\Player)) {
				$this->close();
				return null;
			}
			$player = $this->shootingEntity;
			$hookedPlayer = $this->getHookedPlayer();
			if ($hookedPlayer instanceof \pocketmine\Player) {
				$this->pullHookedPlayer($player, $hookedPlayer);
				$this->consumeDurability($player, true);
				$player->unlinkHookFromPlayer();
				$this->close();
			}
			if (!($this->canCatchFish())) {
				$player->unlinkHookFromPlayer();
				$this->close();
			}
			$item = $this->rollLoot();
			new \pocketmine\event\player\PlayerFishEvent($player, $item, $this);
			$ev = new \pocketmine\event\player\PlayerFishEvent($player, $item, $this);
			$this->server->getPluginManager()->callEvent($ev);
			if (!($ev->isCancelled())) {
				$dropPos = $player->getPosition()->add(0, 1.5, 0)->add($player->getDirectionVector()->multiply(0.5));
				new \pocketmine\math\Vector3(0, 0.15, 0);
				$this->level->dropItem($dropPos, $ev->getItem(), new \pocketmine\math\Vector3(0, 0.15, 0));
				$player->addExperience(mt_rand(2, 12));
				new \pocketmine\level\sound\SplashSound($player);
				$this->level->addSound(new \pocketmine\level\sound\SplashSound($player));
				$this->consumeDurability($player, true);
			}
			$player->unlinkHookFromPlayer();
			$this->close();
		}

	public function reeline() {
			$this->reelIn();
			return null;
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->eid = $this->getId();
			$pk->type = self::NETWORK_ID;
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->yaw = $this->yaw;
			$pk->pitch = $this->pitch;
			$pk->modifiers = 0;
			$pk->metadata = $this->dataProperties;
			if ((0 < $this->lead)) {
				$pk->metadata[self::DATA_LEAD_HOLDER] = [self::DATA_TYPE_LONG, $this->lead];
				$pk->metadata[self::DATA_LEAD] = [self::DATA_TYPE_LONG, 0];
			}
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

}
