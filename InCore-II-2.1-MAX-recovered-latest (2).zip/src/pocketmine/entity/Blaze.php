<?php

namespace pocketmine\entity;

class Blaze extends \pocketmine\entity\FlyingAnimal {
	public const NETWORK_ID = 43;

	public $width = 0.3;
	public $length = 0.9;
	public $height = 1.8;
	public $dropExp = array (
  0 => 10,
  1 => 10,
);
	private $attackDelay = 0;
	private $fireballBurst = 0;

	public function getName() {
			return 'Blaze';
		}

	public function initEntity() {
			/* decompiled (structured CF) */
			$this->setMaxHealth(20);
			parent::initEntity();
			$this->fireProof = true;
			return null;
		}

	public function onUpdate($currentTick = null) {
			/* decompiled (structured CF) */
			$hasUpdate = parent::onUpdate($currentTick);
			if ((!($this->closed) && $this->isAlive())) {
				if (($this->attackDelay < 200)) {
				}
				$this->attackNearestPlayer();
			}
			return $hasUpdate;
		}

	protected function attackNearestPlayer() {
			/* decompiled (structured CF) */
			$target = null;
			$bestDistance = 2304;
			foreach ($this->getLevel()->getPlayers() as $player) {
				if ((method_exists($player, 'isAlive') && !($player->isAlive()))) {
					/* goto */
				}
				if ((method_exists($player, 'isSurvival') && method_exists($player, 'isAdventure'))) {
					if ((!($player->isSurvival()) && !($player->isAdventure()))) {
						/* goto */
					}
				}
				if ((property_exists($player, 'closed') && $player->closed)) {
					/* goto */
				}
				$distance = $this->distanceSquared($player);
				if (($distance <= $bestDistance)) {
					$bestDistance = $distance;
					$target = $player;
				}
				/* goto */
			}
			if ($target instanceof \pocketmine\entity\Entity) {
				$this->setPm1eFlyFollowTarget($target);
				$this->attackEntity($target);
			} else {
				$this->setPm1eFlyFollowTarget(null);
			}
			return null;
		}

	public function attackEntity($player = null) {
			/* decompiled (structured CF) */
			if ((($this->attackDelay == 60) && ($this->fireballBurst == 0))) {
				$this->setDataFlag(self::DATA_FLAGS, self::DATA_FLAG_ACTION, true);
			}
			if ((((((0 < $this->fireballBurst) && ($this->fireballBurst < 3)) && (5 < $this->attackDelay)) || ((120 < $this->attackDelay) && (mt_rand(1, 32) < 4))) && ($this->distanceSquared($player) <= 256))) {
				$this->attackDelay = 0;
				if ((3 <= $this->fireballBurst)) {
					$this->fireballBurst = 0;
					$this->setDataFlag(self::DATA_FLAGS, self::DATA_FLAG_ACTION, false);
				}
				new \pocketmine\nbt\tag\DoubleTag('', $this->x);
				new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight()));
				new \pocketmine\nbt\tag\DoubleTag('', $this->z);
				new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight())), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]);
				new \pocketmine\nbt\tag\DoubleTag('', 0);
				new \pocketmine\nbt\tag\DoubleTag('', 0);
				new \pocketmine\nbt\tag\DoubleTag('', 0);
				new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]);
				new \pocketmine\nbt\tag\FloatTag('', $this->yaw);
				new \pocketmine\nbt\tag\FloatTag('', $this->pitch);
				new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $this->yaw), new \pocketmine\nbt\tag\FloatTag('', $this->pitch)]);
				new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight())), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $this->yaw), new \pocketmine\nbt\tag\FloatTag('', $this->pitch)])]);
				$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight())), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $this->yaw), new \pocketmine\nbt\tag\FloatTag('', $this->pitch)])]);
				$fireball = \pocketmine\entity\Entity::createEntity('SmallFireball', $this->chunk, $nbt, $this);
				if ($fireball instanceof \pocketmine\entity\SmallFireball) {
					$fireball->setMotion($player->add(0, 0.3, 0)->subtract($this)->normalize()->multiply(1.2));
					new \pocketmine\event\entity\ProjectileLaunchEvent($fireball);
					$ev = new \pocketmine\event\entity\ProjectileLaunchEvent($fireball);
					$this->server->getPluginManager()->callEvent($ev);
					if ($ev->isCancelled()) {
						$fireball->close();
					} else {
						$fireball->spawnToAll();
					}
				}
			}
			return null;
		}

	public function getDrops() {
			return [\pocketmine\item\Item::get(\pocketmine\item\Item::BLAZE_ROD, 0, mt_rand(0, 1))];
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->eid = $this->getId();
			$pk->type = self::NETWORK_ID;
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->yaw = $this->yaw;
			$pk->pitch = $this->pitch;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

}
