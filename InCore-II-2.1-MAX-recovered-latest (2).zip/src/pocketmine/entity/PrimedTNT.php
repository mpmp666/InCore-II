<?php

namespace pocketmine\entity;

class PrimedTNT extends \pocketmine\entity\Entity implements \pocketmine\entity\Explosive {
	public const NETWORK_ID = 65;

	public $width = 0.98;
	public $length = 0.98;
	public $height = 0.98;
	protected $gravity = 0.04;
	protected $drag = 0.02;
	protected $fuse = NULL;
	public $canCollide = false;

	public function attack($damage = null, $source = null) {
			/* decompiled (structured CF) */
			if (($source->getCause() === \pocketmine\event\entity\EntityDamageEvent::CAUSE_VOID)) {
				parent::attack($damage, $source);
			}
			return null;
		}

	protected function initEntity() {
			/* decompiled (structured CF) */
			parent::initEntity();
			if (isset($this->namedtag->Fuse)) {
				$this->fuse = $this->namedtag['Fuse'];
			} else {
				$this->fuse = 80;
			}
			return null;
		}

	public function canCollideWith($entity = null) {
			return false;
		}

	public function saveNBT() {
			/* decompiled (structured CF) */
			parent::saveNBT();
			new \pocketmine\nbt\tag\ByteTag('Fuse', $this->fuse);
			$this->namedtag->Fuse = new \pocketmine\nbt\tag\ByteTag('Fuse', $this->fuse);
			return null;
		}

	public function onUpdate($currentTick = null) {
			/* decompiled (structured CF) */
			if ($this->closed) {
				return false;
			}
			$this->timings->startTiming();
			$tickDiff = ($currentTick - $this->lastUpdate);
			if ((($tickDiff <= 0) && !($this->justCreated))) {
				return true;
			}
			$this->lastUpdate = $currentTick;
			$hasUpdate = $this->entityBaseTick($tickDiff);
			if ($this->isAlive()) {
				$this->motionY -= $this->gravity;
				$this->move($this->motionX, $this->motionY, $this->motionZ);
				$friction = (1 - $this->drag);
				$this->motionX *= $friction;
				$this->motionY *= $friction;
				$this->motionZ *= $friction;
				$this->updateMovement();
				if ($this->onGround) {
					$this->motionY *= -0.5;
					$this->motionX *= 0.7;
					$this->motionZ *= 0.7;
				}
				$this->fuse -= $tickDiff;
				if (($this->fuse <= 0)) {
					$this->kill();
					$this->explode();
				}
			}
			return (((($hasUpdate || (0 <= $this->fuse)) || (1e-05 < abs($this->motionX))) || (1e-05 < abs($this->motionY))) || (1e-05 < abs($this->motionZ)));
		}

	public function explode() {
			/* decompiled (structured CF) */
			if (!($this->server->tntExplosionEnabled)) {
				return null;
			}
			new \pocketmine\event\entity\ExplosionPrimeEvent($this, 4);
			$ev = new \pocketmine\event\entity\ExplosionPrimeEvent($this, 4);
			$this->server->getPluginManager()->callEvent($ev);
			$blockDamageDisabled = $this->server->isWorldTntBlockDamageDisabled($this->getLevel());
			if ((!($this->server->getConfigString('use-tnt')) && !($ev->isCancelled()))) {
				new \pocketmine\level\Position($this->getX(), $this->getY(), $this->getZ(), $this->getLevel());
				new \pocketmine\level\Explosion(new \pocketmine\level\Position($this->getX(), $this->getY(), $this->getZ(), $this->getLevel()), 8, $this);
				$e = new \pocketmine\level\Explosion(new \pocketmine\level\Position($this->getX(), $this->getY(), $this->getZ(), $this->getLevel()), 8, $this);
				$e->explodeB();
			}
			if (!($ev->isCancelled())) {
				new \pocketmine\level\Position($this->getX(), $this->getY(), $this->getZ(), $this->getLevel());
				new \pocketmine\level\Explosion(new \pocketmine\level\Position($this->getX(), $this->getY(), $this->getZ(), $this->getLevel()), 8, $this);
				$explosion = new \pocketmine\level\Explosion(new \pocketmine\level\Position($this->getX(), $this->getY(), $this->getZ(), $this->getLevel()), 8, $this);
				if ((!($blockDamageDisabled) && $ev->isBlockBreaking())) {
					$explosion->explodeA();
				}
				$explosion->explodeB();
			}
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->type = 65;
			$pk->eid = $this->getId();
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

}
