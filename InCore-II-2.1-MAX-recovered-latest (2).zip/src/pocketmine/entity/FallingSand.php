<?php

namespace pocketmine\entity;

class FallingSand extends \pocketmine\entity\Entity {
	public const NETWORK_ID = 66;

	public $width = 0.98;
	public $length = 0.98;
	public $height = 0.98;
	protected $gravity = 0.04;
	protected $drag = 0.02;
	protected $blockId = 0;
	protected $damage = NULL;
	public $canCollide = false;

	protected function initEntity() {
			/* decompiled (structured CF) */
			parent::initEntity();
			if (isset($this->namedtag->TileID)) {
				$this->blockId = $this->namedtag['TileID'];
			} else {
				if (isset($this->namedtag->Tile)) {
					$this->blockId = $this->namedtag['Tile'];
					new \pocketmine\nbt\tag\IntTag('TileID', $this->blockId);
					$this->namedtag['TileID'] = new \pocketmine\nbt\tag\IntTag('TileID', $this->blockId);
				}
			}
			if (isset($this->namedtag->Data)) {
				$this->damage = $this->namedtag['Data'];
			}
			if (($this->blockId === 0)) {
				$this->close();
				return null;
			}
			$this->setDataProperty(self::DATA_BLOCK_INFO, self::DATA_TYPE_INT, ($this->getBlock() | ($this->getDamage() << 8)));
		}

	public function canCollideWith($entity = null) {
			return false;
		}

	public function attack($damage = null, $source = null) {
			/* decompiled (structured CF) */
			if (($source->getCause() === \pocketmine\event\entity\EntityDamageEvent::CAUSE_VOID)) {
				parent::attack($damage, $source);
			}
			return null;
		}

	public function onUpdate($currentTick = null) {
			/* decompiled (structured CF) */
			if ($this->closed) {
				return false;
			}
			$this->timings->startTiming();
			$tickDiff = ($currentTick - $this->lastUpdate);
			if ((($tickDiff <= 0) && !($this->justCreated))) {
				return true;
			}
			$this->lastUpdate = $currentTick;
			$height = $this->fallDistance;
			$hasUpdate = $this->entityBaseTick($tickDiff);
			if ($this->isAlive()) {
				new \pocketmine\math\Vector3(($this->x - 0.5), $this->y, ($this->z - 0.5));
				$pos = (new \pocketmine\math\Vector3(($this->x - 0.5), $this->y, ($this->z - 0.5)))->round();
				if (($this->ticksLived === 1)) {
					$block = $this->level->getBlock($pos);
					if (($block->getId() !== $this->blockId)) {
						$this->kill();
						return true;
					}
					$this->level->setBlock($pos, \pocketmine\block\Block::get(0), true);
				}
				$this->motionY -= $this->gravity;
				$this->move($this->motionX, $this->motionY, $this->motionZ);
				$friction = (1 - $this->drag);
				$this->motionX *= $friction;
				$this->motionY *= (1 - $this->drag);
				$this->motionZ *= $friction;
				new \pocketmine\math\Vector3(($this->x - 0.5), $this->y, ($this->z - 0.5));
				$pos = (new \pocketmine\math\Vector3(($this->x - 0.5), $this->y, ($this->z - 0.5)))->round();
				if ($this->onGround) {
					$this->kill();
					$block = $this->level->getBlock($pos);
					if ((((0 < $block->getId()) && !($block->isSolid())) && !($block instanceof \pocketmine\block\Liquid))) {
						$this->getLevel()->dropItem($this, \pocketmine\item\Item::get($this->getBlock(), $this->getDamage(), 1));
					} else {
						if ($block instanceof \pocketmine\block\SnowLayer) {
							$oldDamage = $block->getDamage();
							new \pocketmine\event\entity\EntityBlockChangeEvent($this, $block, \pocketmine\block\Block::get($this->getBlock(), ($this->getDamage() + $oldDamage)));
							$ev = new \pocketmine\event\entity\EntityBlockChangeEvent($this, $block, \pocketmine\block\Block::get($this->getBlock(), ($this->getDamage() + $oldDamage)));
							$this->server->getPluginManager()->callEvent($ev);
						} else {
							new \pocketmine\event\entity\EntityBlockChangeEvent($this, $block, \pocketmine\block\Block::get($this->getBlock(), $this->getDamage()));
							$ev = new \pocketmine\event\entity\EntityBlockChangeEvent($this, $block, \pocketmine\block\Block::get($this->getBlock(), $this->getDamage()));
							$this->server->getPluginManager()->callEvent($ev);
						}
						if (!($ev->isCancelled())) {
							$this->getLevel()->setBlock($pos, $ev->getTo(), true);
							if ($ev->getTo() instanceof \pocketmine\block\Anvil) {
								new \pocketmine\level\sound\AnvilFallSound($this);
								$sound = new \pocketmine\level\sound\AnvilFallSound($this);
								$this->getLevel()->addSound($sound);
								foreach ($this->level->getNearbyEntities($this->boundingBox->grow(0.1, 0.1, 0.1), $this) as $entity) {
									$entity->scheduleUpdate();
									if (!($entity->isAlive())) {
										/* goto */
									}
									if ($entity instanceof \pocketmine\entity\Living) {
										$damage = (($height - 1) * 2);
										if ((40 < $damage)) {
											$damage = 40;
										}
										new \pocketmine\event\entity\EntityDamageByEntityEvent($this, $entity, \pocketmine\event\entity\EntityDamageByEntityEvent::CAUSE_FALL, $damage, 0.1);
										$ev = new \pocketmine\event\entity\EntityDamageByEntityEvent($this, $entity, \pocketmine\event\entity\EntityDamageByEntityEvent::CAUSE_FALL, $damage, 0.1);
										$entity->attack($damage, $ev);
									}
									/* goto */
								}
							}
						}
					}
					$hasUpdate = true;
				}
				$this->updateMovement();
			}
			return (((($hasUpdate || !($this->onGround)) || (1e-05 < abs($this->motionX))) || (1e-05 < abs($this->motionY))) || (1e-05 < abs($this->motionZ)));
		}

	public function getBlock() {
			return $this->blockId;
		}

	public function getDamage() {
			return $this->damage;
		}

	public function saveNBT() {
			/* decompiled (structured CF) */
			new \pocketmine\nbt\tag\IntTag('TileID', $this->blockId);
			$this->namedtag->TileID = new \pocketmine\nbt\tag\IntTag('TileID', $this->blockId);
			new \pocketmine\nbt\tag\ByteTag('Data', $this->damage);
			$this->namedtag->Data = new \pocketmine\nbt\tag\ByteTag('Data', $this->damage);
			return null;
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->type = 66;
			$pk->eid = $this->getId();
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->yaw = $this->yaw;
			$pk->pitch = $this->pitch;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

}
