<?php

namespace pocketmine\entity;

class Item extends \pocketmine\entity\Entity {
	public const NETWORK_ID = 64;

	protected $owner = NULL;
	protected $thrower = NULL;
	protected $pickupDelay = 0;
	protected $item = NULL;
	public $width = 0.25;
	public $length = 0.25;
	public $height = 0.25;
	protected $gravity = 0.04;
	protected $drag = 0.02;
	public $canCollide = false;

	protected function initEntity() {
			/* decompiled (structured CF) */
			parent::initEntity();
			$this->setMaxHealth(5);
			$this->setHealth($this->namedtag['Health']);
			if (isset($this->namedtag->Age)) {
				$this->age = $this->namedtag['Age'];
			}
			if (isset($this->namedtag->PickupDelay)) {
				$this->pickupDelay = $this->namedtag['PickupDelay'];
			}
			if (isset($this->namedtag->Owner)) {
				$this->owner = $this->namedtag['Owner'];
			}
			if (isset($this->namedtag->Thrower)) {
				$this->thrower = $this->namedtag['Thrower'];
			}
			if (!(isset($this->namedtag->Item))) {
				$this->close();
				return null;
			}
			$this->item = \pocketmine\nbt\NBT::getItemHelper($this->namedtag->Item);
			if (($this->item->getId() <= 0)) {
				$this->close();
			}
			new \pocketmine\event\entity\ItemSpawnEvent($this);
			$this->server->getPluginManager()->callEvent(new \pocketmine\event\entity\ItemSpawnEvent($this));
		}

	public function attack($damage = null, $source = null) {
			/* decompiled (structured CF) */
			if ((((($source->getCause() === \pocketmine\event\entity\EntityDamageEvent::CAUSE_VOID) || ($source->getCause() === \pocketmine\event\entity\EntityDamageEvent::CAUSE_FIRE_TICK)) || ($source->getCause() === \pocketmine\event\entity\EntityDamageEvent::CAUSE_ENTITY_EXPLOSION)) || ($source->getCause() === \pocketmine\event\entity\EntityDamageEvent::CAUSE_BLOCK_EXPLOSION))) {
				parent::attack($damage, $source);
			}
			return null;
		}

	public function onUpdate($currentTick = null) {
			/* decompiled (structured CF) */
			if ($this->closed) {
				return false;
			}
			$tickDiff = ($currentTick - $this->lastUpdate);
			if ((($tickDiff <= 0) && !($this->justCreated))) {
				return true;
			}
			$this->lastUpdate = $currentTick;
			$this->timings->startTiming();
			$hasUpdate = $this->entityBaseTick($tickDiff);
			if ($this->isAlive()) {
				if (((0 < $this->pickupDelay) && ($this->pickupDelay < 32767))) {
					$this->pickupDelay -= $tickDiff;
					if (($this->pickupDelay < 0)) {
						$this->pickupDelay = 0;
					}
				}
				$this->motionY -= $this->gravity;
				if ($this->checkObstruction($this->x, $this->y, $this->z)) {
					$hasUpdate = true;
				}
				$this->move($this->motionX, $this->motionY, $this->motionZ);
				$friction = (1 - $this->drag);
				if (($this->onGround && ((1e-05 < abs($this->motionX)) || (1e-05 < abs($this->motionZ))))) {
					$friction = ($friction * $this->getLevel()->getBlock($this->temporalVector->setComponents((floor($this->x)), (floor(($this->y - 1))), ((floor($this->z)) - 1)))->getFrictionFactor());
				}
				$this->motionX *= $friction;
				$this->motionY *= (1 - $this->drag);
				$this->motionZ *= $friction;
				if ($this->onGround) {
					$this->motionY *= -0.5;
				}
				if ((($currentTick % 5) == 0)) {
					$this->updateMovement();
				}
				if ((2000 < $this->age)) {
					new \pocketmine\event\entity\ItemDespawnEvent($this);
					$ev = new \pocketmine\event\entity\ItemDespawnEvent($this);
					$this->server->getPluginManager()->callEvent($ev);
					if ($ev->isCancelled()) {
						$this->age = 0;
					} else {
						$this->kill();
						$hasUpdate = true;
					}
				}
			}
			$this->timings->stopTiming();
			return (((($hasUpdate || !($this->onGround)) || (1e-05 < abs($this->motionX))) || (1e-05 < abs($this->motionY))) || (1e-05 < abs($this->motionZ)));
		}

	public function saveNBT() {
			/* decompiled (structured CF) */
			parent::saveNBT();
			$this->namedtag->Item = \pocketmine\nbt\NBT::putItemHelper($this->item);
			new \pocketmine\nbt\tag\ShortTag('Health', $this->getHealth());
			$this->namedtag->Health = new \pocketmine\nbt\tag\ShortTag('Health', $this->getHealth());
			new \pocketmine\nbt\tag\ShortTag('Age', $this->age);
			$this->namedtag->Age = new \pocketmine\nbt\tag\ShortTag('Age', $this->age);
			new \pocketmine\nbt\tag\ShortTag('PickupDelay', $this->pickupDelay);
			$this->namedtag->PickupDelay = new \pocketmine\nbt\tag\ShortTag('PickupDelay', $this->pickupDelay);
			if (($this->owner !== null)) {
				new \pocketmine\nbt\tag\StringTag('Owner', $this->owner);
				$this->namedtag->Owner = new \pocketmine\nbt\tag\StringTag('Owner', $this->owner);
			}
			if (($this->thrower !== null)) {
				new \pocketmine\nbt\tag\StringTag('Thrower', $this->thrower);
				$this->namedtag->Thrower = new \pocketmine\nbt\tag\StringTag('Thrower', $this->thrower);
			}
			return null;
		}

	public function getItem() {
			return $this->item;
		}

	public function canCollideWith($entity = null) {
			return false;
		}

	public function getPickupDelay() {
			return $this->pickupDelay;
		}

	public function setPickupDelay($delay = null) {
			$this->pickupDelay = $delay;
		}

	public function getOwner() {
			return $this->owner;
		}

	public function setOwner($owner = null) {
			$this->owner = $owner;
		}

	public function getThrower() {
			return $this->thrower;
		}

	public function setThrower($thrower = null) {
			$this->thrower = $thrower;
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			$item = $this->getItem();
			$itemMeta = $item->getDamage();
			if (($itemMeta === null)) {
			} else {
			}
			if ((\pocketmine\network\protocol\ProtocolCompatibility::requiresLegacyRedstoneMapping(($player->getProtocol())) && \pocketmine\network\protocol\ProtocolCompatibility::isHiddenItemForProtocol(($player->getProtocol()), $item->getId(), ($itemMeta)))) {
				return null;
			}
			$item = \pocketmine\network\protocol\ProtocolCompatibility::mapItemForProtocol(($player->getProtocol()), $item, false);
			new \pocketmine\network\protocol\AddItemEntityPacket();
			$pk = new \pocketmine\network\protocol\AddItemEntityPacket();
			$pk->eid = $this->getId();
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->item = $item;
			$player->dataPacket($pk);
			$this->sendData($player);
			parent::spawnTo($player);
		}

}
