<?php

namespace pocketmine\entity;

interface Ageable {
	public function isBaby();

	public function setBaby(bool $resting);

}
