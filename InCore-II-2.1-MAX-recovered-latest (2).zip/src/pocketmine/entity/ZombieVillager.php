<?php

namespace pocketmine\entity;

class ZombieVillager extends \pocketmine\entity\Zombie {
	public const NETWORK_ID = 44;
	public const CURE_TIME_MIN = 600;
	public const CURE_TIME_MAX = 1800;

	public $width = 1.031;
	public $length = 0.891;
	public $height = 2.125;

	public function initEntity() {
			/* decompiled (structured CF) */
			$this->setMaxHealth(20);
			parent::initEntity();
			if (!(isset($this->namedtag->Profession))) {
				$this->setProfession(mt_rand(0, 4));
			}
			if (isset($this->namedtag->CureTime)) {
				$this->setCureTime(($this->namedtag['CureTime']));
			}
			$this->setBaby($this->isBaby());
			$this->setDataProperty(self::DATA_PROFESSION_ID, self::DATA_TYPE_BYTE, $this->getProfession());
			return null;
		}

	public function getName() {
			return;
		}

	public function entityBaseTick($tickDiff = null) {
			/* decompiled (structured CF) */
			$hasUpdate = parent::entityBaseTick($tickDiff);
			if (($this->isAlive() && $this->isCuring())) {
				$this->setCureTime(($this->getCureTime() - $tickDiff));
				if (($this->getCureTime() <= 0)) {
					$this->convertToVillager();
					return true;
				}
				$hasUpdate = true;
			}
			return $hasUpdate;
		}

	public function saveNBT() {
			/* decompiled (structured CF) */
			parent::saveNBT();
			new \pocketmine\nbt\tag\ByteTag('Profession', $this->getProfession());
			$this->namedtag->Profession = new \pocketmine\nbt\tag\ByteTag('Profession', $this->getProfession());
			if ($this->isCuring()) {
				new \pocketmine\nbt\tag\IntTag('CureTime', $this->getCureTime());
				$this->namedtag->CureTime = new \pocketmine\nbt\tag\IntTag('CureTime', $this->getCureTime());
			} else {
			}
			return null;
		}

	public function setProfession($profession = null) {
			/* decompiled (structured CF) */
			new \pocketmine\nbt\tag\ByteTag('Profession', min(4, max(0, $profession)));
			$this->namedtag->Profession = new \pocketmine\nbt\tag\ByteTag('Profession', min(4, max(0, $profession)));
			$this->setDataProperty(self::DATA_PROFESSION_ID, self::DATA_TYPE_BYTE, $this->getProfession());
			return null;
		}

	public function getProfession() {
			/* decompiled (structured CF) */
			if (isset($this->namedtag->Profession)) {
			} else {
			}
			$profession = 0;
			return min(4, max(0, $profession));
		}

	public function canStartCure() {
			return (!($this->isCuring()) && $this->hasEffect(\pocketmine\entity\Effect::WEAKNESS));
		}

	public function attemptCureWith($item = null) {
			/* decompiled (structured CF) */
			if ((($item->getId() !== \pocketmine\item\Item::GOLDEN_APPLE) || !($this->canStartCure()))) {
				return false;
			}
			$this->startCure();
			return true;
		}

	public function startCure($time = null) {
			/* decompiled (structured CF) */
			if (($time === null)) {
			} else {
			}
			$this->setCureTime($time);
			new \pocketmine\level\sound\ZombieHealSound($this);
			$this->getLevel()->addSound(new \pocketmine\level\sound\ZombieHealSound($this));
			return null;
		}

	public function isCuring() {
			return (0 < $this->getCureTime());
		}

	public function getCureTime() {
			/* decompiled (structured CF) */
			if (isset($this->namedtag->CureTime)) {
			} else {
			}
			return 0;
		}

	protected function setCureTime($time = null) {
			/* decompiled (structured CF) */
			if ((0 < $time)) {
				new \pocketmine\nbt\tag\IntTag('CureTime', $time);
				$this->namedtag->CureTime = new \pocketmine\nbt\tag\IntTag('CureTime', $time);
			} else {
			}
			return null;
		}

	protected function convertToVillager() {
			/* decompiled (structured CF) */
			$chunk = $this->getLevel()->getChunk(($this->x >> 4), ($this->z >> 4), true);
			if (($chunk === null)) {
				return null;
			}
			new \pocketmine\nbt\tag\DoubleTag(0, $this->x);
			new \pocketmine\nbt\tag\DoubleTag(1, $this->y);
			new \pocketmine\nbt\tag\DoubleTag(2, $this->z);
			new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag(0, $this->x), new \pocketmine\nbt\tag\DoubleTag(1, $this->y), new \pocketmine\nbt\tag\DoubleTag(2, $this->z)]);
			new \pocketmine\nbt\tag\DoubleTag(0, $this->motionX);
			new \pocketmine\nbt\tag\DoubleTag(1, $this->motionY);
			new \pocketmine\nbt\tag\DoubleTag(2, $this->motionZ);
			new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag(0, $this->motionX), new \pocketmine\nbt\tag\DoubleTag(1, $this->motionY), new \pocketmine\nbt\tag\DoubleTag(2, $this->motionZ)]);
			new \pocketmine\nbt\tag\FloatTag(0, $this->yaw);
			new \pocketmine\nbt\tag\FloatTag(1, $this->pitch);
			new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag(0, $this->yaw), new \pocketmine\nbt\tag\FloatTag(1, $this->pitch)]);
			new \pocketmine\nbt\tag\ByteTag('Profession', $this->getProfession());
			if ($this->isBaby()) {
			} else {
			}
			new \pocketmine\nbt\tag\ByteTag('IsBaby', 0);
			new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag(0, $this->x), new \pocketmine\nbt\tag\DoubleTag(1, $this->y), new \pocketmine\nbt\tag\DoubleTag(2, $this->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag(0, $this->motionX), new \pocketmine\nbt\tag\DoubleTag(1, $this->motionY), new \pocketmine\nbt\tag\DoubleTag(2, $this->motionZ)]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag(0, $this->yaw), new \pocketmine\nbt\tag\FloatTag(1, $this->pitch)]), new \pocketmine\nbt\tag\ByteTag('Profession', $this->getProfession()), new \pocketmine\nbt\tag\ByteTag('IsBaby', 0)]);
			$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag(0, $this->x), new \pocketmine\nbt\tag\DoubleTag(1, $this->y), new \pocketmine\nbt\tag\DoubleTag(2, $this->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag(0, $this->motionX), new \pocketmine\nbt\tag\DoubleTag(1, $this->motionY), new \pocketmine\nbt\tag\DoubleTag(2, $this->motionZ)]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag(0, $this->yaw), new \pocketmine\nbt\tag\FloatTag(1, $this->pitch)]), new \pocketmine\nbt\tag\ByteTag('Profession', $this->getProfession()), new \pocketmine\nbt\tag\ByteTag('IsBaby', 0)]);
			if (isset($this->namedtag->Offers)) {
				$nbt->Offers = clone $this->namedtag->Offers;
			}
			new \pocketmine\entity\Villager($chunk, $nbt);
			$villager = new \pocketmine\entity\Villager($chunk, $nbt);
			$villager->setHealth($villager->getMaxHealth());
			$villager->spawnToAll();
			$this->close();
		}

}
