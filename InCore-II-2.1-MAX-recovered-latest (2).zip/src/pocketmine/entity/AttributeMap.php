<?php

namespace pocketmine\entity;

class AttributeMap implements \ArrayAccess {
	private $attributes = array (
);

	public function addAttribute($attribute = null) {
			$this->attributes[$attribute->getId()] = $attribute;
			return null;
		}

	public function getAttribute($id = null) {
			return null;
		}

	public function needSend() {
			return array_filter($this->attributes, function () { /* unrecovered lambda E:/Desktop/src/src/pocketmine/entity/AttributeMap.php.702Oma */ return null; });
		}

	public function offsetExists($offset = null) {
			return isset($this->attributes[$offset]);
		}

	public function offsetGet($offset = null) {
			return $this->attributes[$offset]->getValue();
		}

	public function offsetSet($offset = null, $value = null) {
			$this->attributes[$offset]->setValue($value);
			return null;
		}

	public function offsetUnset($offset = null) {
			new \RuntimeException($this);
			throw new \RuntimeException($this);
			return null;
		}

}
