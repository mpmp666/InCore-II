<?php

namespace pocketmine\entity;

class Arrow extends \pocketmine\entity\Projectile {
	public const NETWORK_ID = 80;

	public $width = 0.5;
	public $length = 0.5;
	public $height = 0.5;
	protected $gravity = 0.05;
	protected $drag = 0.01;
	protected $damage = 2;
	protected $isCritical = NULL;
	protected $knockBack = 0.4;
	protected $arrowItem = NULL;

	public function __construct($chunk = null, $nbt = null, $shootingEntity = null, $critical = null) {
			/* decompiled (structured CF) */
			$this->isCritical = $critical;
			parent::__construct($chunk, $nbt, $shootingEntity);
			$arrowMeta = 0;
			if (isset($this->namedtag->Potion)) {
				$arrowMeta = ($this->namedtag['Potion']);
			} else {
				if (isset($this->namedtag->PotionId)) {
					$arrowMeta = \pocketmine\item\Arrow::getArrowMetaFromPotionMeta(($this->namedtag['PotionId']));
				}
			}
			$this->setArrowItem(\pocketmine\item\Item::get(\pocketmine\item\Item::ARROW, $arrowMeta, 1));
			return;
		}

	public function setBaseDamage($damage = null) {
			$this->damage = max(0, ($damage));
			return null;
		}

	public function getBaseDamage() {
			return $this->damage;
		}

	public function setKnockBack($knockBack = null) {
			$this->knockBack = max(0, ($knockBack));
			return null;
		}

	protected function getProjectileKnockBack() {
			return $this->knockBack;
		}

	public function setArrowItem($arrow = null) {
			/* decompiled (structured CF) */
			if (!($arrow instanceof \pocketmine\item\Arrow)) {
				$arrow = \pocketmine\item\Item::get(\pocketmine\item\Item::ARROW, 0, 1);
			} else {
				$arrow = clone $arrow;
				$arrow->setCount(1);
			}
			$this->arrowItem = $arrow;
			return null;
		}

	public function getArrowItem() {
			return clone $this->arrowItem;
		}

	public function getPotionId() {
			/* decompiled (structured CF) */
			if (($this->arrowItem instanceof \pocketmine\item\Arrow && $this->arrowItem->isTipped())) {
			} else {
			}
			return 0;
		}

	public function applyTippedArrowEffects($entity = null) {
			/* decompiled (structured CF) */
			if ((!($this->arrowItem instanceof \pocketmine\item\Arrow) || !($this->arrowItem->isTipped()))) {
				return null;
			}
			foreach (\pocketmine\item\Potion::getArrowEffectsByMeta(($this->arrowItem->getPotionMeta())) as $effect) {
				$entity->addEffect($effect);
				/* goto */
			}
		}

	public function saveNBT() {
			/* decompiled (structured CF) */
			parent::saveNBT();
			new \pocketmine\nbt\tag\ShortTag('Potion', $this->getPotionId());
			$this->namedtag->Potion = new \pocketmine\nbt\tag\ShortTag('Potion', $this->getPotionId());
			return null;
		}

	public function onUpdate($currentTick = null) {
			/* decompiled (structured CF) */
			if ($this->closed) {
				return false;
			}
			$this->timings->startTiming();
			$hasUpdate = parent::onUpdate($currentTick);
			if ((!($this->hadCollision) && $this->isCritical)) {
				new \pocketmine\level\particle\CriticalParticle($this->add((($this->width / 2) + (mt_rand(-100, 100) / 500)), (($this->height / 2) + (mt_rand(-100, 100) / 500)), (($this->width / 2) + (mt_rand(-100, 100) / 500))));
				$this->level->addParticle(new \pocketmine\level\particle\CriticalParticle($this->add((($this->width / 2) + (mt_rand(-100, 100) / 500)), (($this->height / 2) + (mt_rand(-100, 100) / 500)), (($this->width / 2) + (mt_rand(-100, 100) / 500)))));
			} else {
				if ($this->onGround) {
					$this->isCritical = false;
				}
			}
			if (($this->arrowItem instanceof \pocketmine\item\Arrow && $this->arrowItem->isTipped())) {
				if ((!($this->onGround) || ($this->onGround && (($currentTick % 4) === 0)))) {
					$color = \pocketmine\item\Potion::getColor(($this->arrowItem->getPotionMeta()));
					new \pocketmine\level\particle\MobSpellParticle($this->add((($this->width / 2) + (mt_rand(-100, 100) / 500)), (($this->height / 2) + (mt_rand(-100, 100) / 500)), (($this->width / 2) + (mt_rand(-100, 100) / 500))), $color[0], $color[1], $color[2]);
					$this->level->addParticle(new \pocketmine\level\particle\MobSpellParticle($this->add((($this->width / 2) + (mt_rand(-100, 100) / 500)), (($this->height / 2) + (mt_rand(-100, 100) / 500)), (($this->width / 2) + (mt_rand(-100, 100) / 500))), $color[0], $color[1], $color[2]), $this->getViewers());
				}
				$hasUpdate = true;
			}
			if ((1200 < $this->age)) {
				$this->kill();
				$hasUpdate = true;
			}
			$this->timings->stopTiming();
			return $hasUpdate;
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->type = 80;
			$pk->eid = $this->getId();
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

}
