<?php

namespace pocketmine\entity;

class Fireball extends \pocketmine\entity\SmallFireball implements \pocketmine\entity\Explosive {
	public const NETWORK_ID = 85;

	public $width = 1.0;
	public $length = 1.0;
	public $height = 1.0;
	protected $damage = 2;

	public function __construct($chunk = null, $nbt = null, $shootingEntity = null) {
			parent::__construct($chunk, $nbt, $shootingEntity);
			return;
		}

	public function onUpdate($currentTick = null) {
			/* decompiled (structured CF) */
			if ($this->closed) {
				return false;
			}
			$this->timings->startTiming();
			$hasUpdate = parent::onUpdate($currentTick);
			if ($this->isCollided) {
				$this->explode();
				$this->kill();
				$hasUpdate = true;
			}
			$this->timings->stopTiming();
			return $hasUpdate;
		}

	protected function onHitEntity($entityHit = null) {
			/* decompiled (structured CF) */
			$hit = parent::onHitEntity($entityHit);
			if ($hit) {
				$this->explode();
			}
			return $hit;
		}

	public function explode() {
			/* decompiled (structured CF) */
			if ($this->closed) {
				return null;
			}
			new \pocketmine\level\Explosion($this, 1, $this);
			$explosion = new \pocketmine\level\Explosion($this, 1, $this);
			$explosion->explodeB();
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->type = self::NETWORK_ID;
			$pk->eid = $this->getId();
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

}
