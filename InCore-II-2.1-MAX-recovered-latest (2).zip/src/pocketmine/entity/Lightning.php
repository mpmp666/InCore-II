<?php

namespace pocketmine\entity;

class Lightning extends \pocketmine\entity\Animal {
	public const NETWORK_ID = 93;

	public $width = 0.3;
	public $length = 0.9;
	public $height = 1.8;

	public function getName() {
			return 'Lightning';
		}

	public function initEntity() {
			/* decompiled (structured CF) */
			parent::initEntity();
			$this->setMaxHealth(2);
			$this->setHealth(2);
			return null;
		}

	public function onUpdate($tick = null) {
			/* decompiled (structured CF) */
			parent::onUpdate($tick);
			if ((20 < $this->age)) {
				$this->kill();
				$this->close();
			}
			return true;
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->eid = $this->getId();
			$pk->type = self::NETWORK_ID;
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->yaw = $this->yaw;
			$pk->pitch = $this->pitch;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			new \pocketmine\network\protocol\ExplodePacket();
			$pk = new \pocketmine\network\protocol\ExplodePacket();
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->radius = 10;
			$pk->records = ['__array_ptr' => '2aaaac9fc9a0'];
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

	public function spawnToAll() {
			/* decompiled (structured CF) */
			parent::spawnToAll();
			if ($this->getLevel()->getServer()->lightningFire) {
				$fire = \pocketmine\item\Item::get(\pocketmine\item\Item::FIRE)->getBlock();
				$oldBlock = $this->getLevel()->getBlock($this);
				if ($oldBlock instanceof \pocketmine\block\Liquid) {
				} else {
					if ($oldBlock->isSolid()) {
						new \pocketmine\math\Vector3($this->x, ($this->y + 1), $this->z);
						$v3 = new \pocketmine\math\Vector3($this->x, ($this->y + 1), $this->z);
					} else {
						new \pocketmine\math\Vector3($this->x, $this->y, $this->z);
						$v3 = new \pocketmine\math\Vector3($this->x, $this->y, $this->z);
					}
				}
				if ($t33) {
					$this->getLevel()->setBlock($v3, $fire);
				}
				foreach ($this->level->getNearbyEntities($this->boundingBox->grow(4, 3, 4), $this) as $entity) {
					if ($entity instanceof \pocketmine\Player) {
						$damage = mt_rand(8, 20);
						new \pocketmine\event\entity\EntityDamageByEntityEvent($this, $entity, \pocketmine\event\entity\EntityDamageByEntityEvent::CAUSE_LIGHTNING, $damage);
						$ev = new \pocketmine\event\entity\EntityDamageByEntityEvent($this, $entity, \pocketmine\event\entity\EntityDamageByEntityEvent::CAUSE_LIGHTNING, $damage);
						if (($entity->attack($ev->getFinalDamage(), $ev) === true)) {
							$ev->useArmors();
						}
						$entity->setOnFire(mt_rand(3, 8));
					}
					if ($entity instanceof \pocketmine\entity\Creeper) {
						$entity->setPowered(true, $this);
					}
					/* goto */
				}
			}
			return null;
		}

}
