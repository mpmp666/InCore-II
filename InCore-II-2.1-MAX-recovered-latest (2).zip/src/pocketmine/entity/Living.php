<?php

namespace pocketmine\entity;

abstract class Living extends \pocketmine\entity\Entity implements \pocketmine\entity\Damageable {
	protected $gravity = 0.08;
	protected $drag = 0.02;
	protected $attackTime = 0;
	protected $invisible = false;
	private $lastLootingLevel = 0;

	protected function initEntity() {
			/* decompiled (structured CF) */
			parent::initEntity();
			if (isset($this->namedtag->HealF)) {
				new \pocketmine\nbt\tag\ShortTag('Health', ($this->namedtag['HealF']));
				$this->namedtag->Health = new \pocketmine\nbt\tag\ShortTag('Health', ($this->namedtag['HealF']));
			}
			if ((!(isset($this->namedtag->Health)) || !($this->namedtag->Health instanceof \pocketmine\nbt\tag\ShortTag))) {
				new \pocketmine\nbt\tag\ShortTag('Health', $this->getMaxHealth());
				$this->namedtag->Health = new \pocketmine\nbt\tag\ShortTag('Health', $this->getMaxHealth());
			}
			if (($this->namedtag['Health'] <= 0)) {
				$this->setHealth(20);
			} else {
				$this->setHealth($this->namedtag['Health']);
			}
			return null;
		}

	public function setHealth($amount = null) {
			/* decompiled (structured CF) */
			$wasAlive = $this->isAlive();
			parent::setHealth($amount);
			if (($this->isAlive() && !($wasAlive))) {
				new \pocketmine\network\protocol\EntityEventPacket();
				$pk = new \pocketmine\network\protocol\EntityEventPacket();
				$pk->eid = $this->getId();
				$pk->event = \pocketmine\network\protocol\EntityEventPacket::RESPAWN;
				\pocketmine\Server::broadcastPacket($this->hasSpawned, $pk);
			}
			return null;
		}

	public function saveNBT() {
			/* decompiled (structured CF) */
			parent::saveNBT();
			new \pocketmine\nbt\tag\ShortTag('Health', $this->getHealth());
			$this->namedtag->Health = new \pocketmine\nbt\tag\ShortTag('Health', $this->getHealth());
			return null;
		}

	public abstract function getName();

	public function hasLineOfSight($entity = null) {
			return true;
		}

	public function heal($amount = null, $source = null) {
			/* decompiled (structured CF) */
			parent::heal($amount, $source);
			if ($source->isCancelled()) {
				return null;
			}
			$this->attackTime = 0;
		}

	public function attack($damage = null, $source = null) {
			/* decompiled (structured CF) */
			if (((0 < $this->attackTime) || (0 < $this->noDamageTicks))) {
				if (($source->getCause() === \pocketmine\event\entity\EntityDamageEvent::CAUSE_ENTITY_ATTACK)) {
					$source->setCancelled();
				} else {
					$lastCause = $this->getLastDamageCause();
					if ((($lastCause !== null) && ($damage <= $lastCause->getDamage()))) {
						$source->setCancelled();
					}
				}
			}
			if ($source->isCancelled()) {
				return false;
			}
			$this->captureLootingLevel($source);
			if (((!($source->isCancelled()) && !($this instanceof \pocketmine\Player)) && method_exists($this, 'getArmorContents'))) {
				switch ($source->getCause()) {
					case \pocketmine\event\entity\EntityDamageEvent::CAUSE_CONTACT:
					case \pocketmine\event\entity\EntityDamageEvent::CAUSE_ENTITY_ATTACK:
					case \pocketmine\event\entity\EntityDamageEvent::CAUSE_PROJECTILE:
					case \pocketmine\event\entity\EntityDamageEvent::CAUSE_FIRE:
					case \pocketmine\event\entity\EntityDamageEvent::CAUSE_LAVA:
					case \pocketmine\event\entity\EntityDamageEvent::CAUSE_BLOCK_EXPLOSION:
					case \pocketmine\event\entity\EntityDamageEvent::CAUSE_ENTITY_EXPLOSION:
					case \pocketmine\event\entity\EntityDamageEvent::CAUSE_LIGHTNING:
					$source->setDamage(\pocketmine\entity\VanillaMobEquipment::applyArmorReduction($source->getDamage(), $this->getArmorContents(), $source->getCause()));
					$damage = $source->getFinalDamage();
					/* jump */
					parent::attack($damage, $source);
					if ($source->isCancelled()) {
						$this->lastLootingLevel = 0;
						return false;
					}
					if ($this->closed) {
						return true;
					}
					if ($source instanceof \pocketmine\event\entity\EntityDamageByEntityEvent) {
						if (!($source->getDamager() instanceof \pocketmine\Player)) {
							\pocketmine\item\Tool::applyWeaponHitEffects($source);
						}
						$e = $source->getDamager();
						if ($source instanceof \pocketmine\event\entity\EntityDamageByChildEntityEvent) {
							$e = $source->getChild();
						}
						if ((0 < $e->isOnFire())) {
							$this->setOnFire(($this->server->getDifficulty() * 2));
						}
						$deltaX = ($this->x - $e->x);
						$deltaZ = ($this->z - $e->z);
						$this->knockBack($e, $damage, $deltaX, $deltaZ, $source->getKnockBack());
						if ($source instanceof \pocketmine\event\entity\EntityDamageByChildEntityEvent) {
						} else {
						}
						$this->applyThornsDamage($source, $e);
					}
					new \pocketmine\network\protocol\EntityEventPacket();
					$pk = new \pocketmine\network\protocol\EntityEventPacket();
					$pk->eid = $this->getId();
					if (($this->getHealth() <= 0)) {
					} else {
					}
					$pk->event = \pocketmine\network\protocol\EntityEventPacket::HURT_ANIMATION;
					\pocketmine\Server::broadcastPacket($this->hasSpawned, $pk);
					$this->attackTime = 10;
					$this->noDamageTicks = max($this->noDamageTicks, 10);
					return true;
				}
			}
		}

	public function knockBack($attacker = null, $damage = null, $x = null, $z = null, $base = null) {
			/* decompiled (structured CF) */
			$f = sqrt((($x * $x) + ($z * $z)));
			if (($f <= 0)) {
				$yaw = $attacker->yaw;
				$x = sin(deg2rad($yaw));
				$z = (cos(deg2rad($yaw)) * -1);
				$f = sqrt((($x * $x) + ($z * $z)));
				if (($f <= 0)) {
					return null;
				}
			}
			$f = (1 / $f);
			$motion = $this->getMotion();
			$motion->x = (($motion->x * 0.5) + ($base * ($x * $f)));
			$motion->z = (($motion->z * 0.5) + ($base * ($z * $f)));
			$motion->y = min(0.4, max(0.15, ($base * 0.3)));
			$this->setMotion($motion);
		}

	public function kill() {
			/* decompiled (structured CF) */
			if (!($this->isAlive())) {
				return null;
			}
			parent::kill();
			$dropDisabled = $this->server->isWorldMobDeathDropsAndExperienceDisabled($this->getLevel());
			if ($dropDisabled) {
			} else {
				if ($this->handlesLootingDrops()) {
				} else {
				}
			}
			$drops = $this->applyLootingDrops($this->getDrops());
			new \pocketmine\event\entity\EntityDeathEvent($this, $drops);
			$ev = new \pocketmine\event\entity\EntityDeathEvent($this, $drops);
			$this->server->getPluginManager()->callEvent($ev);
			if (!($dropDisabled)) {
				foreach ($ev->getDrops() as $item) {
					$this->getLevel()->dropItem($this, $item);
					/* goto */
				}
			}
		}

	protected function getLastDamageLootingLevel() {
			return $this->lastLootingLevel;
		}

	protected function handlesLootingDrops() {
			return false;
		}

	private function captureLootingLevel($source = null) {
			/* decompiled (structured CF) */
			$this->lastLootingLevel = 0;
			if ($source instanceof \pocketmine\event\entity\EntityDamageByEntityEvent) {
				$damager = $source->getDamager();
				if ($source instanceof \pocketmine\event\entity\EntityDamageByChildEntityEvent) {
					$damager = $source->getChild();
				}
				if ($damager instanceof \pocketmine\Player) {
					$this->lastLootingLevel = min(3, $damager->getInventory()->getItemInHand()->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_WEAPON_LOOTING));
				}
			}
			return null;
		}

	private function applyLootingDrops($drops = null) {
			/* decompiled (structured CF) */
			if ((($this->lastLootingLevel <= 0) || $this instanceof \pocketmine\Player)) {
				return $drops;
			}
			foreach ($drops as $item) {
				if ((!($item instanceof \pocketmine\item\Item) || ($item->getId() === \pocketmine\item\Item::AIR))) {
					/* goto */
				}
				$extra = mt_rand(0, $this->lastLootingLevel);
				if (($extra <= 0)) {
					/* goto */
				}
				$bonus = clone $item;
				$bonus->setCount($extra);
				$drops[] = $bonus;
				/* goto */
			}
			return $drops;
		}

	private function applyThornsDamage($source = null, $attacker = null) {
			/* decompiled (structured CF) */
			if (((!($this instanceof \pocketmine\Player) || ($source->getCause() === \pocketmine\event\entity\EntityDamageEvent::CAUSE_MAGIC)) || !($attacker->isAlive()))) {
				return null;
			}
			$inventory = $this->getInventory();
			$armor = $inventory->getArmorContents();
			$changed = false;
			foreach ($armor as $index => $item) {
				if ($item->isArmor()) {
				} else {
				}
				$level = 0;
				if ((($level <= 0) || (($level * 15) < mt_rand(1, 100)))) {
					/* goto */
				}
				$damage = mt_rand(1, 4);
				new \pocketmine\event\entity\EntityDamageEvent($attacker, \pocketmine\event\entity\EntityDamageEvent::CAUSE_MAGIC, $damage);
				$ev = new \pocketmine\event\entity\EntityDamageEvent($attacker, \pocketmine\event\entity\EntityDamageEvent::CAUSE_MAGIC, $damage);
				$attacker->attack($ev->getFinalDamage(), $ev);
				if (!($item->isUnbreakable())) {
					$item->setDamage(($item->getDamage() + 3));
					if (($item->getMaxDurability() <= $item->getDamage())) {
						$armor[$index] = \pocketmine\item\Item::get(\pocketmine\item\Item::AIR, 0, 0);
					} else {
						$armor[$index] = $item;
					}
					$changed = true;
				}
				/* jump */
				/* goto */
			}
			if ($changed) {
				$inventory->setArmorContents($armor);
			}
		}

	public function entityBaseTick($tickDiff = null) {
			/* decompiled (structured CF) */
			\pocketmine\event\Timings::$timerLivingEntityBaseTick->startTiming();
			$hasUpdate = parent::entityBaseTick($tickDiff);
			if ($this->isAlive()) {
				if ($this->isInsideOfSolid()) {
					$hasUpdate = true;
					new \pocketmine\event\entity\EntityDamageEvent($this, \pocketmine\event\entity\EntityDamageEvent::CAUSE_SUFFOCATION, 1);
					$ev = new \pocketmine\event\entity\EntityDamageEvent($this, \pocketmine\event\entity\EntityDamageEvent::CAUSE_SUFFOCATION, 1);
					$this->attack($ev->getFinalDamage(), $ev);
				}
				if ((!($this->hasEffect(\pocketmine\entity\Effect::WATER_BREATHING)) && $this->isInsideOfWater())) {
					if ($this instanceof \pocketmine\entity\WaterAnimal) {
						$this->setDataProperty(self::DATA_AIR, self::DATA_TYPE_SHORT, 300);
					} else {
						$hasUpdate = true;
						if ($this instanceof \pocketmine\Player) {
						} else {
						}
						$respiration = 0;
						$airLoss = $tickDiff;
						if ((0 < $respiration)) {
							$airLoss = 0;
							$i = 0;
							while (($i < $tickDiff)) {
								if ((mt_rand(0, $respiration) === 0)) {
									$airLoss++;
								}
								$i++;
							}
						}
						$airTicks = ($this->getDataProperty(self::DATA_AIR) - $airLoss);
						if (($airTicks <= -20)) {
							$airTicks = 0;
							new \pocketmine\event\entity\EntityDamageEvent($this, \pocketmine\event\entity\EntityDamageEvent::CAUSE_DROWNING, 2);
							$ev = new \pocketmine\event\entity\EntityDamageEvent($this, \pocketmine\event\entity\EntityDamageEvent::CAUSE_DROWNING, 2);
							$this->attack($ev->getFinalDamage(), $ev);
						}
						$this->setDataProperty(self::DATA_AIR, self::DATA_TYPE_SHORT, $airTicks);
					}
				} else {
					if ($this instanceof \pocketmine\entity\WaterAnimal) {
						$hasUpdate = true;
						$airTicks = ($this->getDataProperty(self::DATA_AIR) - $tickDiff);
						if (($airTicks <= -20)) {
							$airTicks = 0;
							new \pocketmine\event\entity\EntityDamageEvent($this, \pocketmine\event\entity\EntityDamageEvent::CAUSE_SUFFOCATION, 2);
							$ev = new \pocketmine\event\entity\EntityDamageEvent($this, \pocketmine\event\entity\EntityDamageEvent::CAUSE_SUFFOCATION, 2);
							$this->attack($ev->getFinalDamage(), $ev);
						}
						$this->setDataProperty(self::DATA_AIR, self::DATA_TYPE_SHORT, $airTicks);
					} else {
						$this->setDataProperty(self::DATA_AIR, self::DATA_TYPE_SHORT, 300);
					}
				}
			}
			if ((0 < $this->attackTime)) {
				$this->attackTime -= $tickDiff;
			}
			\pocketmine\event\Timings::$timerLivingEntityBaseTick->stopTiming();
			return $hasUpdate;
		}

	public function getDrops() {
			return ['__array_ptr' => '2aaaac9fc9a0'];
		}

	public function getLineOfSight($maxDistance = null, $maxLength = null, $transparent = null) {
			/* decompiled (structured CF) */
			if ((120 < $maxDistance)) {
				$maxDistance = 120;
			}
			if ((count($transparent) === 0)) {
				$transparent = null;
			}
			$blocks = ['__array_ptr' => '2aaaac9fc9a0'];
			$nextIndex = 0;
			new \pocketmine\utils\BlockIterator($this->level, $this->getPosition(), $this->getDirectionVector(), $this->getEyeHeight(), $maxDistance);
			$itr = new \pocketmine\utils\BlockIterator($this->level, $this->getPosition(), $this->getDirectionVector(), $this->getEyeHeight(), $maxDistance);
			while ($itr->valid()) {
				$itr->next();
				$block = $itr->current();
				$nextIndex++;
				$blocks[$nextIndex] = $block;
				if ((($maxLength !== 0) && ($maxLength < count($blocks)))) {
					array_shift($blocks);
					$nextIndex--;
				}
				$id = $block->getId();
				if (($transparent === null)) {
					if (($id !== 0)) {
					} else {
						/* jump */
						if (!(isset($transparent[$id]))) {
						} else {
						}
					}
					return $blocks;
				}
			}
		}

	public function getTargetBlock($maxDistance = null, $transparent = null) {
			/* decompiled (structured CF) */
			$block = $this->getLineOfSight($maxDistance, 1, $transparent)[0];
			if ($block instanceof \pocketmine\block\Block) {
				return $block;
			}
			/* jump */
		}

}
