<?php

namespace pocketmine\entity;

class Rabbit extends \pocketmine\entity\Animal {
	public const NETWORK_ID = 18;
	public const TYPE_BROWN = 0;
	public const TYPE_WHITE = 1;
	public const TYPE_BLACK = 2;
	public const TYPE_BLACK_WHITE = 3;
	public const TYPE_GOLD = 4;
	public const TYPE_SALT_PEPPER = 5;
	public const TYPE_KILLER_BUNNY = 99;

	public $height = 0.5;
	public $width = 0.5;
	public $length = 0.5;
	public $dropExp = array (
  0 => 1,
  1 => 3,
);

	public function initEntity() {
			$this->setMaxHealth(3);
			parent::initEntity();
			return null;
		}

	public function usesPm1eGroundAi() {
			return true;
		}

	public function __construct($chunk = null, $nbt = null) {
			/* decompiled (structured CF) */
			if (!(isset($nbt->RabbitType))) {
				new \pocketmine\nbt\tag\ByteTag('RabbitType', $this->getRandomRabbitType());
				$nbt->RabbitType = new \pocketmine\nbt\tag\ByteTag('RabbitType', $this->getRandomRabbitType());
			}
			parent::__construct($chunk, $nbt);
			$this->setDataProperty(self::DATA_RABBIT_TYPE, self::DATA_TYPE_BYTE, $this->getRabbitType());
			return;
		}

	public function getRandomRabbitType() {
			$arr = ['__array_ptr' => '2aaaadd5d5b0'];
			return $arr[mt_rand(0, (count($arr) - 1))];
		}

	public function setRabbitType($type = null) {
			new \pocketmine\nbt\tag\ByteTag('RabbitType', $type);
			$this->namedtag->RabbitType = new \pocketmine\nbt\tag\ByteTag('RabbitType', $type);
			return null;
		}

	public function getRabbitType() {
			return ($this->namedtag['RabbitType']);
		}

	public function getName() {
			return 'Rabbit';
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->eid = $this->getId();
			$pk->type = 18;
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->yaw = $this->yaw;
			$pk->pitch = $this->pitch;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

	public function getDrops() {
			/* decompiled (structured CF) */
			$drops = [\pocketmine\item\Item::get(\pocketmine\item\Item::RABBIT_HIDE, 0, mt_rand(0, 2))];
			if (($this->getLastDamageCause() === \pocketmine\event\entity\EntityDamageEvent::CAUSE_FIRE)) {
				$drops[] = \pocketmine\item\Item::get(\pocketmine\item\Item::COOKED_RABBIT, 0, mt_rand(1, 2));
			} else {
				$drops[] = \pocketmine\item\Item::get(\pocketmine\item\Item::RAW_RABBIT, 0, mt_rand(1, 2));
			}
			return $drops;
		}

}
