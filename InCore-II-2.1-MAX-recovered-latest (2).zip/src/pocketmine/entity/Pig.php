<?php

namespace pocketmine\entity;

class Pig extends \pocketmine\entity\Animal {
	public const NETWORK_ID = 12;

	public $width = 0.3;
	public $length = 0.9;
	public $height = 0.3;
	public $dropExp = array (
  0 => 1,
  1 => 3,
);
	protected $riderInputX = 0.0;
	protected $riderInputY = 0.0;
	protected $riderJumping = false;
	protected $riderSneaking = false;
	protected $riderSeatEntityId = NULL;

	public function __construct($chunk = null, $nbt = null) {
			parent::__construct($chunk, $nbt);
			return;
		}

	public function getName() {
			return 'Pig';
		}

	public function initEntity() {
			/* decompiled (structured CF) */
			new \pocketmine\entity\behavior\inLoveBehavior($this);
			$this->addBehavior(new \pocketmine\entity\behavior\inLoveBehavior($this));
			new \pocketmine\entity\behavior\findFoodBehavior($this, 391);
			$this->addBehavior(new \pocketmine\entity\behavior\findFoodBehavior($this, 391));
			$this->setMaxHealth(10);
			parent::initEntity();
			$saddled = ((isset($this->namedtag->Saddled) && (0 < ($this->namedtag['Saddled']))) || (isset($this->namedtag->saddled) && (0 < ($this->namedtag['saddled']))));
			$this->setSaddled($saddled);
			return null;
		}

	public function usesPm1eGroundAi() {
			return true;
		}

	public function canBeSaddled() {
			return !($this->isBaby());
		}

	public function isSaddled() {
			return $this->getDataFlag(self::DATA_FLAGS, self::DATA_FLAG_SADDLED);
		}

	public function setSaddled($saddled = null) {
			/* decompiled (structured CF) */
			if (($saddled && !($this->canBeSaddled()))) {
				return false;
			}
			$changed = ($saddled !== $this->isSaddled());
			$this->setDataFlag(self::DATA_FLAGS, self::DATA_FLAG_SADDLED, $saddled);
			if ($saddled) {
			} else {
			}
			new \pocketmine\nbt\tag\ByteTag('Saddled', 0);
			$this->namedtag->Saddled = new \pocketmine\nbt\tag\ByteTag('Saddled', 0);
			return $changed;
		}

	public function canBeRidden() {
			return (!($this->isBaby()) && $this->isSaddled());
		}

	public function getItemControllable() {
			return \pocketmine\item\Item::FISHING_ROD;
		}

	protected function getBreedingItemIds() {
			return [\pocketmine\item\Item::CARROT];
		}

	public function canBeControlledBy($rider = null) {
			/* decompiled (structured CF) */
			if ((!($this->canBeRidden()) || !($rider instanceof \pocketmine\Player))) {
				return false;
			}
			$item = $rider->getInventory()->getItemInHand();
			return ($item instanceof \pocketmine\item\Item && ($item->getId() === $this->getItemControllable()));
		}

	public function mountPlayer($player = null) {
			/* decompiled (structured CF) */
			if (!($this->canBeRidden())) {
				return false;
			}
			$item = $player->getInventory()->getItemInHand();
			if ((!($item instanceof \pocketmine\item\Item) || ($item->getId() !== $this->getItemControllable()))) {
				return false;
			}
			$this->linkedEntity = $player;
			$this->linkedType = 1;
			$player->linkedEntity = $this;
			$player->linkedType = 1;
			$this->passenger = $player;
			$player->vehicle = $this;
			$player->setDataFlag(self::DATA_FLAGS, self::DATA_FLAG_RIDING, true);
			$this->syncRiderMount($player);
			return true;
		}

	public function dismountPlayer($player = null, $scheduleDelayedTeleport = null) {
			/* decompiled (structured CF) */
			new \pocketmine\scheduler\CallbackTask(function () { /* unrecovered lambda E:/Desktop/src/src/pocketmine/entity/Pig.php.hMOlqc:124$14b */ return null; }, [$player, $player->getPosition(), $player->getYaw(), $player->getPitch()]);
			$this->server->getScheduler()->scheduleDelayedTask(new \pocketmine\scheduler\CallbackTask(function () { /* unrecovered lambda E:/Desktop/src/src/pocketmine/entity/Pig.php.hMOlqc:124$14b */ return null; }, [$player, $player->getPosition(), $player->getYaw(), $player->getPitch()]), 5);
			if ((($player !== $this->getLinkedEntity()) && ($player->getLinkedEntity() !== $this))) {
				return false;
			}
			if (($this->riderSeatEntityId !== null)) {
				$this->removeRiderSeatEntity($player, $this->riderSeatEntityId);
			}
			$this->linkedEntity = null;
			$this->linkedType = 0;
			$this->passenger = null;
			$this->riderSeatEntityId = null;
			$this->riderInputX = 0;
			$this->riderInputY = 0;
			$this->riderJumping = false;
			$this->riderSneaking = false;
			$player->linkedEntity = null;
			$player->linkedType = 0;
			$player->vehicle = null;
			$player->setDataFlag(self::DATA_FLAGS, self::DATA_FLAG_RIDING, false);
			return true;
		}

	public function onInteract($player = null, $item = null) {
			/* decompiled (structured CF) */
			if ($item instanceof \pocketmine\item\Lead) {
				return $item->leashEntity($player, $this);
			}
			if ($this->isBaby()) {
				return false;
			}
			if ((($item->getId() === \pocketmine\item\Item::SADDLE) && !($this->isSaddled()))) {
				if (($this->setSaddled(true) && !($player->isCreative()))) {
					$item->setCount(($item->getCount() - 1));
					if ((0 < $item->getCount())) {
					} else {
					}
					$player->getInventory()->setItemInHand(\pocketmine\item\Item::get(\pocketmine\item\Item::AIR, 0, 1));
				}
				return true;
			}
			if ((($item->getId() === \pocketmine\item\Item::FISHING_ROD) && $this->canBeRidden())) {
				return $this->mountPlayer($player);
			}
			return false;
		}

	public function handleRiderInput($player = null, $motX = null, $motY = null, $jumping = null, $sneaking = null) {
			/* decompiled (structured CF) */
			if (($player !== $this->getLinkedEntity())) {
				return false;
			}
			$this->riderInputX = max(-1, min(1, $motX));
			$this->riderInputY = max(-1, min(1, $motY));
			$this->riderJumping = $jumping;
			$this->riderSneaking = $sneaking;
			return true;
		}

	protected function tickPm1eGroundAi($tickDiff = null) {
			/* decompiled (structured CF) */
			$rider = $this->getLinkedEntity();
			if ($rider instanceof \pocketmine\Player) {
				return $this->tickRiddenPig($rider, $tickDiff);
			}
			return parent::tickPm1eGroundAi($tickDiff);
		}

	protected function tickRiddenPig($rider = null, $tickDiff = null) {
			/* decompiled (structured CF) */
			$level = $this->getLevel();
			if (($level === null)) {
				return false;
			}
			$chunksReady = $this->preloadRiderChunks(2);
			if (!($chunksReady)) {
				$this->syncRiderSeatPosition($rider, \pocketmine\network\protocol\MovePlayerPacket::MODE_NORMAL, false);
				$this->syncRiderSeatEntityPosition($rider);
				return true;
			}
			$liquidType = $this->getPm1eLiquidType();
			$inLiquid = ($liquidType !== null);
			$inputX = 0;
			$inputY = 0;
			$controlledByRider = $this->canBeControlledBy($rider);
			if ($controlledByRider) {
				$this->pm1eStayTime = 0;
				$inputX = $this->riderInputX;
				$inputY = (abs($this->riderInputX) <= 0.001);
				if ((abs($this->riderInputY) <= 0.001)) {
				} else {
				}
			}
			if (((abs($inputX) <= 0.001) && (abs($inputY) <= 0.001))) {
				$this->motionX = 0;
				$this->motionZ = 0;
			} else {
				$yaw = deg2rad($rider->yaw);
				$forwardX = (sin($yaw) * -1);
				$forwardZ = cos($yaw);
				$strafeX = cos($yaw);
				$strafeZ = sin($yaw);
				$moveX = (($forwardX * $inputY) + ($strafeX * $inputX));
				$moveZ = (($forwardZ * $inputY) + ($strafeZ * $inputX));
				$length = sqrt((($moveX * $moveX) + ($moveZ * $moveZ)));
				if ((0.001 < $length)) {
					$speed = $this->getPigRidingSpeed($liquidType);
					if (($inputY < 0)) {
						$speed *= 0.5;
					}
					$this->motionX = ($speed * ($moveX / $length));
					$this->motionZ = ($speed * ($moveZ / $length));
					$diff = (abs($this->motionX) + abs($this->motionZ));
					if ((0.001 < $diff)) {
						$this->yaw = ((atan2(($this->motionX / $diff), ($this->motionZ / $diff)) * -1) * (180 / \M_PI));
					}
				}
			}
			if ($inLiquid) {
				$this->motionY = max($this->motionY, $this->getPm1eLiquidBuoyancy());
			} else {
				$jumped = false;
				if (((1e-05 < abs($this->motionX)) || (1e-05 < abs($this->motionZ)))) {
					$jumped = $this->checkPm1eJump();
				}
				if (!($jumped)) {
					if ($this->onGround) {
						$this->motionY = 0;
					} else {
						$this->motionY -= $this->gravity;
					}
				}
			}
			$this->normalizePm1eGroundCollisionBox();
			$this->move($this->motionX, $this->motionY, $this->motionZ);
			$friction = (1 - $this->drag);
			if (($this->onGround && ((1e-05 < abs($this->motionX)) || (1e-05 < abs($this->motionZ))))) {
				$friction = ($friction * $this->getLevel()->getBlock($this->temporalVector->setComponents((floor($this->x)), (floor(($this->y - 1))), ((floor($this->z)) - 1)))->getFrictionFactor());
			}
			$this->motionX *= $friction;
			$this->motionZ *= $friction;
			if ($inLiquid) {
			} else {
			}
			$this->motionY *= (1 - $this->drag);
			if (($this->onGround && !($inLiquid))) {
				$this->motionY *= -0.5;
			}
			$chunksReady = $this->preloadRiderChunks(1);
			if (!($chunksReady)) {
				$this->syncRiderSeatPosition($rider, \pocketmine\network\protocol\MovePlayerPacket::MODE_NORMAL, false);
				$this->syncRiderSeatEntityPosition($rider);
				return true;
			}
			$this->syncRiderSeatPosition($rider, \pocketmine\network\protocol\MovePlayerPacket::MODE_NORMAL, false);
			$this->syncRiderSeatEntityPosition($rider);
			return true;
		}

	protected function getPigRidingSpeed($liquidType = null) {
			/* decompiled (structured CF) */
			if (($liquidType === 'lava')) {
				return 0.02;
			}
			if (($liquidType === 'water')) {
				return 0.05;
			}
			return 0.25;
		}

	protected function shouldAvoidPm1eCliff($block = null, $down = null) {
			return (!($this->getLinkedEntity() instanceof \pocketmine\Player) && parent::shouldAvoidPm1eCliff($block, $down));
		}

	protected function syncRiderMount($rider = null) {
			/* decompiled (structured CF) */
			$this->spawnRiderSeatEntity($rider);
			$this->sendRidePacket($rider, $rider->getId());
			$this->sendRidePacket($rider, 0);
			$this->syncRiderSeatPosition($rider, \pocketmine\network\protocol\MovePlayerPacket::MODE_RESET);
			return null;
		}

	protected function sendRidePacket($rider = null, $riderId = null) {
			/* decompiled (structured CF) */
			$seatEntityId = $this->getRiderSeatEntityId();
			if ((($seatEntityId === null) || ($rider->getId() === null))) {
				return null;
			}
			$this->sendRiderSeatLinkPacket($rider, $seatEntityId, $riderId, \pocketmine\network\protocol\SetEntityLinkPacket::TYPE_PASSENGER);
		}

	protected function sendRiderSeatLinkPacket($rider = null, $seatEntityId = null, $riderId = null, $type = null) {
			/* decompiled (structured CF) */
			if ((($seatEntityId === null) || ($rider->getId() === null))) {
				return null;
			}
			new \pocketmine\network\protocol\SetEntityLinkPacket();
			$pk = new \pocketmine\network\protocol\SetEntityLinkPacket();
			$pk->from = $seatEntityId;
			$pk->to = $riderId;
			$pk->type = $type;
			if (($riderId === 0)) {
				$rider->dataPacket($pk);
			} else {
				if (((($this->server !== null) && ($this->level !== null)) && method_exists($this->level, 'getPlayers'))) {
					$this->server->broadcastPacket($this->level->getPlayers(), $pk);
				} else {
					if (($riderId === $rider->getId())) {
						$rider->dataPacket($pk);
					}
				}
			}
		}

	protected function removeRiderSeatEntity($rider = null, $seatEntityId = null) {
			/* decompiled (structured CF) */
			$this->sendRiderSeatLinkPacket($rider, $seatEntityId, $rider->getId(), \pocketmine\network\protocol\SetEntityLinkPacket::TYPE_REMOVE);
			$this->sendRiderSeatLinkPacket($rider, $seatEntityId, 0, \pocketmine\network\protocol\SetEntityLinkPacket::TYPE_REMOVE);
			new \pocketmine\network\protocol\RemoveEntityPacket();
			$pk = new \pocketmine\network\protocol\RemoveEntityPacket();
			$pk->eid = $seatEntityId;
			if (((($this->server !== null) && ($this->level !== null)) && method_exists($this->level, 'getPlayers'))) {
				$this->server->broadcastPacket($this->level->getPlayers(), $pk);
			} else {
				$rider->dataPacket($pk);
			}
			return null;
		}

	protected function spawnRiderSeatEntity($rider = null) {
			/* decompiled (structured CF) */
			$seatEntityId = $this->getRiderSeatEntityId();
			if (($seatEntityId === null)) {
				return null;
			}
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->eid = $seatEntityId;
			$pk->type = \pocketmine\entity\Minecart::NETWORK_ID;
			$pk->x = $this->getRiderSeatX();
			$pk->y = $this->getRiderSeatY();
			$pk->z = $this->getRiderSeatZ();
			$pk->speedX = 0;
			$pk->speedY = 0;
			$pk->speedZ = 0;
			$pk->yaw = $this->yaw;
			$pk->pitch = $this->pitch;
			$pk->metadata = [[self::DATA_TYPE_BYTE, (1 << self::DATA_FLAG_INVISIBLE)], [self::DATA_TYPE_STRING, ''], [self::DATA_TYPE_BYTE, 1], [self::DATA_TYPE_BYTE, 1]];
			if (((($this->server !== null) && ($this->level !== null)) && method_exists($this->level, 'getPlayers'))) {
				$this->server->broadcastPacket($this->level->getPlayers(), $pk);
			} else {
				$rider->dataPacket($pk);
			}
		}

	protected function syncRiderSeatEntityPosition($rider = null) {
			/* decompiled (structured CF) */
			$seatEntityId = $this->getRiderSeatEntityId();
			if (($seatEntityId === null)) {
				return null;
			}
			new \pocketmine\network\protocol\MoveEntityPacket();
			$pk = new \pocketmine\network\protocol\MoveEntityPacket();
			$seatX = $this->getRiderSeatX();
			$seatY = $this->getRiderSeatY();
			$seatZ = $this->getRiderSeatZ();
			$pk->entities[] = [$seatEntityId, $seatX, $seatY, $seatZ, $this->yaw, $this->yaw, $this->pitch];
			if (((($this->server !== null) && ($this->level !== null)) && method_exists($this->level, 'getPlayers'))) {
				$this->server->broadcastPacket($this->level->getPlayers(), $pk);
			} else {
				$rider->dataPacket($pk);
			}
		}

	protected function getRiderSeatEntityId() {
			/* decompiled (structured CF) */
			if (($this->riderSeatEntityId === null)) {
				$this->riderSeatEntityId = $t3;
			}
			return $this->riderSeatEntityId;
		}

	protected function syncRiderSeatPosition($rider = null, $mode = null, $sendPacket = null) {
			/* decompiled (structured CF) */
			$rider->x = $this->getRiderSeatX();
			$rider->y = $this->getRiderSeatY();
			$rider->z = $this->getRiderSeatZ();
			if (((!($sendPacket) || ($this->getId() === null)) || ($rider->getId() === null))) {
				return null;
			}
			new \pocketmine\network\protocol\MovePlayerPacket();
			$pk = new \pocketmine\network\protocol\MovePlayerPacket();
			$pk->eid = 0;
			$pk->x = $rider->x;
			$pk->y = ($rider->y + $rider->getEyeHeight());
			$pk->z = $rider->z;
			$pk->yaw = $rider->yaw;
			$pk->bodyYaw = $rider->yaw;
			$pk->pitch = $rider->pitch;
			$pk->mode = $mode;
			$pk->onGround = $this->onGround;
			$rider->dataPacket($pk);
		}

	protected function getRiderSeatY() {
			return ($this->y + $this->getRiderSeatYOffset());
		}

	protected function getRiderSeatYOffset() {
			return (max(0, ($this->height - 0.15)) + 0.45);
		}

	protected function getRiderSeatX() {
			return ($this->x - (sin(deg2rad($this->yaw)) * $this->getRiderSeatForwardOffset()));
		}

	protected function getRiderSeatZ() {
			return ($this->z + (cos(deg2rad($this->yaw)) * $this->getRiderSeatForwardOffset()));
		}

	protected function getRiderSeatForwardOffset() {
			return 0.6;
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->eid = $this->getId();
			$pk->type = 12;
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->yaw = $this->yaw;
			$pk->pitch = $this->pitch;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

	public function getDrops() {
			/* decompiled (structured CF) */
			if ($this->isOnFire()) {
				$drops = [\pocketmine\item\Item::get(\pocketmine\item\Item::COOKED_PORKCHOP, 0, mt_rand(1, 2))];
			} else {
				$drops = [\pocketmine\item\Item::get(\pocketmine\item\Item::RAW_PORKCHOP, 0, mt_rand(1, 2))];
			}
			if ($this->isSaddled()) {
				$drops[] = \pocketmine\item\Item::get(\pocketmine\item\Item::SADDLE, 0, 1);
			}
			return $drops;
		}

}
