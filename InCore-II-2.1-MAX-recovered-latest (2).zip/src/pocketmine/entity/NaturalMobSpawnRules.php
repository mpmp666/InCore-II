<?php

namespace pocketmine\entity;

final class NaturalMobSpawnRules {
	public const HOSTILE_SPAWN_MAX_LIGHT = 7;
	public const PASSIVE_SPAWN_MIN_LIGHT = 9;
	public const ZOMBIE_VILLAGER_VARIANT_CHANCE = 20;

	private function __construct() {
			// empty
		}

	public static function selectLandEntityId($level = null, $pos = null, $inVillage = null, $roll = null, $zombieVariantRoll = null) {
			/* decompiled (structured CF) */
			if (($level->getDimension() === \pocketmine\level\Level::DIMENSION_NETHER)) {
				if (!(self::canSpawnLandEntityOn($level, $pos, \pocketmine\entity\PigZombie::NETWORK_ID, false))) {
					return 0;
				}
				if (self::isNetherFortressPosition($level, $pos)) {
					return self::selectFromPool(self::getNetherFortressLandPool(), $roll);
				}
				return self::selectFromPool(self::getNetherLandPool(), $roll);
			}
			if (($level->getDimension() === \pocketmine\level\Level::DIMENSION_END)) {
				if ((!(self::canSpawnHostileAt($level, $pos)) || !(self::canSpawnLandEntityOn($level, $pos, \pocketmine\entity\Enderman::NETWORK_ID, false)))) {
					return 0;
				}
				return self::selectFromPool(self::getHostilePool(\pocketmine\level\generator\biome\Biome::END), $roll);
			}
			if (($level->getDimension() !== \pocketmine\level\Level::DIMENSION_NORMAL)) {
				return 0;
			}
			$biomeId = ($level->getBiomeId((floor($pos->x)), (floor($pos->z))));
			if (($biomeId === \pocketmine\level\generator\biome\Biome::VILLAGE)) {
				$inVillage = true;
			}
			if (($inVillage && !(self::isDarkOverworldPosition($level, $pos)))) {
				if (!(self::canSpawnLandEntityOn($level, $pos, \pocketmine\entity\Villager::NETWORK_ID, true))) {
					return 0;
				}
				return self::selectFromPool(self::getPassivePool($biomeId, true), $roll);
			}
			if (self::isDarkOverworldPosition($level, $pos)) {
				if (self::canSpawnHostileAt($level, $pos)) {
					$hostilePool = self::getHostilePoolForPosition($biomeId, $pos);
					$spawnablePool = ['__array_ptr' => '2aaaac9fc9a0'];
					foreach ($hostilePool as $entityId) {
						if (self::canSpawnLandEntityOn($level, $pos, $entityId, false)) {
							$spawnablePool[] = $entityId;
						}
						/* goto */
					}
					$entityId = self::selectFromPool($spawnablePool, $roll);
					if (($entityId === \pocketmine\entity\Zombie::NETWORK_ID)) {
					} else {
					}
					return $entityId;
				}
				return 0;
			}
			if (!(self::canSpawnPassiveAt($level, $pos))) {
				return 0;
			}
			$passivePool = self::getPassivePool($biomeId, false);
			$spawnablePool = ['__array_ptr' => '2aaaac9fc9a0'];
			foreach ($passivePool as $entityId) {
				if (self::canSpawnSelectedLandEntityAt($level, $pos, $entityId, false)) {
					$spawnablePool[] = $entityId;
				}
				/* goto */
			}
			return self::selectFromPool($spawnablePool, $roll);
		}

	public static function selectLandEntityGroupIds($level = null, $pos = null, $inVillage = null, $roll = null, $groupRoll = null, $smallRoll = null, $zombieVariantRoll = null) {
			/* decompiled (structured CF) */
			if (($level->getDimension() !== \pocketmine\level\Level::DIMENSION_NORMAL)) {
				$entityId = self::selectLandEntityId($level, $pos, $inVillage, $roll, $zombieVariantRoll);
				if ((0 < $entityId)) {
				} else {
				}
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
			$biomeId = ($level->getBiomeId((floor($pos->x)), (floor($pos->z))));
			if (($biomeId === \pocketmine\level\generator\biome\Biome::VILLAGE)) {
				$inVillage = true;
			}
			if (($inVillage || self::isDarkOverworldPosition($level, $pos))) {
				$entityId = self::selectLandEntityId($level, $pos, $inVillage, $roll, $zombieVariantRoll);
				if ((0 < $entityId)) {
				} else {
				}
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
			if (!(self::canSpawnPassiveAt($level, $pos))) {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
			$passivePool = self::getPassiveHerdSelectionPool($biomeId);
			$spawnablePool = ['__array_ptr' => '2aaaac9fc9a0'];
			foreach ($passivePool as $entityId) {
				if (self::canSpawnSelectedLandEntityAt($level, $pos, $entityId, false)) {
					$spawnablePool[] = $entityId;
				}
				/* goto */
			}
			$entityId = self::selectFromPool($spawnablePool, $roll);
			if (($entityId <= 0)) {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
			$range = self::getPassiveGroupSizeRange($entityId, $biomeId);
			$groupSize = self::selectInRange($range[0], $range[1], $groupRoll);
			$group = array_fill(0, $groupSize, $entityId);
			if (self::canMixSmallPassiveWith($entityId)) {
				$smallPool = ['__array_ptr' => '2aaaac9fc9a0'];
				foreach (self::getSmallPassiveMixPool($biomeId) as $smallEntityId) {
					if ((($smallEntityId !== $entityId) && self::canSpawnSelectedLandEntityAt($level, $pos, $smallEntityId, false))) {
						$smallPool[] = $smallEntityId;
					}
					/* goto */
				}
				$smallEntityId = self::selectFromPool($smallPool, $smallRoll);
				if ((0 < $smallEntityId)) {
					$group[] = $smallEntityId;
				}
			}
			return $group;
		}

	public static function selectAirEntityId($level = null, $pos = null, $roll = null) {
			/* decompiled (structured CF) */
			if (($level->getDimension() === \pocketmine\level\Level::DIMENSION_NETHER)) {
				return self::selectFromPool([\pocketmine\entity\Ghast::NETWORK_ID], $roll);
			}
			return 0;
		}

	public static function selectCaveEntityId($level = null, $pos = null, $roll = null) {
			/* decompiled (structured CF) */
			if (($level->getDimension() !== \pocketmine\level\Level::DIMENSION_NORMAL)) {
				return 0;
			}
			$biomeId = ($level->getBiomeId((floor($pos->x)), (floor($pos->z))));
			if (!(self::canUseOverworldCaveAmbientPool($biomeId))) {
				return 0;
			}
			if ((63 <= (floor($pos->y)))) {
				return 0;
			}
			if ((3 < $level->getFullLightAt((floor($pos->x)), (floor($pos->y)), (floor($pos->z))))) {
				return 0;
			}
			return self::selectFromPool(self::getCaveAmbientPool(), $roll);
		}

	public static function selectWaterEntityId($biomeId = null, $roll = null) {
			/* decompiled (structured CF) */
			if (!(self::isWaterBiome($biomeId))) {
				return 0;
			}
			return self::selectFromPool([\pocketmine\entity\Squid::NETWORK_ID], $roll);
		}

	public static function selectWaterEntityIdForPosition($level = null, $pos = null, $roll = null) {
			/* decompiled (structured CF) */
			if (($level->getDimension() !== \pocketmine\level\Level::DIMENSION_NORMAL)) {
				return 0;
			}
			$blockId = $level->getBlockIdAt((floor($pos->x)), (floor($pos->y)), (floor($pos->z)));
			if ((($blockId !== \pocketmine\block\Block::WATER) && ($blockId !== \pocketmine\block\Block::STILL_WATER))) {
				return 0;
			}
			$biomeId = ($level->getBiomeId((floor($pos->x)), (floor($pos->z))));
			return self::selectWaterEntityId($biomeId, $roll);
		}

	public static function getNetherLandPool() {
			return [\pocketmine\entity\PigZombie::NETWORK_ID, \pocketmine\entity\PigZombie::NETWORK_ID, \pocketmine\entity\PigZombie::NETWORK_ID, \pocketmine\entity\LavaSlime::NETWORK_ID];
		}

	public static function getNetherFortressLandPool() {
			return [\pocketmine\entity\PigZombie::NETWORK_ID, \pocketmine\entity\PigZombie::NETWORK_ID, \pocketmine\entity\LavaSlime::NETWORK_ID, \pocketmine\entity\Blaze::NETWORK_ID];
		}

	public static function getCaveAmbientPool() {
			return [\pocketmine\entity\Bat::NETWORK_ID];
		}

	public static function selectZombieVariantEntityId($roll = null) {
			/* decompiled (structured CF) */
			if (($roll === null)) {
				$roll = mt_rand(0, (self::ZOMBIE_VILLAGER_VARIANT_CHANCE - 1));
			}
			if (((abs($roll) % self::ZOMBIE_VILLAGER_VARIANT_CHANCE) === 0)) {
			} else {
			}
			return \pocketmine\entity\Zombie::NETWORK_ID;
		}

	public static function getNaturalSpawnEntityIds() {
			return [\pocketmine\entity\Bat::NETWORK_ID, \pocketmine\entity\Blaze::NETWORK_ID, \pocketmine\entity\Chicken::NETWORK_ID, \pocketmine\entity\Cow::NETWORK_ID, \pocketmine\entity\Creeper::NETWORK_ID, \pocketmine\entity\Enderman::NETWORK_ID, \pocketmine\entity\Ghast::NETWORK_ID, \pocketmine\entity\IronGolem::NETWORK_ID, \pocketmine\entity\LavaSlime::NETWORK_ID, \pocketmine\entity\Mooshroom::NETWORK_ID, \pocketmine\entity\Ocelot::NETWORK_ID, \pocketmine\entity\Pig::NETWORK_ID, \pocketmine\entity\PigZombie::NETWORK_ID, \pocketmine\entity\Rabbit::NETWORK_ID, \pocketmine\entity\Sheep::NETWORK_ID, \pocketmine\entity\Skeleton::NETWORK_ID, \pocketmine\entity\Slime::NETWORK_ID, \pocketmine\entity\SnowGolem::NETWORK_ID, \pocketmine\entity\Spider::NETWORK_ID, \pocketmine\entity\Squid::NETWORK_ID, \pocketmine\entity\Villager::NETWORK_ID, \pocketmine\entity\Witch::NETWORK_ID, \pocketmine\entity\Wolf::NETWORK_ID, \pocketmine\entity\Zombie::NETWORK_ID, \pocketmine\entity\ZombieVillager::NETWORK_ID];
		}

	public static function getNonNaturalMobEntityReasons() {
			return ['spawner_only', 'weather_event', 'block_or_spawner_only'];
		}

	public static function getPassivePool($biomeId = null, $inVillage = null) {
			/* decompiled (structured CF) */
			if (($inVillage || ($biomeId === \pocketmine\level\generator\biome\Biome::VILLAGE))) {
				return [\pocketmine\entity\Villager::NETWORK_ID, \pocketmine\entity\Villager::NETWORK_ID, \pocketmine\entity\Villager::NETWORK_ID, \pocketmine\entity\Villager::NETWORK_ID, \pocketmine\entity\Villager::NETWORK_ID, \pocketmine\entity\Villager::NETWORK_ID, \pocketmine\entity\Villager::NETWORK_ID, \pocketmine\entity\Villager::NETWORK_ID, \pocketmine\entity\IronGolem::NETWORK_ID];
			}
			if (self::isMushroomBiome($biomeId)) {
				return [\pocketmine\entity\Mooshroom::NETWORK_ID];
			}
			if (self::isWolfBiome($biomeId)) {
				$pool = [\pocketmine\entity\Wolf::NETWORK_ID, \pocketmine\entity\Wolf::NETWORK_ID, \pocketmine\entity\Sheep::NETWORK_ID, \pocketmine\entity\Chicken::NETWORK_ID, \pocketmine\entity\Pig::NETWORK_ID, \pocketmine\entity\Cow::NETWORK_ID];
				if (self::isRabbitBiome($biomeId)) {
					$pool[] = \pocketmine\entity\Rabbit::NETWORK_ID;
				}
				if (self::isSnowyPassiveBiome($biomeId)) {
					$pool[] = \pocketmine\entity\SnowGolem::NETWORK_ID;
				}
				return $pool;
			}
			if (!(($biomeId == \pocketmine\level\generator\biome\Biome::END))) {
				if (!(($biomeId == \pocketmine\level\generator\biome\Biome::HELL))) {
					if (!(($biomeId == \pocketmine\level\generator\biome\Biome::SKY))) {
						if (!(($biomeId == \pocketmine\level\generator\biome\Biome::DESERT))) {
							if (!(($biomeId == \pocketmine\level\generator\biome\Biome::DESERT_HILLS))) {
								if (!(($biomeId == \pocketmine\level\generator\biome\Biome::ICE_PLAINS))) {
									if (!(($biomeId == \pocketmine\level\generator\biome\Biome::ICE_MOUNTAINS))) {
										if (!(($biomeId == \pocketmine\level\generator\biome\Biome::SAVANNA))) {
											if (!(($biomeId == \pocketmine\level\generator\biome\Biome::SAVANNA_PLATEAU))) {
												if (!(($biomeId == \pocketmine\level\generator\biome\Biome::JUNGLE))) {
													if (!(($biomeId == \pocketmine\level\generator\biome\Biome::JUNGLE_HILLS))) {
														if (!(($biomeId == \pocketmine\level\generator\biome\Biome::JUNGLE_EDGE))) {
															if (!(($biomeId == \pocketmine\level\generator\biome\Biome::OCEAN))) {
																if (!(($biomeId == \pocketmine\level\generator\biome\Biome::DEEP_OCEAN))) {
																	if (!(($biomeId == \pocketmine\level\generator\biome\Biome::FROZEN_OCEAN))) {
																		if (!(($biomeId == \pocketmine\level\generator\biome\Biome::RIVER))) {
																			if (!(($biomeId == \pocketmine\level\generator\biome\Biome::FROZEN_RIVER))) {
																				if (!(($biomeId == \pocketmine\level\generator\biome\Biome::BEACH))) {
																					if (!(($biomeId == \pocketmine\level\generator\biome\Biome::COLD_BEACH))) {
																						if (!(($biomeId == \pocketmine\level\generator\biome\Biome::STONE_BEACH))) {
																							/* jump */
																							return ['__array_ptr' => '2aaaac9fc9a0'];
																							$pool = [\pocketmine\entity\Rabbit::NETWORK_ID];
																							if (self::isSnowyPassiveBiome($biomeId)) {
																								$pool[] = \pocketmine\entity\SnowGolem::NETWORK_ID;
																							}
																							return $pool;
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
						return ['__array_ptr' => '2aaaac9fc9a0'];
						$pool = [\pocketmine\entity\Sheep::NETWORK_ID, \pocketmine\entity\Pig::NETWORK_ID, \pocketmine\entity\Chicken::NETWORK_ID, \pocketmine\entity\Cow::NETWORK_ID];
						if (self::isSnowyPassiveBiome($biomeId)) {
							$pool[] = \pocketmine\entity\SnowGolem::NETWORK_ID;
						}
						return $pool;
					}
				}
			}
		}

	public static function getPassiveGroupSizeRange($entityId = null, $biomeId = null) {
			/* decompiled (structured CF) */
			if (!(($entityId == \pocketmine\entity\Cow::NETWORK_ID))) {
				if (!(($entityId == \pocketmine\entity\Sheep::NETWORK_ID))) {
					if (!(($entityId == \pocketmine\entity\Pig::NETWORK_ID))) {
						if (!(($entityId == \pocketmine\entity\Chicken::NETWORK_ID))) {
							if (!(($entityId == \pocketmine\entity\Rabbit::NETWORK_ID))) {
								if (!(($entityId == \pocketmine\entity\Mooshroom::NETWORK_ID))) {
									if (!(($entityId == \pocketmine\entity\Wolf::NETWORK_ID))) {
										if (!(($entityId == \pocketmine\entity\Ocelot::NETWORK_ID))) {
											/* jump */
											return ['__array_ptr' => '2aaaadd70498'];
											if ((((((($biomeId === \pocketmine\level\generator\biome\Biome::TAIGA) || ($biomeId === \pocketmine\level\generator\biome\Biome::TAIGA_HILLS)) || ($biomeId === \pocketmine\level\generator\biome\Biome::COLD_TAIGA)) || ($biomeId === \pocketmine\level\generator\biome\Biome::COLD_TAIGA_HILLS)) || ($biomeId === \pocketmine\level\generator\biome\Biome::MEGA_TAIGA)) || ($biomeId === \pocketmine\level\generator\biome\Biome::MEGA_TAIGA_HILLS))) {
												return ['__array_ptr' => '2aaaadd705b0'];
											}
											return ['__array_ptr' => '2aaaadd705e8'];
										}
									}
								}
							}
						}
					}
					return ['__array_ptr' => '2aaaadd70620'];
				}
			}
		}

	public static function getSmallPassiveMixPool($biomeId = null) {
			/* decompiled (structured CF) */
			$pool = ['__array_ptr' => '2aaaac9fc9a0'];
			foreach (self::getPassivePool($biomeId, false) as $entityId) {
				if ((($entityId === \pocketmine\entity\Chicken::NETWORK_ID) || ($entityId === \pocketmine\entity\Rabbit::NETWORK_ID))) {
					if (!(in_array($entityId, $pool, true))) {
						$pool[] = $entityId;
					}
				}
				/* goto */
			}
			return $pool;
		}

	public static function getHostilePool($biomeId = null) {
			/* decompiled (structured CF) */
			if (self::isMushroomBiome($biomeId)) {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
			if (!(($biomeId == \pocketmine\level\generator\biome\Biome::END))) {
				if (!(($biomeId == \pocketmine\level\generator\biome\Biome::HELL))) {
					if (!(($biomeId == \pocketmine\level\generator\biome\Biome::SKY))) {
						if (!(($biomeId == \pocketmine\level\generator\biome\Biome::SWAMP))) {
							/* jump */
							return [\pocketmine\entity\Enderman::NETWORK_ID];
						}
					}
				}
				return [\pocketmine\entity\Zombie::NETWORK_ID, \pocketmine\entity\Zombie::NETWORK_ID, \pocketmine\entity\Zombie::NETWORK_ID, \pocketmine\entity\Skeleton::NETWORK_ID, \pocketmine\entity\Creeper::NETWORK_ID, \pocketmine\entity\Spider::NETWORK_ID, \pocketmine\entity\Enderman::NETWORK_ID, \pocketmine\entity\Witch::NETWORK_ID, \pocketmine\entity\Slime::NETWORK_ID];
			}
		}

	public static function getEntitySpawnLimit($entityId = null, $inVillage = null) {
			/* decompiled (structured CF) */
			if (!(($entityId == \pocketmine\entity\Villager::NETWORK_ID))) {
				if (!(($entityId == \pocketmine\entity\IronGolem::NETWORK_ID))) {
					if (!(($entityId == \pocketmine\entity\Squid::NETWORK_ID))) {
						if (!(($entityId == \pocketmine\entity\Wolf::NETWORK_ID))) {
							if (!(($entityId == \pocketmine\entity\Mooshroom::NETWORK_ID))) {
								/* jump */
								if ($inVillage) {
								} else {
								}
								return 5;
							}
						}
					}
				}
				return 8;
				if (self::isHostileEntityId($entityId)) {
				} else {
				}
				return 5;
			}
		}

	public static function canSpawnHostileAt($level = null, $pos = null) {
			/* decompiled (structured CF) */
			if (($level->getDimension() === \pocketmine\level\Level::DIMENSION_END)) {
				return ($level->getFullLightAt((floor($pos->x)), (floor($pos->y)), (floor($pos->z))) <= self::HOSTILE_SPAWN_MAX_LIGHT);
			}
			if (($level->getDimension() !== \pocketmine\level\Level::DIMENSION_NORMAL)) {
				return true;
			}
			$biomeId = ($level->getBiomeId((floor($pos->x)), (floor($pos->z))));
			if (self::isMushroomBiome($biomeId)) {
				return false;
			}
			return self::isDarkOverworldPosition($level, $pos);
		}

	public static function canSpawnPassiveAt($level = null, $pos = null) {
			/* decompiled (structured CF) */
			if (($level->getDimension() !== \pocketmine\level\Level::DIMENSION_NORMAL)) {
				return true;
			}
			if (self::isNight($level)) {
				return false;
			}
			return (self::PASSIVE_SPAWN_MIN_LIGHT <= $level->getFullLightAt((floor($pos->x)), (floor($pos->y)), (floor($pos->z))));
		}

	public static function isNight($level = null) {
			$time = ($level->getTime() % \pocketmine\level\Level::TIME_FULL);
			return ((\pocketmine\level\Level::TIME_NIGHT <= $time) && ($time < \pocketmine\level\Level::TIME_SUNRISE));
		}

	public static function isSwampSlimeHeight($pos = null) {
			$y = (floor($pos->y));
			return ((50 <= $y) && ($y <= 70));
		}

	public static function canSpawnLandEntityOn($level = null, $pos = null, $entityId = null, $inVillage = null) {
			/* decompiled (structured CF) */
			$groundId = $level->getBlockIdAt((floor($pos->x)), ((floor($pos->y)) - 1), (floor($pos->z)));
			if (($level->getDimension() === \pocketmine\level\Level::DIMENSION_END)) {
				return (($entityId === \pocketmine\entity\Enderman::NETWORK_ID) && ($groundId === \pocketmine\block\Block::END_STONE));
			}
			if (($level->getDimension() === \pocketmine\level\Level::DIMENSION_NETHER)) {
				if (!(($groundId == \pocketmine\block\Block::NETHERRACK))) {
					if (!(($groundId == \pocketmine\block\Block::NETHER_BRICKS))) {
						if (!(($groundId == \pocketmine\block\Block::NETHER_BRICK_FENCE))) {
							if (!(($groundId == \pocketmine\block\Block::NETHER_BRICKS_STAIRS))) {
							} else {
								return true;
							}
							return false;
							if ($inVillage) {
								if (!(($groundId == \pocketmine\block\Block::GRASS))) {
									if (!(($groundId == \pocketmine\block\Block::DIRT))) {
										if (!(($groundId == \pocketmine\block\Block::GRAVEL))) {
											if (!(($groundId == \pocketmine\block\Block::COBBLESTONE))) {
												if (!(($groundId == \pocketmine\block\Block::PLANK))) {
													if (!(($groundId == \pocketmine\block\Block::STONE))) {
														if (!(($groundId == \pocketmine\block\Block::FARMLAND))) {
															if (!(($groundId == \pocketmine\block\Block::GRASS_PATH))) {
															} else {
																return true;
															}
															return false;
															if (($entityId === \pocketmine\entity\Mooshroom::NETWORK_ID)) {
																return ($groundId === \pocketmine\block\Block::MYCELIUM);
															}
															if (($entityId === \pocketmine\entity\Rabbit::NETWORK_ID)) {
																$biomeId = ($level->getBiomeId((floor($pos->x)), (floor($pos->z))));
																if ((($biomeId === \pocketmine\level\generator\biome\Biome::DESERT) || ($biomeId === \pocketmine\level\generator\biome\Biome::DESERT_HILLS))) {
																	return ($groundId === \pocketmine\block\Block::SAND);
																}
															}
															if (self::isHostileEntityId($entityId)) {
																return self::isNaturalHostileSpawnGround($groundId);
															}
															return ($groundId === \pocketmine\block\Block::GRASS);
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

	public static function canSpawnSelectedLandEntityAt($level = null, $pos = null, $entityId = null, $inVillage = null) {
			/* decompiled (structured CF) */
			if ((($entityId <= 0) || !(self::canSpawnLandEntityOn($level, $pos, $entityId, $inVillage)))) {
				return false;
			}
			if (($level->getDimension() === \pocketmine\level\Level::DIMENSION_NETHER)) {
				if (self::isNetherFortressPosition($level, $pos)) {
					return in_array($entityId, self::getNetherFortressLandPool(), true);
				}
				return in_array($entityId, self::getNetherLandPool(), true);
			}
			if (($level->getDimension() === \pocketmine\level\Level::DIMENSION_END)) {
				return (self::canSpawnHostileAt($level, $pos) && in_array($entityId, self::getHostilePool(\pocketmine\level\generator\biome\Biome::END), true));
			}
			if (($level->getDimension() !== \pocketmine\level\Level::DIMENSION_NORMAL)) {
				return false;
			}
			$biomeId = ($level->getBiomeId((floor($pos->x)), (floor($pos->z))));
			if (($biomeId === \pocketmine\level\generator\biome\Biome::VILLAGE)) {
				$inVillage = true;
			}
			if (($inVillage && !(self::isDarkOverworldPosition($level, $pos)))) {
				return in_array($entityId, self::getPassivePool($biomeId, true), true);
			}
			if (self::isHostileEntityId($entityId)) {
				if (($entityId === \pocketmine\entity\ZombieVillager::NETWORK_ID)) {
				} else {
				}
				$hostilePoolEntityId = $entityId;
				return (self::canSpawnHostileAt($level, $pos) && in_array($hostilePoolEntityId, self::getHostilePoolForPosition($biomeId, $pos), true));
			}
			return (self::canSpawnPassiveAt($level, $pos) && in_array($entityId, self::getPassivePool($biomeId, false), true));
		}

	private static function isNaturalHostileSpawnGround($groundId = null) {
			$ground = \pocketmine\block\Block::get($groundId);
			return $ground->isNormalBlock();
		}

	public static function isHostileEntityId($entityId = null) {
			/* decompiled (structured CF) */
			if (!(($entityId == \pocketmine\entity\Zombie::NETWORK_ID))) {
				if (!(($entityId == \pocketmine\entity\ZombieVillager::NETWORK_ID))) {
					if (!(($entityId == \pocketmine\entity\Skeleton::NETWORK_ID))) {
						if (!(($entityId == \pocketmine\entity\Creeper::NETWORK_ID))) {
							if (!(($entityId == \pocketmine\entity\Spider::NETWORK_ID))) {
								if (!(($entityId == \pocketmine\entity\PigZombie::NETWORK_ID))) {
									if (!(($entityId == \pocketmine\entity\Slime::NETWORK_ID))) {
										if (!(($entityId == \pocketmine\entity\Enderman::NETWORK_ID))) {
											if (!(($entityId == \pocketmine\entity\Silverfish::NETWORK_ID))) {
												if (!(($entityId == \pocketmine\entity\CaveSpider::NETWORK_ID))) {
													if (!(($entityId == \pocketmine\entity\Ghast::NETWORK_ID))) {
														if (!(($entityId == \pocketmine\entity\LavaSlime::NETWORK_ID))) {
															if (!(($entityId == \pocketmine\entity\Blaze::NETWORK_ID))) {
																if (!(($entityId == \pocketmine\entity\Witch::NETWORK_ID))) {
																} else {
																	return true;
																}
																return false;
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

	public static function isWolfBiome($biomeId = null) {
			/* decompiled (structured CF) */
			if (!(($biomeId == \pocketmine\level\generator\biome\Biome::FOREST))) {
				if (!(($biomeId == \pocketmine\level\generator\biome\Biome::FOREST_HILLS))) {
					if (!(($biomeId == \pocketmine\level\generator\biome\Biome::BIRCH_FOREST))) {
						if (!(($biomeId == \pocketmine\level\generator\biome\Biome::BIRCH_FOREST_HILLS))) {
							if (!(($biomeId == \pocketmine\level\generator\biome\Biome::PINK_FOREST))) {
								if (!(($biomeId == \pocketmine\level\generator\biome\Biome::GOLDEN_FOREST))) {
									if (!(($biomeId == \pocketmine\level\generator\biome\Biome::TAIGA))) {
										if (!(($biomeId == \pocketmine\level\generator\biome\Biome::TAIGA_HILLS))) {
											if (!(($biomeId == \pocketmine\level\generator\biome\Biome::COLD_TAIGA))) {
												if (!(($biomeId == \pocketmine\level\generator\biome\Biome::COLD_TAIGA_HILLS))) {
													if (!(($biomeId == \pocketmine\level\generator\biome\Biome::MEGA_TAIGA))) {
														if (!(($biomeId == \pocketmine\level\generator\biome\Biome::MEGA_TAIGA_HILLS))) {
														} else {
															return true;
														}
														return false;
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

	public static function isWaterBiome($biomeId = null) {
			/* decompiled (structured CF) */
			if (!(($biomeId == \pocketmine\level\generator\biome\Biome::OCEAN))) {
				if (!(($biomeId == \pocketmine\level\generator\biome\Biome::DEEP_OCEAN))) {
					if (!(($biomeId == \pocketmine\level\generator\biome\Biome::FROZEN_OCEAN))) {
						if (!(($biomeId == \pocketmine\level\generator\biome\Biome::RIVER))) {
							if (!(($biomeId == \pocketmine\level\generator\biome\Biome::FROZEN_RIVER))) {
							} else {
								return true;
							}
							return false;
						}
					}
				}
			}
		}

	public static function isRabbitBiome($biomeId = null) {
			/* decompiled (structured CF) */
			if (!(($biomeId == \pocketmine\level\generator\biome\Biome::DESERT))) {
				if (!(($biomeId == \pocketmine\level\generator\biome\Biome::DESERT_HILLS))) {
					if (!(($biomeId == \pocketmine\level\generator\biome\Biome::ICE_PLAINS))) {
						if (!(($biomeId == \pocketmine\level\generator\biome\Biome::ICE_MOUNTAINS))) {
							if (!(($biomeId == \pocketmine\level\generator\biome\Biome::TAIGA))) {
								if (!(($biomeId == \pocketmine\level\generator\biome\Biome::TAIGA_HILLS))) {
									if (!(($biomeId == \pocketmine\level\generator\biome\Biome::COLD_TAIGA))) {
										if (!(($biomeId == \pocketmine\level\generator\biome\Biome::COLD_TAIGA_HILLS))) {
											if (!(($biomeId == \pocketmine\level\generator\biome\Biome::MEGA_TAIGA))) {
												if (!(($biomeId == \pocketmine\level\generator\biome\Biome::MEGA_TAIGA_HILLS))) {
													if (!(($biomeId == \pocketmine\level\generator\biome\Biome::SAVANNA))) {
														if (!(($biomeId == \pocketmine\level\generator\biome\Biome::SAVANNA_PLATEAU))) {
														} else {
															return true;
														}
														return false;
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

	private static function isSnowyPassiveBiome($biomeId = null) {
			/* decompiled (structured CF) */
			if (!(($biomeId == \pocketmine\level\generator\biome\Biome::ICE_PLAINS))) {
				if (!(($biomeId == \pocketmine\level\generator\biome\Biome::ICE_MOUNTAINS))) {
					if (!(($biomeId == \pocketmine\level\generator\biome\Biome::COLD_TAIGA))) {
						if (!(($biomeId == \pocketmine\level\generator\biome\Biome::COLD_TAIGA_HILLS))) {
						} else {
							return true;
						}
						return false;
					}
				}
			}
		}

	private static function isMushroomBiome($biomeId = null) {
			return (($biomeId === \pocketmine\level\generator\biome\Biome::MUSHROOM_ISLAND) || ($biomeId === \pocketmine\level\generator\biome\Biome::MUSHROOM_ISLAND_SHORE));
		}

	private static function canUseOverworldCaveAmbientPool($biomeId = null) {
			/* decompiled (structured CF) */
			if ((($biomeId === \pocketmine\level\generator\biome\Biome::END) || ($biomeId === \pocketmine\level\generator\biome\Biome::HELL))) {
				return false;
			}
			return !(self::isMushroomBiome($biomeId));
		}

	private static function isNetherFortressPosition($level = null, $pos = null) {
			/* decompiled (structured CF) */
			$belowId = $level->getBlockIdAt((floor($pos->x)), ((floor($pos->y)) - 1), (floor($pos->z)));
			if (!(($belowId == \pocketmine\block\Block::NETHER_BRICKS))) {
				if (!(($belowId == \pocketmine\block\Block::NETHER_BRICK_FENCE))) {
					if (!(($belowId == \pocketmine\block\Block::NETHER_BRICKS_STAIRS))) {
					} else {
						return true;
					}
					return false;
				}
			}
		}

	private static function isDarkOverworldPosition($level = null, $pos = null) {
			/* decompiled (structured CF) */
			if (($level->getDimension() !== \pocketmine\level\Level::DIMENSION_NORMAL)) {
				return false;
			}
			$x = (floor($pos->x));
			$y = (floor($pos->y));
			$z = (floor($pos->z));
			if (self::isNight($level)) {
				return ($level->getBlockLightAt($x, $y, $z) <= self::HOSTILE_SPAWN_MAX_LIGHT);
			}
			return ($level->getFullLightAt($x, $y, $z) <= self::HOSTILE_SPAWN_MAX_LIGHT);
		}

	private static function getHostilePoolForPosition($biomeId = null, $pos = null) {
			/* decompiled (structured CF) */
			$pool = self::getHostilePool($biomeId);
			if ((($biomeId !== \pocketmine\level\generator\biome\Biome::SWAMP) || self::isSwampSlimeHeight($pos))) {
				return $pool;
			}
			$filteredPool = ['__array_ptr' => '2aaaac9fc9a0'];
			foreach ($pool as $entityId) {
				if (($entityId !== \pocketmine\entity\Slime::NETWORK_ID)) {
					$filteredPool[] = $entityId;
				}
				/* goto */
			}
			return $filteredPool;
		}

	private static function getPassiveHerdSelectionPool($biomeId = null) {
			/* decompiled (structured CF) */
			$pool = ['__array_ptr' => '2aaaac9fc9a0'];
			foreach (self::getPassivePool($biomeId, false) as $entityId) {
				if (self::isPassiveHerdEntityId($entityId)) {
					$pool[] = $entityId;
				}
				/* goto */
			}
			return $pool;
		}

	private static function isPassiveHerdEntityId($entityId = null) {
			/* decompiled (structured CF) */
			if (!(($entityId == \pocketmine\entity\Cow::NETWORK_ID))) {
				if (!(($entityId == \pocketmine\entity\Pig::NETWORK_ID))) {
					if (!(($entityId == \pocketmine\entity\Sheep::NETWORK_ID))) {
						if (!(($entityId == \pocketmine\entity\Chicken::NETWORK_ID))) {
							if (!(($entityId == \pocketmine\entity\Rabbit::NETWORK_ID))) {
								if (!(($entityId == \pocketmine\entity\Mooshroom::NETWORK_ID))) {
									if (!(($entityId == \pocketmine\entity\Wolf::NETWORK_ID))) {
										if (!(($entityId == \pocketmine\entity\Ocelot::NETWORK_ID))) {
										} else {
											return true;
										}
										return false;
									}
								}
							}
						}
					}
				}
			}
		}

	private static function canMixSmallPassiveWith($entityId = null) {
			/* decompiled (structured CF) */
			if (!(($entityId == \pocketmine\entity\Cow::NETWORK_ID))) {
				if (!(($entityId == \pocketmine\entity\Pig::NETWORK_ID))) {
					if (!(($entityId == \pocketmine\entity\Sheep::NETWORK_ID))) {
					} else {
						return true;
					}
					return false;
				}
			}
		}

	private static function selectInRange($min = null, $max = null, $roll = null) {
			/* decompiled (structured CF) */
			if (($max <= $min)) {
				return $min;
			}
			if (($roll === null)) {
				$roll = mt_rand(0, ($max - $min));
			}
			return ($min + (abs($roll) % (($max - $min) + 1)));
		}

	private static function selectFromPool($pool = null, $roll = null) {
			/* decompiled (structured CF) */
			$count = count($pool);
			if (($count === 0)) {
				return 0;
			}
			if (($roll === null)) {
				$roll = mt_rand(0, ($count - 1));
			}
			return ($pool[(abs($roll) % $count)]);
		}

}
