<?php

namespace pocketmine\entity;

class Effect {
	public const SPEED = 1;
	public const SLOWNESS = 2;
	public const HASTE = 3;
	public const SWIFTNESS = 3;
	public const FATIGUE = 4;
	public const MINING_FATIGUE = 4;
	public const STRENGTH = 5;
	public const HEALING = 6;
	public const HARMING = 7;
	public const JUMP = 8;
	public const NAUSEA = 9;
	public const CONFUSION = 9;
	public const REGENERATION = 10;
	public const DAMAGE_RESISTANCE = 11;
	public const FIRE_RESISTANCE = 12;
	public const WATER_BREATHING = 13;
	public const INVISIBILITY = 14;
	public const BLINDNESS = 15;
	public const NIGHT_VISION = 16;
	public const HUNGER = 17;
	public const WEAKNESS = 18;
	public const POISON = 19;
	public const WITHER = 20;
	public const HEALTH_BOOST = 21;
	public const ABSORPTION = 22;
	public const SATURATION = 23;
	public const MAX_DURATION = 2147483648.0;

	protected static $effects = NULL;
	protected $id = NULL;
	protected $name = NULL;
	protected $duration = NULL;
	protected $amplifier = 0;
	protected $color = NULL;
	protected $show = true;
	protected $ambient = false;
	protected $bad = NULL;

	public static function init() {
			/* decompiled (structured CF) */
			new \SplFixedArray(256);
			self::$effects = new \SplFixedArray(256);
			new \pocketmine\entity\Effect(1, '%potion.moveSpeed', 124, 175, 198);
			self::$effects[1] = new \pocketmine\entity\Effect(1, '%potion.moveSpeed', 124, 175, 198);
			new \pocketmine\entity\Effect(2, '%potion.moveSlowdown', 90, 108, 129, true);
			self::$effects[2] = new \pocketmine\entity\Effect(2, '%potion.moveSlowdown', 90, 108, 129, true);
			new \pocketmine\entity\Effect(3, '%potion.digSpeed', 217, 192, 67);
			self::$effects[3] = new \pocketmine\entity\Effect(3, '%potion.digSpeed', 217, 192, 67);
			new \pocketmine\entity\Effect(4, '%potion.digSlowDown', 74, 66, 23, true);
			self::$effects[4] = new \pocketmine\entity\Effect(4, '%potion.digSlowDown', 74, 66, 23, true);
			new \pocketmine\entity\Effect(5, '%potion.damageBoost', 147, 36, 35);
			self::$effects[5] = new \pocketmine\entity\Effect(5, '%potion.damageBoost', 147, 36, 35);
			new \pocketmine\entity\InstantEffect(6, '%potion.heal', 248, 36, 35);
			self::$effects[6] = new \pocketmine\entity\InstantEffect(6, '%potion.heal', 248, 36, 35);
			new \pocketmine\entity\InstantEffect(7, '%potion.harm', 67, 10, 9, true);
			self::$effects[7] = new \pocketmine\entity\InstantEffect(7, '%potion.harm', 67, 10, 9, true);
			new \pocketmine\entity\Effect(8, '%potion.jump', 34, 255, 76);
			self::$effects[8] = new \pocketmine\entity\Effect(8, '%potion.jump', 34, 255, 76);
			new \pocketmine\entity\Effect(9, '%potion.confusion', 85, 29, 74, true);
			self::$effects[9] = new \pocketmine\entity\Effect(9, '%potion.confusion', 85, 29, 74, true);
			new \pocketmine\entity\Effect(10, '%potion.regeneration', 205, 92, 171);
			self::$effects[10] = new \pocketmine\entity\Effect(10, '%potion.regeneration', 205, 92, 171);
			new \pocketmine\entity\Effect(11, '%potion.resistance', 153, 69, 58);
			self::$effects[11] = new \pocketmine\entity\Effect(11, '%potion.resistance', 153, 69, 58);
			new \pocketmine\entity\Effect(12, '%potion.fireResistance', 228, 154, 58);
			self::$effects[12] = new \pocketmine\entity\Effect(12, '%potion.fireResistance', 228, 154, 58);
			new \pocketmine\entity\Effect(13, '%potion.waterBreathing', 46, 82, 153);
			self::$effects[13] = new \pocketmine\entity\Effect(13, '%potion.waterBreathing', 46, 82, 153);
			new \pocketmine\entity\Effect(14, '%potion.invisibility', 127, 131, 146);
			self::$effects[14] = new \pocketmine\entity\Effect(14, '%potion.invisibility', 127, 131, 146);
			new \pocketmine\entity\Effect(15, '%potion.blindness', 191, 192, 192);
			self::$effects[15] = new \pocketmine\entity\Effect(15, '%potion.blindness', 191, 192, 192);
			new \pocketmine\entity\Effect(16, '%potion.nightVision', 0, 0, 139);
			self::$effects[16] = new \pocketmine\entity\Effect(16, '%potion.nightVision', 0, 0, 139);
			new \pocketmine\entity\Effect(17, '%potion.hunger', 46, 139, 87);
			self::$effects[17] = new \pocketmine\entity\Effect(17, '%potion.hunger', 46, 139, 87);
			new \pocketmine\entity\Effect(18, '%potion.weakness', 72, 77, 72, true);
			self::$effects[18] = new \pocketmine\entity\Effect(18, '%potion.weakness', 72, 77, 72, true);
			new \pocketmine\entity\Effect(19, '%potion.poison', 78, 147, 49, true);
			self::$effects[19] = new \pocketmine\entity\Effect(19, '%potion.poison', 78, 147, 49, true);
			new \pocketmine\entity\Effect(20, '%potion.wither', 53, 42, 39, true);
			self::$effects[20] = new \pocketmine\entity\Effect(20, '%potion.wither', 53, 42, 39, true);
			new \pocketmine\entity\Effect(21, '%potion.healthBoost', 248, 125, 35);
			self::$effects[21] = new \pocketmine\entity\Effect(21, '%potion.healthBoost', 248, 125, 35);
			new \pocketmine\entity\Effect(22, '%potion.absorption', 36, 107, 251);
			self::$effects[22] = new \pocketmine\entity\Effect(22, '%potion.absorption', 36, 107, 251);
			new \pocketmine\entity\Effect(23, '%potion.saturation', 255, 0, 255);
			self::$effects[23] = new \pocketmine\entity\Effect(23, '%potion.saturation', 255, 0, 255);
			return null;
		}

	public static function getEffect($id = null) {
			if (isset(self::$effects[$id])) {
				return clone self::$effects[($id)];
			}
		}

	public static function getEffectByName($name = null) {
			if (defined(('pocketmine\\entity\\Effect::' . strtoupper($name)))) {
				return self::getEffect(constant(('pocketmine\\entity\\Effect::' . strtoupper($name))));
			}
		}

	public function __construct($id = null, $name = null, $r = null, $g = null, $b = null, $isBad = null) {
			/* decompiled (structured CF) */
			$this->id = $id;
			$this->name = $name;
			$this->bad = $isBad;
			$this->setColor($r, $g, $b);
			return;
		}

	public function getName() {
			return $this->name;
		}

	public function getId() {
			return $this->id;
		}

	public function setDuration($ticks = null) {
			/* decompiled (structured CF) */
			if ((self::MAX_DURATION < $ticks)) {
			} else {
			}
			$this->duration = $ticks;
			return $this;
		}

	public function getDuration() {
			return $this->duration;
		}

	public function isVisible() {
			return $this->show;
		}

	public function setVisible($bool = null) {
			$this->show = $bool;
			return $this;
		}

	public function getAmplifier() {
			return $this->amplifier;
		}

	public function setAmplifier($amplifier = null) {
			$this->amplifier = ($amplifier);
			return $this;
		}

	public function isAmbient() {
			return $this->ambient;
		}

	public function setAmbient($ambient = null) {
			$this->ambient = $ambient;
			return $this;
		}

	public function isBad() {
			return $this->bad;
		}

	public function canTick() {
			/* decompiled (structured CF) */
			if (($this->amplifier < 0)) {
				$this->amplifier = 0;
			}
			switch ($this->id) {
				case 19:
				$interval = (25 >> $this->amplifier);
				if ((0 < $interval)) {
					return (($this->duration % $interval) === 0);
				}
				return true;
				case 20:
				$interval = (50 >> $this->amplifier);
				if ((0 < $interval)) {
					return (($this->duration % $interval) === 0);
				}
				return true;
				case 10:
				case 17:
				$interval = (40 >> $this->amplifier);
				if ((0 < $interval)) {
					return (($this->duration % $interval) === 0);
				}
				return true;
				case 6:
				case 7:
				return true;
				case 23:
				$interval = (20 >> $this->amplifier);
				if ((0 < $interval)) {
					return (($this->duration % $interval) === 0);
				}
				return true;
			}
		}

	public function applyEffect($entity = null) {
			/* decompiled (structured CF) */
			switch ($this->id) {
				case 19:
				if ((1 < $entity->getHealth())) {
					new \pocketmine\event\entity\EntityDamageEvent($entity, \pocketmine\event\entity\EntityDamageEvent::CAUSE_MAGIC, 1);
					$ev = new \pocketmine\event\entity\EntityDamageEvent($entity, \pocketmine\event\entity\EntityDamageEvent::CAUSE_MAGIC, 1);
					$entity->attack($ev->getFinalDamage(), $ev);
				}
				break;
				case 20:
				new \pocketmine\event\entity\EntityDamageEvent($entity, \pocketmine\event\entity\EntityDamageEvent::CAUSE_MAGIC, 1);
				$ev = new \pocketmine\event\entity\EntityDamageEvent($entity, \pocketmine\event\entity\EntityDamageEvent::CAUSE_MAGIC, 1);
				$entity->attack($ev->getFinalDamage(), $ev);
				break;
				case 10:
				if (($entity->getHealth() < $entity->getMaxHealth())) {
					new \pocketmine\event\entity\EntityRegainHealthEvent($entity, 1, \pocketmine\event\entity\EntityRegainHealthEvent::CAUSE_MAGIC);
					$ev = new \pocketmine\event\entity\EntityRegainHealthEvent($entity, 1, \pocketmine\event\entity\EntityRegainHealthEvent::CAUSE_MAGIC);
					$entity->heal($ev->getAmount(), $ev);
				}
				break;
				case 17:
				if ($entity instanceof \pocketmine\Player) {
					if ($entity->getServer()->foodEnabled) {
						$entity->setFood(($entity->getFood() - 1));
					}
				}
				break;
				case 6:
				$level = ($this->amplifier + 1);
				if ((($entity->getHealth() + ($level * 4)) <= $entity->getMaxHealth())) {
					new \pocketmine\event\entity\EntityRegainHealthEvent($entity, ($level * 4), \pocketmine\event\entity\EntityRegainHealthEvent::CAUSE_MAGIC);
					$ev = new \pocketmine\event\entity\EntityRegainHealthEvent($entity, ($level * 4), \pocketmine\event\entity\EntityRegainHealthEvent::CAUSE_MAGIC);
					$entity->heal($ev->getAmount(), $ev);
				} else {
					new \pocketmine\event\entity\EntityRegainHealthEvent($entity, ($entity->getMaxHealth() - $entity->getHealth()), \pocketmine\event\entity\EntityRegainHealthEvent::CAUSE_MAGIC);
					$ev = new \pocketmine\event\entity\EntityRegainHealthEvent($entity, ($entity->getMaxHealth() - $entity->getHealth()), \pocketmine\event\entity\EntityRegainHealthEvent::CAUSE_MAGIC);
					$entity->heal($ev->getAmount(), $ev);
				}
				break;
				case 7:
				$level = ($this->amplifier + 1);
				if ((0 <= ($entity->getHealth() - ($level * 6)))) {
					new \pocketmine\event\entity\EntityDamageEvent($entity, \pocketmine\event\entity\EntityDamageEvent::CAUSE_MAGIC, ($level * 6));
					$ev = new \pocketmine\event\entity\EntityDamageEvent($entity, \pocketmine\event\entity\EntityDamageEvent::CAUSE_MAGIC, ($level * 6));
					$entity->attack($ev->getFinalDamage(), $ev);
				} else {
					new \pocketmine\event\entity\EntityDamageEvent($entity, \pocketmine\event\entity\EntityDamageEvent::CAUSE_MAGIC, $entity->getHealth());
					$ev = new \pocketmine\event\entity\EntityDamageEvent($entity, \pocketmine\event\entity\EntityDamageEvent::CAUSE_MAGIC, $entity->getHealth());
					$entity->attack($ev->getFinalDamage(), $ev);
				}
				break;
				case 23:
				if ($entity instanceof \pocketmine\Player) {
					if ($entity->getServer()->foodEnabled) {
						$entity->setFood(($entity->getFood() + 1));
					}
				}
				break;
			}
			return null;
		}

	public function getColor() {
			return [($this->color >> 16), (($this->color >> 8) & 255), ($this->color & 255)];
		}

	public function setColor($r = null, $g = null, $b = null) {
			$this->color = (((($r & 255) << 16) + (($g & 255) << 8)) + ($b & 255));
			return null;
		}

	public function add($entity = null, $modify = null, $oldEffect = null) {
			/* decompiled (structured CF) */
			if ($entity instanceof \pocketmine\Player) {
				new \pocketmine\network\protocol\MobEffectPacket();
				$pk = new \pocketmine\network\protocol\MobEffectPacket();
				$pk->eid = 0;
				$pk->effectId = $this->getId();
				$pk->amplifier = $this->getAmplifier();
				$pk->particles = $this->isVisible();
				$pk->duration = $this->getDuration();
				if ($modify) {
					$pk->eventId = \pocketmine\network\protocol\MobEffectPacket::EVENT_MODIFY;
				} else {
					$pk->eventId = \pocketmine\network\protocol\MobEffectPacket::EVENT_ADD;
				}
				$entity->dataPacket($pk);
			}
			if (($this->id === 14)) {
				$entity->setDataFlag(\pocketmine\entity\Entity::DATA_FLAGS, \pocketmine\entity\Entity::DATA_FLAG_INVISIBLE, true);
				$entity->setDataProperty(\pocketmine\entity\Entity::DATA_SHOW_NAMETAG, \pocketmine\entity\Entity::DATA_TYPE_BYTE, 0);
			} else {
				if (($this->id === 1)) {
					$attr = $entity->getAttributeMap()->getAttribute(\pocketmine\entity\Attribute::MOVEMENT_SPEED);
					if (($attr !== null)) {
						if (($modify && ($oldEffect !== null))) {
							$speed = ($attr->getValue() / (1 + ($oldEffect->getAmplifier() * 0.2)));
						} else {
							$speed = $attr->getValue();
						}
						$speed *= (1 + ($this->amplifier * 0.2));
						$attr->setValue($speed);
					}
				} else {
					if (($this->id === 2)) {
						$attr = $entity->getAttributeMap()->getAttribute(\pocketmine\entity\Attribute::MOVEMENT_SPEED);
						if (($attr !== null)) {
							if (($modify && ($oldEffect !== null))) {
								$speed = ($attr->getValue() / (1 - ($oldEffect->getAmplifier() * 0.15)));
							} else {
								$speed = $attr->getValue();
							}
							$speed *= (1 - ($this->amplifier * 0.15));
							$attr->setValue($speed);
						}
					}
				}
			}
			return null;
		}

	public function remove($entity = null) {
			/* decompiled (structured CF) */
			if ($entity instanceof \pocketmine\Player) {
				new \pocketmine\network\protocol\MobEffectPacket();
				$pk = new \pocketmine\network\protocol\MobEffectPacket();
				$pk->eid = 0;
				$pk->eventId = \pocketmine\network\protocol\MobEffectPacket::EVENT_REMOVE;
				$pk->effectId = $this->getId();
				$entity->dataPacket($pk);
			}
			if (($this->id === 14)) {
				$entity->setDataFlag(\pocketmine\entity\Entity::DATA_FLAGS, \pocketmine\entity\Entity::DATA_FLAG_INVISIBLE, false);
				$entity->setDataProperty(\pocketmine\entity\Entity::DATA_SHOW_NAMETAG, \pocketmine\entity\Entity::DATA_TYPE_BYTE, 1);
			} else {
				if (($this->id === 1)) {
					$attr = $entity->getAttributeMap()->getAttribute(\pocketmine\entity\Attribute::MOVEMENT_SPEED);
					if (($attr !== null)) {
						$attr->setValue(($attr->getValue() / (1 + ($this->amplifier * 0.2))));
					}
				} else {
					if (($this->id === 2)) {
						$attr = $entity->getAttributeMap()->getAttribute(\pocketmine\entity\Attribute::MOVEMENT_SPEED);
						if (($attr !== null)) {
							$attr->setValue(($attr->getValue() / (1 - ($this->amplifier * 0.15))));
						}
					}
				}
			}
			return null;
		}

}
