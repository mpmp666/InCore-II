<?php

namespace pocketmine\entity;

class Attribute {
	public const ABSORPTION = 0;
	public const SATURATION = 1;
	public const EXHAUSTION = 2;
	public const KNOCKBACK_RESISTANCE = 3;
	public const HEALTH = 4;
	public const MOVEMENT_SPEED = 5;
	public const FOLLOW_RANGE = 6;
	public const HUNGER = 7;
	public const FOOD = 7;
	public const ATTACK_DAMAGE = 8;
	public const EXPERIENCE_LEVEL = 9;
	public const EXPERIENCE = 10;

	private $id = NULL;
	protected $minValue = NULL;
	protected $maxValue = NULL;
	protected $defaultValue = NULL;
	protected $currentValue = NULL;
	protected $name = NULL;
	protected $shouldSend = NULL;
	protected $desynchronized = true;
	protected static $attributes = array (
);

	public static function init() {
			/* decompiled (structured CF) */
			self::addAttribute(self::ABSORPTION, 'generic.absorption', 0, 3.4028234663852886e+38, 0);
			self::addAttribute(self::SATURATION, 'player.saturation', 0, 20, 5);
			self::addAttribute(self::EXHAUSTION, 'player.exhaustion', 0, 5, 0.41);
			self::addAttribute(self::KNOCKBACK_RESISTANCE, 'generic.knockbackResistance', 0, 1, 0);
			self::addAttribute(self::HEALTH, 'generic.health', 0, 20, 20);
			self::addAttribute(self::MOVEMENT_SPEED, 'generic.movementSpeed', 0, 3.4028234663852886e+38, 0.1);
			self::addAttribute(self::FOLLOW_RANGE, 'generic.followRange', 0, 2048, 16, false);
			self::addAttribute(self::HUNGER, 'player.hunger', 0, 20, 20);
			self::addAttribute(self::ATTACK_DAMAGE, 'generic.attackDamage', 0, 3.4028234663852886e+38, 1, false);
			self::addAttribute(self::EXPERIENCE_LEVEL, 'player.level', 0, 24791, 0);
			self::addAttribute(self::EXPERIENCE, 'player.experience', 0, 1, 0);
			return null;
		}

	public static function addAttribute($id = null, $name = null, $minValue = null, $maxValue = null, $defaultValue = null, $shouldSend = null) {
			/* decompiled (structured CF) */
			if (((($maxValue < $minValue) || ($maxValue < $defaultValue)) || ($defaultValue < $minValue))) {
				new \InvalidArgumentException(($this . $defaultValue));
				throw new \InvalidArgumentException(($this . $defaultValue));
			}
			new \pocketmine\entity\Attribute($id, $name, $minValue, $maxValue, $defaultValue, $shouldSend);
			self::$attributes[($id)] = new \pocketmine\entity\Attribute($id, $name, $minValue, $maxValue, $defaultValue, $shouldSend);
			return $t16;
		}

	public static function getAttribute($id = null) {
			/* decompiled (structured CF) */
			if (isset(self::$attributes[$id])) {
			} else {
			}
			return null;
		}

	public static function getAttributeByName($name = null) {
			/* decompiled (structured CF) */
			foreach (self::$attributes as $a) {
				if (($name === $a->getName())) {
					return clone $a;
				}
				/* goto */
			}
		}

	private function __construct($id = null, $name = null, $minValue = null, $maxValue = null, $defaultValue = null, $shouldSend = null) {
			/* decompiled (structured CF) */
			$this->id = ($id);
			$this->name = ($name);
			$this->minValue = ($minValue);
			$this->maxValue = ($maxValue);
			$this->defaultValue = ($defaultValue);
			$this->shouldSend = $shouldSend;
			$this->currentValue = $this->defaultValue;
			return;
		}

	public function getMinValue() {
			return $this->minValue;
		}

	public function setMinValue($minValue = null) {
			/* decompiled (structured CF) */
			if (($this->getMaxValue() < $minValue)) {
				new \InvalidArgumentException(($this . $this));
				throw new \InvalidArgumentException(($this . $this));
			}
			if (($minValue != $this->minValue)) {
				$this->desynchronized = true;
				$this->minValue = $minValue;
			}
			return $this;
		}

	public function getMaxValue() {
			return $this->maxValue;
		}

	public function setMaxValue($maxValue = null) {
			/* decompiled (structured CF) */
			if (($maxValue < $this->getMinValue())) {
				new \InvalidArgumentException(($this . $this));
				throw new \InvalidArgumentException(($this . $this));
			}
			if (($maxValue != $this->maxValue)) {
				$this->desynchronized = true;
				$this->maxValue = $maxValue;
			}
			return $this;
		}

	public function getDefaultValue() {
			return $this->defaultValue;
		}

	public function setDefaultValue($defaultValue = null) {
			/* decompiled (structured CF) */
			if ((($this->getMaxValue() < $defaultValue) || ($defaultValue < $this->getMinValue()))) {
				new \InvalidArgumentException(($this . $this));
				throw new \InvalidArgumentException(($this . $this));
			}
			if (($defaultValue !== $this->defaultValue)) {
				$this->desynchronized = true;
				$this->defaultValue = $defaultValue;
			}
			return $this;
		}

	public function getValue() {
			return $this->currentValue;
		}

	public function setValue($value = null, $fit = null) {
			/* decompiled (structured CF) */
			if ((($this->getMaxValue() < $value) || ($value < $this->getMinValue()))) {
				if (!($fit)) {
					\pocketmine\Server::getInstance()->getLogger()->error(($this . $this));
				}
				$value = min(max($value, $this->getMinValue()), $this->getMaxValue());
			}
			if (($value != $this->currentValue)) {
				$this->desynchronized = true;
				$this->currentValue = $value;
			}
			return $this;
		}

	public function getName() {
			return $this->name;
		}

	public function getId() {
			return $this->id;
		}

	public function isSyncable() {
			return $this->shouldSend;
		}

	public function isDesynchronized() {
			return ($this->shouldSend && $this->desynchronized);
		}

	public function markSynchronized($synced = null) {
			$this->desynchronized = !($synced);
			return null;
		}

}
