<?php

namespace pocketmine\entity;

class Skeleton extends \pocketmine\entity\Monster implements \pocketmine\entity\ProjectileSource {
	public const NETWORK_ID = 34;

	public $width = 0.6;
	public $length = 0.6;
	public $height = 1.8;
	public $dropExp = array (
  0 => 5,
  1 => 5,
);
	protected $armor = array (
);
	protected $weapon = NULL;

	public function getName() {
			return 'Skeleton';
		}

	public function initEntity() {
			/* decompiled (structured CF) */
			$this->setMaxHealth(20);
			new \pocketmine\entity\behavior\ShootPlayerBehavior($this, 80);
			$this->addBehavior(new \pocketmine\entity\behavior\ShootPlayerBehavior($this, 80));
			parent::initEntity();
			$equipment = \pocketmine\entity\VanillaMobEquipment::generateSkeletonEquipment($this->server->getDifficulty());
			$this->weapon = $equipment['weapon'];
			$this->armor = $equipment['armor'];
			return null;
		}

	public function usesPm1eGroundAi() {
			return true;
		}

	public function getWeapon() {
			/* decompiled (structured CF) */
			if ($this->weapon instanceof \pocketmine\item\Item) {
			} else {
			}
			return \pocketmine\item\Item::get(\pocketmine\item\Item::BOW, 0, 1);
		}

	public function getArmorContents() {
			/* decompiled (structured CF) */
			if ((count($this->armor) === 4)) {
			} else {
			}
			return \pocketmine\entity\VanillaMobEquipment::emptyArmor();
		}

	protected function handlesLootingDrops() {
			return true;
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->eid = $this->getId();
			$pk->type = 34;
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->yaw = $this->yaw;
			$pk->pitch = $this->pitch;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			new \pocketmine\network\protocol\MobEquipmentPacket();
			$pk = new \pocketmine\network\protocol\MobEquipmentPacket();
			$pk->eid = $this->getId();
			$pk->item = $this->getWeapon();
			$pk->slot = 0;
			$pk->selectedSlot = 0;
			$player->dataPacket($pk);
			new \pocketmine\network\protocol\MobArmorEquipmentPacket();
			$pk = new \pocketmine\network\protocol\MobArmorEquipmentPacket();
			$pk->eid = $this->getId();
			$pk->slots = $this->getArmorContents();
			$player->dataPacket($pk);
			return null;
		}

	public function getDrops() {
			/* decompiled (structured CF) */
			$looting = $this->getLastDamageLootingLevel();
			$drops = [\pocketmine\item\Item::get(\pocketmine\item\Item::BONE, 0, mt_rand(0, 2)), \pocketmine\item\Item::get(\pocketmine\item\Item::ARROW, 0, mt_rand(0, 2))];
			$drops = \pocketmine\entity\VanillaMobEquipment::applyLootingToCommonDrops($drops, $looting);
			if ((mt_rand(1, 1000) <= \pocketmine\entity\VanillaMobEquipment::rareDropChance($looting))) {
				$drops[] = \pocketmine\item\Item::get(\pocketmine\item\Item::BOW, mt_rand(250, 384), 1);
			}
			foreach (\pocketmine\entity\VanillaMobEquipment::maybeDropEquipment($this->getArmorContents(), $this->getWeapon(), $looting) as $drop) {
				$drops[] = $drop;
				/* goto */
			}
			return $drops;
		}

}
