<?php

namespace pocketmine\entity;

abstract class Projectile extends \pocketmine\entity\Entity {
	public $shootingEntity = NULL;
	protected $damage = 0;
	public $hadCollision = false;

	public function __construct($chunk = null, $nbt = null, $shootingEntity = null) {
			/* decompiled (structured CF) */
			$this->shootingEntity = $shootingEntity;
			if (($shootingEntity !== null)) {
				$this->setDataProperty(self::DATA_SHOOTER_ID, self::DATA_TYPE_LONG, $shootingEntity->getId());
			}
			parent::__construct($chunk, $nbt);
			return;
		}

	public function attack($damage = null, $source = null) {
			/* decompiled (structured CF) */
			if (($source->getCause() === \pocketmine\event\entity\EntityDamageEvent::CAUSE_VOID)) {
				parent::attack($damage, $source);
			}
			return null;
		}

	protected function initEntity() {
			/* decompiled (structured CF) */
			parent::initEntity();
			$this->setMaxHealth(1);
			$this->setHealth(1);
			if (isset($this->namedtag->Age)) {
				$this->age = $this->namedtag['Age'];
			}
			return null;
		}

	public function canCollideWith($entity = null) {
			return ($entity instanceof \pocketmine\entity\Living && !($this->onGround));
		}

	public function saveNBT() {
			/* decompiled (structured CF) */
			parent::saveNBT();
			new \pocketmine\nbt\tag\ShortTag('Age', $this->age);
			$this->namedtag->Age = new \pocketmine\nbt\tag\ShortTag('Age', $this->age);
			return null;
		}

	public function onUpdate($currentTick = null) {
			/* decompiled (structured CF) */
			if ($this->closed) {
				return false;
			}
			$tickDiff = ($currentTick - $this->lastUpdate);
			if ((($tickDiff <= 0) && !($this->justCreated))) {
				return true;
			}
			$this->lastUpdate = $currentTick;
			$hasUpdate = $this->entityBaseTick($tickDiff);
			if ($this->isAlive()) {
				$movingObjectPosition = null;
				if (!($this->isCollided)) {
					$this->motionY -= $this->gravity;
				}
				new \pocketmine\math\Vector3(($this->x + $this->motionX), ($this->y + $this->motionY), ($this->z + $this->motionZ));
				$moveVector = new \pocketmine\math\Vector3(($this->x + $this->motionX), ($this->y + $this->motionY), ($this->z + $this->motionZ));
				$list = $this->getLevel()->getCollidingEntities($this->boundingBox->addCoord($this->motionX, $this->motionY, $this->motionZ)->expand(1, 1, 1), $this);
				$nearDistance = \PHP_INT_MAX;
				$nearEntity = null;
				foreach ($list as $entity) {
					if ((($entity === $this->shootingEntity) && ($this->ticksLived < 5))) {
						/* goto */
					}
					$axisalignedbb = $entity->boundingBox->grow(0.3, 0.3, 0.3);
					$ob = $axisalignedbb->calculateIntercept($this, $moveVector);
					if (($ob === null)) {
						/* goto */
					}
					$distance = $this->distanceSquared($ob->hitVector);
					if (($distance < $nearDistance)) {
						$nearDistance = $distance;
						$nearEntity = $entity;
					}
					/* goto */
				}
				if (($nearEntity !== null)) {
					$movingObjectPosition = \pocketmine\level\MovingObjectPosition::fromEntity($nearEntity);
				}
				if (($movingObjectPosition !== null)) {
					if (($movingObjectPosition->entityHit !== null)) {
						if ($this->onHitEntity($movingObjectPosition->entityHit)) {
							return true;
						}
						new \pocketmine\event\entity\ProjectileHitEvent($this);
						$this->server->getPluginManager()->callEvent(new \pocketmine\event\entity\ProjectileHitEvent($this));
						$motion = sqrt((($t90 + $t92) + $t95));
						$damage = ceil(($motion * $this->damage));
						if (($this instanceof \pocketmine\entity\Arrow && $this->isCritical)) {
							$damage += mt_rand(0, ((($damage / 2)) + 1));
						}
						if (($this->shootingEntity === null)) {
							new \pocketmine\event\entity\EntityDamageByEntityEvent($this, $movingObjectPosition->entityHit, \pocketmine\event\entity\EntityDamageEvent::CAUSE_PROJECTILE, $damage);
							$ev = new \pocketmine\event\entity\EntityDamageByEntityEvent($this, $movingObjectPosition->entityHit, \pocketmine\event\entity\EntityDamageEvent::CAUSE_PROJECTILE, $damage);
						} else {
							new \pocketmine\event\entity\EntityDamageByChildEntityEvent($this->shootingEntity, $this, $movingObjectPosition->entityHit, \pocketmine\event\entity\EntityDamageEvent::CAUSE_PROJECTILE, $damage, $this->getProjectileKnockBack());
							$ev = new \pocketmine\event\entity\EntityDamageByChildEntityEvent($this->shootingEntity, $this, $movingObjectPosition->entityHit, \pocketmine\event\entity\EntityDamageEvent::CAUSE_PROJECTILE, $damage, $this->getProjectileKnockBack());
						}
						if (($movingObjectPosition->entityHit->attack($ev->getFinalDamage(), $ev) === true)) {
							if ($this instanceof \pocketmine\entity\Arrow) {
								$this->applyTippedArrowEffects($movingObjectPosition->entityHit);
							}
							$ev->useArmors();
						}
						$this->hadCollision = true;
						if ((0 < $this->fireTicks)) {
							new \pocketmine\event\entity\EntityCombustByEntityEvent($this, $movingObjectPosition->entityHit, 5);
							$ev = new \pocketmine\event\entity\EntityCombustByEntityEvent($this, $movingObjectPosition->entityHit, 5);
							$this->server->getPluginManager()->callEvent($ev);
							if (!($ev->isCancelled())) {
								$movingObjectPosition->entityHit->setOnFire($ev->getDuration());
							}
						}
						$this->kill();
						return true;
					}
				}
				$this->move($this->motionX, $this->motionY, $this->motionZ);
				if (($this->isCollided && !($this->hadCollision))) {
					$this->hadCollision = true;
					$this->motionX = 0;
					$this->motionY = 0;
					$this->motionZ = 0;
					new \pocketmine\event\entity\ProjectileHitEvent($this);
					$this->server->getPluginManager()->callEvent(new \pocketmine\event\entity\ProjectileHitEvent($this));
				} else {
					if ((!($this->isCollided) && $this->hadCollision)) {
						$this->hadCollision = false;
					}
				}
				if ((((!($this->onGround) || (1e-05 < abs($this->motionX))) || (1e-05 < abs($this->motionY))) || (1e-05 < abs($this->motionZ)))) {
					$f = sqrt(($t186 + $t188));
					$this->yaw = ((atan2($this->motionX, $this->motionZ) * 180) / \M_PI);
					$this->pitch = ((atan2($this->motionY, $f) * 180) / \M_PI);
					$hasUpdate = true;
				}
				$this->updateMovement();
			}
			return $hasUpdate;
		}

	protected function onHitEntity($entityHit = null) {
			return false;
		}

	protected function getProjectileKnockBack() {
			return 0.4;
		}

}
