<?php

namespace pocketmine\entity;

class SnowGolem extends \pocketmine\entity\Animal {
	public const NETWORK_ID = 21;

	public $width = 0.3;
	public $length = 0.9;
	public $height = 2.0;

	public function initEntity() {
			/* decompiled (structured CF) */
			$this->setMaxHealth(100);
			new \pocketmine\entity\behavior\ShootEnemyBehavior($this, ['__array_ptr' => '2aaaadd5d4d0'], 'Snowball');
			$this->addBehavior(new \pocketmine\entity\behavior\ShootEnemyBehavior($this, ['__array_ptr' => '2aaaadd5d4d0'], 'Snowball'));
			parent::initEntity();
			return null;
		}

	public function usesPm1eGroundAi() {
			return true;
		}

	public function getName() {
			return;
		}

	public function getHurt() {
			return mt_rand(7, 21);
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->eid = $this->getId();
			$pk->type = self::NETWORK_ID;
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->yaw = $this->yaw;
			$pk->pitch = $this->pitch;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

}
