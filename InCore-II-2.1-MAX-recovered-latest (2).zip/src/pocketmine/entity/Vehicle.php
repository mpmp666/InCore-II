<?php

namespace pocketmine\entity;

abstract class Vehicle extends \pocketmine\entity\Entity implements \pocketmine\entity\Rideable {
	public function canBeRidden() {
			return true;
		}

	public function applyRailEffects($rail = null) {
			/* decompiled (structured CF) */
			if ((($rail->getId() === \pocketmine\block\Block::POWERED_RAIL) && $rail instanceof \pocketmine\block\PoweredRail)) {
				if ($rail->isActive()) {
					$this->accelerateOnPoweredRail($rail);
				} else {
					$this->brakeOnPoweredRail();
				}
			} else {
				if ((($rail->getId() === \pocketmine\block\Block::ACTIVATOR_RAIL) && $rail instanceof \pocketmine\block\ActivatorRail)) {
					$this->activateByRail($rail, $rail->isActive());
				}
			}
			return null;
		}

	protected function activateByRail($rail = null, $active = null) {
			return null;
		}

	protected function brakeOnPoweredRail() {
			/* decompiled (structured CF) */
			$speed = sqrt((($this->motionX * $this->motionX) + ($this->motionZ * $this->motionZ)));
			if (($speed < 0.03)) {
				$this->motionX = 0;
				$this->motionY = 0;
				$this->motionZ = 0;
			} else {
				$this->motionX *= 0.5;
				$this->motionY = 0;
				$this->motionZ *= 0.5;
			}
			if (property_exists($this, 'moveSpeed')) {
				$this->moveSpeed = max(0.1, ($this->moveSpeed * 0.5));
			}
			return null;
		}

	protected function accelerateOnPoweredRail($rail = null) {
			/* decompiled (structured CF) */
			$speed = sqrt((($this->motionX * $this->motionX) + ($this->motionZ * $this->motionZ)));
			if (property_exists($this, 'moveSpeed')) {
				$this->moveSpeed = min(1.2, ($this->moveSpeed + 0.1));
			}
			if ((0.01 < $speed)) {
				$this->motionX += (($this->motionX / $speed) * 0.06);
				$this->motionZ += (($this->motionZ / $speed) * 0.06);
				return null;
			}
			switch ($rail->getRealMeta()) {
				case \pocketmine\block\Rail::STRAIGHT_NORTH_SOUTH:
				new \pocketmine\math\Vector3(($rail->x - 1), $rail->y, $rail->z);
				if ($this->getLevel()->getBlock(new \pocketmine\math\Vector3(($rail->x - 1), $rail->y, $rail->z))->isNormalBlock()) {
					$this->motionX = 0.02;
				} else {
					new \pocketmine\math\Vector3(($rail->x + 1), $rail->y, $rail->z);
					if ($this->getLevel()->getBlock(new \pocketmine\math\Vector3(($rail->x + 1), $rail->y, $rail->z))->isNormalBlock()) {
						$this->motionX = -0.02;
					}
				}
				/* jump */
				case \pocketmine\block\Rail::STRAIGHT_EAST_WEST:
				new \pocketmine\math\Vector3($rail->x, $rail->y, ($rail->z - 1));
				if ($this->getLevel()->getBlock(new \pocketmine\math\Vector3($rail->x, $rail->y, ($rail->z - 1)))->isNormalBlock()) {
					$this->motionZ = 0.02;
				} else {
					new \pocketmine\math\Vector3($rail->x, $rail->y, ($rail->z + 1));
					if ($this->getLevel()->getBlock(new \pocketmine\math\Vector3($rail->x, $rail->y, ($rail->z + 1)))->isNormalBlock()) {
						$this->motionZ = -0.02;
					}
				}
				/* jump */
			}
		}

}
