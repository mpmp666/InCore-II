<?php

namespace pocketmine\entity;

abstract class FlyingAnimal extends \pocketmine\entity\Creature {
	protected $gravity = 0;
	protected $drag = 0.02;
	public $flyDirection = NULL;
	public $flySpeed = 0.5;
	public $highestY = 128;
	protected $pm1eFlyFollowTarget = NULL;
	private $pm1eFlyKnockbackTicks = 0;
	private $switchDirectionTicker = 0;
	public $switchDirectionTicks = 300;

	public function onUpdate($currentTick = null) {
			/* decompiled (structured CF) */
			if (($this->closed !== false)) {
				return false;
			}
			if ((0 < $this->attackingTick)) {
			}
			if ((!($this->isAlive()) && $this->hasSpawned)) {
				if ((20 <= $this->deadTicks)) {
					$this->despawnFromAll();
				}
				return true;
			}
			$tickDiff = ($currentTick - $this->lastUpdate);
			if (($tickDiff <= 0)) {
				return false;
			}
			$this->lastUpdate = $currentTick;
			$this->timings->startTiming();
			$hasUpdate = $this->entityBaseTick($tickDiff);
			if ((($this->willMove(100) && $this->getLevel()->getServer()->aiEnabled) && $this->isAlive())) {
				$hasUpdate = ($this->tickPm1eFlyingAi($tickDiff) || $hasUpdate);
			}
			$this->timings->stopTiming();
			return (((($hasUpdate || !($this->onGround)) || (1e-05 < abs($this->motionX))) || (1e-05 < abs($this->motionY))) || (1e-05 < abs($this->motionZ)));
		}

	public function setPm1eFlyFollowTarget($target = null) {
			$this->pm1eFlyFollowTarget = $target;
		}

	public function getPm1eFlyFollowTarget() {
			return $this->pm1eFlyFollowTarget;
		}

	protected function tickPm1eFlyingAi($tickDiff = null) {
			/* decompiled (structured CF) */
			if (((0 < $this->pm1eFlyKnockbackTicks) && (((1e-05 < abs($this->motionX)) || (1e-05 < abs($this->motionY))) || (1e-05 < abs($this->motionZ))))) {
				$this->pm1eFlyKnockbackTicks = max(0, ($this->pm1eFlyKnockbackTicks - max(1, $tickDiff)));
				$this->move($this->motionX, $this->motionY, $this->motionZ);
				$friction = (1 - $this->drag);
				$this->motionX *= $friction;
				$this->motionY *= $friction;
				$this->motionZ *= $friction;
				$this->updateMovement();
				return true;
			}
			if ($this->pm1eFlyFollowTarget instanceof \pocketmine\entity\Entity) {
				if (($this->pm1eFlyFollowTarget->closed || !($this->pm1eFlyFollowTarget->isAlive()))) {
					$this->pm1eFlyFollowTarget = null;
				}
			}
			if (($t45 === $this->switchDirectionTicks)) {
				$this->switchDirectionTicker = 0;
				if ((mt_rand(0, 100) < 50)) {
					$this->flyDirection = null;
				}
			}
			$target = $this->pm1eFlyFollowTarget;
			if ($target instanceof \pocketmine\math\Vector3) {
				$dx = ($target->x - $this->x);
				$dy = ($target->y - $this->y);
				$dz = ($target->z - $this->z);
				$diff = (abs($dx) + abs($dz));
				$distanceSquared = ((($dx * $dx) + ($dy * $dy)) + ($dz * $dz));
				if (($distanceSquared <= 4)) {
					$this->motionX = 0;
					$this->motionY = 0;
					$this->motionZ = 0;
					return true;
				} else {
					if ((0.001 < $diff)) {
						$this->motionX = (($dx / $diff) * 0.15);
						$this->motionY = (($dy / max(0.001, $diff)) * 0.27);
						$this->motionZ = (($dz / $diff) * 0.15);
						$this->yaw = (((atan2($this->motionX, $this->motionZ) * -1) * 180) / \M_PI);
						$f = sqrt(($t101 + $t103));
						$this->pitch = (((atan2($f, $this->motionY) * -1) * 180) / \M_PI);
						$this->move($this->motionX, $this->motionY, $this->motionZ);
						$this->updateMovement();
						return true;
					}
				}
			}
			if ((($this->highestY < $this->y) && ($this->flyDirection !== null))) {
				$this->flyDirection->y = -0.5;
			}
			$inAir = !($this->isInsideOfSolid());
			if (!($inAir)) {
				$this->flyDirection = null;
			}
			if ($this->flyDirection instanceof \pocketmine\math\Vector3) {
				$this->setMotion($this->flyDirection->multiply($this->flySpeed));
			} else {
				$this->flyDirection = $this->generateRandomDirection();
				$this->flySpeed = (mt_rand(50, 100) / 500);
				$this->setMotion($this->flyDirection);
			}
			$this->move($this->motionX, $this->motionY, $this->motionZ);
			$this->updateMovement();
			$f = sqrt(($t152 + $t154));
			$this->yaw = (((atan2($this->motionX, $this->motionZ) * -1) * 180) / \M_PI);
			$this->pitch = (((atan2($f, $this->motionY) * -1) * 180) / \M_PI);
			if (($this->onGround && $this->flyDirection instanceof \pocketmine\math\Vector3)) {
				$this->flyDirection->y *= -1;
			}
			return true;
		}

	private function generateRandomDirection() {
			new \pocketmine\math\Vector3((mt_rand(-1000, 1000) / 1000), (mt_rand(-500, 500) / 1000), (mt_rand(-1000, 1000) / 1000));
			return new \pocketmine\math\Vector3((mt_rand(-1000, 1000) / 1000), (mt_rand(-500, 500) / 1000), (mt_rand(-1000, 1000) / 1000));
		}

	public function initEntity() {
			/* decompiled (structured CF) */
			parent::initEntity();
			if (($this->getDataProperty(self::DATA_AGEABLE_FLAGS) === null)) {
				$this->setDataProperty(self::DATA_AGEABLE_FLAGS, self::DATA_TYPE_BYTE, 0);
			}
			return null;
		}

	public function knockBack($attacker = null, $damage = null, $x = null, $z = null, $base = null) {
			/* decompiled (structured CF) */
			parent::knockBack($attacker, $damage, $x, $z, $base);
			if ((((1e-05 < abs($this->motionX)) || (1e-05 < abs($this->motionY))) || (1e-05 < abs($this->motionZ)))) {
				$this->pm1eFlyKnockbackTicks = 6;
			}
			return null;
		}

	public function attack($damage = null, $source = null) {
			/* decompiled (structured CF) */
			if ($source->isCancelled()) {
				return false;
			}
			if (($source->getCause() == \pocketmine\event\entity\EntityDamageEvent::CAUSE_FALL)) {
				$source->setCancelled();
				return false;
			}
			return parent::attack($damage, $source);
		}

}
