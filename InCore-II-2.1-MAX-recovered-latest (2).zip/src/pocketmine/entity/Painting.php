<?php

namespace pocketmine\entity;

class Painting extends \pocketmine\entity\Hanging {
	public const NETWORK_ID = 83;

	private $motive = NULL;

	public function initEntity() {
			/* decompiled (structured CF) */
			$this->setMaxHealth(1);
			parent::initEntity();
			if (isset($this->namedtag->Motive)) {
				$this->motive = $this->namedtag['Motive'];
			} else {
				$this->close();
			}
			return null;
		}

	protected function updateMovement() {
			return null;
		}

	public function attack($damage = null, $source = null) {
			parent::attack($damage, $source);
			$this->close();
			return null;
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddPaintingPacket();
			$pk = new \pocketmine\network\protocol\AddPaintingPacket();
			$pk->eid = $this->getId();
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->direction = $this->getDirection();
			$pk->title = $this->motive;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

	public function getDrops() {
			/* decompiled (structured CF) */
			if ((($this->getLevel() !== null) && $this->getLevel()->getServer()->isWorldNonLivingEntityDropsDisabled($this->getLevel()))) {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
			return [\pocketmine\item\Item::get(\pocketmine\item\Item::PAINTING, 0, 1)];
		}

}
