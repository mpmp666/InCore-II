<?php

namespace pocketmine\entity;

class Villager extends \pocketmine\entity\Mob implements \pocketmine\entity\NPC, \pocketmine\entity\Ageable {
	public const PROFESSION_FARMER = 0;
	public const PROFESSION_LIBRARIAN = 1;
	public const PROFESSION_PRIEST = 2;
	public const PROFESSION_BLACKSMITH = 3;
	public const PROFESSION_BUTCHER = 4;
	public const NETWORK_ID = 15;

	public $width = 0.6;
	public $length = 0.6;
	public $height = 0.8;
	private $tradeOffers = NULL;

	public function getName() {
			return 'Villager';
		}

	public static function getProfessionDisplayName($profession = null) {
			/* decompiled (structured CF) */
			switch (min(4, max(0, $profession))) {
				case self::PROFESSION_FARMER:
				return "\xe5\x86\x9c\xe6\xb0\x91";
				case self::PROFESSION_LIBRARIAN:
				return "\xe5\x9b\xbe\xe4\xb9\xa6\xe7\xae\xa1\xe7\x90\x86\xe5\x91\x98";
				case self::PROFESSION_PRIEST:
				return "\xe7\x89\xa7\xe5\xb8\x88";
				case self::PROFESSION_BLACKSMITH:
				return "\xe9\x93\x81\xe5\x8c\xa0";
				case self::PROFESSION_BUTCHER:
				return "\xe5\xb1\xa0\xe5\xa4\xab";
			}
		}

	public function __construct($chunk = null, $nbt = null) {
			parent::__construct($chunk, $nbt);
			$this->setDataProperty(self::DATA_PROFESSION_ID, self::DATA_TYPE_BYTE, $this->getProfession());
			return;
		}

	public function usesPm1eGroundAi() {
			return true;
		}

	public function initEntity() {
			/* decompiled (structured CF) */
			parent::initEntity();
			if (!(isset($this->namedtag->Profession))) {
				$this->setProfession(mt_rand(0, 4));
			}
			self::ensureTradeData($this->namedtag);
			$this->tradeOffers = self::loadTradeOffersFromNBT($this->namedtag);
			if (!(isset($this->namedtag->IsBaby))) {
				new \pocketmine\nbt\tag\ByteTag('IsBaby', 1);
				$this->namedtag->IsBaby = new \pocketmine\nbt\tag\ByteTag('IsBaby', 1);
				$this->setBaby(false);
			}
			$this->setBaby($this->isBaby());
			return null;
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->eid = $this->getId();
			$pk->type = 15;
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->yaw = $this->yaw;
			$pk->pitch = $this->pitch;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

	public function saveNBT() {
			/* decompiled (structured CF) */
			parent::saveNBT();
			new \pocketmine\nbt\tag\ByteTag('Profession', $this->getProfession());
			$this->namedtag->Profession = new \pocketmine\nbt\tag\ByteTag('Profession', $this->getProfession());
			$this->saveTradeOffersToNBT($this->namedtag);
			return null;
		}

	public function setProfession($profession = null) {
			new \pocketmine\nbt\tag\ByteTag('Profession', $profession);
			$this->namedtag->Profession = new \pocketmine\nbt\tag\ByteTag('Profession', $profession);
			return null;
		}

	public function getProfession() {
			$pro = ($this->namedtag['Profession']);
			return min(4, max(0, $pro));
		}

	public function getTradeOffers() {
			/* decompiled (structured CF) */
			if (($this->tradeOffers === null)) {
				self::ensureTradeData($this->namedtag);
				$this->tradeOffers = self::loadTradeOffersFromNBT($this->namedtag);
			}
			return $this->tradeOffers;
		}

	public function setTradeOffers($offers = null) {
			$this->tradeOffers = array_values(array_filter($offers, function () { /* unrecovered lambda E:/Desktop/src/src/pocketmine/entity/Villager.php.TdmbGj:135 */ return null; }));
			$this->saveTradeOffersToNBT($this->namedtag);
			return null;
		}

	public function saveTradeOffersToNBT($nbt = null) {
			$nbt = $this->namedtag;
			$nbt->Offers = self::offersToNBT($this->getTradeOffers());
			return null;
		}

	public static function ensureTradeData($nbt = null, $seed = null) {
			/* decompiled (structured CF) */
			if (((isset($nbt->Offers) && $nbt->Offers instanceof \pocketmine\nbt\tag\ListTag) && (0 < $nbt->Offers->getCount()))) {
				return null;
			}
			if (isset($nbt->Profession)) {
			} else {
			}
			$profession = self::PROFESSION_FARMER;
			$nbt->Offers = self::offersToNBT(\pocketmine\entity\trade\VillagerTradeFactory::generateOffers($profession, mt_rand(1, \PHP_INT_MAX)));
		}

	public static function loadTradeOffersFromNBT($nbt = null) {
			/* decompiled (structured CF) */
			if ((!(isset($nbt->Offers)) || !($nbt->Offers instanceof \pocketmine\nbt\tag\ListTag))) {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
			$offers = ['__array_ptr' => '2aaaac9fc9a0'];
			foreach ($nbt->Offers as $tag) {
				if ($tag instanceof \pocketmine\nbt\tag\CompoundTag) {
					$offers[] = \pocketmine\entity\trade\VillagerTradeOffer::fromNBT($tag);
				}
				/* goto */
			}
			return $offers;
		}

	public static function offersToNBT($offers = null) {
			/* decompiled (structured CF) */
			new \pocketmine\nbt\tag\ListTag('Offers', ['__array_ptr' => '2aaaac9fc9a0']);
			$list = new \pocketmine\nbt\tag\ListTag('Offers', ['__array_ptr' => '2aaaac9fc9a0']);
			$list->setTagType(\pocketmine\nbt\NBT::TAG_Compound);
			foreach (array_values($offers) as $index => $offer) {
				if ($offer instanceof \pocketmine\entity\trade\VillagerTradeOffer) {
					$list->prop = $offer->toNBT($index);
				}
				/* goto */
			}
			return $list;
		}

	public function openTradeWindow($player = null, $currentTradeIndex = null) {
			/* decompiled (structured CF) */
			if ($this->isBaby()) {
				return -1;
			}
			return $player->addWindow(\pocketmine\inventory\VillagerTradeInventory::createForPlayer($this, $player, $currentTradeIndex));
		}

	public function kill() {
			/* decompiled (structured CF) */
			if ($this->closed) {
				return null;
			}
			if (!($this->isAlive())) {
			}
			if ($this->transformIntoZombieVillager()) {
			}
			parent::kill();
		}

	protected function transformIntoZombieVillager() {
			/* decompiled (structured CF) */
			$cause = $this->getLastDamageCause();
			if (!($cause instanceof \pocketmine\event\entity\EntityDamageByEntityEvent)) {
				return false;
			}
			$damager = $cause->getDamager();
			if (!($damager instanceof \pocketmine\entity\Zombie)) {
				return false;
			}
			$chunk = $this->getLevel()->getChunk(($this->x >> 4), ($this->z >> 4), true);
			if (($chunk === null)) {
				return false;
			}
			new \pocketmine\nbt\tag\DoubleTag(0, $this->x);
			new \pocketmine\nbt\tag\DoubleTag(1, $this->y);
			new \pocketmine\nbt\tag\DoubleTag(2, $this->z);
			new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag(0, $this->x), new \pocketmine\nbt\tag\DoubleTag(1, $this->y), new \pocketmine\nbt\tag\DoubleTag(2, $this->z)]);
			new \pocketmine\nbt\tag\DoubleTag(0, $this->motionX);
			new \pocketmine\nbt\tag\DoubleTag(1, $this->motionY);
			new \pocketmine\nbt\tag\DoubleTag(2, $this->motionZ);
			new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag(0, $this->motionX), new \pocketmine\nbt\tag\DoubleTag(1, $this->motionY), new \pocketmine\nbt\tag\DoubleTag(2, $this->motionZ)]);
			new \pocketmine\nbt\tag\FloatTag(0, $this->yaw);
			new \pocketmine\nbt\tag\FloatTag(1, $this->pitch);
			new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag(0, $this->yaw), new \pocketmine\nbt\tag\FloatTag(1, $this->pitch)]);
			new \pocketmine\nbt\tag\ByteTag('Profession', $this->getProfession());
			if ($this->isBaby()) {
			} else {
			}
			new \pocketmine\nbt\tag\ByteTag('IsBaby', 0);
			new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag(0, $this->x), new \pocketmine\nbt\tag\DoubleTag(1, $this->y), new \pocketmine\nbt\tag\DoubleTag(2, $this->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag(0, $this->motionX), new \pocketmine\nbt\tag\DoubleTag(1, $this->motionY), new \pocketmine\nbt\tag\DoubleTag(2, $this->motionZ)]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag(0, $this->yaw), new \pocketmine\nbt\tag\FloatTag(1, $this->pitch)]), new \pocketmine\nbt\tag\ByteTag('Profession', $this->getProfession()), new \pocketmine\nbt\tag\ByteTag('IsBaby', 0)]);
			$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag(0, $this->x), new \pocketmine\nbt\tag\DoubleTag(1, $this->y), new \pocketmine\nbt\tag\DoubleTag(2, $this->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag(0, $this->motionX), new \pocketmine\nbt\tag\DoubleTag(1, $this->motionY), new \pocketmine\nbt\tag\DoubleTag(2, $this->motionZ)]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag(0, $this->yaw), new \pocketmine\nbt\tag\FloatTag(1, $this->pitch)]), new \pocketmine\nbt\tag\ByteTag('Profession', $this->getProfession()), new \pocketmine\nbt\tag\ByteTag('IsBaby', 0)]);
			$this->saveTradeOffersToNBT($nbt);
			$soundPlayers = $this->getLevel()->getChunkPlayers($chunk->getX(), $chunk->getZ());
			new \pocketmine\entity\ZombieVillager($chunk, $nbt);
			$zombieVillager = new \pocketmine\entity\ZombieVillager($chunk, $nbt);
			$zombieVillager->setHealth($zombieVillager->getMaxHealth());
			$zombieVillager->spawnToAll();
			new \pocketmine\level\sound\VillagerDeathSound($this);
			$this->getLevel()->addSound(new \pocketmine\level\sound\VillagerDeathSound($this), $soundPlayers);
			new \pocketmine\level\sound\ZombieInfectSound($this);
			$this->getLevel()->addSound(new \pocketmine\level\sound\ZombieInfectSound($this), $soundPlayers);
			$this->close();
			return true;
		}

	public function isBaby() {
			/* decompiled (structured CF) */
			if (($this->namedtag['IsBaby'] == 0)) {
			} else {
			}
			return true;
		}

	public function setBaby($resting = null) {
			/* decompiled (structured CF) */
			if ($resting) {
			} else {
			}
			$this->setDataProperty(self::DATA_VILLAGER_IS_BABY, self::DATA_TYPE_BYTE, 0);
			if ($resting) {
			} else {
			}
			new \pocketmine\nbt\tag\ByteTag('IsBaby', 0);
			$this->namedtag->IsBaby = new \pocketmine\nbt\tag\ByteTag('IsBaby', 0);
			return null;
		}

	public function getDrops() {
			return [\pocketmine\item\Item::get(\pocketmine\item\Item::EMERALD, 0, mt_rand(0, 2))];
		}

}
