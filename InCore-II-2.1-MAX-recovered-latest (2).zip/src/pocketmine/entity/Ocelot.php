<?php

namespace pocketmine\entity;

class Ocelot extends \pocketmine\entity\Animal {
	public const NETWORK_ID = 22;
	public const TYPE_WILD = 0;
	public const TYPE_TUXEDO = 1;
	public const TYPE_TABBY = 2;
	public const TYPE_SIAMESE = 3;
	public const PM1E_TEMPT_RADIUS_SQUARED = 256;
	public const PM1E_SCARE_RADIUS_SQUARED = 36;
	public const PM1E_WALK_MULTIPLIER = 2.0;
	public const PM1E_TEMPT_MULTIPLIER = 3.3333333333333335;
	public const PM1E_SCARED_MULTIPLIER = 3.6;

	public $width = 0.312;
	public $length = 2.188;
	public $height = 0.75;
	public $dropExp = array (
  0 => 1,
  1 => 3,
);

	public function getName() {
			return 'Ocelot';
		}

	public function __construct($chunk = null, $nbt = null) {
			/* decompiled (structured CF) */
			if (!(isset($nbt->CatType))) {
				new \pocketmine\nbt\tag\ByteTag('CatType', mt_rand(0, 3));
				$nbt->CatType = new \pocketmine\nbt\tag\ByteTag('CatType', mt_rand(0, 3));
			}
			parent::__construct($chunk, $nbt);
			$this->setDataProperty(self::DATA_CAT_TYPE, self::DATA_TYPE_BYTE, $this->getCatType());
			return;
		}

	public function usesPm1eGroundAi() {
			return true;
		}

	public function onUpdate($currentTick = null) {
			/* decompiled (structured CF) */
			if ($this->closed) {
				return false;
			}
			if ((!($this->closed) && $this->isAlive())) {
				$this->tickPm1eOcelotLogic();
			}
			$hasUpdate = parent::onUpdate($currentTick);
			return $hasUpdate;
		}

	protected function tickPm1eOcelotLogic() {
			/* decompiled (structured CF) */
			$fishHolder = $this->findPm1eFishHoldingPlayer();
			if ($fishHolder instanceof \pocketmine\Player) {
				if ($this->doesPm1ePlayerScare($fishHolder)) {
					$this->setPm1eFollowTarget(null);
					$this->setPm1eMoveTarget($this->getPm1eFleeTarget($fishHolder, 12));
					$this->setPm1eMoveMultiplier(self::PM1E_SCARED_MULTIPLIER);
					$this->setPm1eStayTime(0);
					return null;
				}
				$this->setPm1eFollowTarget($fishHolder);
				$this->setPm1eMoveMultiplier(self::PM1E_TEMPT_MULTIPLIER);
				$this->setPm1eStayTime(0);
			}
			if ($this->getPm1eFollowTarget() instanceof \pocketmine\Player) {
				$this->setPm1eFollowTarget(null);
			}
			$this->setPm1eMoveMultiplier(self::PM1E_WALK_MULTIPLIER);
		}

	protected function findPm1eFishHoldingPlayer() {
			/* decompiled (structured CF) */
			$level = $this->getLevel();
			if ((($level === null) || !(method_exists($level, 'getPlayers')))) {
				return null;
			}
			$closest = null;
			$bestDistance = self::PM1E_TEMPT_RADIUS_SQUARED;
			foreach ($level->getPlayers() as $player) {
				if (!($this->canPm1ePlayerHoldFish($player))) {
					/* goto */
				}
				$distance = $this->distanceSquared($player);
				if (($distance <= $bestDistance)) {
					$bestDistance = $distance;
					$closest = $player;
				}
				/* goto */
			}
			return $closest;
		}

	protected function canPm1ePlayerHoldFish($player = null) {
			/* decompiled (structured CF) */
			if (($player->closed || !($player->isAlive()))) {
				return false;
			}
			if ((((method_exists($player, 'isSurvival') && method_exists($player, 'isAdventure')) && !($player->isSurvival())) && !($player->isAdventure()))) {
				return false;
			}
			return $this->isPm1eTemptFish($player->getInventory()->getItemInHand());
		}

	protected function doesPm1ePlayerScare($player = null) {
			/* decompiled (structured CF) */
			if ((self::PM1E_SCARE_RADIUS_SQUARED < $this->distanceSquared($player))) {
				return false;
			}
			return ($player->isSprinting() || !($player->isSneaking()));
		}

	protected function getPm1eFleeTarget($player = null, $distance = null) {
			/* decompiled (structured CF) */
			$dx = ($this->x - $player->x);
			$dz = ($this->z - $player->z);
			$length = sqrt((($dx * $dx) + ($dz * $dz)));
			if (($length < 0.0001)) {
				$dx = 1;
				$dz = 0;
				$length = 1;
			}
			new \pocketmine\math\Vector3(($this->x + ($distance * ($dx / $length))), $this->y, ($this->z + ($distance * ($dz / $length))));
			return new \pocketmine\math\Vector3(($this->x + ($distance * ($dx / $length))), $this->y, ($this->z + ($distance * ($dz / $length))));
		}

	protected function isPm1eTemptFish($item = null) {
			return (($item->getId() === \pocketmine\item\Item::RAW_SALMON) || (($item->getId() === \pocketmine\item\Item::RAW_FISH) && (($item->getDamage() === 0) || ($item->getDamage() === 1))));
		}

	public function onInteract($player = null, $item = null) {
			/* decompiled (structured CF) */
			if ($item instanceof \pocketmine\item\Lead) {
				return $item->leashEntity($player, $this);
			}
			if (!($this->isPm1eTemptFish($item))) {
				return false;
			}
			if (($this->getHealth() < $this->getMaxHealth())) {
				$this->setHealth(min($this->getMaxHealth(), ($this->getHealth() + 2)));
			}
			if ($player->isSurvival()) {
				$item->setCount(($item->getCount() - 1));
				if ((0 < $item->getCount())) {
				} else {
				}
				$player->getInventory()->setItemInHand(\pocketmine\item\Item::get(\pocketmine\item\Item::AIR, 0, 0));
			}
			return true;
		}

	public function setCatType($type = null) {
			new \pocketmine\nbt\tag\ByteTag('CatType', $type);
			$this->namedtag->CatType = new \pocketmine\nbt\tag\ByteTag('CatType', $type);
			return null;
		}

	public function getCatType() {
			return ($this->namedtag['CatType']);
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->eid = $this->getId();
			$pk->type = self::NETWORK_ID;
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->yaw = $this->yaw;
			$pk->pitch = $this->pitch;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

}
