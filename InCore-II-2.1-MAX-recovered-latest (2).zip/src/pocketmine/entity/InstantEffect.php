<?php

namespace pocketmine\entity;

class InstantEffect extends \pocketmine\entity\Effect {
}
