<?php

namespace pocketmine\entity;

class Minecart extends \pocketmine\entity\Vehicle {
	public const NETWORK_ID = 84;
	public const TYPE_NORMAL = 1;
	public const TYPE_CHEST = 2;
	public const TYPE_HOPPER = 3;
	public const TYPE_TNT = 4;
	public const STATE_INITIAL = 0;
	public const STATE_ON_RAIL = 1;
	public const STATE_OFF_RAIL = 2;
	public const MAX_RAIL_STEP_DISTANCE = 0.25;

	public $height = 0.7;
	public $width = 0.98;
	public $drag = 0.1;
	public $gravity = 0.5;
	public $isMoving = false;
	public $moveSpeed = 0.5;
	private $state = 0;
	private $direction = -1;
	private $moveVector = array (
);
	public $motionX = 0;
	public $motionY = 0;
	public $motionZ = 0;

	public function initEntity() {
			/* decompiled (structured CF) */
			$this->setMaxHealth(1);
			$this->setHealth($this->getMaxHealth());
			new \pocketmine\math\Vector3(-1, 0, 0);
			$this->moveVector[\pocketmine\entity\Entity::NORTH] = new \pocketmine\math\Vector3(-1, 0, 0);
			new \pocketmine\math\Vector3(1, 0, 0);
			$this->moveVector[\pocketmine\entity\Entity::SOUTH] = new \pocketmine\math\Vector3(1, 0, 0);
			new \pocketmine\math\Vector3(0, 0, -1);
			$this->moveVector[\pocketmine\entity\Entity::EAST] = new \pocketmine\math\Vector3(0, 0, -1);
			new \pocketmine\math\Vector3(0, 0, 1);
			$this->moveVector[\pocketmine\entity\Entity::WEST] = new \pocketmine\math\Vector3(0, 0, 1);
			parent::initEntity();
			return null;
		}

	public function getName() {
			return 'Minecart';
		}

	public function getType() {
			return self::TYPE_NORMAL;
		}

	public function onUpdate($currentTick = null) {
			/* decompiled (structured CF) */
			if (($this->closed !== false)) {
				return false;
			}
			$tickDiff = ($currentTick - $this->lastUpdate);
			if (($tickDiff <= 1)) {
				return false;
			}
			$this->lastUpdate = $currentTick;
			$this->timings->startTiming();
			$hasUpdate = false;
			$rider = $this->getLinkedEntity();
			if ($rider instanceof \pocketmine\Player) {
				$this->syncRiderPositionToVehicle($rider, 0.7);
			}
			$chunksReady = $this->preloadRiderChunks(2);
			if (!($chunksReady)) {
				if ($rider instanceof \pocketmine\Player) {
					$this->syncRiderPositionToVehicle($rider, 0.7);
				}
				$this->timings->stopTiming();
				return true;
			}
			if ($this->isAlive()) {
				$movingType = $this->getLevel()->getServer()->minecartMovingType;
				if (($movingType == -1)) {
					return false;
				} else {
					if (($movingType == 1)) {
						$p = $this->getLinkedEntity();
						if ($p instanceof \pocketmine\Player) {
							if (($this->state === 0)) {
								$this->checkIfOnRail();
							} else {
								if (($this->state === 1)) {
									$hasUpdate = $this->forwardOnRail($p);
									$this->updateMovement();
								}
							}
						}
					} else {
						if (($movingType == 0)) {
							$p = $this->getLinkedEntity();
							if ($p instanceof \pocketmine\Player) {
								$this->motionX = (sin((($p->getYaw() / 180) * \M_PI)) * -1);
								$this->motionZ = cos((($p->getYaw() / 180) * \M_PI));
							}
							$target = $this->getLevel()->getBlock($this->add($this->motionX, 0, $this->motionZ)->round());
							$target2 = $this->getLevel()->getBlock($this->add($this->motionX, 0, $this->motionZ)->floor());
							if ((($target->getId() != \pocketmine\item\Item::AIR) || ($target2->getId() != \pocketmine\item\Item::AIR))) {
								$this->motionY = ($this->gravity * 3);
							} else {
								$this->motionY -= $this->gravity;
							}
							if ($this->checkObstruction($this->x, $this->y, $this->z)) {
								$hasUpdate = true;
							}
							$this->move($this->motionX, $this->motionY, $this->motionZ);
							$this->updateMovement();
							$friction = (1 - $this->drag);
							if (($this->onGround && ((1e-05 < abs($this->motionX)) || (1e-05 < abs($this->motionZ))))) {
								$friction = ($friction * $this->getLevel()->getBlock($this->temporalVector->setComponents((floor($this->x)), (floor(($this->y - 1))), ((floor($this->z)) - 1)))->getFrictionFactor());
							}
							$this->motionX *= $friction;
							$this->motionY *= (1 - $this->drag);
							$this->motionZ *= $friction;
							if ($this->onGround) {
								$this->motionY *= -0.5;
							}
						} else {
							if (($movingType == 2)) {
								$p = $this->getLinkedEntity();
								if ($p instanceof \pocketmine\Player) {
									if (($this->state === 0)) {
										$y = -1;
										while (($this->state === 0)) {
											$positionToCheck = $this->temporalVector->setComponents($this->x, ($this->y + $y), $this->z);
											$block = $this->level->getBlock($positionToCheck);
											if ($this->isRail($block)) {
												$minecartPosition = $positionToCheck->floor()->add(0.5, 0.75, 0.5);
												$this->setPosition($minecartPosition);
												$this->state = 1;
											}
											$y++;
										}
										if (($this->state !== 1)) {
											$this->state = 0;
											if ($p instanceof \pocketmine\Player) {
												$this->motionX = (sin((($p->getYaw() / 180) * \M_PI)) * -1);
												$this->motionZ = cos((($p->getYaw() / 180) * \M_PI));
											}
											$target = $this->getLevel()->getBlock($this->add($this->motionX, 0, $this->motionZ)->round());
											$target2 = $this->getLevel()->getBlock($this->add($this->motionX, 0, $this->motionZ)->floor());
											if ((($target->getId() != \pocketmine\item\Item::AIR) || ($target2->getId() != \pocketmine\item\Item::AIR))) {
												$this->motionY = ($this->gravity * 3);
											} else {
												$this->motionY -= $this->gravity;
											}
											if ($this->checkObstruction($this->x, $this->y, $this->z)) {
												$hasUpdate = true;
											}
											$this->move($this->motionX, $this->motionY, $this->motionZ);
											$this->updateMovement();
											$friction = (1 - $this->drag);
											if (($this->onGround && ((1e-05 < abs($this->motionX)) || (1e-05 < abs($this->motionZ))))) {
												$friction = ($friction * $this->getLevel()->getBlock($this->temporalVector->setComponents((floor($this->x)), (floor(($this->y - 1))), ((floor($this->z)) - 1)))->getFrictionFactor());
											}
											$this->motionX *= $friction;
											$this->motionY *= (1 - $this->drag);
											$this->motionZ *= $friction;
											if ($this->onGround) {
												$this->motionY *= -0.5;
											}
										}
									} else {
										if (($this->state === 1)) {
											$hasUpdate = $this->forwardOnRail($p);
											$this->updateMovement();
										}
									}
								}
							}
						}
					}
				}
			}
			$this->preloadRiderChunks(1);
			if ($rider instanceof \pocketmine\Player) {
				$this->syncRiderPositionToVehicle($rider, 0.7);
			}
			$this->timings->stopTiming();
			return (((($hasUpdate || !($this->onGround)) || (1e-05 < abs($this->motionX))) || (1e-05 < abs($this->motionY))) || (1e-05 < abs($this->motionZ)));
		}

	private function checkIfOnRail() {
			/* decompiled (structured CF) */
			$y = -1;
			while (($this->state === 0)) {
				$positionToCheck = $this->temporalVector->setComponents($this->x, ($this->y + $y), $this->z);
				$block = $this->level->getBlock($positionToCheck);
				if ($this->isRail($block)) {
					$minecartPosition = $positionToCheck->floor()->add(0.5, 0.75, 0.5);
					$this->setPosition($minecartPosition);
					$this->state = 1;
				}
				$y++;
			}
			if (($this->state !== 1)) {
				$this->state = 2;
			}
			return null;
		}

	private function isRail($rail = null) {
			return (($rail !== null) && in_array($rail->getId(), [\pocketmine\block\Block::RAIL, \pocketmine\block\Block::ACTIVATOR_RAIL, \pocketmine\block\Block::DETECTOR_RAIL, \pocketmine\block\Block::POWERED_RAIL]));
		}

	private function getCurrentRail() {
			/* decompiled (structured CF) */
			$block = $this->getLevel()->getBlock($this);
			if ($this->isRail($block)) {
				return $block;
			}
			$down = $this->temporalVector->setComponents($this->x, ($this->y - 1), $this->z);
			$block = $this->getLevel()->getBlock($down);
			if ($this->isRail($block)) {
				return $block;
			}
		}

	private function forwardOnRail($player = null) {
			/* decompiled (structured CF) */
			if (($this->direction === -1)) {
				$candidateDirection = $player->getDirection();
			} else {
				$candidateDirection = $this->direction;
			}
			$rail = $this->getCurrentRail();
			if (($rail !== null)) {
				$this->applyRailEffects($rail);
				return $this->moveAlongRail($candidateDirection, max(0, ($this->moveSpeed)), $rail);
			} else {
				$this->state = 0;
			}
			return false;
		}

	private function moveAlongRail($candidateDirection = null, $distance = null, $startingRail = null) {
			/* decompiled (structured CF) */
			if (($distance <= 0)) {
				return false;
			}
			$remaining = $distance;
			$moved = false;
			$rail = $startingRail;
			while ((1e-06 < $remaining)) {
				if (($rail === null)) {
					$rail = $this->getCurrentRail();
				}
				if (($rail === null)) {
					$this->state = 0;
					return $moved;
				}
				$railType = $rail->getRealMeta();
				$nextDirection = $this->getDirectionToMove($railType, $candidateDirection);
				if (($nextDirection === -1)) {
					$this->direction = -1;
					return $moved;
				}
				$this->direction = $nextDirection;
				$step = min($remaining, self::MAX_RAIL_STEP_DISTANCE);
				$movedVertically = $this->checkForVertical($railType, $nextDirection);
				if ((!($movedVertically) && !($this->moveIfRail($step)))) {
					return $moved;
				}
				$moved = true;
				$remaining -= $step;
				$candidateDirection = $this->direction;
				$rail = null;
			}
			return $moved;
		}

	private function getDirectionToMove($railType = null, $candidateDirection = null) {
			/* decompiled (structured CF) */
			if (!(($railType == \pocketmine\block\Rail::STRAIGHT_NORTH_SOUTH))) {
				if (!(($railType == \pocketmine\block\Rail::SLOPED_ASCENDING_NORTH))) {
					if (!(($railType == \pocketmine\block\Rail::SLOPED_ASCENDING_SOUTH))) {
						if (!(($railType == \pocketmine\block\Rail::STRAIGHT_EAST_WEST))) {
							if (!(($railType == \pocketmine\block\Rail::SLOPED_ASCENDING_EAST))) {
								if (!(($railType == \pocketmine\block\Rail::SLOPED_ASCENDING_WEST))) {
									if (!(($railType == \pocketmine\block\Rail::CURVED_SOUTH_EAST))) {
										if (!(($railType == \pocketmine\block\Rail::CURVED_SOUTH_WEST))) {
											if (!(($railType == \pocketmine\block\Rail::CURVED_NORTH_WEST))) {
												if (!(($railType == \pocketmine\block\Rail::CURVED_NORTH_EAST))) {
												} else {
													if (!(($candidateDirection == \pocketmine\entity\Entity::NORTH))) {
														if (!(($candidateDirection == \pocketmine\entity\Entity::SOUTH))) {
														} else {
															return $candidateDirection;
														}
														/* jump */
														if (!(($candidateDirection == \pocketmine\entity\Entity::WEST))) {
															if (!(($candidateDirection == \pocketmine\entity\Entity::EAST))) {
															} else {
																return $candidateDirection;
															}
															/* jump */
															if (!(($candidateDirection == \pocketmine\entity\Entity::SOUTH))) {
																if (!(($candidateDirection == \pocketmine\entity\Entity::EAST))) {
																	if (!(($candidateDirection == \pocketmine\entity\Entity::NORTH))) {
																		if (!(($candidateDirection == \pocketmine\entity\Entity::WEST))) {
																			/* jump */
																			return $candidateDirection;
																		}
																	}
																	return $this->checkForTurn($candidateDirection, \pocketmine\entity\Entity::SOUTH);
																	/* jump */
																	if (!(($candidateDirection == \pocketmine\entity\Entity::SOUTH))) {
																		if (!(($candidateDirection == \pocketmine\entity\Entity::WEST))) {
																			if (!(($candidateDirection == \pocketmine\entity\Entity::NORTH))) {
																				if (!(($candidateDirection == \pocketmine\entity\Entity::EAST))) {
																					/* jump */
																					return $candidateDirection;
																				}
																			}
																			return $this->checkForTurn($candidateDirection, \pocketmine\entity\Entity::SOUTH);
																			/* jump */
																			if (!(($candidateDirection == \pocketmine\entity\Entity::NORTH))) {
																				if (!(($candidateDirection == \pocketmine\entity\Entity::WEST))) {
																					if (!(($candidateDirection == \pocketmine\entity\Entity::SOUTH))) {
																						if (!(($candidateDirection == \pocketmine\entity\Entity::EAST))) {
																							/* jump */
																							return $candidateDirection;
																						}
																					}
																					return $this->checkForTurn($candidateDirection, \pocketmine\entity\Entity::NORTH);
																					/* jump */
																					if (!(($candidateDirection == \pocketmine\entity\Entity::NORTH))) {
																						if (!(($candidateDirection == \pocketmine\entity\Entity::EAST))) {
																							if (!(($candidateDirection == \pocketmine\entity\Entity::SOUTH))) {
																								if (!(($candidateDirection == \pocketmine\entity\Entity::WEST))) {
																									/* jump */
																									return $candidateDirection;
																								}
																							}
																							return $this->checkForTurn($candidateDirection, \pocketmine\entity\Entity::NORTH);
																							/* jump */
																							return -1;
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

	private function checkForTurn($currentDirection = null, $newDirection = null) {
			/* decompiled (structured CF) */
			if (!(($currentDirection == \pocketmine\entity\Entity::NORTH))) {
				if (!(($currentDirection == \pocketmine\entity\Entity::SOUTH))) {
					if (!(($currentDirection == \pocketmine\entity\Entity::EAST))) {
						if (!(($currentDirection == \pocketmine\entity\Entity::WEST))) {
						} else {
							$diff = ($this->x - $this->getFloorX());
							if ((($diff !== 0) && ($diff <= 0.5))) {
								$dx = (($this->getFloorX() + 0.5) - $this->x);
								$this->move($dx, 0, 0);
								return $newDirection;
							}
							/* jump */
							$diff = ($this->x - $this->getFloorX());
							if ((($diff !== 0) && (0.5 <= $diff))) {
								$dx = (($this->getFloorX() + 0.5) - $this->x);
								$this->move($dx, 0, 0);
								return $newDirection;
							}
							/* jump */
							$diff = ($this->z - $this->getFloorZ());
							if ((($diff !== 0) && ($diff <= 0.5))) {
								$dz = (($this->getFloorZ() + 0.5) - $this->z);
								$this->move(0, 0, $dz);
								return $newDirection;
							}
							/* jump */
							$diff = ($this->z - $this->getFloorZ());
							if ((($diff !== 0) && (0.5 <= $diff))) {
								$dz = (($this->getFloorZ() + 0.5) - $this->z);
								$dz = $dz;
								$this->move(0, 0, $dz);
								return $newDirection;
							}
							/* jump */
						}
						return $currentDirection;
					}
				}
			}
		}

	private function checkForVertical($railType = null, $currentDirection = null) {
			/* decompiled (structured CF) */
			if (!(($railType == \pocketmine\block\Rail::SLOPED_ASCENDING_NORTH))) {
				if (!(($railType == \pocketmine\block\Rail::SLOPED_ASCENDING_SOUTH))) {
					if (!(($railType == \pocketmine\block\Rail::SLOPED_ASCENDING_EAST))) {
						if (!(($railType == \pocketmine\block\Rail::SLOPED_ASCENDING_WEST))) {
						} else {
							if (!(($currentDirection == \pocketmine\entity\Entity::NORTH))) {
								if (!(($currentDirection == \pocketmine\entity\Entity::SOUTH))) {
								} else {
									$diff = ($this->x - $this->getFloorX());
									if ((($diff !== 0) && ($diff <= 0.5))) {
										$dx = (($this->getFloorX() - 0.1) - $this->x);
										$this->move($dx, -1, 0);
										return true;
									}
									/* jump */
									$diff = ($this->x - $this->getFloorX());
									if ((($diff !== 0) && (0.5 <= $diff))) {
										$dx = (($this->getFloorX() + 1) - $this->x);
										$this->move($dx, 1, 0);
										return true;
									}
									/* jump */
								}
								/* jump */
								if (!(($currentDirection == \pocketmine\entity\Entity::SOUTH))) {
									if (!(($currentDirection == \pocketmine\entity\Entity::NORTH))) {
									} else {
										$diff = ($this->x - $this->getFloorX());
										if ((($diff !== 0) && (0.5 <= $diff))) {
											$dx = (($this->getFloorX() + 1) - $this->x);
											$this->move($dx, -1, 0);
											return true;
										}
										/* jump */
										$diff = ($this->x - $this->getFloorX());
										if ((($diff !== 0) && ($diff <= 0.5))) {
											$dx = (($this->getFloorX() - 0.1) - $this->x);
											$this->move($dx, 1, 0);
											return true;
										}
										/* jump */
									}
									/* jump */
									if (!(($currentDirection == \pocketmine\entity\Entity::EAST))) {
										if (!(($currentDirection == \pocketmine\entity\Entity::WEST))) {
										} else {
											$diff = ($this->z - $this->getFloorZ());
											if ((($diff !== 0) && ($diff <= 0.5))) {
												$dz = (($this->getFloorZ() - 0.1) - $this->z);
												$this->move(0, 1, $dz);
												return true;
											}
											/* jump */
											$diff = ($this->z - $this->getFloorZ());
											if ((($diff !== 0) && (0.5 <= $diff))) {
												$dz = (($this->getFloorZ() + 1) - $this->z);
												$this->move(0, -1, $dz);
												return true;
											}
											/* jump */
										}
										/* jump */
										if (!(($currentDirection == \pocketmine\entity\Entity::WEST))) {
											if (!(($currentDirection == \pocketmine\entity\Entity::EAST))) {
											} else {
												$diff = ($this->z - $this->getFloorZ());
												if ((($diff !== 0) && (0.5 <= $diff))) {
													$dz = (($this->getFloorZ() + 1) - $this->z);
													$this->move(0, 1, $dz);
													return true;
												}
												/* jump */
												$diff = ($this->z - $this->getFloorZ());
												if ((($diff !== 0) && ($diff <= 0.5))) {
													$dz = (($this->getFloorZ() - 0.1) - $this->z);
													$this->move(0, -1, $dz);
													return true;
												}
												/* jump */
											}
											/* jump */
											return false;
										}
									}
								}
							}
						}
					}
				}
			}
		}

	private function moveIfRail($distance = null) {
			/* decompiled (structured CF) */
			$nextMoveVector = $this->moveVector[$this->direction];
			if (($distance === null)) {
			} else {
			}
			$nextMoveVector = $nextMoveVector->multiply($distance);
			$newVector = $this->add($nextMoveVector->x, $nextMoveVector->y, $nextMoveVector->z);
			$possibleRail = $this->getCurrentRail();
			if ((($possibleRail !== null) && in_array($possibleRail->getId(), [\pocketmine\block\Block::RAIL, \pocketmine\block\Block::ACTIVATOR_RAIL, \pocketmine\block\Block::DETECTOR_RAIL, \pocketmine\block\Block::POWERED_RAIL]))) {
				$this->moveUsingVector($newVector);
				if (($this->getCurrentRail() === null)) {
					$this->move(($nextMoveVector->x * -1), ($nextMoveVector->y * -1), ($nextMoveVector->z * -1));
					return false;
				}
				return true;
			}
			return false;
		}

	private function moveUsingVector($desiredPosition = null) {
			/* decompiled (structured CF) */
			$dx = ($desiredPosition->x - $this->x);
			$dy = ($desiredPosition->y - $this->y);
			$dz = ($desiredPosition->z - $this->z);
			$this->move($dx, $dy, $dz);
			return null;
		}

	public function getNearestRail() {
			/* decompiled (structured CF) */
			$minX = \pocketmine\math\Math::floorFloat($this->boundingBox->minX);
			$minY = \pocketmine\math\Math::floorFloat($this->boundingBox->minY);
			$minZ = \pocketmine\math\Math::floorFloat($this->boundingBox->minZ);
			$maxX = \pocketmine\math\Math::ceilFloat($this->boundingBox->maxX);
			$maxY = \pocketmine\math\Math::ceilFloat($this->boundingBox->maxY);
			$maxZ = \pocketmine\math\Math::ceilFloat($this->boundingBox->maxZ);
			$rails = ['__array_ptr' => '2aaaac9fc9a0'];
			$z = $minZ;
			while (($z <= $maxZ)) {
				$x = $minX;
				while (($x <= $maxX)) {
					$y = $minY;
					while (($y <= $maxY)) {
						$block = $this->level->getBlock($this->temporalVector->setComponents($x, $y, $z));
						if (in_array($block->getId(), [\pocketmine\block\Block::RAIL, \pocketmine\block\Block::ACTIVATOR_RAIL, \pocketmine\block\Block::DETECTOR_RAIL, \pocketmine\block\Block::POWERED_RAIL])) {
							$rails[] = $block;
						}
						$y++;
					}
					$x++;
				}
				$z++;
			}
			$minDistance = \PHP_INT_MAX;
			$nearestRail = null;
			foreach ($rails as $rail) {
				$dis = $this->distance($rail);
				if (($dis < $minDistance)) {
					$nearestRail = $rail;
					$minDistance = $dis;
				}
				/* goto */
			}
			return $nearestRail;
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->eid = $this->getId();
			$pk->type = 84;
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = 0;
			$pk->speedY = 0;
			$pk->speedZ = 0;
			$pk->yaw = 0;
			$pk->pitch = 0;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

	public function attack($damage = null, $source = null) {
			/* decompiled (structured CF) */
			parent::attack($damage, $source);
			if (!($source->isCancelled())) {
				new \pocketmine\network\protocol\EntityEventPacket();
				$pk = new \pocketmine\network\protocol\EntityEventPacket();
				$pk->eid = $this->id;
				$pk->event = \pocketmine\network\protocol\EntityEventPacket::HURT_ANIMATION;
				foreach ($this->getLevel()->getPlayers() as $player) {
					$player->dataPacket($pk);
					/* goto */
				}
			}
			return null;
		}

	public function getDrops() {
			return [\pocketmine\item\Item::get(\pocketmine\item\Item::MINECART, 0, 1)];
		}

	public function getSaveId() {
			new \ReflectionClass($t2);
			$class = new \ReflectionClass($t2);
			return $class->getShortName();
		}

	public function close() {
			/* decompiled (structured CF) */
			if ((!($this->closed) && !($this->getLevel()->getServer()->isWorldNonLivingEntityDropsDisabled($this->getLevel())))) {
				foreach ($this->getDrops() as $item) {
					$this->getLevel()->dropItem($this, $item);
					/* goto */
				}
			}
			parent::close();
			return null;
		}

}
