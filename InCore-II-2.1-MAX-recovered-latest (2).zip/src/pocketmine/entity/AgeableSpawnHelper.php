<?php

namespace pocketmine\entity;

final class AgeableSpawnHelper {
	public const PNX_SPAWN_EGG_BABY_CHANCE = 6;
	public const PNX_NATURAL_BABY_CHANCE = 6;

	private static $notBabyCapableClasses = array (
  0 => 'pocketmine\\entity\\IronGolem',
  1 => 'pocketmine\\entity\\SnowGolem',
  2 => 'pocketmine\\entity\\Lightning',
);

	private function __construct() {
			// empty
		}

	public static function canSpawnAsBaby($entity = null) {
			/* decompiled (structured CF) */
			if (!($entity instanceof \pocketmine\entity\Ageable)) {
				return false;
			}
			foreach (self::$notBabyCapableClasses as $class) {
				if ($entity instanceof \pocketmine\entity\Ageable) {
					return false;
				}
				/* goto */
			}
			return true;
		}

	public static function maybeSetBaby($entity = null, $chance = null, $roll = null) {
			/* decompiled (structured CF) */
			if ((!(self::canSpawnAsBaby($entity)) || ($chance <= 0))) {
				return false;
			}
			if (($roll === null)) {
			} else {
			}
			$roll = $roll;
			if ((($roll % $chance) !== 0)) {
				return false;
			}
			$entity->setBaby(true);
			return true;
		}

}
