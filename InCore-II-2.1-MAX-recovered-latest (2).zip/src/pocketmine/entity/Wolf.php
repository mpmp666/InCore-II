<?php

namespace pocketmine\entity;

class Wolf extends \pocketmine\entity\Animal {
	public const NETWORK_ID = 14;
	public const DEFAULT_COLLAR_COLOR = 14;
	public const SITTING_NAME_SUFFIX = ' - 待命中';
	public const FOLLOW_START_DISTANCE_SQUARED = 16.0;
	public const FOLLOW_STOP_DISTANCE_SQUARED = 9.0;
	public const FOLLOW_TELEPORT_DISTANCE_SQUARED = 225.0;

	public $width = 0.6;
	public $length = 0.9;
	public $height = 0.8;
	public $dropExp = array (
  0 => 1,
  1 => 3,
);
	private $hurt = 4;
	private $angry = false;
	private $ownerName = '';
	private $collarColor = 14;
	private $pm1eAttackLeapTarget = NULL;
	private $pm1eAttackLeapCooldown = 0;

	public function __construct($chunk = null, $nbt = null) {
			parent::__construct($chunk, $nbt);
			return;
		}

	public function initEntity() {
			/* decompiled (structured CF) */
			$loadedTamed = (isset($this->namedtag->Tamed) && (0 < ($this->namedtag['Tamed'])));
			if ($loadedTamed) {
			} else {
			}
			$this->setMaxHealth(8);
			new \pocketmine\entity\behavior\WolfAttackBehavior($this, ['__array_ptr' => '2aaaac9fc9a0'], false);
			$this->addBehavior(new \pocketmine\entity\behavior\WolfAttackBehavior($this, ['__array_ptr' => '2aaaac9fc9a0'], false));
			parent::initEntity();
			if (isset($this->namedtag->OwnerName)) {
			} else {
			}
			$this->ownerName = '';
			if (isset($this->namedtag->CollarColor)) {
			} else {
			}
			$this->collarColor = self::DEFAULT_COLLAR_COLOR;
			$this->setTamed($loadedTamed);
			$this->setSitting((isset($this->namedtag->Sitting) && (0 < ($this->namedtag['Sitting']))));
			$this->setAngry(false);
			$this->setCollarColor($this->collarColor);
			return null;
		}

	public function saveNBT() {
			/* decompiled (structured CF) */
			parent::saveNBT();
			if ($this->isTamed()) {
			} else {
			}
			new \pocketmine\nbt\tag\ByteTag('Tamed', 0);
			$this->namedtag->Tamed = new \pocketmine\nbt\tag\ByteTag('Tamed', 0);
			if ($this->isSitting()) {
			} else {
			}
			new \pocketmine\nbt\tag\ByteTag('Sitting', 0);
			$this->namedtag->Sitting = new \pocketmine\nbt\tag\ByteTag('Sitting', 0);
			new \pocketmine\nbt\tag\StringTag('OwnerName', $this->ownerName);
			$this->namedtag->OwnerName = new \pocketmine\nbt\tag\StringTag('OwnerName', $this->ownerName);
			new \pocketmine\nbt\tag\ByteTag('CollarColor', $this->collarColor);
			$this->namedtag->CollarColor = new \pocketmine\nbt\tag\ByteTag('CollarColor', $this->collarColor);
			return null;
		}

	public function usesPm1eGroundAi() {
			return true;
		}

	public function getHurt() {
			return $this->hurt;
		}

	public function setHurt($hurt = null) {
			$this->hurt = $hurt;
		}

	public function isTamed() {
			return $this->getDataFlag(self::DATA_FLAGS, self::DATA_FLAG_TAMED);
		}

	public function setTamed($tamed = null) {
			/* decompiled (structured CF) */
			$this->setDataFlag(self::DATA_FLAGS, self::DATA_FLAG_TAMED, $tamed);
			if ($tamed) {
			} else {
			}
			$this->setMaxHealth(8);
			$this->updatePetNameTag();
			return null;
		}

	public function isSitting() {
			return $this->getDataFlag(self::DATA_FLAGS, self::DATA_FLAG_SITTING);
		}

	public function setSitting($sitting = null) {
			/* decompiled (structured CF) */
			$this->setDataFlag(self::DATA_FLAGS, self::DATA_FLAG_SITTING, $sitting);
			if ($sitting) {
				$this->setPm1eRetaliationTarget(null);
				$this->setPm1eFollowTarget(null);
				$this->setPm1eMoveTarget(null);
				$this->setPm1eMoveMultiplier(1);
				$this->pm1eAttackLeapTarget = null;
				$this->setAngry(false);
			}
			$this->updatePetNameTag();
			return null;
		}

	public function isAngry() {
			return $this->angry;
		}

	public function setAngry($angry = null) {
			$this->angry = $angry;
			$this->setDataFlag(self::DATA_FLAGS, self::DATA_FLAG_ANGRY, $angry);
			return null;
		}

	public function setOwner($player = null) {
			$this->ownerName = $player->getName();
			$this->updatePetNameTag();
			return null;
		}

	public function getOwnerName() {
			return $this->ownerName;
		}

	public function isOwner($player = null) {
			return (($this->ownerName !== '') && (strtolower($this->ownerName) === strtolower($player->getName())));
		}

	public function getOwnerPlayer() {
			/* decompiled (structured CF) */
			if (($this->ownerName === '')) {
				return null;
			}
			$owner = $this->server->getPlayerExact($this->ownerName);
			if (!($owner instanceof \pocketmine\Player)) {
			}
			if ((method_exists($owner, 'isConnected') && !($owner->isConnected()))) {
			}
			if ((!($owner->isAlive()) || $owner->closed)) {
			}
			return $owner;
		}

	public function getCollarColor() {
			return $this->collarColor;
		}

	public function setCollarColor($color = null) {
			/* decompiled (structured CF) */
			$this->collarColor = ($color & 15);
			new \pocketmine\nbt\tag\ByteTag('CollarColor', $this->collarColor);
			$this->namedtag->CollarColor = new \pocketmine\nbt\tag\ByteTag('CollarColor', $this->collarColor);
			$this->setDataProperty(self::DATA_COLOR_INFO, self::DATA_TYPE_BYTE, $this->collarColor);
			$this->updatePetNameTag();
			return null;
		}

	public function onInteract($player = null, $item = null) {
			/* decompiled (structured CF) */
			if ($item instanceof \pocketmine\item\Lead) {
				return $item->leashEntity($player, $this);
			}
			if ($this->isTamed()) {
				if (!($this->isOwner($player))) {
					return false;
				}
				if (($item->getId() === \pocketmine\item\Item::DYE)) {
					$newColor = self::dyeMetaToWoolColor(($item->getDamage()));
					if (($newColor !== $this->getCollarColor())) {
						$this->setCollarColor(self::dyeMetaToWoolColor(($item->getDamage())));
						$this->consumeHeldItem($player, $item);
					}
					return true;
				}
				if (!($this->isInsideOfWater())) {
					$this->setSitting(!($this->isSitting()));
					return true;
				}
				return false;
			}
			if (($item->getId() === \pocketmine\item\Item::BONE)) {
				$this->consumeHeldItem($player, $item);
				if ((mt_rand(0, 2) === 0)) {
					$this->setOwner($player);
					$this->setTamed(true);
					$this->setSitting(true);
					$this->setAngry(false);
					$this->setCollarColor(self::DEFAULT_COLLAR_COLOR);
					$this->setHealth($this->getMaxHealth());
					$this->broadcastTameEvent(\pocketmine\network\protocol\EntityEventPacket::TAME_SUCCESS);
				} else {
					$this->broadcastTameEvent(\pocketmine\network\protocol\EntityEventPacket::TAME_FAIL);
				}
				return true;
			}
			return parent::onInteract($player, $item);
		}

	private static function dyeMetaToWoolColor($meta = null) {
			/* decompiled (structured CF) */
			switch (($meta & 15)) {
				case \pocketmine\item\Dye::BLACK:
				return 15;
				case \pocketmine\item\Dye::RED:
				return 14;
				case \pocketmine\item\Dye::GREEN:
				return 13;
				case \pocketmine\item\Dye::BROWN:
				return 12;
				case \pocketmine\item\Dye::BLUE:
				return 11;
				case \pocketmine\item\Dye::PURPLE:
				return 10;
				case \pocketmine\item\Dye::CYAN:
				return 9;
				case \pocketmine\item\Dye::SILVER:
				return 8;
				case \pocketmine\item\Dye::GRAY:
				return 7;
				case \pocketmine\item\Dye::PINK:
				return 6;
				case \pocketmine\item\Dye::LIME:
				return 5;
				case \pocketmine\item\Dye::YELLOW:
				return 4;
				case \pocketmine\item\Dye::LIGHT_BLUE:
				return 3;
				case \pocketmine\item\Dye::MAGENTA:
				return 2;
				case \pocketmine\item\Dye::ORANGE:
				return 1;
				case \pocketmine\item\Dye::WHITE:
				return 0;
			}
		}

	private function updatePetNameTag() {
			/* decompiled (structured CF) */
			if ((!($this->isTamed()) || ($this->ownerName === ''))) {
				$this->setNameTagVisible(false);
				return null;
			}
			$name = ((self::woolColorToTextFormat($this->collarColor) . $this->ownerName) . $this);
			if ($this->isSitting()) {
				$name .= self::SITTING_NAME_SUFFIX;
			}
			$this->setNameTag($name);
			$this->setNameTagVisible(true);
		}

	private static function woolColorToTextFormat($color = null) {
			/* decompiled (structured CF) */
			/* jump */
			switch (($color & 15)) {
				case 0:
				return \pocketmine\utils\TextFormat::WHITE;
				case 1:
				return \pocketmine\utils\TextFormat::GOLD;
				case 2:
				return \pocketmine\utils\TextFormat::LIGHT_PURPLE;
				case 3:
				return \pocketmine\utils\TextFormat::AQUA;
				case 4:
				return \pocketmine\utils\TextFormat::YELLOW;
				case 5:
				return \pocketmine\utils\TextFormat::GREEN;
				case 6:
				return \pocketmine\utils\TextFormat::LIGHT_PURPLE;
				case 7:
				return \pocketmine\utils\TextFormat::DARK_GRAY;
				case 8:
				return \pocketmine\utils\TextFormat::GRAY;
				case 9:
				return \pocketmine\utils\TextFormat::DARK_AQUA;
				case 10:
				return \pocketmine\utils\TextFormat::DARK_PURPLE;
				case 11:
				return \pocketmine\utils\TextFormat::BLUE;
				case 12:
				return \pocketmine\utils\TextFormat::GOLD;
				case 13:
				return \pocketmine\utils\TextFormat::DARK_GREEN;
				case self::DEFAULT_COLLAR_COLOR:
				return \pocketmine\utils\TextFormat::RED;
				case 15:
				return \pocketmine\utils\TextFormat::BLACK;
			}
		}

	private function consumeHeldItem($player = null, $item = null) {
			/* decompiled (structured CF) */
			if (!($player->isSurvival())) {
				return null;
			}
			$item->setCount(($item->getCount() - 1));
			if ((0 < $item->getCount())) {
			} else {
			}
			$player->getInventory()->setItemInHand(\pocketmine\item\Item::get(\pocketmine\item\Item::AIR, 0, 0));
		}

	private function broadcastTameEvent($event = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\EntityEventPacket();
			$pk = new \pocketmine\network\protocol\EntityEventPacket();
			$pk->eid = $this->getId();
			$pk->event = $event;
			\pocketmine\Server::broadcastPacket($this->hasSpawned, $pk);
			return null;
		}

	protected function tickPm1eGroundAi($tickDiff = null) {
			$this->updateOwnerFollowTarget($tickDiff);
			return parent::tickPm1eGroundAi($tickDiff);
		}

	private function updateOwnerFollowTarget($tickDiff = null) {
			/* decompiled (structured CF) */
			if (!($this->isTamed())) {
				return null;
			}
			if ($this->isSitting()) {
				$this->setPm1eRetaliationTarget(null);
				$this->setPm1eFollowTarget(null);
				$this->setPm1eMoveTarget(null);
				$this->setPm1eMoveMultiplier(0);
				if ($this->isInsideOfWater()) {
				} else {
				}
				$this->setPm1eStayTime(($tickDiff + 20));
			}
			$retaliationTarget = $this->getPm1eRetaliationTarget();
			if ((($retaliationTarget instanceof \pocketmine\entity\Entity && !($retaliationTarget->closed)) && $retaliationTarget->isAlive())) {
			}
			$owner = $this->getOwnerPlayer();
			if ((!($owner instanceof \pocketmine\Player) || ($owner->getLevel() !== $this->getLevel()))) {
				$this->setPm1eFollowTarget(null);
				$this->setPm1eMoveMultiplier(1);
			}
			$distanceSquared = $this->distanceSquared($owner);
			if ((self::FOLLOW_TELEPORT_DISTANCE_SQUARED < $distanceSquared)) {
				new \pocketmine\math\Vector3($owner->x, $owner->y, $owner->z);
				$this->teleport(new \pocketmine\math\Vector3($owner->x, $owner->y, $owner->z), $this->yaw, $this->pitch);
				$this->setPm1eFollowTarget(null);
				$this->setPm1eMoveMultiplier(1);
				$distanceSquared = $this->distanceSquared($owner);
			}
			if ((self::FOLLOW_START_DISTANCE_SQUARED < $distanceSquared)) {
				$this->setPm1eFollowTarget($owner);
				$this->setPm1eMoveMultiplier(1.35);
				$this->setPm1eStayTime(0);
			} else {
				if (($distanceSquared <= self::FOLLOW_STOP_DISTANCE_SQUARED)) {
					if (($owner === $this->getPm1eFollowTarget())) {
						$this->setPm1eFollowTarget(null);
					}
					$this->setPm1eMoveMultiplier(1);
				}
			}
		}

	public function requestPm1eAttackLeap($target = null) {
			/* decompiled (structured CF) */
			if (((!($this->onGround) || (0 < $this->pm1eAttackLeapCooldown)) || $this->isSitting())) {
				return null;
			}
			$distanceSquared = $this->distanceSquared($target);
			if (((4 <= $distanceSquared) && ($distanceSquared <= 16))) {
				$this->pm1eAttackLeapTarget = $target;
			}
		}

	protected function checkPm1eJump() {
			/* decompiled (structured CF) */
			if ((0 < $this->pm1eAttackLeapCooldown)) {
			}
			if ($this->pm1eAttackLeapTarget instanceof \pocketmine\entity\Entity) {
				$target = $this->pm1eAttackLeapTarget;
				$this->pm1eAttackLeapTarget = null;
				if ((($this->onGround && !($target->closed)) && $target->isAlive())) {
					$distanceSquared = $this->distanceSquared($target);
					if (((4 <= $distanceSquared) && ($distanceSquared <= 16))) {
						$this->motionY = max($this->motionY, $this->getPm1eJumpStrength());
						$this->pm1eAttackLeapCooldown = 10;
						return true;
					}
				}
			}
			return parent::checkPm1eJump();
		}

	public function getName() {
			return 'Wolf';
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->eid = $this->getId();
			$pk->type = 14;
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->yaw = $this->yaw;
			$pk->pitch = $this->pitch;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

}
