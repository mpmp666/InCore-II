<?php

namespace pocketmine\entity;

abstract class WaterAnimal extends \pocketmine\entity\Creature {
	public function initEntity() {
			/* decompiled (structured CF) */
			parent::initEntity();
			if (($this->getDataProperty(self::DATA_AGEABLE_FLAGS) === null)) {
				$this->setDataProperty(self::DATA_AGEABLE_FLAGS, self::DATA_TYPE_BYTE, 0);
			}
			return null;
		}

}
