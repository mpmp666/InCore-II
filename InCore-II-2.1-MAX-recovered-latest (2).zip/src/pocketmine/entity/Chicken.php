<?php

namespace pocketmine\entity;

class Chicken extends \pocketmine\entity\Animal {
	public const NETWORK_ID = 10;

	public $width = 0.6;
	public $length = 0.6;
	public $height = 0.7;
	public $dropExp = array (
  0 => 1,
  1 => 3,
);

	public function getName() {
			return 'Chicken';
		}

	public function initEntity() {
			/* decompiled (structured CF) */
			$this->setMaxHealth(4);
			new \pocketmine\entity\behavior\inLoveBehavior($this);
			$this->addBehavior(new \pocketmine\entity\behavior\inLoveBehavior($this));
			new \pocketmine\entity\behavior\findFoodBehavior($this, 296);
			$this->addBehavior(new \pocketmine\entity\behavior\findFoodBehavior($this, 296));
			parent::initEntity();
			return null;
		}

	public function usesPm1eGroundAi() {
			return true;
		}

	protected function getBreedingItemIds() {
			return [\pocketmine\item\Item::WHEAT];
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->eid = $this->getId();
			$pk->type = 10;
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->yaw = $this->yaw;
			$pk->pitch = $this->pitch;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

	public function getDrops() {
			/* decompiled (structured CF) */
			$drops = ['__array_ptr' => '2aaaac9fc9a0'];
			switch (mt_rand(0, 1)) {
				case 0:
				if ($this->isOnFire()) {
					$drops[] = \pocketmine\item\Item::get(\pocketmine\item\Item::COOKED_CHICKEN, 0, mt_rand(1, 2));
				} else {
					$drops[] = \pocketmine\item\Item::get(\pocketmine\item\Item::RAW_CHICKEN, 0, mt_rand(1, 2));
				}
				/* jump */
				case 1:
				$drops[] = \pocketmine\item\Item::get(\pocketmine\item\Item::FEATHER, 0, mt_rand(1, 2));
				/* jump */
				return $drops;
			}
		}

}
