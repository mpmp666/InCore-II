<?php

namespace pocketmine\entity\behavior;

class LookAtPlayerBehavior extends \pocketmine\entity\behavior\Behavior {
	public $player = NULL;
	public $lookDistance = 0;

	public function getName() {
			return "\xe7\x9c\x8b\xe7\x8e\xa9\xe5\xae\xb6";
		}

	public function __construct($entity = null, $lookDistance = null) {
			parent::__construct($entity);
			$this->lookDistance = $lookDistance;
			return;
		}

	public function shouldStart() {
			/* decompiled (structured CF) */
			if ((rand(0, 10) != 0)) {
				return false;
			}
			$players = $this->entity->level->getPlayers();
			foreach ($players as $p) {
				if (($this->entity->distance($p) < $this->lookDistance)) {
					$this->player = $p;
				} else {
					/* goto */
				}
			}
			if (($this->player == null)) {
				return false;
			}
			$this->duration = (40 + mt_rand(0, 40));
			return true;
		}

	public function canContinue() {
			return (0 < $t0);
		}

	public function onTick() {
			/* decompiled (structured CF) */
			$this->AimPlayer($this->player, $this->entity);
			$this->swimming();
			$this->entity->level->addEntityMovement($this->entity->chunk->getX(), $this->entity->chunk->getZ(), $this->entity->getID(), $this->entity->x, ($this->entity->y + $this->entity->getEyeHeight()), $this->entity->z, $this->entity->yaw, $this->entity->pitch, $this->entity->yaw);
			return null;
		}

	public function AimPlayer($palyer = null, $entity = null) {
			/* decompiled (structured CF) */
			$x = ($palyer->x - $entity->x);
			$y = ($palyer->y - $entity->y);
			$z = ($palyer->z - $entity->z);
			$a = ($palyer->x + 0.5);
			$b = $palyer->y;
			$c = ($palyer->z + 0.5);
			$len = sqrt(((($x * $x) + ($y * $y)) + ($z * $z)));
			$y = ($y / $len);
			$pitch = asin($y);
			$pitch = (($pitch * 180) / \M_PI);
			$pitch = ($pitch * -1);
			$yaw = ((atan2(($a - ($entity->x + 0.5)), ($c - ($entity->z + 0.5))) * -1) * (180 / \M_PI));
			$this->entity->pitch = $pitch;
			$this->entity->yaw = $yaw;
			return null;
		}

	public function onEnd() {
			$this->player = null;
			$this->entity->pitch = 0;
			return null;
		}

	public function toDegree($angle = null) {
			return ($angle * (180 / pi()));
		}

}
