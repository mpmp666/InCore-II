<?php

namespace pocketmine\entity\behavior;

class SlimeBehavior extends \pocketmine\entity\behavior\Behavior {
	public $duration = NULL;
	public $timeLeft = NULL;
	public $speed = NULL;
	public $speedMultiplier = NULL;

	public function __construct($entity = null, $duration = null, $speed = null, $speedMultiplier = null) {
			/* decompiled (structured CF) */
			parent::__construct($entity);
			$this->duration = $duration;
			$this->speed = $speed;
			$this->speedMultiplier = $speedMultiplier;
			$this->timeLeft = $duration;
			return;
		}

	public function getName() {
			return "\xe5\x8f\xb2\xe8\x8e\xb1\xe5\xa7\x86\xe8\xa1\x8c\xe8\xb5\xb0";
		}

	public function shouldStart() {
			return true;
		}

	public function canContinue() {
			return (0 < $t0);
		}

	public function onTick() {
			/* decompiled (structured CF) */
			if ($this->entity->isInsideOfWater()) {
			} else {
			}
			$speedFactor = (((($this->speed * $this->speedMultiplier) * 0.7) * 0.4));
			$level = $this->entity->getLevel();
			$coordinates = $this->entity->getPosition();
			$direction = $this->entity->getDirectionVector();
			$direction->y = 0;
			$entity = $this->entity;
			$blockDown = $level->getBlock($coordinates->add(0, -1, 0));
			if ((($entity->getMotion()->y < 0) && $blockDown->canPassThrough())) {
				$entity->motionY -= 0.1;
				return null;
			}
			$coord = $coordinates->add($direction->multiply($speedFactor))->add($direction->multiply(0.5));
			$players = $entity->getViewers();
			$block = $level->getBlock($coord);
			$blockUp = $level->getBlock($coord->add(0, 1, 0));
			$blockUpUp = $level->getBlock($coord->add(0, 2, 0));
			$colliding = (!($blockUpUp->canPassThrough()) && !($blockUp->canPassThrough()));
			if (!($colliding)) {
				$motion = $direction->multiply($speedFactor);
				$pm = $entity->getMotion();
				if (($pm->length() < $motion->length())) {
					$entity->setMotion($pm->add(($motion->x - $pm->x), ($entity->getSize() * 0.45), ($motion->z - $pm->z)));
				} else {
					$entity->setMotion($motion);
				}
			} else {
				$entity->yaw += 180;
			}
			if ($entity->isInsideOfWater()) {
				$entity->motionY = 0.5;
			}
		}

	public function onEnd() {
			/* decompiled (structured CF) */
			$this->timeLeft = $this->duration;
			new \pocketmine\math\Vector3(0, 0, 0);
			$this->entity->setMotion(new \pocketmine\math\Vector3(0, 0, 0));
			return null;
		}

}
