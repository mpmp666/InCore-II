<?php

namespace pocketmine\entity\behavior;

class attackEnemyBehavior extends \pocketmine\entity\behavior\Behavior {
	public $speed = NULL;
	public $speedMultiplier = NULL;
	public $lookDistance = 16.0;
	public $NetworkID = NULL;
	public $enemy = NULL;
	public $timeLeft = 0;
	public $attackPlayer = false;

	public function __construct($entity = null, $NetWorkID = null, $attackPlayer = null, $speed = null, $speedMultiplier = null) {
			/* decompiled (structured CF) */
			parent::__construct($entity);
			$this->speed = $speed;
			$this->speedMultiplier = $speedMultiplier;
			$this->NetworkID = $NetWorkID;
			$this->attackPlayer = $attackPlayer;
			return;
		}

	public function getName() {
			return "\xe4\xb8\x80\xe8\x88\xac\xe6\x95\x8c\xe5\xaf\xb9\xe5\xae\x9e\xe4\xbd\x93\xe6\x94\xbb\xe5\x87\xbb";
		}

	public function shouldStart() {
			/* decompiled (structured CF) */
			if ($this->canUseCurrentTarget()) {
				return true;
			}
			$entities = $this->entity->level->getEntities();
			$find = false;
			$MinDistance = 9999;
			foreach ($entities as $entity) {
				if ((in_array($entity::NETWORK_ID, $this->NetworkID) && ($this->entity->distance($entity) < $this->lookDistance))) {
					if (($this->entity->distance($entity) < $MinDistance)) {
						$this->enemy = $entity;
						$MinDistance = $this->entity->distance($entity);
						$find = true;
					}
				}
				/* goto */
			}
			if ($this->attackPlayer) {
				$players = $this->entity->level->getPlayers();
				foreach ($players as $p) {
					if (($this->entity->distance($p) < $this->lookDistance)) {
						if (($this->entity->distance($p) < $MinDistance)) {
							if ($p->isSurvival()) {
								$this->enemy = $p;
								$MinDistance = $this->entity->distance($p);
								$find = true;
							}
						}
					}
					/* goto */
				}
			}
			return $find;
		}

	private function canUseCurrentTarget() {
			/* decompiled (structured CF) */
			if (($this->enemy instanceof \pocketmine\entity\Entity && $this->enemy->isAlive())) {
				if (($this->enemy instanceof \pocketmine\Player && !($this->enemy->isConnected()))) {
					return false;
				}
				return ($this->entity->distance($this->enemy) < $this->lookDistance);
			}
			return false;
		}

	public function canContinue() {
			return $this->canUseCurrentTarget();
		}

	public function onTick() {
			/* decompiled (structured CF) */
			if ((!($this->enemy instanceof \pocketmine\entity\Entity) || !($this->enemy->isAlive()))) {
				return null;
			}
			$distance = $this->entity->distance($this->enemy);
			$entity = $this->entity;
			if ((1.5 <= $distance)) {
				$entity->setPm1eFollowTarget($this->enemy);
				$entity->setPm1eMoveMultiplier($this->speedMultiplier);
				$entity->setPm1eStayTime(0);
			} else {
				if (($this->timeLeft == 0)) {
					$damage = $entity->getHurt();
					$knockBack = 0.4;
					if (method_exists($entity, 'getWeapon')) {
						$damage += max(0, (\pocketmine\entity\VanillaMobEquipment::getWeaponBaseDamage($entity->getWeapon()) - 1));
						$damage += \pocketmine\item\Tool::getWeaponEnchantmentDamageBonus($entity, $this->enemy);
						$knockBack = \pocketmine\item\Tool::getWeaponKnockBackStrength($knockBack, $entity);
					}
					new \pocketmine\event\entity\EntityDamageByEntityEvent($entity, $this->enemy, \pocketmine\event\entity\EntityDamageEvent::CAUSE_ENTITY_ATTACK, $damage, $knockBack);
					$this->enemy->attack($damage, new \pocketmine\event\entity\EntityDamageByEntityEvent($entity, $this->enemy, \pocketmine\event\entity\EntityDamageEvent::CAUSE_ENTITY_ATTACK, $damage, $knockBack));
					$this->timeLeft = mt_rand(30, 40);
				}
			}
			if ((0 < $this->timeLeft)) {
			}
			$this->swimming();
		}

	public function onEnd() {
			$this->entity->setPm1eFollowTarget(null);
			$this->entity->setPm1eMoveMultiplier(1);
			return null;
		}

	public function bowAimPitch($palyer = null, $entity = null, $distance = null) {
			/* decompiled (structured CF) */
			$_0x2bf6x17f = 1;
			$x = ($palyer->x - $entity->x);
			$y = ($palyer->y - $entity->y);
			$z = ($palyer->z - $entity->z);
			$_0x2bf6x183 = sqrt((($x * $x) + ($z * $z)));
			$_0x2bf6x184 = $distance;
			$_0x2bf6x185 = (($_0x2bf6x17f * ($_0x2bf6x17f * ($_0x2bf6x17f * $_0x2bf6x17f))) - ($_0x2bf6x184 * (($_0x2bf6x184 * ($_0x2bf6x183 * $_0x2bf6x183)) + (($y * 2) * ($_0x2bf6x17f * $_0x2bf6x17f)))));
			$pitch = (atan(((($_0x2bf6x17f * $_0x2bf6x17f) - sqrt($_0x2bf6x185)) / ($_0x2bf6x184 * $_0x2bf6x183))) * ((180 / \M_PI) * -1));
			if (is_nan($pitch)) {
				$pitch = 0;
			}
			$entity->pitch = $pitch;
			return $pitch;
		}

}
