<?php

namespace pocketmine\entity\behavior;

class FindFoodBehavior extends \pocketmine\entity\behavior\Behavior {
	public function __construct($entity = null, $foodID = null, $speed = null, $speedMultiplier = null) {
		/* decompiled (structured CF) */
		parent::__construct($entity);
		$this->speed = $speed;
		$this->speedMultiplier = $speedMultiplier;
		$this->foodID = $foodID;
		return;
	}

	public function getName() {
		return "\xe8\xa7\x85\xe9\xa3\x9f";
	}

	public function shouldStart() {
		/* decompiled (structured CF) */
		$closestPlayer = $this->findClosestPlayerWithFood();
		if (($closestPlayer !== null)) {
			$this->targetPlayer = $closestPlayer;
			return true;
		}
		return false;
	}

	public function canContinue() {
		/* decompiled (structured CF) */
		if (((($this->targetPlayer === null) || !($this->targetPlayer->isConnected())) || !($this->targetPlayer->isAlive()))) {
			return false;
		}
		$heldItem = $this->targetPlayer->getItemInHand();
		return ($heldItem->getId() === $this->foodID);
	}

	public function onTick() {
		/* decompiled (structured CF) */
		if (($this->targetPlayer === null)) {
			return null;
		}
		$distance = $this->entity->distance($this->targetPlayer);
		if (($distance < self::MIN_APPROACH_DISTANCE)) {
			$this->entity->setPm1eFollowTarget(null);
			$this->entity->setPm1eStayTime(10);
		}
		$this->entity->setPm1eFollowTarget($this->targetPlayer);
		$this->entity->setPm1eMoveMultiplier($this->speedMultiplier);
		$this->entity->setPm1eStayTime(0);
		$this->handleSwimming();
	}

	public function onEnd() {
		/* decompiled (structured CF) */
		$this->entity->setPm1eFollowTarget(null);
		$this->entity->setPm1eMoveMultiplier(1);
		$this->targetPlayer = null;
		return null;
	}

	private function findClosestPlayerWithFood() {
		/* decompiled (structured CF) */
		$closestPlayer = null;
		$closestDistance = 16777215;
		foreach ($this->entity->getLevel()->getPlayers() as $player) {
			if ((!($player->isConnected()) || !($player->isAlive()))) {
				/* goto */
			}
			$heldItem = $player->getItemInHand();
			if (($heldItem->getId() !== $this->foodID)) {
				/* goto */
			}
			$distance = $this->entity->distance($player);
			if ((($distance < $this->lookDistance) && ($distance < $closestDistance))) {
				$closestPlayer = $player;
				$closestDistance = $distance;
			}
			/* goto */
		}
		return $closestPlayer;
	}

	private function handleSwimming() {
		/* decompiled (structured CF) */
		if (method_exists($this->entity, 'swimming')) {
			$this->entity->swimming();
		}
		return null;
	}

	public function getFoodID() {
		return $this->foodID;
	}

	public function setFoodID($foodID = null) {
		$this->foodID = $foodID;
	}

	public function getLookDistance() {
		return $this->lookDistance;
	}

	public function setLookDistance($lookDistance = null) {
		$this->lookDistance = max(0, $lookDistance);
		return null;
	}

}
