<?php

namespace pocketmine\entity\behavior;

class inLoveBehavior extends \pocketmine\entity\behavior\Behavior {
	public $speed = NULL;
	public $speedMultiplier = NULL;
	public $timeLeft = NULL;
	public $inLoveEntity = NULL;
	public $inLovetime = 0;

	public function __construct($entity = null, $speed = null, $speedMultiplier = null) {
			/* decompiled (structured CF) */
			parent::__construct($entity);
			$this->speed = $speed;
			$this->speedMultiplier = $speedMultiplier;
			return;
		}

	public function getName() {
			return "\xe7\xb9\x81\xe6\xae\x96";
		}

	public function shouldStart() {
			/* decompiled (structured CF) */
			if (!($this->entity->isInLove())) {
				return false;
			}
			$find = false;
			foreach ($this->entity->level->getNearbyEntities($this->entity->boundingBox->grow(10, 3, 10), $this->entity) as $entity) {
				if (((get_class($entity) == get_class($this->entity)) && $entity->isInLove())) {
					$find = true;
					$this->timeLeft = 200;
					$this->inLoveEntity = $entity;
				}
				/* goto */
			}
			return $find;
		}

	public function canContinue() {
			return ((0 < $t0) || !($this->inLoveEntity->isAlive()));
		}

	public function onTick() {
			/* decompiled (structured CF) */
			if (($this->entity->distance($this->inLoveEntity) < 0.5)) {
				if ((10 <= $this->inLovetime)) {
					new \pocketmine\nbt\tag\DoubleTag('', 0);
					new \pocketmine\nbt\tag\DoubleTag('', 0);
					new \pocketmine\nbt\tag\DoubleTag('', 0);
					new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]);
					new \pocketmine\nbt\tag\DoubleTag('', 0);
					new \pocketmine\nbt\tag\DoubleTag('', 0);
					new \pocketmine\nbt\tag\DoubleTag('', 0);
					new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]);
					new \pocketmine\nbt\tag\FloatTag('', 0);
					new \pocketmine\nbt\tag\FloatTag('', 0);
					new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', 0), new \pocketmine\nbt\tag\FloatTag('', 0)]);
					new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', 0), new \pocketmine\nbt\tag\FloatTag('', 0)])]);
					$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', 0), new \pocketmine\nbt\tag\FloatTag('', 0)])]);
					$class = get_class($this->entity);
					new $class($this->entity->chunk, $nbt);
					$entity = new $class($this->entity->chunk, $nbt);
					$entity->setBaby(true);
					$entity->setPosition($this->entity->getPosition());
					$entity->setHealth($this->entity->getMaxHealth());
					$entity->spawnToAll();
					$this->entity->setInLove(false);
					$this->inLoveEntity->setInLove(false);
					$this->inLovetime = 0;
					$this->timeLeft = 0;
				}
				$this->entity->setPm1eFollowTarget(null);
				$this->entity->setPm1eStayTime(10);
				return null;
			}
			$this->entity->setPm1eFollowTarget($this->inLoveEntity);
			$this->entity->setPm1eMoveMultiplier($this->speedMultiplier);
			$this->entity->setPm1eStayTime(0);
			$this->swimming();
		}

	public function onEnd() {
			$this->entity->setPm1eFollowTarget(null);
			$this->entity->setPm1eMoveMultiplier(1);
			return null;
		}

}
