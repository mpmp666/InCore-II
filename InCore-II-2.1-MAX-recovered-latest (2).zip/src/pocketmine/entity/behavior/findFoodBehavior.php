<?php

namespace pocketmine\entity\behavior;

class FindFoodBehavior extends \pocketmine\entity\behavior\Behavior {
	public const DEFAULT_SPEED = 0.35;
	public const DEFAULT_SPEED_MULTIPLIER = 0.75;
	public const BASE_SPEED_FACTOR = 0.7;
	public const WATER_SPEED_MULTIPLIER = 0.3;
	public const LAND_SPEED_MULTIPLIER = 0.4;
	public const LOOK_AHEAD_DISTANCE = 0.5;
	public const JUMP_VELOCITY = 0.42;
	public const MAX_LOOK_DISTANCE = 6.0;
	public const MIN_APPROACH_DISTANCE = 0.5;

	public $speed = NULL;
	public $speedMultiplier = NULL;
	public $foodID = NULL;
	public $targetPlayer = NULL;
	public $lookDistance = 6.0;

	public function __construct(pocketmine\entity\Mob $entity, int $foodID, float $speed = 0.35, float $speedMultiplier = 0.75)
	    {
	        // TODO body via opdump
	    }

	public function getName(): string
	    {
	        // TODO body via opdump
	    }

	public function shouldStart(): bool
	    {
	        // TODO body via opdump
	    }

	public function canContinue(): bool
	    {
	        // TODO body via opdump
	    }

	public function onTick()
	    {
	        // TODO body via opdump
	    }

	public function onEnd()
	    {
	        // TODO body via opdump
	    }

	private function findClosestPlayerWithFood()
	    {
	        // TODO body via opdump
	    }

	private function handleSwimming()
	    {
	        // TODO body via opdump
	    }

	public function getFoodID(): int
	    {
	        // TODO body via opdump
	    }

	public function setFoodID(int $foodID)
	    {
	        // TODO body via opdump
	    }

	public function getLookDistance(): float
	    {
	        // TODO body via opdump
	    }

	public function setLookDistance(float $lookDistance)
	    {
	        // TODO body via opdump
	    }

}
