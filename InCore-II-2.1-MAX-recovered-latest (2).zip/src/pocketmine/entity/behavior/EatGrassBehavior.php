<?php

namespace pocketmine\entity\behavior;

class EatGrassBehavior extends \pocketmine\entity\behavior\Behavior {
	public function getName() {
		return "\xe5\x90\x83\xe8\x8d\x89";
	}

	public function shouldStart() {
		/* decompiled (structured CF) */
		if ($this->entity->hasWool()) {
			return false;
		}
		if (!($this->isStandingOnGrass())) {
			return false;
		}
		return (mt_rand(0, (self::START_CHANCE - 1)) === 0);
	}

	public function canContinue() {
		/* decompiled (structured CF) */
		if (!($this->isStandingOnGrass())) {
			return false;
		}
		return (0 < $t2);
	}

	public function onTick() {
		/* decompiled (structured CF) */
		if ((($this->timeLeft === self::EATING_DURATION) && !($this->animationPlayed))) {
			$this->playEatGrassAnimation();
			$this->animationPlayed = true;
		}
		return null;
	}

	public function onEnd() {
		$this->completeEating();
		return null;
	}

	private function isStandingOnGrass() {
		$blockBelow = $this->entity->getLevel()->getBlock($this->entity->floor()->subtract(0, 1, 0));
		return ($blockBelow->getId() === self::GRASS_BLOCK_ID);
	}

	private function playEatGrassAnimation() {
		/* decompiled (structured CF) */
		foreach ($this->entity->getViewers() as $player) {
			$pk = \pocketmine\network\mcpe\protocol\ActorEventPacket::create($this->entity->getId(), \pocketmine\network\mcpe\protocol\types\ActorEvent::EAT_GRASS_ANIMATION, 0);
			$player->dataPacket($pk);
			/* goto */
		}
		return null;
	}

	private function completeEating() {
		/* decompiled (structured CF) */
		$this->entity->setHasWool(true);
		$blockPos = $this->entity->floor()->subtract(0, 1, 0);
		$block = $this->entity->getLevel()->getBlock($blockPos);
		if (($block->getId() === self::GRASS_BLOCK_ID)) {
			$this->convertGrassToDirt($blockPos);
		}
		return null;
	}

	private function convertGrassToDirt($position = null) {
		$dirtBlock = \pocketmine\block\Block::get(self::DIRT_BLOCK_ID);
		$this->entity->getLevel()->setBlock($position, $dirtBlock, false, false);
		return null;
	}

	public function reset() {
		$this->timeLeft = 0;
		$this->animationPlayed = false;
		$this->player = null;
	}

}
