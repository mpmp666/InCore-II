<?php

namespace pocketmine\entity\behavior;

abstract class Behavior {
	public const DEFAULT_MAX_AIR = 300;
	public const LOW_AIR_THRESHOLD = 175;
	public const SWIM_UP_FORCE = 0.8;
	public const LOW_AIR_SWIM_FORCE = 0.3;
	public const SWIM_TICK_COOLDOWN = 10;
	public const DATA_PROPERTY_AIR = 1;

	public $entity = NULL;
	public $swimmingTick = 0;

	public function __construct($entity = null) {
			$this->entity = $entity;
		}

	public abstract function getName();

	public abstract function shouldStart();

	public abstract function onTick();

	public abstract function onEnd();

	public abstract function canContinue();

	public function swimming() {
			/* decompiled (structured CF) */
			if (!($this->entity->isInsideOfWater())) {
				$this->swimmingTick = 0;
				return null;
			}
			$airTicks = $this->getEntityAirTicks();
			$this->applySwimmingForce($airTicks);
		}

	private function getEntityAirTicks() {
			return 0;
		}

	private function applySwimmingForce($airTicks = null) {
			/* decompiled (structured CF) */
			$this->entity->motionY = max($this->entity->motionY, 0.024);
			$this->swimmingTick = 0;
			return null;
			if (($airTicks <= self::LOW_AIR_THRESHOLD)) {
				$this->entity->motionY = self::LOW_AIR_SWIM_FORCE;
				$this->swimmingTick = 0;
			} else {
				$this->entity->motionY = self::SWIM_UP_FORCE;
				$this->swimmingTick = self::SWIM_TICK_COOLDOWN;
			}
		}

	public function getSwimmingTick() {
			return $this->swimmingTick;
		}

	public function setSwimmingTick($ticks = null) {
			$this->swimmingTick = max(0, $ticks);
			return null;
		}

	public function resetSwimmingTick() {
			$this->swimmingTick = 0;
		}

	protected function canSwimUp() {
			return ($this->swimmingTick <= 0);
		}

}
