<?php

namespace pocketmine\entity\behavior;

class WolfAttackBehavior extends \pocketmine\entity\behavior\attackEnemyBehavior {
	public const PNX_ATTACK_SPEED = 0.7;
	public const PNX_ATTACK_COOLDOWN = 20;
	public const ATTACK_RANGE = 1.6;
	public const ATTACK_SPEED_MULTIPLIER = 2.3333333333;
	public const POUNCE_MIN_DISTANCE = 2.0;
	public const POUNCE_MAX_DISTANCE = 4.0;

	public function __construct($entity = null, $NetWorkID = null, $attackPlayer = null, $speed = null, $speedMultiplier = null) {
			parent::__construct($entity, $NetWorkID, $attackPlayer, $speed, $speedMultiplier);
			$this->lookDistance = 33;
			return;
		}

	public function getName() {
			return;
		}

	public function shouldStart() {
			/* decompiled (structured CF) */
			if (($this->entity instanceof \pocketmine\entity\Wolf && $this->entity->isSitting())) {
				return false;
			}
			if (parent::shouldStart()) {
				return true;
			}
			if (($this->entity instanceof \pocketmine\entity\Wolf && $this->entity->isTamed())) {
				return false;
			}
			return $this->findSuitableWolfTarget();
		}

	public function canContinue() {
			/* decompiled (structured CF) */
			if (($this->entity instanceof \pocketmine\entity\Wolf && $this->entity->isSitting())) {
				return false;
			}
			return parent::canContinue();
		}

	public function onTick() {
			/* decompiled (structured CF) */
			if ((0 < $this->timeLeft)) {
			}
			if ((!($this->enemy instanceof \pocketmine\entity\Entity) || !($this->enemy->isAlive()))) {
				return null;
			}
			$entity = $this->entity;
			if (method_exists($entity, 'setAngry')) {
				$entity->setAngry(true);
			}
			$distance = $entity->distance($this->enemy);
			if ((self::ATTACK_RANGE < $distance)) {
				$entity->setPm1eFollowTarget($this->enemy);
				$entity->setPm1eMoveMultiplier($this->speedMultiplier);
				$entity->setPm1eStayTime(0);
				if ((((self::POUNCE_MIN_DISTANCE <= $distance) && ($distance <= self::POUNCE_MAX_DISTANCE)) && method_exists($entity, 'requestPm1eAttackLeap'))) {
					$entity->requestPm1eAttackLeap($this->enemy);
				}
			} else {
				if (($this->timeLeft <= 0)) {
					$damage = $entity->getHurt();
					$knockBack = 0.4;
					if (method_exists($entity, 'getWeapon')) {
						$damage += max(0, (\pocketmine\entity\VanillaMobEquipment::getWeaponBaseDamage($entity->getWeapon()) - 1));
						$damage += \pocketmine\item\Tool::getWeaponEnchantmentDamageBonus($entity, $this->enemy);
						$knockBack = \pocketmine\item\Tool::getWeaponKnockBackStrength($knockBack, $entity);
					}
					new \pocketmine\event\entity\EntityDamageByEntityEvent($entity, $this->enemy, \pocketmine\event\entity\EntityDamageEvent::CAUSE_ENTITY_ATTACK, $damage, $knockBack);
					$this->enemy->attack($damage, new \pocketmine\event\entity\EntityDamageByEntityEvent($entity, $this->enemy, \pocketmine\event\entity\EntityDamageEvent::CAUSE_ENTITY_ATTACK, $damage, $knockBack));
					$this->timeLeft = self::PNX_ATTACK_COOLDOWN;
				}
			}
			$this->swimming();
		}

	private function findSuitableWolfTarget() {
			/* decompiled (structured CF) */
			$level = $this->entity->getLevel();
			if (($level === null)) {
				return false;
			}
			$closest = null;
			$closestDistance = $this->lookDistance;
			foreach ($level->getEntities() as $entity) {
				if (((!($entity instanceof \pocketmine\entity\Entity) || ($entity === $this->entity)) || !($this->isSuitableWolfTarget($entity)))) {
					/* goto */
				}
				if (($entity->closed || !($entity->isAlive()))) {
					/* goto */
				}
				$distance = $this->entity->distance($entity);
				if (($distance < $closestDistance)) {
					$closest = $entity;
					$closestDistance = $distance;
				}
				/* goto */
			}
			if ($closest instanceof \pocketmine\entity\Entity) {
				$this->enemy = $closest;
				return true;
			}
			return false;
		}

	private function isSuitableWolfTarget($entity = null) {
			return (($entity instanceof \pocketmine\entity\Skeleton || $entity instanceof \pocketmine\entity\Rabbit) || $entity instanceof \pocketmine\entity\Sheep);
		}

	public function onEnd() {
			/* decompiled (structured CF) */
			$enemy = $this->enemy;
			parent::onEnd();
			if ((($enemy instanceof \pocketmine\entity\Entity && method_exists($this->entity, 'getPm1eRetaliationTarget')) && ($enemy === $this->entity->getPm1eRetaliationTarget()))) {
				$this->entity->setPm1eRetaliationTarget(null);
			}
			$this->enemy = null;
			if (method_exists($this->entity, 'setAngry')) {
				$this->entity->setAngry(false);
			}
			return null;
		}

}
