<?php

namespace pocketmine\entity\behavior;

class StrollBehavior extends \pocketmine\entity\behavior\Behavior {
	public const DEFAULT_DURATION = 80;
	public const DEFAULT_SPEED = 0.25;
	public const DEFAULT_SPEED_MULTIPLIER = 0.75;
	public const BASE_SPEED_FACTOR = 0.7;
	public const WATER_SPEED_MULTIPLIER = 1.3;
	public const LAND_SPEED_MULTIPLIER = 1.4;
	public const JUMP_VELOCITY = 0.42;

	public $duration = 0;
	public $timeLeft = 0;
	public $speed = 0;
	public $speedMultiplier = 0;
	private $startChance = 10;

	public function __construct($entity = null, $duration = null, $speed = null, $speedMultiplier = null) {
			/* decompiled (structured CF) */
			parent::__construct($entity);
			$this->duration = $duration;
			$this->speed = $speed;
			$this->speedMultiplier = $speedMultiplier;
			$this->reset();
			return;
		}

	public function getName() {
			return "\xe8\xa1\x8c\xe8\xb5\xb0";
		}

	public function shouldStart() {
			return (mt_rand(0, $this->startChance) === 0);
		}

	public function canContinue() {
			return (0 < $t0);
		}

	public function onTick() {
			/* decompiled (structured CF) */
			if ($this->isFalling()) {
				$this->timeLeft = $this->duration;
				return null;
			}
			$direction = $this->entity->getDirectionVector();
			$direction->y = 0;
			$speedFactor = $this->calculateSpeedFactor();
			$targetPos = $this->getTargetPosition($direction, $speedFactor);
			if ($this->isColliding($targetPos)) {
				$this->handleCollision($targetPos);
			} else {
				$this->moveToDirection($direction, $speedFactor);
			}
			$this->handleSwimming();
		}

	public function onEnd() {
			$this->reset();
			return null;
		}

	private function reset() {
			$this->timeLeft = $this->duration;
			return null;
		}

	private function calculateSpeedFactor() {
			/* decompiled (structured CF) */
			$baseFactor = (($this->speed * $this->speedMultiplier) * self::BASE_SPEED_FACTOR);
			if ($this->entity->isInsideOfWater()) {
			} else {
			}
			$environmentMultiplier = self::LAND_SPEED_MULTIPLIER;
			return ($baseFactor * $environmentMultiplier);
		}

	private function getTargetPosition($direction = null, $speedFactor = null) {
			new \pocketmine\math\Vector3($this->entity->x, $this->entity->y, $this->entity->z);
			$coordinates = new \pocketmine\math\Vector3($this->entity->x, $this->entity->y, $this->entity->z);
			return $coordinates->add($direction->multiply(($speedFactor + 0.5)));
		}

	private function isFalling() {
			/* decompiled (structured CF) */
			if ((0 <= $this->entity->getMotion()->y)) {
				return false;
			}
			$blockBelow = $this->entity->getLevel()->getBlock($this->entity->floor()->subtract(0, 1, 0));
			return $blockBelow->canPassThrough();
		}

	private function isColliding($targetPos = null) {
			/* decompiled (structured CF) */
			$level = $this->entity->getLevel();
			$block = $level->getBlock($targetPos);
			if (!($block->canPassThrough())) {
				return true;
			}
			if ((1 <= $this->entity->height)) {
				$blockAbove = $level->getBlock($targetPos->add(0, 1, 0));
				if (!($blockAbove->canPassThrough())) {
					return true;
				}
			}
			return false;
		}

	private function handleCollision($targetPos = null) {
			/* decompiled (structured CF) */
			$level = $this->entity->getLevel();
			$blockAbove = $level->getBlock($targetPos->add(0, 1, 0));
			$blockTwoAbove = $level->getBlock($targetPos->add(0, 2, 0));
			if ((($blockAbove->canPassThrough() && !(((1 < $this->entity->height) && !($blockTwoAbove->canPassThrough())))) && (mt_rand(0, 5) !== 0))) {
				$this->entity->motionY = self::JUMP_VELOCITY;
			} else {
				$this->entity->yaw += 180;
			}
			return null;
		}

	private function moveToDirection($direction = null, $speedFactor = null) {
			/* decompiled (structured CF) */
			$motion = $direction->multiply($speedFactor);
			$currentMotion = $this->entity->getMotion();
			if (($currentMotion->lengthSquared() < $motion->lengthSquared())) {
				$newMotion = clone $currentMotion;
				$newMotion->x += ($motion->x - $currentMotion->x);
				$newMotion->z += ($motion->z - $currentMotion->z);
				$this->entity->setMotion($newMotion);
			} else {
				$this->entity->setMotion($motion);
			}
			return null;
		}

	private function handleSwimming() {
			/* decompiled (structured CF) */
			if (method_exists($this->entity, 'swimming')) {
				$this->entity->swimming();
			}
			return null;
		}

}
