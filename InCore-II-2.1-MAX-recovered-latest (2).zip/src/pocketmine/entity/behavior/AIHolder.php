<?php

namespace pocketmine\entity\behavior;

class AIHolder {
	public const HOSTILE_SPAWN_MAX_LIGHT = 7;
	public const NATURAL_SPAWN_TASK = 'MobGenerate';

	public $ChickenAI = NULL;
	public $CowAI = NULL;
	public $CreeperAI = NULL;
	public $PigAI = NULL;
	public $SheepAI = NULL;
	public $SkeletonAI = NULL;
	public $SpiderAI = NULL;
	public $ZombieAI = NULL;
	public $DefultAI = NULL;
	public $Zombie = array (
);
	public $ZombieVillager = array (
);
	public $PigZombie = array (
);
	public $Creeper = array (
);
	public $Skeleton = array (
);
	public $Cow = array (
);
	public $Squid = array (
);
	public $Pig = array (
);
	public $Sheep = array (
);
	public $Spider = array (
);
	public $CaveSpider = array (
);
	public $LavaSlime = array (
);
	public $Slime = array (
);
	public $Enderman = array (
);
	public $Witch = array (
);
	public $Ghast = array (
);
	public $Bat = array (
);
	public $Silverfish = array (
);
	public $Chicken = array (
);
	public $Ocelot = array (
);
	public $Mooshroom = array (
);
	public $Blaze = array (
);
	public $Rabbit = array (
);
	public $Wolf = array (
);
	public $Villager = array (
);
	public $IronGolem = array (
);
	public $Defult = array (
);
	public $birth_r = 30;
	public $tasks = array (
);
	public $server = NULL;

	public function getServer() {
			return $this->server;
		}

	public function __construct($server = null) {
			/* decompiled (structured CF) */
			$this->server = $server;
			if ($this->server->aiConfig['mobgenerate']) {
				$this->RestartSpawnTimer(self::getNaturalSpawnTaskPeriod($this->server->getDifficulty()));
			}
			new \pocketmine\scheduler\CallbackTask([$this, 'TimeFix']);
			$this->getServer()->getScheduler()->scheduleRepeatingTask(new \pocketmine\scheduler\CallbackTask([$this, 'TimeFix']), 20);
			new \pocketmine\scheduler\CallbackTask([$this, 'RotationTimer']);
			$this->getServer()->getScheduler()->scheduleRepeatingTask(new \pocketmine\scheduler\CallbackTask([$this, 'RotationTimer']), 2);
			return;
		}

	public static function getNaturalSpawnTaskPeriod($difficulty = null) {
			/* decompiled (structured CF) */
			switch (max(0, min(3, ($difficulty)))) {
				case 0:
				return 1200;
				case 1:
				return 600;
				case 2:
				return 360;
				case 3:
				return 240;
			}
		}

	public static function getNaturalSpawnAttempts($difficulty = null) {
			/* decompiled (structured CF) */
			switch (max(0, min(3, ($difficulty)))) {
				case 0:
				return 1;
				case 1:
				return 1;
				case 2:
				return 2;
				case 3:
				return 3;
			}
		}

	public function setZombieHatred_r($r = null) {
			$this->ZombieAI->hatred_r = $r;
			return null;
		}

	public function setZombieBirth_r($r = null) {
			$this->birth_r = $r;
		}

	public function setZombieHate_v($v = null) {
			$this->ZombieAI->zo_hate_v = $v;
			return null;
		}

	public function RestartSpawnTimer($tick = null) {
			/* decompiled (structured CF) */
			if (($tick === null)) {
				$tick = self::getNaturalSpawnTaskPeriod($this->getServer()->getDifficulty());
			}
			if ((isset($this->tasks[self::NATURAL_SPAWN_TASK]) && $this->tasks[self::NATURAL_SPAWN_TASK] instanceof \pocketmine\scheduler\TaskHandler)) {
				$this->tasks[self::NATURAL_SPAWN_TASK]->cancel();
			}
			if (!($this->server->aiConfig['mobgenerate'])) {
				return false;
			}
			new \pocketmine\scheduler\CallbackTask([$this, 'MobGenerate']);
			$this->tasks[self::NATURAL_SPAWN_TASK] = $this->getServer()->getScheduler()->scheduleRepeatingTask(new \pocketmine\scheduler\CallbackTask([$this, 'MobGenerate']), max(1, ($tick)));
			return $this->tasks[self::NATURAL_SPAWN_TASK] instanceof \pocketmine\scheduler\TaskHandler;
		}

	public function TimeFix() {
			/* decompiled (structured CF) */
			$mode = $this->mode();
			foreach ($this->getServer()->getLevels() as $level) {
				foreach ($level->getEntities() as $entity) {
					if ($entity instanceof \pocketmine\entity\Zombie) {
						$this->ahurt($entity, $mode);
					}
					if (($entity instanceof \pocketmine\entity\Spider || $entity instanceof \pocketmine\entity\CaveSpider)) {
						$this->bhurt($entity, $mode);
					}
					/* goto */
				}
				if ((24000 < $level->getTime())) {
					$level->setTime(0);
				}
				/* goto */
			}
			return null;
		}

	public function mode() {
			/* decompiled (structured CF) */
			$mode = 1;
			switch ($this->getServer()->getDifficulty()) {
				case 0:
				case 1:
				$mode = 1;
				break;
				case 2:
				$mode = 2;
				break;
				case 3:
				$mode = 3;
				break;
			}
			return $mode;
		}

	public function ahurt($e = null, $mode = null) {
			/* decompiled (structured CF) */
			if (!(($mode == 1))) {
				if (!(($mode == 2))) {
					if (!(($mode == 3))) {
					} else {
						$hurt = 5;
						/* jump */
						$hurt = 6;
						/* jump */
						$hurt = 8;
						/* jump */
					}
					return $e->setHurt($hurt);
				}
			}
		}

	public function bhurt($e = null, $mode = null) {
			/* decompiled (structured CF) */
			if (!(($mode == 1))) {
				if (!(($mode == 2))) {
					if (!(($mode == 3))) {
					} else {
						$hurt = 5;
						/* jump */
						$hurt = 6;
						/* jump */
						$hurt = 6;
						/* jump */
					}
					return $e->setHurt($hurt);
				}
			}
		}

	private function finalizeNaturalMob($entity = null) {
			\pocketmine\entity\AgeableSpawnHelper::maybeSetBaby($entity, \pocketmine\entity\AgeableSpawnHelper::PNX_NATURAL_BABY_CHANCE);
			$entity->spawnToAll();
			return null;
		}

	public function spawnZombie($pos = null, $maxHealth = null, $health = null) {
			/* decompiled (structured CF) */
			$chunk = $pos->level->getChunk(($pos->x >> 4), ($pos->z >> 4), false);
			$nbt = $this->getNBT();
			new \pocketmine\entity\Zombie($chunk, $nbt);
			$zo = new \pocketmine\entity\Zombie($chunk, $nbt);
			$zo->setPosition($pos);
			$zo->setMaxHealth($maxHealth);
			$zo->setHealth($health);
			$this->finalizeNaturalMob($zo);
			return null;
		}

	public function spawnZombieVillager($pos = null, $maxHealth = null, $health = null) {
			/* decompiled (structured CF) */
			$chunk = $pos->level->getChunk(($pos->x >> 4), ($pos->z >> 4), false);
			$nbt = $this->getNBT();
			new \pocketmine\entity\ZombieVillager($chunk, $nbt);
			$zov = new \pocketmine\entity\ZombieVillager($chunk, $nbt);
			$zov->setPosition($pos);
			$zov->setMaxHealth($maxHealth);
			$zov->setHealth($health);
			$this->finalizeNaturalMob($zov);
			return null;
		}

	public function spawnPigZombie($pos = null, $maxHealth = null, $health = null) {
			/* decompiled (structured CF) */
			$chunk = $pos->level->getChunk(($pos->x >> 4), ($pos->z >> 4), false);
			$nbt = $this->getNBT();
			new \pocketmine\entity\PigZombie($chunk, $nbt);
			$zo = new \pocketmine\entity\PigZombie($chunk, $nbt);
			$zo->setPosition($pos);
			$zo->setMaxHealth($maxHealth);
			$zo->setHealth($health);
			$this->finalizeNaturalMob($zo);
			return null;
		}

	public function spawnCreeper($pos = null, $maxHealth = null, $health = null) {
			/* decompiled (structured CF) */
			$chunk = $pos->level->getChunk(($pos->x >> 4), ($pos->z >> 4), false);
			$nbt = $this->getNBT();
			new \pocketmine\entity\Creeper($chunk, $nbt);
			$co = new \pocketmine\entity\Creeper($chunk, $nbt);
			$co->setPosition($pos);
			$co->setMaxHealth($maxHealth);
			$co->setHealth($health);
			$this->finalizeNaturalMob($co);
			return null;
		}

	public function spawnSquid($pos = null, $maxHealth = null, $health = null) {
			/* decompiled (structured CF) */
			$chunk = $pos->level->getChunk(($pos->x >> 4), ($pos->z >> 4), false);
			$nbt = $this->getNBT();
			new \pocketmine\entity\Squid($chunk, $nbt);
			$squ = new \pocketmine\entity\Squid($chunk, $nbt);
			$squ->setPosition($pos);
			$squ->setMaxHealth($maxHealth);
			$squ->setHealth($health);
			$this->finalizeNaturalMob($squ);
			return null;
		}

	public function spawnSkeleton($pos = null, $maxHealth = null, $health = null) {
			/* decompiled (structured CF) */
			$chunk = $pos->level->getChunk(($pos->x >> 4), ($pos->z >> 4), false);
			$nbt = $this->getNBT();
			new \pocketmine\entity\Skeleton($chunk, $nbt);
			$so = new \pocketmine\entity\Skeleton($chunk, $nbt);
			$so->setPosition($pos);
			$so->setMaxHealth($maxHealth);
			$so->setHealth($health);
			$this->finalizeNaturalMob($so);
			return null;
		}

	public function spawnSpider($pos = null, $maxHealth = null, $health = null) {
			/* decompiled (structured CF) */
			$chunk = $pos->level->getChunk(($pos->x >> 4), ($pos->z >> 4), false);
			$nbt = $this->getNBT();
			new \pocketmine\entity\Spider($chunk, $nbt);
			$so = new \pocketmine\entity\Spider($chunk, $nbt);
			$so->setPosition($pos);
			$so->setMaxHealth($maxHealth);
			$so->setHealth($health);
			$this->finalizeNaturalMob($so);
			return null;
		}

	public function spawnCow($pos = null, $maxHealth = null, $health = null) {
			/* decompiled (structured CF) */
			$chunk = $pos->level->getChunk(($pos->x >> 4), ($pos->z >> 4), false);
			$nbt = $this->getNBT();
			new \pocketmine\entity\Cow($chunk, $nbt);
			$coo = new \pocketmine\entity\Cow($chunk, $nbt);
			$coo->setPosition($pos);
			$coo->setMaxHealth($maxHealth);
			$coo->setHealth($health);
			$this->finalizeNaturalMob($coo);
			return null;
		}

	public function spawnPig($pos = null, $maxHealth = null, $health = null) {
			/* decompiled (structured CF) */
			$chunk = $pos->level->getChunk(($pos->x >> 4), ($pos->z >> 4), false);
			$nbt = $this->getNBT();
			new \pocketmine\entity\Pig($chunk, $nbt);
			$po = new \pocketmine\entity\Pig($chunk, $nbt);
			$po->setPosition($pos);
			$po->setMaxHealth($maxHealth);
			$po->setHealth($health);
			$this->finalizeNaturalMob($po);
			return null;
		}

	public function spawnSheep($pos = null, $maxHealth = null, $health = null) {
			/* decompiled (structured CF) */
			$chunk = $pos->level->getChunk(($pos->x >> 4), ($pos->z >> 4), false);
			$nbt = $this->getNBT();
			new \pocketmine\entity\Sheep($chunk, $nbt);
			$sho = new \pocketmine\entity\Sheep($chunk, $nbt);
			$sho->setPosition($pos);
			$sho->setMaxHealth($maxHealth);
			$sho->setHealth($health);
			$this->finalizeNaturalMob($sho);
			return null;
		}

	public function spawnChicken($pos = null, $maxHealth = null, $health = null) {
			/* decompiled (structured CF) */
			$chunk = $pos->level->getChunk(($pos->x >> 4), ($pos->z >> 4), false);
			$nbt = $this->getNBT();
			new \pocketmine\entity\Chicken($chunk, $nbt);
			$cho = new \pocketmine\entity\Chicken($chunk, $nbt);
			$cho->setPosition($pos);
			$cho->setMaxHealth($maxHealth);
			$cho->setHealth($health);
			$this->finalizeNaturalMob($cho);
			return null;
		}

	public function spawnRabbit($pos = null, $maxHealth = null, $health = null) {
			/* decompiled (structured CF) */
			$chunk = $pos->level->getChunk(($pos->x >> 4), ($pos->z >> 4), false);
			$nbt = $this->getNBT();
			new \pocketmine\entity\Rabbit($chunk, $nbt);
			$rab = new \pocketmine\entity\Rabbit($chunk, $nbt);
			$rab->setPosition($pos);
			$rab->setMaxHealth($maxHealth);
			$rab->setHealth($health);
			$this->finalizeNaturalMob($rab);
			return null;
		}

	public function spawnMooshroom($pos = null, $maxHealth = null, $health = null) {
			/* decompiled (structured CF) */
			$chunk = $pos->level->getChunk(($pos->x >> 4), ($pos->z >> 4), false);
			$nbt = $this->getNBT();
			new \pocketmine\entity\Mooshroom($chunk, $nbt);
			$moo = new \pocketmine\entity\Mooshroom($chunk, $nbt);
			$moo->setPosition($pos);
			$moo->setMaxHealth($maxHealth);
			$moo->setHealth($health);
			$this->finalizeNaturalMob($moo);
			return null;
		}

	public function spawnWolf($pos = null, $maxHealth = null, $health = null) {
			/* decompiled (structured CF) */
			$chunk = $pos->level->getChunk(($pos->x >> 4), ($pos->z >> 4), false);
			$nbt = $this->getNBT();
			new \pocketmine\entity\Wolf($chunk, $nbt);
			$wolf = new \pocketmine\entity\Wolf($chunk, $nbt);
			$wolf->setPosition($pos);
			$wolf->setMaxHealth($maxHealth);
			$wolf->setHealth($health);
			$this->finalizeNaturalMob($wolf);
			return null;
		}

	public function spawnOcelot($pos = null, $maxHealth = null, $health = null) {
			/* decompiled (structured CF) */
			$chunk = $pos->level->getChunk(($pos->x >> 4), ($pos->z >> 4), false);
			$nbt = $this->getNBT();
			new \pocketmine\entity\Ocelot($chunk, $nbt);
			$ocelot = new \pocketmine\entity\Ocelot($chunk, $nbt);
			$ocelot->setPosition($pos);
			$ocelot->setMaxHealth($maxHealth);
			$ocelot->setHealth($health);
			$this->finalizeNaturalMob($ocelot);
			return null;
		}

	public function spawnGhast($pos = null, $maxHealth = null, $health = null) {
			/* decompiled (structured CF) */
			$chunk = $pos->level->getChunk(($pos->x >> 4), ($pos->z >> 4), false);
			$nbt = $this->getNBT();
			new \pocketmine\entity\Ghast($chunk, $nbt);
			$ghast = new \pocketmine\entity\Ghast($chunk, $nbt);
			$ghast->setPosition($pos);
			$ghast->setMaxHealth($maxHealth);
			$ghast->setHealth($health);
			$this->finalizeNaturalMob($ghast);
			return null;
		}

	public function spawnBat($pos = null, $maxHealth = null, $health = null) {
			/* decompiled (structured CF) */
			$chunk = $pos->level->getChunk(($pos->x >> 4), ($pos->z >> 4), false);
			$nbt = $this->getNBT();
			new \pocketmine\entity\Bat($chunk, $nbt);
			$bat = new \pocketmine\entity\Bat($chunk, $nbt);
			$bat->setPosition($pos);
			$bat->setMaxHealth($maxHealth);
			$bat->setHealth($health);
			$this->finalizeNaturalMob($bat);
			return null;
		}

	public function spawnVillager($pos = null, $maxHealth = null, $health = null) {
			/* decompiled (structured CF) */
			$chunk = $pos->level->getChunk(($pos->x >> 4), ($pos->z >> 4), false);
			$nbt = $this->getNBT();
			new \pocketmine\entity\Villager($chunk, $nbt);
			$villager = new \pocketmine\entity\Villager($chunk, $nbt);
			$villager->setPosition($pos);
			$villager->setMaxHealth($maxHealth);
			$villager->setHealth($health);
			$this->finalizeNaturalMob($villager);
			return null;
		}

	public function spawnIronGolem($pos = null, $maxHealth = null, $health = null) {
			/* decompiled (structured CF) */
			$chunk = $pos->level->getChunk(($pos->x >> 4), ($pos->z >> 4), false);
			$nbt = $this->getNBT();
			new \pocketmine\entity\IronGolem($chunk, $nbt);
			$golem = new \pocketmine\entity\IronGolem($chunk, $nbt);
			$golem->setPosition($pos);
			$golem->setMaxHealth($maxHealth);
			$golem->setHealth($health);
			$this->finalizeNaturalMob($golem);
			return null;
		}

	public function spawnCaveSpider($pos = null, $maxHealth = null, $health = null) {
			/* decompiled (structured CF) */
			$chunk = $pos->level->getChunk(($pos->x >> 4), ($pos->z >> 4), false);
			$nbt = $this->getNBT();
			new \pocketmine\entity\CaveSpider($chunk, $nbt);
			$cspi = new \pocketmine\entity\CaveSpider($chunk, $nbt);
			$cspi->setPosition($pos);
			$cspi->setMaxHealth($maxHealth);
			$cspi->setHealth($health);
			$this->finalizeNaturalMob($cspi);
			return null;
		}

	public function spawnBlaze($pos = null, $maxHealth = null, $health = null) {
			/* decompiled (structured CF) */
			$chunk = $pos->level->getChunk(($pos->x >> 4), ($pos->z >> 4), false);
			$nbt = $this->getNBT();
			new \pocketmine\entity\Blaze($chunk, $nbt);
			$bla = new \pocketmine\entity\Blaze($chunk, $nbt);
			$bla->setPosition($pos);
			$bla->setMaxHealth($maxHealth);
			$bla->setHealth($health);
			$this->finalizeNaturalMob($bla);
			return null;
		}

	public function spawnLavaSlime($pos = null, $maxHealth = null, $health = null) {
			/* decompiled (structured CF) */
			$chunk = $pos->level->getChunk(($pos->x >> 4), ($pos->z >> 4), false);
			$nbt = $this->getNBT();
			new \pocketmine\entity\LavaSlime($chunk, $nbt);
			$lav = new \pocketmine\entity\LavaSlime($chunk, $nbt);
			$lav->setPosition($pos);
			$lav->setMaxHealth($maxHealth);
			$lav->setHealth($health);
			$this->finalizeNaturalMob($lav);
			return null;
		}

	public function spawnSlime($pos = null, $maxHealth = null, $health = null) {
			/* decompiled (structured CF) */
			$chunk = $pos->level->getChunk(($pos->x >> 4), ($pos->z >> 4), false);
			$nbt = $this->getNBT();
			new \pocketmine\entity\Slime($chunk, $nbt);
			$slime = new \pocketmine\entity\Slime($chunk, $nbt);
			$slime->setPosition($pos);
			$slime->setMaxHealth($maxHealth);
			$slime->setHealth($health);
			$this->finalizeNaturalMob($slime);
			return null;
		}

	public function spawnEnderman($pos = null, $maxHealth = null, $health = null) {
			/* decompiled (structured CF) */
			$chunk = $pos->level->getChunk(($pos->x >> 4), ($pos->z >> 4), false);
			$nbt = $this->getNBT();
			new \pocketmine\entity\Enderman($chunk, $nbt);
			$enderman = new \pocketmine\entity\Enderman($chunk, $nbt);
			$enderman->setPosition($pos);
			$enderman->setMaxHealth($maxHealth);
			$enderman->setHealth($health);
			$this->finalizeNaturalMob($enderman);
			return null;
		}

	public function spawnWitch($pos = null, $maxHealth = null, $health = null) {
			/* decompiled (structured CF) */
			$chunk = $pos->level->getChunk(($pos->x >> 4), ($pos->z >> 4), false);
			$nbt = $this->getNBT();
			new \pocketmine\entity\Witch($chunk, $nbt);
			$witch = new \pocketmine\entity\Witch($chunk, $nbt);
			$witch->setPosition($pos);
			$witch->setMaxHealth($maxHealth);
			$witch->setHealth($health);
			$this->finalizeNaturalMob($witch);
			return null;
		}

	public function spawnSilverfish($pos = null, $maxHealth = null, $health = null) {
			/* decompiled (structured CF) */
			$chunk = $pos->level->getChunk(($pos->x >> 4), ($pos->z >> 4), false);
			$nbt = $this->getNBT();
			new \pocketmine\entity\Silverfish($chunk, $nbt);
			$silverfish = new \pocketmine\entity\Silverfish($chunk, $nbt);
			$silverfish->setPosition($pos);
			$silverfish->setMaxHealth($maxHealth);
			$silverfish->setHealth($health);
			$this->finalizeNaturalMob($silverfish);
			return null;
		}

	public function getPlayerDamage($player = null, $damage = null) {
			/* decompiled (structured CF) */
			$armorValues = [1, 3, 2, 1, 1, 5, 4, 1, 1, 5, 3, 1, 2, 6, 5, 2, 3, 8, 6, 3];
			$points = 0;
			foreach ($player->getInventory()->getArmorContents() as $index => $i) {
				if (isset($armorValues[$i->getId()])) {
					$points += $armorValues[$i->getId()];
				}
				/* goto */
			}
			$damage = floor(($damage - ($points * 0.04)));
			if (($damage < 0)) {
				$damage = 0;
			}
			return $damage;
		}

	public function getNBT() {
			/* decompiled (structured CF) */
			new \pocketmine\nbt\tag\DoubleTag('', 0);
			new \pocketmine\nbt\tag\DoubleTag('', 0);
			new \pocketmine\nbt\tag\DoubleTag('', 0);
			new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]);
			new \pocketmine\nbt\tag\DoubleTag('', 0);
			new \pocketmine\nbt\tag\DoubleTag('', 0);
			new \pocketmine\nbt\tag\DoubleTag('', 0);
			new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]);
			new \pocketmine\nbt\tag\FloatTag('', 0);
			new \pocketmine\nbt\tag\FloatTag('', 0);
			new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', 0), new \pocketmine\nbt\tag\FloatTag('', 0)]);
			new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', 0), new \pocketmine\nbt\tag\FloatTag('', 0)])]);
			$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', 0), new \pocketmine\nbt\tag\FloatTag('', 0)])]);
			return $nbt;
		}

	public function getLight($pos = null) {
			/* decompiled (structured CF) */
			$chunk = $pos->getLevel()->getChunk(($pos->x >> 4), ($pos->z >> 4), false);
			$l = 0;
			if ($chunk instanceof \pocketmine\level\format\FullChunk) {
				$l = $chunk->getBlockSkyLight(($pos->x & 15), ($pos->y & 127), ($pos->z & 15));
				if (($l < 15)) {
					$l = $chunk->getBlockLight(($pos->x & 15), ($pos->y & 127), ($pos->z & 15));
				}
			}
			return $l;
		}

	public function canSpawnHostileAt($pos = null) {
			/* decompiled (structured CF) */
			$level = $pos->getLevel();
			if (!($level instanceof \pocketmine\level\Level)) {
				return false;
			}
			return \pocketmine\entity\NaturalMobSpawnRules::canSpawnHostileAt($level, $pos);
		}

	private function isNaturalSpawnLevel($level = null) {
			return ((($level->getDimension() === \pocketmine\level\Level::DIMENSION_NORMAL) || ($level->getDimension() === \pocketmine\level\Level::DIMENSION_NETHER)) || ($level->getDimension() === \pocketmine\level\Level::DIMENSION_END));
		}

	private function isInGeneratedVillage($level = null, $pos = null) {
			return (\pocketmine\level\generator\normal\populator\VillagePopulator::findGeneratedVillageCenter($level, (floor($pos->x)), (floor($pos->z)), 96) !== null);
		}

	private function countNaturalEntities($level = null, $entityId = null) {
			/* decompiled (structured CF) */
			$count = 0;
			foreach ($level->getEntities() as $entity) {
				if (($entity instanceof \pocketmine\entity\Entity && ($entityId === $entity::NETWORK_ID))) {
					$count++;
				}
				/* goto */
			}
			return $count;
		}

	private function canGenerateNaturalEntity($level = null, $entityId = null, $inVillage = null) {
			/* decompiled (structured CF) */
			if (($entityId <= 0)) {
				return false;
			}
			return ($this->countNaturalEntities($level, $entityId) < \pocketmine\entity\NaturalMobSpawnRules::getEntitySpawnLimit($entityId, $inVillage));
		}

	private function generateNaturalEntity($entityId = null, $pos = null, $inVillage = null) {
			/* decompiled (structured CF) */
			if (!($this->canGenerateNaturalEntity($pos->getLevel(), $entityId, $inVillage))) {
				return false;
			}
			new \pocketmine\event\entity\EntityGenerateEvent($pos, $entityId, \pocketmine\event\entity\EntityGenerateEvent::CAUSE_AI_HOLDER);
			$ev = new \pocketmine\event\entity\EntityGenerateEvent($pos, $entityId, \pocketmine\event\entity\EntityGenerateEvent::CAUSE_AI_HOLDER);
			$this->server->getPluginManager()->callEvent($ev);
			if ($ev->isCancelled()) {
				return false;
			}
			return $this->spawnNaturalEntity($entityId, $ev->getPosition());
		}

	private function generateNaturalEntityGroup($entityIds = null, $center = null, $inVillage = null) {
			/* decompiled (structured CF) */
			$spawned = false;
			$index = 0;
			foreach ($entityIds as $entityId) {
				if (($index === 0)) {
				} else {
				}
				$pos = $this->findNaturalGroupSpawnPosition($center, $entityId, $index, $inVillage);
				$index++;
				if (!($pos instanceof \pocketmine\level\Position)) {
					/* goto */
				}
				if ($this->generateNaturalEntity(($entityId), $pos, $inVillage)) {
					$spawned = true;
				}
				/* goto */
			}
			return $spawned;
		}

	private function findNaturalGroupSpawnPosition($center = null, $entityId = null, $index = null, $inVillage = null) {
			/* decompiled (structured CF) */
			$level = $center->getLevel();
			$baseX = (floor($center->x));
			$baseY = (floor($center->y));
			$baseZ = (floor($center->z));
			$offsets = ['__array_ptr' => '2aaaadcd99d8'];
			$count = count($offsets);
			$i = 0;
			while (($i < $count)) {
				$offset = $offsets[((($index + $i) - 1) % $count)];
				$x = ($baseX + $offset[0]);
				$z = ($baseZ + $offset[1]);
				$y = ($baseY - 2);
				while (($y <= $t68)) {
					new \pocketmine\math\Vector3($x, ($y - 1), $z);
					if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y - 1), $z)) !== 'block')) {
					} else {
						new \pocketmine\math\Vector3($x, $y, $z);
						if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, $y, $z)) !== 'air')) {
						} else {
							new \pocketmine\math\Vector3($x, ($y + 1), $z);
							if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y + 1), $z)) !== 'air')) {
							} else {
								new \pocketmine\level\Position(($x + 0.5), $y, ($z + 0.5), $level);
								$pos = new \pocketmine\level\Position(($x + 0.5), $y, ($z + 0.5), $level);
								if (\pocketmine\entity\NaturalMobSpawnRules::canSpawnSelectedLandEntityAt($level, $pos, $entityId, $inVillage)) {
									return $pos;
								}
							}
						}
					}
					$y++;
				}
				$i++;
			}
		}

	private function spawnNaturalEntity($entityId = null, $pos = null) {
			/* decompiled (structured CF) */
			if (!(($entityId == \pocketmine\entity\Zombie::NETWORK_ID))) {
				if (!(($entityId == \pocketmine\entity\ZombieVillager::NETWORK_ID))) {
					if (!(($entityId == \pocketmine\entity\Skeleton::NETWORK_ID))) {
						if (!(($entityId == \pocketmine\entity\Creeper::NETWORK_ID))) {
							if (!(($entityId == \pocketmine\entity\Spider::NETWORK_ID))) {
								if (!(($entityId == \pocketmine\entity\CaveSpider::NETWORK_ID))) {
									if (!(($entityId == \pocketmine\entity\Slime::NETWORK_ID))) {
										if (!(($entityId == \pocketmine\entity\Enderman::NETWORK_ID))) {
											if (!(($entityId == \pocketmine\entity\Witch::NETWORK_ID))) {
												if (!(($entityId == \pocketmine\entity\PigZombie::NETWORK_ID))) {
													if (!(($entityId == \pocketmine\entity\LavaSlime::NETWORK_ID))) {
														if (!(($entityId == \pocketmine\entity\Blaze::NETWORK_ID))) {
															if (!(($entityId == \pocketmine\entity\Ghast::NETWORK_ID))) {
																if (!(($entityId == \pocketmine\entity\Bat::NETWORK_ID))) {
																	if (!(($entityId == \pocketmine\entity\Silverfish::NETWORK_ID))) {
																		if (!(($entityId == \pocketmine\entity\Cow::NETWORK_ID))) {
																			if (!(($entityId == \pocketmine\entity\Pig::NETWORK_ID))) {
																				if (!(($entityId == \pocketmine\entity\Sheep::NETWORK_ID))) {
																					if (!(($entityId == \pocketmine\entity\Chicken::NETWORK_ID))) {
																						if (!(($entityId == \pocketmine\entity\Rabbit::NETWORK_ID))) {
																							if (!(($entityId == \pocketmine\entity\Mooshroom::NETWORK_ID))) {
																								if (!(($entityId == \pocketmine\entity\Ocelot::NETWORK_ID))) {
																									if (!(($entityId == \pocketmine\entity\Squid::NETWORK_ID))) {
																										if (!(($entityId == \pocketmine\entity\Wolf::NETWORK_ID))) {
																											if (!(($entityId == \pocketmine\entity\Villager::NETWORK_ID))) {
																												if (!(($entityId == \pocketmine\entity\IronGolem::NETWORK_ID))) {
																													/* jump */
																													$this->spawnZombie($pos);
																													return true;
																													$this->spawnZombieVillager($pos);
																													return true;
																													$this->spawnSkeleton($pos);
																													return true;
																													$this->spawnCreeper($pos);
																													return true;
																													$this->spawnSpider($pos);
																													return true;
																													$this->spawnCaveSpider($pos);
																													return true;
																													$this->spawnSlime($pos);
																													return true;
																													$this->spawnEnderman($pos);
																													return true;
																													$this->spawnWitch($pos);
																													return true;
																													$this->spawnPigZombie($pos);
																													return true;
																													$this->spawnLavaSlime($pos);
																													return true;
																													$this->spawnBlaze($pos);
																													return true;
																													$this->spawnGhast($pos);
																													return true;
																													$this->spawnBat($pos);
																													return true;
																													$this->spawnSilverfish($pos);
																													return true;
																													$this->spawnCow($pos);
																													return true;
																													$this->spawnPig($pos);
																													return true;
																													$this->spawnSheep($pos);
																													return true;
																													$this->spawnChicken($pos);
																													return true;
																													$this->spawnRabbit($pos);
																													return true;
																													$this->spawnMooshroom($pos);
																													return true;
																													$this->spawnOcelot($pos);
																													return true;
																													$this->spawnSquid($pos);
																													return true;
																													$this->spawnWolf($pos);
																													return true;
																													$this->spawnVillager($pos);
																													return true;
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
				$this->spawnIronGolem($pos);
				return true;
			}
		}

	private function tryGenerateWaterMobNear($player = null, $level = null) {
			/* decompiled (structured CF) */
			$x = (floor(($player->x + mt_rand(($this->birth_r * -1), $this->birth_r))));
			$z = (floor(($player->z + mt_rand(($this->birth_r * -1), $this->birth_r))));
			$y = 62;
			while ((46 <= $y)) {
				new \pocketmine\math\Vector3($x, $y, $z);
				$v = new \pocketmine\math\Vector3($x, $y, $z);
				if (($this->whatBlock($level, $v) === 'water')) {
					new \pocketmine\level\Position($x, $y, $z, $level);
					$pos = new \pocketmine\level\Position($x, $y, $z, $level);
					$entityId = \pocketmine\entity\NaturalMobSpawnRules::selectWaterEntityIdForPosition($level, $pos);
					return $this->generateNaturalEntity($entityId, $pos);
				}
				$y--;
			}
			return false;
		}

	private function tryGenerateAirMobNear($player = null, $level = null) {
			/* decompiled (structured CF) */
			$x = (floor(($player->getX() + mt_rand(($this->birth_r * -1), $this->birth_r))));
			$z = (floor(($player->getZ() + mt_rand(($this->birth_r * -1), $this->birth_r))));
			$baseY = (floor($player->getY()));
			$y = ($baseY - 8);
			while (($y <= $t50)) {
				new \pocketmine\math\Vector3($x, $y, $z);
				if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, $y, $z)) !== 'air')) {
				} else {
					new \pocketmine\math\Vector3($x, ($y + 1), $z);
					if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y + 1), $z)) !== 'air')) {
					} else {
						new \pocketmine\level\Position(($x + 0.5), $y, ($z + 0.5), $level);
						$pos = new \pocketmine\level\Position(($x + 0.5), $y, ($z + 0.5), $level);
						$entityId = \pocketmine\entity\NaturalMobSpawnRules::selectAirEntityId($level, $pos);
						return $this->generateNaturalEntity($entityId, $pos);
					}
				}
				$y++;
			}
			return false;
		}

	private function tryGenerateCaveMobNear($player = null, $level = null) {
			/* decompiled (structured CF) */
			$x = (floor(($player->getX() + mt_rand(($this->birth_r * -1), $this->birth_r))));
			$z = (floor(($player->getZ() + mt_rand(($this->birth_r * -1), $this->birth_r))));
			$baseY = min((floor($player->getY())), 62);
			$y = max(1, ($baseY - 20));
			while (($y <= min(62, $t47))) {
				new \pocketmine\math\Vector3($x, $y, $z);
				if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, $y, $z)) !== 'air')) {
				} else {
					new \pocketmine\level\Position(($x + 0.5), $y, ($z + 0.5), $level);
					$pos = new \pocketmine\level\Position(($x + 0.5), $y, ($z + 0.5), $level);
					$entityId = \pocketmine\entity\NaturalMobSpawnRules::selectCaveEntityId($level, $pos);
					return $this->generateNaturalEntity($entityId, $pos);
				}
				$y++;
			}
			return false;
		}

	private function tryGenerateLandMobNear($player = null, $level = null) {
			/* decompiled (structured CF) */
			$x = (floor(($player->getX() + mt_rand(($this->birth_r * -1), $this->birth_r))));
			$z = (floor(($player->getZ() + mt_rand(($this->birth_r * -1), $this->birth_r))));
			$baseY = (floor($player->getY()));
			$y = ($baseY - 15);
			while (($y <= $t59)) {
				new \pocketmine\math\Vector3($x, $y, $z);
				if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, $y, $z)) !== 'block')) {
				} else {
					new \pocketmine\math\Vector3($x, ($y + 1), $z);
					if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y + 1), $z)) !== 'air')) {
					} else {
						new \pocketmine\math\Vector3($x, ($y + 2), $z);
						if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y + 2), $z)) !== 'air')) {
						} else {
							new \pocketmine\level\Position(($x + 0.5), ($y + 1), ($z + 0.5), $level);
							$pos = new \pocketmine\level\Position(($x + 0.5), ($y + 1), ($z + 0.5), $level);
							$inVillage = $this->isInGeneratedVillage($level, $pos);
							$entityIds = \pocketmine\entity\NaturalMobSpawnRules::selectLandEntityGroupIds($level, $pos, $inVillage);
							return $this->generateNaturalEntityGroup($entityIds, $pos, $inVillage);
						}
					}
				}
				$y++;
			}
			return false;
		}

	public function willMove($entity = null) {
			/* decompiled (structured CF) */
			foreach ($entity->getViewers() as $viewer) {
				if (($entity->distance($viewer->getLocation()) <= 32)) {
					return true;
				}
				/* goto */
			}
			return false;
		}

	private function getTrackedEntityArrayName($entity = null) {
			/* decompiled (structured CF) */
			if ($entity instanceof \pocketmine\entity\ZombieVillager) {
				return 'ZombieVillager';
			}
			if ($entity instanceof \pocketmine\entity\Zombie) {
				return 'Zombie';
			}
			if ($entity instanceof \pocketmine\entity\PigZombie) {
				return 'PigZombie';
			}
			if ($entity instanceof \pocketmine\entity\Creeper) {
				return 'Creeper';
			}
			if ($entity instanceof \pocketmine\entity\Skeleton) {
				return 'Skeleton';
			}
			if ($entity instanceof \pocketmine\entity\Cow) {
				return 'Cow';
			}
			if ($entity instanceof \pocketmine\entity\Squid) {
				return 'Squid';
			}
			if ($entity instanceof \pocketmine\entity\Pig) {
				return 'Pig';
			}
			if ($entity instanceof \pocketmine\entity\Sheep) {
				return 'Sheep';
			}
			if ($entity instanceof \pocketmine\entity\Chicken) {
				return 'Chicken';
			}
			if ($entity instanceof \pocketmine\entity\CaveSpider) {
				return 'CaveSpider';
			}
			if ($entity instanceof \pocketmine\entity\Spider) {
				return 'Spider';
			}
			if ($entity instanceof \pocketmine\entity\Slime) {
				return 'Slime';
			}
			if ($entity instanceof \pocketmine\entity\Enderman) {
				return 'Enderman';
			}
			if ($entity instanceof \pocketmine\entity\Witch) {
				return 'Witch';
			}
			if ($entity instanceof \pocketmine\entity\Ghast) {
				return 'Ghast';
			}
			if ($entity instanceof \pocketmine\entity\Bat) {
				return 'Bat';
			}
			if ($entity instanceof \pocketmine\entity\Silverfish) {
				return 'Silverfish';
			}
			if ($entity instanceof \pocketmine\entity\Ocelot) {
				return 'Ocelot';
			}
			if ($entity instanceof \pocketmine\entity\Mooshroom) {
				return 'Mooshroom';
			}
			if ($entity instanceof \pocketmine\entity\Rabbit) {
				return 'Rabbit';
			}
			if ($entity instanceof \pocketmine\entity\Wolf) {
				return 'Wolf';
			}
			if ($entity instanceof \pocketmine\entity\Villager) {
				return 'Villager';
			}
			if ($entity instanceof \pocketmine\entity\IronGolem) {
				return 'IronGolem';
			}
			if ($entity instanceof \pocketmine\entity\Blaze) {
				return 'Blaze';
			}
			if ($entity instanceof \pocketmine\entity\LavaSlime) {
				return 'LavaSlime';
			}
			return '';
		}

	private function getTrackedEntityArrayNames() {
			return ['__array_ptr' => '2aaaadcd9f88'];
		}

	public function RotationTimer() {
			/* decompiled (structured CF) */
			foreach ($this->getServer()->getLevels() as $level) {
				foreach ($level->getEntities() as $entity) {
					if (($entity instanceof \pocketmine\entity\Mob && $entity->usesPm1eGroundAi())) {
						/* goto */
					}
					$arrayName = $this->getTrackedEntityArrayName($entity);
					if (($arrayName !== '')) {
						if ((count($entity->getViewers()) != 0)) {
							if (isset($array[$entity->getId()])) {
								$yaw0 = $entity->yaw;
								$yaw = $array[$entity->getId()]['yaw'];
								if ((abs(($yaw0 - $yaw)) <= 180)) {
									if (($yaw0 <= $yaw)) {
										if ((($yaw - $yaw0) <= 15)) {
											$yaw0 = $yaw;
										} else {
											$yaw0 += 15;
										}
									} else {
										if ((($yaw0 - $yaw) <= 15)) {
											$yaw0 = $yaw;
										} else {
											$yaw0 -= 15;
										}
									}
								} else {
									if (($yaw <= $yaw0)) {
										if ((((180 - $yaw0) + ($yaw + 180)) <= 15)) {
											$yaw0 = $yaw;
										} else {
											$yaw0 += 15;
											if ((180 <= $yaw0)) {
												$yaw0 = ($yaw0 - 360);
											}
										}
									} else {
										if ((((180 - $yaw) - ($yaw0 + 180)) <= 15)) {
											$yaw0 = $yaw;
										} else {
											$yaw0 -= 15;
											if (($yaw0 <= 180)) {
												$yaw0 = ($yaw0 + 360);
											}
										}
									}
								}
								$pitch0 = $entity->pitch;
								$pitch = $array[$entity->getId()]['pitch'];
								if ((abs(($pitch0 - $pitch)) <= 15)) {
									$pitch0 = $pitch;
								} else {
									if (($pitch0 < $pitch)) {
										$pitch0 += 10;
									} else {
										if (($pitch < $pitch0)) {
											$pitch0 -= 10;
										}
									}
								}
								$entity->setRotation($yaw0, $pitch0);
							}
						}
					}
					/* goto */
				}
				/* goto */
			}
			return null;
		}

	public function getyaw($mx = null, $mz = null) {
			/* decompiled (structured CF) */
			if (($mz == 0)) {
				if (($mx < 0)) {
					$yaw = -90;
				} else {
					$yaw = 90;
				}
			} else {
				if (((0 <= $mx) && (0 < $mz))) {
					$atan = atan(($mx / $mz));
					$yaw = rad2deg($atan);
				} else {
					if (((0 <= $mx) && ($mz < 0))) {
						$atan = atan(($mx / abs($mz)));
						$yaw = (180 - rad2deg($atan));
					} else {
						if ((($mx < 0) && ($mz < 0))) {
							$atan = atan(($mx / $mz));
							$yaw = ((180 - rad2deg($atan)) * -1);
						} else {
							if ((($mx < 0) && (0 < $mz))) {
								$atan = atan((abs($mx) / $mz));
								$yaw = (rad2deg($atan) * -1);
							} else {
								$yaw = 0;
							}
						}
					}
				}
			}
			$yaw = ($yaw * -1);
			return $yaw;
		}

	public function getpitch($from = null, $to = null) {
			/* decompiled (structured CF) */
			$distance = $from->distance($to);
			$height = ($to->y - $from->y);
			if ((0 < $height)) {
				return (rad2deg(asin(($height / $distance))) * -1);
			} else {
				if (($height < 0)) {
					return rad2deg(asin((($height * -1) / $distance)));
				} else {
					return 0;
				}
			}
		}

	public function ifjump($level = null, $v3 = null, $hate = null, $reason = null) {
			/* decompiled (structured CF) */
			$x = floor($v3->getX());
			$y = floor($v3->getY());
			$z = floor($v3->getZ());
			new \pocketmine\math\Vector3($x, $y, $z);
			if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, $y, $z)) == 'air')) {
				new \pocketmine\math\Vector3($x, ($y - 1), $z);
				new \pocketmine\math\Vector3($x, ($y - 1), $z);
				if ((($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y - 1), $z)) == 'block') || (new \pocketmine\math\Vector3($x, ($y - 1), $z) == 'climb'))) {
					new \pocketmine\math\Vector3($x, ($y + 1), $z);
					new \pocketmine\math\Vector3($x, ($y + 1), $z);
					new \pocketmine\math\Vector3($x, ($y + 1), $z);
					if (((($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y + 1), $z)) == 'block') || ($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y + 1), $z)) == 'half')) || ($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y + 1), $z)) == 'high'))) {
						if ($reason) {
							return 'up!';
						}
						return false;
					} else {
						if ($reason) {
							return 'GO';
						}
						return $y;
					}
				} else {
					new \pocketmine\math\Vector3($x, ($y - 1), $z);
					if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y - 1), $z)) == 'water')) {
						if ($reason) {
							return 'swim';
						}
						return ($y - 1);
					} else {
						new \pocketmine\math\Vector3($x, ($y - 1), $z);
						if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y - 1), $z)) == 'half')) {
							if ($reason) {
								return 'half';
							}
							return ($y - 0.5);
						} else {
							new \pocketmine\math\Vector3($x, ($y - 1), $z);
							if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y - 1), $z)) == 'lava')) {
								if ($reason) {
									return 'lava';
								}
								return false;
							} else {
								new \pocketmine\math\Vector3($x, ($y - 1), $z);
								if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y - 1), $z)) == 'air')) {
									new \pocketmine\math\Vector3($x, ($y - 2), $z);
									if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y - 2), $z)) == 'block')) {
										if ($reason) {
											return 'down';
										}
										return ($y - 1);
									} else {
										if ($reason) {
											return 'fall';
										}
										if (($hate === false)) {
											return false;
										} else {
											return ($y - 1);
										}
									}
								}
							}
						}
					}
				}
			} else {
				new \pocketmine\math\Vector3($x, $y, $z);
				if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, $y, $z)) == 'water')) {
					new \pocketmine\math\Vector3($x, ($y + 1), $z);
					if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y + 1), $z)) == 'water')) {
						if ($reason) {
							return 'inwater';
						}
						return ($y + 1);
					} else {
						new \pocketmine\math\Vector3($x, ($y + 1), $z);
						new \pocketmine\math\Vector3($x, ($y + 1), $z);
						if ((($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y + 1), $z)) == 'block') || ($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y + 1), $z)) == 'half'))) {
							new \pocketmine\math\Vector3($x, ($y - 1), $z);
							new \pocketmine\math\Vector3($x, ($y - 1), $z);
							if ((($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y - 1), $z)) == 'block') || ($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y - 1), $z)) == 'half'))) {
								if ($reason) {
									return 'up!_down!';
								}
								return false;
							} else {
								if ($reason) {
									return 'up!';
								}
								return ($y - 1);
							}
						} else {
							return $y;
						}
					}
				} else {
					new \pocketmine\math\Vector3($x, $y, $z);
					if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, $y, $z)) == 'half')) {
						new \pocketmine\math\Vector3($x, ($y + 1), $z);
						new \pocketmine\math\Vector3($x, ($y + 1), $z);
						new \pocketmine\math\Vector3($x, ($y + 1), $z);
						if (((($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y + 1), $z)) == 'block') || ($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y + 1), $z)) == 'half')) || ($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y + 1), $z)) == 'high'))) {
						} else {
							if ($reason) {
								return 'halfGO';
							}
							return ($y + 0.5);
						}
					} else {
						new \pocketmine\math\Vector3($x, $y, $z);
						if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, $y, $z)) == 'lava')) {
							if ($reason) {
								return 'lava';
							}
							return false;
						} else {
							new \pocketmine\math\Vector3($x, $y, $z);
							if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, $y, $z)) == 'high')) {
								if ($reason) {
									return 'high';
								}
								return false;
							} else {
								new \pocketmine\math\Vector3($x, $y, $z);
								if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, $y, $z)) == 'climb')) {
									if ($reason) {
										return 'climb';
									}
									if ($hate) {
										return ($y + 0.7);
									} else {
										return ($y + 0.5);
									}
								} else {
									new \pocketmine\math\Vector3($x, ($y + 1), $z);
									if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y + 1), $z)) != 'air')) {
										if ($reason) {
											return 'wall';
										}
										return false;
									} else {
										new \pocketmine\math\Vector3($x, ($y + 2), $z);
										new \pocketmine\math\Vector3($x, ($y + 2), $z);
										new \pocketmine\math\Vector3($x, ($y + 2), $z);
										if (((($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y + 2), $z)) == 'block') || ($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y + 2), $z)) == 'half')) || ($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y + 2), $z)) == 'high'))) {
											if ($reason) {
												return 'up2!';
											}
											return false;
										} else {
											if ($reason) {
												return 'upGO';
											}
											return ($y + 1);
										}
									}
								}
							}
						}
					}
				}
			}
			return false;
		}

	public function whatBlock($level = null, $v3 = null) {
			/* decompiled (structured CF) */
			$block = $level->getBlock($v3);
			$id = $block->getID();
			$damage = $block->getDamage();
			if (!(($id == 0))) {
				if (!(($id == 6))) {
					if (!(($id == 27))) {
						if (!(($id == 30))) {
							if (!(($id == 31))) {
								if (!(($id == 37))) {
									if (!(($id == 38))) {
										if (!(($id == 39))) {
											if (!(($id == 40))) {
												if (!(($id == 50))) {
													if (!(($id == 51))) {
														if (!(($id == 63))) {
															if (!(($id == 66))) {
																if (!(($id == 68))) {
																	if (!(($id == 78))) {
																		if (!(($id == 111))) {
																			if (!(($id == 141))) {
																				if (!(($id == 142))) {
																					if (!(($id == 171))) {
																						if (!(($id == 175))) {
																							if (!(($id == 244))) {
																								if (!(($id == 323))) {
																									if (!(($id == 8))) {
																										if (!(($id == 9))) {
																											if (!(($id == 10))) {
																												if (!(($id == 11))) {
																													if (!(($id == 44))) {
																														if (!(($id == 158))) {
																															if (!(($id == 64))) {
																																if (!(($id == 85))) {
																																	if (!(($id == 107))) {
																																		if (!(($id == 113))) {
																																			if (!(($id == 139))) {
																																				if (!(($id == 183))) {
																																					if (!(($id == 184))) {
																																						if (!(($id == 185))) {
																																							if (!(($id == 186))) {
																																								if (!(($id == 187))) {
																																									if (!(($id == 65))) {
																																										if (!(($id == 106))) {
																																											/* jump */
																																											return 'air';
																																										} else {
																																											/* jump */
																																											return 'lava';
																																											/* jump */
																																											if ((8 <= $damage)) {
																																												return 'block';
																																											} else {
																																												return 'half';
																																											}
																																											/* jump */
																																											if ((($damage & 8) === 8)) {
																																												return 'air';
																																											} else {
																																												return 'block';
																																											}
																																											/* jump */
																																											return 'high';
																																											/* jump */
																																											return 'climb';
																																											/* jump */
																																											/* jump */
																																										}
																																									}
																																								}
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

	public function MobDeath($event = null) {
			/* decompiled (structured CF) */
			$entity = $event->getEntity();
			$arrayName = $this->getTrackedEntityArrayName($entity);
			if (($arrayName === '')) {
				return null;
			}
			$eid = $entity->getID();
			if ($entity instanceof \pocketmine\entity\Creeper) {
				$eid = $entity->getID();
				if (isset($this->Creeper[$eid])) {
					if ($this->Creeper[$eid]['boomed']) {
						$event->setDrops(['__array_ptr' => '2aaaac9fc9a0']);
					}
				}
			}
			if (isset($this->{$arrayName}[$eid])) {
			}
		}

	public function MobGenerate() {
			/* decompiled (structured CF) */
			foreach ($this->getServer()->getOnlinePlayers() as $p) {
				$level = $p->getLevel();
				if (!($this->isNaturalSpawnLevel($level))) {
					/* goto */
				}
				if ($this->getServer()->isWorldNaturalMobSpawnDisabled($level)) {
					/* goto */
				}
				$attempts = self::getNaturalSpawnAttempts($this->getServer()->getDifficulty());
				$i = 0;
				while (($i < $attempts)) {
					if (($level->getDimension() === \pocketmine\level\Level::DIMENSION_NORMAL)) {
						$this->tryGenerateWaterMobNear($p, $level);
						$this->tryGenerateCaveMobNear($p, $level);
					} else {
						if (($level->getDimension() === \pocketmine\level\Level::DIMENSION_NETHER)) {
							$this->tryGenerateAirMobNear($p, $level);
						}
					}
					$this->tryGenerateLandMobNear($p, $level);
					$i++;
				}
				/* goto */
			}
			return null;
		}

	public function EntityDamage($event = null) {
			/* decompiled (structured CF) */
			$this->handleSkeletonArrowRetaliation($event);
			$this->handleSkeletonHostileRetaliation($event);
			$this->handlePlayerGuardianRetaliation($event);
			$this->handleTamedWolfOwnerCombat($event);
			if ($event instanceof \pocketmine\event\entity\EntityDamageByEntityEvent) {
				$p = $event->getDamager();
				$entity = $event->getEntity();
				$arrayName = $this->getTrackedEntityArrayName($entity);
				if (($arrayName !== '')) {
				} else {
					$array = ['__array_ptr' => '2aaaac9fc9a0'];
				}
				if (isset($array[$entity->getId()])) {
					if (($p instanceof \pocketmine\Player && ($array[$entity->getId()]['canAttack'] == 0))) {
						$weapon = $p->getInventory()->getItemInHand()->getID();
						if (((($weapon == 258) || ($weapon == 271)) || ($weapon == 275))) {
							$back = 1.5;
						} else {
							if (((((($weapon == 267) || ($weapon == 272)) || ($weapon == 279)) || ($weapon == 283)) || ($weapon == 286))) {
								$back = 3;
							} else {
								if (($weapon == 276)) {
									$back = 4;
								} else {
									if (($weapon == 292)) {
										$back = 8;
										$high = 3;
									} else {
										$back = 1;
									}
								}
							}
						}
						$array[$entity->getId()]['x'] = ($array[$entity->getId()]['x'] - ($back * $array[$entity->getId()]['xxx']));
						$array[$entity->getId()]['y'] = ($entity->getY() + $high);
						$array[$entity->getId()]['z'] = ($array[$entity->getId()]['z'] - ($back * $array[$entity->getId()]['zzz']));
						new \pocketmine\math\Vector3($array[$entity->getId()]['x'], $array[$entity->getId()]['y'], $array[$entity->getId()]['z']);
						$pos = new \pocketmine\math\Vector3($array[$entity->getId()]['x'], $array[$entity->getId()]['y'], $array[$entity->getId()]['z']);
						$entity->knockBack($entity, 0, ($back * $array[$entity->getId()]['xxx']), ($back * $array[$entity->getId()]['zzz']));
						if (isset($array[$entity->getId()])) {
							$zom['IsChasing'] = $p->getName();
						}
					}
				}
			}
			return null;
		}

	private function handlePlayerGuardianRetaliation($event = null) {
			/* decompiled (structured CF) */
			if ((!($event instanceof \pocketmine\event\entity\EntityDamageByEntityEvent) || $event instanceof \pocketmine\event\entity\EntityDamageByChildEntityEvent)) {
				return null;
			}
			if (($event->getCause() !== \pocketmine\event\entity\EntityDamageEvent::CAUSE_ENTITY_ATTACK)) {
			}
			$player = $event->getDamager();
			if (!($player instanceof \pocketmine\Player)) {
			}
			$target = $event->getEntity();
			if ($target instanceof \pocketmine\entity\IronGolem) {
				if ((((!($target->closed) && $target->isAlive()) && !($player->closed)) && $player->isAlive())) {
					$target->setPm1eRetaliationTarget($player);
				}
			}
			if ($target instanceof \pocketmine\entity\Wolf) {
				$this->retaliateForAttackedWolf($target, $player);
			}
			if ($target instanceof \pocketmine\entity\Villager) {
				$this->retaliateForAttackedVillager($target, $player);
			}
		}

	private function handleTamedWolfOwnerCombat($event = null) {
			/* decompiled (structured CF) */
			if ($event->isCancelled()) {
				return null;
			}
			if (!($event instanceof \pocketmine\event\entity\EntityDamageByEntityEvent)) {
			}
			$isDirectAttack = (!($event instanceof \pocketmine\event\entity\EntityDamageByChildEntityEvent) && ($event->getCause() === \pocketmine\event\entity\EntityDamageEvent::CAUSE_ENTITY_ATTACK));
			$isProjectile = ($event instanceof \pocketmine\event\entity\EntityDamageByChildEntityEvent && ($event->getCause() === \pocketmine\event\entity\EntityDamageEvent::CAUSE_PROJECTILE));
			if ((!($isDirectAttack) && !($isProjectile))) {
			}
			$attacker = $event->getDamager();
			$target = $event->getEntity();
			if (($attacker instanceof \pocketmine\Player && $target instanceof \pocketmine\entity\Entity)) {
				$this->commandTamedWolves($attacker, $target);
			}
			$victim = $target;
			if (($victim instanceof \pocketmine\Player && $attacker instanceof \pocketmine\entity\Entity)) {
				$this->commandTamedWolves($victim, $attacker);
			}
		}

	private function commandTamedWolves($owner = null, $target = null) {
			/* decompiled (structured CF) */
			if ((((($owner->closed || !($owner->isAlive())) || ($target === $owner)) || $target->closed) || !($target->isAlive()))) {
				return null;
			}
			$level = $owner->getLevel();
			if (($level === null)) {
			}
			foreach ($level->getEntities() as $entity) {
				if (((!($entity instanceof \pocketmine\entity\Wolf) || $entity->closed) || !($entity->isAlive()))) {
					/* goto */
				}
				if (((!($entity->isTamed()) || !($entity->isOwner($owner))) || $entity->isSitting())) {
					/* goto */
				}
				if (($entity === $target)) {
					/* goto */
				}
				if (($target instanceof \pocketmine\entity\Wolf && $target->isOwner($owner))) {
					/* goto */
				}
				$entity->setPm1eRetaliationTarget($target);
				$entity->setAngry(true);
				/* goto */
			}
		}

	private function retaliateForAttackedWolf($wolf = null, $player = null) {
			/* decompiled (structured CF) */
			if (((($wolf->closed || !($wolf->isAlive())) || $player->closed) || !($player->isAlive()))) {
				return null;
			}
			if ($wolf->isTamed()) {
				if ((!($wolf->isOwner($player)) && !($wolf->isSitting()))) {
					$wolf->setPm1eRetaliationTarget($player);
					$wolf->setAngry(true);
				}
			}
			$level = $wolf->getLevel();
			if (($level === null)) {
			}
			foreach ($level->getEntities() as $entity) {
				if (((!($entity instanceof \pocketmine\entity\Wolf) || $entity->closed) || !($entity->isAlive()))) {
					/* goto */
				}
				if ((1024 < $entity->distanceSquared($wolf))) {
					/* goto */
				}
				if ($entity->isTamed()) {
					/* goto */
				}
				$entity->setPm1eRetaliationTarget($player);
				/* goto */
			}
		}

	private function retaliateForAttackedVillager($villager = null, $player = null) {
			/* decompiled (structured CF) */
			if (((($villager->closed || !($villager->isAlive())) || $player->closed) || !($player->isAlive()))) {
				return null;
			}
			$level = $villager->getLevel();
			if (($level === null)) {
			}
			foreach ($level->getEntities() as $entity) {
				if (((!($entity instanceof \pocketmine\entity\IronGolem) || $entity->closed) || !($entity->isAlive()))) {
					/* goto */
				}
				if ((1024 < $entity->distanceSquared($villager))) {
					/* goto */
				}
				$entity->setPm1eRetaliationTarget($player);
				/* goto */
			}
		}

	private function handleSkeletonHostileRetaliation($event = null) {
			/* decompiled (structured CF) */
			if ((!($event instanceof \pocketmine\event\entity\EntityDamageByEntityEvent) || $event instanceof \pocketmine\event\entity\EntityDamageByChildEntityEvent)) {
				return null;
			}
			if (($event->getCause() !== \pocketmine\event\entity\EntityDamageEvent::CAUSE_ENTITY_ATTACK)) {
			}
			$target = $event->getEntity();
			$attacker = $event->getDamager();
			if ((!($target instanceof \pocketmine\entity\Skeleton) || ($target === $attacker))) {
			}
			if (!($this->isSkeletonArrowRetaliationTarget($attacker))) {
			}
			if (((($target->closed || !($target->isAlive())) || $attacker->closed) || !($attacker->isAlive()))) {
			}
			$target->setPm1eRetaliationTarget($attacker);
		}

	private function handleSkeletonArrowRetaliation($event = null) {
			/* decompiled (structured CF) */
			if (!($event instanceof \pocketmine\event\entity\EntityDamageByChildEntityEvent)) {
				return null;
			}
			if (($event->getCause() !== \pocketmine\event\entity\EntityDamageEvent::CAUSE_PROJECTILE)) {
			}
			$shooter = $event->getDamager();
			$projectile = $event->getChild();
			$target = $event->getEntity();
			if (((!($shooter instanceof \pocketmine\entity\Skeleton) || !($projectile instanceof \pocketmine\entity\Arrow)) || ($target === $shooter))) {
			}
			if (!($this->isSkeletonArrowRetaliationTarget($target))) {
			}
			if (((($shooter->closed || !($shooter->isAlive())) || $target->closed) || !($target->isAlive()))) {
			}
			if ($target instanceof \pocketmine\entity\FlyingAnimal) {
				$target->setPm1eFlyFollowTarget($shooter);
			} else {
				$target->setPm1eRetaliationTarget($shooter);
			}
		}

	private function isSkeletonArrowRetaliationTarget($target = null) {
			return (((($target instanceof \pocketmine\entity\Monster || $target instanceof \pocketmine\entity\Slime) || $target instanceof \pocketmine\entity\LavaSlime) || $target instanceof \pocketmine\entity\Blaze) || $target instanceof \pocketmine\entity\Ghast);
		}

	public function knockBackover($entity = null, $v3 = null) {
			/* decompiled (structured CF) */
			if ($entity instanceof \pocketmine\entity\Entity) {
				foreach ($this->getTrackedEntityArrayNames() as $arrayName) {
					if (isset($this->{$arrayName}[$entity->getId()])) {
						$entity->setPosition($v3);
						$this->{$arrayName}[$entity->getId()]['knockBack'] = false;
					}
					/* goto */
				}
				if (isset($this->Defult[$entity->getId()])) {
					$entity->setPosition($v3);
					$this->Defult[$entity->getId()]['knockBack'] = false;
				}
			}
			return null;
		}

}
