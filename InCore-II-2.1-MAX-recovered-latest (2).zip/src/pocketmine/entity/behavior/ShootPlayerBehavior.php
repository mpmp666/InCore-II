<?php

namespace pocketmine\entity\behavior;

class ShootPlayerBehavior extends \pocketmine\entity\behavior\Behavior {
	public $speed = NULL;
	public $speedMultiplier = NULL;
	public $lookDistance = 16.0;
	public $NetworkID = NULL;
	public $player = NULL;
	public $timeLeft = 0;

	public function __construct($entity = null, $NetWorkID = null, $speed = null, $speedMultiplier = null) {
			/* decompiled (structured CF) */
			parent::__construct($entity);
			$this->speed = $speed;
			$this->speedMultiplier = $speedMultiplier;
			$this->NetworkID = $NetWorkID;
			return;
		}

	public function getName() {
			return "\xe6\x8a\x95\xe6\x8e\xb7\xe7\xb1\xbb\xe6\x95\x8c\xe5\xaf\xb9\xe5\xae\x9e\xe4\xbd\x93\xe6\x94\xbb\xe5\x87\xbb";
		}

	public function shouldStart() {
			/* decompiled (structured CF) */
			if ($this->canUseCurrentTarget()) {
				return true;
			}
			$players = $this->entity->level->getPlayers();
			$find = false;
			$MinDistance = 9999;
			foreach ($players as $p) {
				if (($this->entity->distance($p) < $this->lookDistance)) {
					if (($this->entity->distance($p) < $MinDistance)) {
						if ($p->isSurvival()) {
							$this->player = $p;
							$MinDistance = $this->entity->distance($p);
							$find = true;
						}
					}
				}
				/* goto */
			}
			return $find;
		}

	private function canUseCurrentTarget() {
			/* decompiled (structured CF) */
			if ((!($this->player instanceof \pocketmine\entity\Entity) || !($this->player->isAlive()))) {
				return false;
			}
			if (($this->player instanceof \pocketmine\Player && !($this->player->isConnected()))) {
				return false;
			}
			if ($this->player->closed) {
				return false;
			}
			return ($this->entity->distance($this->player) < $this->lookDistance);
		}

	public function canContinue() {
			return $this->canUseCurrentTarget();
		}

	public function onTick() {
			/* decompiled (structured CF) */
			$distance = $this->entity->distance($this->player);
			$entity = $this->entity;
			if ((5 <= $this->timeLeft)) {
				$entity->setPm1eFollowTarget($this->player);
				if (($distance < 4)) {
				} else {
				}
				$entity->setPm1eMoveMultiplier($this->speedMultiplier);
				$entity->setPm1eStayTime(0);
				if ((0 < $this->timeLeft)) {
				}
			} else {
				if (($distance <= 10)) {
					$this->bowAimPitch($this->player, $this->entity);
					$this->entity->level->addEntityMovement($this->entity->chunk->getX(), $this->entity->chunk->getZ(), $this->entity->getID(), $this->entity->x, ($this->entity->y + $this->entity->getEyeHeight()), $this->entity->z, $this->entity->yaw, $this->entity->pitch, $this->entity->yaw);
					if (($this->timeLeft <= 0)) {
						if (($this->NetworkID == 86)) {
							if ((8 <= $distance)) {
								$Damage = 17;
							} else {
								if ((8 <= $this->player->getHealth())) {
									$Damage = 25;
								} else {
									if (($distance <= 3)) {
										$Damage = 34;
									} else {
										$Damage = 23;
									}
								}
							}
							$pitch = $entity->pitch;
							new \pocketmine\nbt\tag\DoubleTag('', $entity->x);
							new \pocketmine\nbt\tag\DoubleTag('', ($entity->y + 1.62));
							new \pocketmine\nbt\tag\DoubleTag('', $entity->z);
							new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $entity->x), new \pocketmine\nbt\tag\DoubleTag('', ($entity->y + 1.62)), new \pocketmine\nbt\tag\DoubleTag('', $entity->z)]);
							new \pocketmine\nbt\tag\DoubleTag('', (cos((($pitch / 180) * \M_PI)) * (sin((($entity->yaw / 180) * \M_PI)) * -1)));
							new \pocketmine\nbt\tag\DoubleTag('', (sin((($pitch / 180) * \M_PI)) * -1));
							new \pocketmine\nbt\tag\DoubleTag('', (cos((($entity->yaw / 180) * \M_PI)) * cos((($pitch / 180) * \M_PI))));
							new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', (cos((($pitch / 180) * \M_PI)) * (sin((($entity->yaw / 180) * \M_PI)) * -1))), new \pocketmine\nbt\tag\DoubleTag('', (sin((($pitch / 180) * \M_PI)) * -1)), new \pocketmine\nbt\tag\DoubleTag('', (cos((($entity->yaw / 180) * \M_PI)) * cos((($pitch / 180) * \M_PI))))]);
							new \pocketmine\nbt\tag\FloatTag('', $entity->yaw);
							new \pocketmine\nbt\tag\FloatTag('', $pitch);
							new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $entity->yaw), new \pocketmine\nbt\tag\FloatTag('', $pitch)]);
							new \pocketmine\nbt\tag\ShortTag('PotionId', $Damage);
							new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $entity->x), new \pocketmine\nbt\tag\DoubleTag('', ($entity->y + 1.62)), new \pocketmine\nbt\tag\DoubleTag('', $entity->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', (cos((($pitch / 180) * \M_PI)) * (sin((($entity->yaw / 180) * \M_PI)) * -1))), new \pocketmine\nbt\tag\DoubleTag('', (sin((($pitch / 180) * \M_PI)) * -1)), new \pocketmine\nbt\tag\DoubleTag('', (cos((($entity->yaw / 180) * \M_PI)) * cos((($pitch / 180) * \M_PI))))]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $entity->yaw), new \pocketmine\nbt\tag\FloatTag('', $pitch)]), new \pocketmine\nbt\tag\ShortTag('PotionId', $Damage)]);
							$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $entity->x), new \pocketmine\nbt\tag\DoubleTag('', ($entity->y + 1.62)), new \pocketmine\nbt\tag\DoubleTag('', $entity->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', (cos((($pitch / 180) * \M_PI)) * (sin((($entity->yaw / 180) * \M_PI)) * -1))), new \pocketmine\nbt\tag\DoubleTag('', (sin((($pitch / 180) * \M_PI)) * -1)), new \pocketmine\nbt\tag\DoubleTag('', (cos((($entity->yaw / 180) * \M_PI)) * cos((($pitch / 180) * \M_PI))))]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $entity->yaw), new \pocketmine\nbt\tag\FloatTag('', $pitch)]), new \pocketmine\nbt\tag\ShortTag('PotionId', $Damage)]);
							$f = 1.1;
							new \pocketmine\entity\ThrownPotion($entity->chunk, $nbt, $entity);
							$thrownPotion = new \pocketmine\entity\ThrownPotion($entity->chunk, $nbt, $entity);
							$thrownPotion->setMotion($thrownPotion->getMotion()->multiply($f));
							$thrownPotion->spawnToAll();
							$this->timeLeft = 40;
						} else {
							if (($this->NetworkID == 80)) {
								$pitch = $this->bowAimPitch($this->player, $this->entity, 0.04);
								new \pocketmine\nbt\tag\DoubleTag('', $entity->x);
								new \pocketmine\nbt\tag\DoubleTag('', ($entity->y + 1.62));
								new \pocketmine\nbt\tag\DoubleTag('', $entity->z);
								new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $entity->x), new \pocketmine\nbt\tag\DoubleTag('', ($entity->y + 1.62)), new \pocketmine\nbt\tag\DoubleTag('', $entity->z)]);
								new \pocketmine\nbt\tag\DoubleTag('', (cos((($pitch / 180) * \M_PI)) * (sin((($entity->yaw / 180) * \M_PI)) * -1)));
								new \pocketmine\nbt\tag\DoubleTag('', (sin((($pitch / 180) * \M_PI)) * -1));
								new \pocketmine\nbt\tag\DoubleTag('', (cos((($entity->yaw / 180) * \M_PI)) * cos((($pitch / 180) * \M_PI))));
								new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', (cos((($pitch / 180) * \M_PI)) * (sin((($entity->yaw / 180) * \M_PI)) * -1))), new \pocketmine\nbt\tag\DoubleTag('', (sin((($pitch / 180) * \M_PI)) * -1)), new \pocketmine\nbt\tag\DoubleTag('', (cos((($entity->yaw / 180) * \M_PI)) * cos((($pitch / 180) * \M_PI))))]);
								new \pocketmine\nbt\tag\FloatTag('', $entity->yaw);
								new \pocketmine\nbt\tag\FloatTag('', $pitch);
								new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $entity->yaw), new \pocketmine\nbt\tag\FloatTag('', $pitch)]);
								if ($entity->isOnFire()) {
								} else {
								}
								new \pocketmine\nbt\tag\ShortTag('Fire', 0);
								new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $entity->x), new \pocketmine\nbt\tag\DoubleTag('', ($entity->y + 1.62)), new \pocketmine\nbt\tag\DoubleTag('', $entity->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', (cos((($pitch / 180) * \M_PI)) * (sin((($entity->yaw / 180) * \M_PI)) * -1))), new \pocketmine\nbt\tag\DoubleTag('', (sin((($pitch / 180) * \M_PI)) * -1)), new \pocketmine\nbt\tag\DoubleTag('', (cos((($entity->yaw / 180) * \M_PI)) * cos((($pitch / 180) * \M_PI))))]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $entity->yaw), new \pocketmine\nbt\tag\FloatTag('', $pitch)]), new \pocketmine\nbt\tag\ShortTag('Fire', 0)]);
								$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $entity->x), new \pocketmine\nbt\tag\DoubleTag('', ($entity->y + 1.62)), new \pocketmine\nbt\tag\DoubleTag('', $entity->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', (cos((($pitch / 180) * \M_PI)) * (sin((($entity->yaw / 180) * \M_PI)) * -1))), new \pocketmine\nbt\tag\DoubleTag('', (sin((($pitch / 180) * \M_PI)) * -1)), new \pocketmine\nbt\tag\DoubleTag('', (cos((($entity->yaw / 180) * \M_PI)) * cos((($pitch / 180) * \M_PI))))]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $entity->yaw), new \pocketmine\nbt\tag\FloatTag('', $pitch)]), new \pocketmine\nbt\tag\ShortTag('Fire', 0)]);
								$f = 1.1;
								new \pocketmine\entity\Arrow($entity->chunk, $nbt, $entity);
								$Arrow = new \pocketmine\entity\Arrow($entity->chunk, $nbt, $entity);
								if (method_exists($entity, 'getWeapon')) {
									$bow = $entity->getWeapon();
									$power = $bow->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_BOW_POWER);
									if ((0 < $power)) {
										$Arrow->setBaseDamage((($Arrow->getBaseDamage() + ($power * 0.5)) + 0.5));
									}
									$punch = $bow->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_BOW_KNOCKBACK);
									if ((0 < $punch)) {
										$Arrow->setKnockBack((0.4 + ($punch * 0.5)));
									}
									if ((0 < $bow->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_BOW_FLAME))) {
										$Arrow->setOnFire(100);
									}
								}
								$Arrow->setMotion($Arrow->getMotion()->multiply($f));
								$Arrow->spawnToAll();
								$this->timeLeft = 40;
							} else {
								$this->timeLeft = 40;
							}
						}
					} else {
					}
				}
			}
			$this->swimming();
			return null;
		}

	public function AimPlayer($palyer = null, $entity = null) {
			/* decompiled (structured CF) */
			$x = ($palyer->x - $entity->x);
			$y = ($palyer->y - $entity->y);
			$z = ($palyer->z - $entity->z);
			$a = ($palyer->x + 0.5);
			$b = $palyer->y;
			$c = ($palyer->z + 0.5);
			$len = sqrt(((($x * $x) + ($y * $y)) + ($z * $z)));
			$y = ($y / $len);
			$pitch = asin($y);
			$pitch = (($pitch * 180) / \M_PI);
			$pitch = ($pitch * -1);
			$entity->pitch = $pitch;
			return null;
		}

	public function onEnd() {
			$this->entity->setPm1eFollowTarget(null);
			$this->entity->setPm1eMoveMultiplier(1);
			return null;
		}

	public function bowAimPitch($palyer = null, $entity = null, $distance = null) {
			/* decompiled (structured CF) */
			$_0x2bf6x17f = 1;
			$x = ($palyer->x - $entity->x);
			$y = ($palyer->y - $entity->y);
			$z = ($palyer->z - $entity->z);
			$_0x2bf6x183 = sqrt((($x * $x) + ($z * $z)));
			$_0x2bf6x184 = $distance;
			$_0x2bf6x185 = (($_0x2bf6x17f * ($_0x2bf6x17f * ($_0x2bf6x17f * $_0x2bf6x17f))) - ($_0x2bf6x184 * (($_0x2bf6x184 * ($_0x2bf6x183 * $_0x2bf6x183)) + (($y * 2) * ($_0x2bf6x17f * $_0x2bf6x17f)))));
			$pitch = (atan(((($_0x2bf6x17f * $_0x2bf6x17f) - sqrt($_0x2bf6x185)) / ($_0x2bf6x184 * $_0x2bf6x183))) * ((180 / \M_PI) * -1));
			if (is_nan($pitch)) {
				$pitch = 0;
			}
			$entity->pitch = $pitch;
			return $pitch;
		}

}
