<?php

namespace pocketmine\entity\behavior;

class CreeperAI {
	private $AIHolder = NULL;
	private $dif = 0;
	private $bomb = 5;
	public $hatred_r = 5;
	public $zo_hate_v = 2;

	public function __construct($AIHolder = null) {
			/* decompiled (structured CF) */
			$this->AIHolder = $AIHolder;
			new \pocketmine\scheduler\CallbackTask([$this, 'CreeperRandomWalkCalc']);
			$this->AIHolder->getServer()->getScheduler()->scheduleRepeatingTask(new \pocketmine\scheduler\CallbackTask([$this, 'CreeperRandomWalkCalc']), 15);
			new \pocketmine\scheduler\CallbackTask([$this, 'CreeperRandomWalk']);
			$this->AIHolder->getServer()->getScheduler()->scheduleRepeatingTask(new \pocketmine\scheduler\CallbackTask([$this, 'CreeperRandomWalk']), 1);
			new \pocketmine\scheduler\CallbackTask([$this, 'CreeperHateWalk']);
			$this->AIHolder->getServer()->getScheduler()->scheduleRepeatingTask(new \pocketmine\scheduler\CallbackTask([$this, 'CreeperHateWalk']), 15);
			new \pocketmine\scheduler\CallbackTask([$this, 'CreeperHateFinder']);
			$this->AIHolder->getServer()->getScheduler()->scheduleRepeatingTask(new \pocketmine\scheduler\CallbackTask([$this, 'CreeperHateFinder']), 10);
			new \pocketmine\scheduler\CallbackTask([$this, 'array_clear']);
			$this->AIHolder->getServer()->getScheduler()->scheduleRepeatingTask(new \pocketmine\scheduler\CallbackTask([$this, 'array_clear']), 100);
			return;
		}

	public function array_clear() {
			/* decompiled (structured CF) */
			if ((count($this->AIHolder->Creeper) != 0)) {
				foreach ($this->AIHolder->Creeper as $eid => $info) {
					foreach ($this->AIHolder->getServer()->getLevels() as $level) {
						if (!($level->getEntity($eid) instanceof \pocketmine\entity\Entity)) {
						}
						/* goto */
					}
					/* goto */
				}
			}
			return null;
		}

	public function CreeperRandomWalkCalc() {
			/* decompiled (structured CF) */
			$this->dif = $this->AIHolder->getServer()->getDifficulty();
			foreach ($this->AIHolder->getServer()->getLevels() as $level) {
				foreach ($level->getEntities() as $zo) {
					if ($zo instanceof \pocketmine\entity\Creeper) {
						if ($this->AIHolder->willMove($zo)) {
							if (!(isset($this->AIHolder->Creeper[$zo->getId()]))) {
								$this->AIHolder->Creeper[$zo->getId()] = [$zo->getId(), false, 0, 0, 0, 10, 10, 0, 0, 0, $zo->getLocation(), 20, 0, $zo->yaw, 0, $zo->getLevel()->getName(), 0, 0, 10, 0, 0.01, true, false, 0, false, false, false];
								$zom['x'] = $zo->getX();
								$zom['y'] = $zo->getY();
								$zom['z'] = $zo->getZ();
							}
							if (!($zom['boom'])) {
								if (($zom['IsChasing'] === false)) {
									$newmx = (mt_rand(-5, 5) / 10);
									while ((0.6 <= abs($t64))) {
										$newmx = (mt_rand(-5, 5) / 10);
									}
									$zom['motionx'] = $newmx;
									$newmz = (mt_rand(-5, 5) / 10);
									while ((0.6 <= abs($t75))) {
										$newmz = (mt_rand(-5, 5) / 10);
									}
									$zom['motionz'] = $newmz;
									if (((20 <= $zom['gotimer']) && ($zom['gotimer'] <= 24))) {
										$zom['motionx'] = 0;
										$zom['motionz'] = 0;
									}
									$zom['gotimer'] += 0.5;
									if ((22 <= $zom['gotimer'])) {
										$zom['gotimer'] = 0;
									}
									$zom['yup'] = 0;
									$zom['up'] = 0;
									new \pocketmine\math\Vector3(($zom['x'] + $zom['motionx']), (floor($zo->getY()) + 1), ($zom['z'] + $zom['motionz']));
									$pos = new \pocketmine\math\Vector3(($zom['x'] + $zom['motionx']), (floor($zo->getY()) + 1), ($zom['z'] + $zom['motionz']));
									$zy = $this->AIHolder->ifjump($zo->getLevel(), $pos);
									if (($zy === false)) {
										new \pocketmine\math\Vector3($zom['x'], $zom['y'], $zom['z']);
										$pos2 = new \pocketmine\math\Vector3($zom['x'], $zom['y'], $zom['z']);
										if (($this->AIHolder->ifjump($zo->getLevel(), $pos2) === false)) {
											new \pocketmine\math\Vector3($zom['x'], ($zom['y'] - 1), $zom['z']);
											$pos2 = new \pocketmine\math\Vector3($zom['x'], ($zom['y'] - 1), $zom['z']);
											$zom['up'] = 1;
											$zom['yup'] = 0;
										} else {
											$zom['motionx'] = ($zom['motionx'] * -1);
											$zom['motionz'] = ($zom['motionz'] * -1);
											$zom['up'] = 0;
										}
									} else {
										new \pocketmine\math\Vector3(($zom['x'] + $zom['motionx']), ($zy - 1), ($zom['z'] + $zom['motionz']));
										$pos2 = new \pocketmine\math\Vector3(($zom['x'] + $zom['motionx']), ($zy - 1), ($zom['z'] + $zom['motionz']));
										if ((($pos2->y - $zom['y']) < 0)) {
											$zom['up'] = 1;
										} else {
											$zom['up'] = 0;
										}
									}
									if ((($zom['motionx'] == 0) && ($zom['motionz'] == 0))) {
									} else {
										$yaw = $this->AIHolder->getyaw($zom['motionx'], $zom['motionz']);
										$zom['yaw'] = $yaw;
										$zom['pitch'] = 0;
									}
									if (!($zom['knockBack'])) {
										$zom['x'] = $pos2->getX();
										$zom['z'] = $pos2->getZ();
										$zom['y'] = $pos2->getY();
									}
									$zom['motiony'] = ($pos2->getY() - $zo->getY());
									$zo->setPosition($pos2);
								}
							}
						}
					}
					/* goto */
				}
				/* goto */
			}
			return null;
		}

	public function CreeperHateFinder() {
			/* decompiled (structured CF) */
			foreach ($this->AIHolder->getServer()->getLevels() as $level) {
				foreach ($level->getEntities() as $zo) {
					if ($zo instanceof \pocketmine\entity\Creeper) {
						if (isset($this->AIHolder->Creeper[$zo->getId()])) {
							$h_r = $this->hatred_r;
							new \pocketmine\math\Vector3($zo->getX(), $zo->getY(), $zo->getZ());
							$pos = new \pocketmine\math\Vector3($zo->getX(), $zo->getY(), $zo->getZ());
							$hatred = false;
							foreach ($zo->getViewers() as $p) {
								if ((($p->distance($pos) <= $h_r) && ($p->getGamemode() == 0))) {
									if (($hatred === false)) {
										$hatred = $p;
									} else {
										if ($hatred instanceof \pocketmine\Player) {
											if (($p->distance($pos) <= $hatred->distance($pos))) {
												$hatred = $p;
											}
										}
									}
								}
								/* goto */
							}
							if ((!($hatred) || ($this->dif == 0))) {
								$zom['IsChasing'] = false;
							} else {
								$zom['IsChasing'] = $hatred->getName();
							}
						}
					}
					/* goto */
				}
				/* goto */
			}
			return null;
		}

	public function CreeperHateWalk() {
			/* decompiled (structured CF) */
			foreach ($this->AIHolder->getServer()->getLevels() as $level) {
				foreach ($level->getEntities() as $zo) {
					if ($zo instanceof \pocketmine\entity\Creeper) {
						if (isset($this->AIHolder->Creeper[$zo->getId()])) {
							if (!($zom['knockBack'])) {
								$zom['oldv3'] = $zo->getLocation();
								$zom['canjump'] = true;
								if (($zom['IsChasing'] !== false)) {
									$p = $this->AIHolder->getServer()->getPlayer($zom['IsChasing']);
									if (($p instanceof \pocketmine\Player === false)) {
										$zom['IsChasing'] = false;
									} else {
										$xx = ($p->getX() - $zo->getX());
										$zz = ($p->getZ() - $zo->getZ());
										$yaw = $this->AIHolder->getyaw($xx, $zz);
										if (($zz != 0)) {
											$bi = ($xx / $zz);
										} else {
											$bi = 0;
										}
										if (($zo->getHealth() == $zo->getMaxHealth())) {
											$zzz = sqrt((($this->zo_hate_v / 2.5) / (($bi * $bi) + 1)));
										} else {
											$zzz = sqrt((($this->zo_hate_v / 2) / (($bi * $bi) + 1)));
										}
										if (($zz < 0)) {
											$zzz = ($zzz * -1);
										}
										$xxx = ($zzz * $bi);
										new \pocketmine\math\Vector2($zo->getX(), $zo->getZ());
										$zo_v2 = new \pocketmine\math\Vector2($zo->getX(), $zo->getZ());
										new \pocketmine\math\Vector2($p->getX(), $p->getZ());
										$p_v2 = new \pocketmine\math\Vector2($p->getX(), $p->getZ());
										if (($zo_v2->distance($p_v2) <= ($this->zo_hate_v / 2))) {
											$xxx = $xx;
											$zzz = $zz;
										}
										$zom['xxx'] = $xxx;
										$zom['zzz'] = $zzz;
										new \pocketmine\math\Vector3($zo->getX(), ($zo->getY() + 1), $zo->getZ());
										$pos0 = new \pocketmine\math\Vector3($zo->getX(), ($zo->getY() + 1), $zo->getZ());
										new \pocketmine\math\Vector3(($zo->getX() + $xxx), ($zo->getY() + 1), ($zo->getZ() + $zzz));
										$pos = new \pocketmine\math\Vector3(($zo->getX() + $xxx), ($zo->getY() + 1), ($zo->getZ() + $zzz));
										$zy = $this->AIHolder->ifjump($zo->getLevel(), $pos, true);
										if ((($zy === false) || (($zy !== false) && ($this->AIHolder->ifjump($zo->getLevel(), $pos0, true, true) == 'fall')))) {
											if (($this->AIHolder->ifjump($zo->getLevel(), $pos0, false) === false)) {
												if (($zom['drop'] === false)) {
													$zom['drop'] = 0;
												}
												new \pocketmine\math\Vector3($zo->getX(), ($zo->getY() - (($zom['drop'] / 2) + 1.25)), $zo->getZ());
												$pos2 = new \pocketmine\math\Vector3($zo->getX(), ($zo->getY() - (($zom['drop'] / 2) + 1.25)), $zo->getZ());
											} else {
												$zom['drop'] = false;
												if (($this->AIHolder->whatBlock($level, $pos0) == 'climb')) {
													$zy = ($pos0->y + 0.7);
													new \pocketmine\math\Vector3($zo->getX(), ($zy - 1), $zo->getZ());
													$pos2 = new \pocketmine\math\Vector3($zo->getX(), ($zy - 1), $zo->getZ());
												} else {
													if ((($xxx != 0) && ($zzz != 0))) {
														new \pocketmine\math\Vector3(($zo->getX() + $xxx), ($zo->getY() + 1), $zo->getZ());
														if (($this->AIHolder->ifjump($zo->getLevel(), new \pocketmine\math\Vector3(($zo->getX() + $xxx), ($zo->getY() + 1), $zo->getZ()), true) !== false)) {
															new \pocketmine\math\Vector3(($zo->getX() + $xxx), floor($zo->getY()), $zo->getZ());
															$pos2 = new \pocketmine\math\Vector3(($zo->getX() + $xxx), floor($zo->getY()), $zo->getZ());
														} else {
															new \pocketmine\math\Vector3($zo->getX(), ($zo->getY() + 1), ($zo->getZ() + $zzz));
															if (($this->AIHolder->ifjump($zo->getLevel(), new \pocketmine\math\Vector3($zo->getX(), ($zo->getY() + 1), ($zo->getZ() + $zzz)), true) !== false)) {
																new \pocketmine\math\Vector3($zo->getX(), floor($zo->getY()), ($zo->getZ() + $zzz));
																$pos2 = new \pocketmine\math\Vector3($zo->getX(), floor($zo->getY()), ($zo->getZ() + $zzz));
															} else {
																new \pocketmine\math\Vector3(($zo->getX() - ($xxx / 5)), floor($zo->getY()), ($zo->getZ() - ($zzz / 5)));
																$pos2 = new \pocketmine\math\Vector3(($zo->getX() - ($xxx / 5)), floor($zo->getY()), ($zo->getZ() - ($zzz / 5)));
															}
														}
													} else {
														new \pocketmine\math\Vector3(($zo->getX() - ($xxx / 5)), floor($zo->getY()), ($zo->getZ() - ($zzz / 5)));
														$pos2 = new \pocketmine\math\Vector3(($zo->getX() - ($xxx / 5)), floor($zo->getY()), ($zo->getZ() - ($zzz / 5)));
													}
												}
											}
										} else {
											new \pocketmine\math\Vector3(($zo->getX() + $xxx), ($zy - 1), ($zo->getZ() + $zzz));
											$pos2 = new \pocketmine\math\Vector3(($zo->getX() + $xxx), ($zy - 1), ($zo->getZ() + $zzz));
										}
										$zo->setPosition($pos2);
										$pos3 = $pos2;
										$pos3->y = ($pos3->y + 2.62);
										$ppos = $p->getLocation();
										$ppos->y = ($ppos->y + $p->getEyeHeight());
										$pitch = $this->AIHolder->getpitch($pos3, $ppos);
										$zom['yaw'] = $yaw;
										$zom['pitch'] = $pitch;
										if (!($zom['knockBack'])) {
											$zom['x'] = $zo->getX();
											$zom['y'] = $zo->getY();
											$zom['z'] = $zo->getZ();
										}
									}
								}
							}
						}
					}
					/* goto */
				}
				/* goto */
			}
			return null;
		}

	public function CreeperRandomWalk() {
			/* decompiled (structured CF) */
			foreach ($this->AIHolder->getServer()->getLevels() as $level) {
				foreach ($level->getEntities() as $zo) {
					if ($zo instanceof \pocketmine\entity\Creeper) {
						if (isset($this->AIHolder->Creeper[$zo->getId()])) {
							if (($zom['canAttack'] != 0)) {
								$zom['canAttack'] -= 1;
							}
							$pos = $zo->getLocation();
							if (!($zom['boom'])) {
								if (($zom['drop'] !== false)) {
									$olddrop = $zom['drop'];
									$zom['drop'] += 0.5;
									$drop = $zom['drop'];
									$dropy = ($zo->getY() - (($olddrop * 0.05) + 0.0125));
									new \pocketmine\math\Vector3(floor($zo->getX()), floor($dropy), floor($zo->getZ()));
									$posd0 = new \pocketmine\math\Vector3(floor($zo->getX()), floor($dropy), floor($zo->getZ()));
									new \pocketmine\math\Vector3($zo->getX(), $dropy, $zo->getZ());
									$posd = new \pocketmine\math\Vector3($zo->getX(), $dropy, $zo->getZ());
									if (($this->AIHolder->whatBlock($zo->getLevel(), $posd0) == 'air')) {
										$zo->setPosition($posd);
									} else {
										$i = 1;
										while (($i <= $drop)) {
											if (($this->AIHolder->whatBlock($zo->getLevel(), $posd0) != 'block')) {
												$posd->y = $posd0->y;
												$zo->setPosition($posd);
												$h = (($zom['drop'] * $zom['drop']) / 20);
												$damage = ($h - 3);
												if ((0 < $damage)) {
													$zo->setHealth(($zo->getHealth() - $damage));
												}
												$zom['drop'] = false;
											} else {
												$i++;
											}
										}
									}
								} else {
									$drop = 0;
								}
								if (($zom['IsChasing'] !== false)) {
									if (!($zom['knockBack'])) {
										$zom['up'] = 0;
										if (($this->AIHolder->whatBlock($level, $pos) == 'water')) {
											$zom['swim'] += 1;
											if ((20 <= $zom['swim'])) {
												$zom['swim'] = 0;
											}
										} else {
											$zom['swim'] = 0;
										}
										if (((abs(($zo->getY() - $zom['oldv3']->y)) == 1) && ($zom['canjump'] === true))) {
											$zom['canjump'] = false;
											$zom['jump'] = 0.5;
										} else {
											if ((0.01 < $zom['jump'])) {
												$zom['jump'] -= 0.1;
											} else {
												$zom['jump'] = 0.01;
											}
										}
										new \pocketmine\network\protocol\SetEntityMotionPacket();
										$pk3 = new \pocketmine\network\protocol\SetEntityMotionPacket();
										$pk3->entities = [[$zo->getID(), ($zom['xxx'] / 10), (((($zom['swim'] * -1) / 100) + $zom['jump']) - $drop), ($zom['zzz'] / 10)]];
										foreach ($zo->getViewers() as $pl) {
											$pl->dataPacket($pk3);
											/* goto */
										}
										$p = $this->AIHolder->getServer()->getPlayer($zom['IsChasing']);
										if ($p instanceof \pocketmine\Player) {
											if (($p->distance($pos) <= 1.3)) {
												if ((0 < $zo->fireTicks)) {
													$p->setOnFire(5);
												}
											}
											if ((($p->distance($pos) <= 2) && ($p->getGamemode() == 0))) {
												$zo->setSwelled(true);
											}
											if (($p->distance($pos) <= 1.5)) {
												if (($zom['canAttack'] == 0)) {
													$zom['canAttack'] = 20;
													$p->knockBack($zo, 0, ($zom['xxx'] / 10), ($zom['zzz'] / 10));
													if ($p->isSurvival()) {
														$damage = 0;
													}
												}
											}
										}
									}
								} else {
									new \pocketmine\network\protocol\SetEntityMotionPacket();
									$pk3 = new \pocketmine\network\protocol\SetEntityMotionPacket();
									$pk3->entities = [[$zo->getID(), ($zom['motionx'] / 10), 0, ($zom['motionz'] / 10)]];
									foreach ($zo->getViewers() as $pl) {
										$pl->dataPacket($pk3);
										/* goto */
									}
								}
							} else {
								$p = $this->AIHolder->getServer()->getPlayer($zom['IsChasing']);
								if (!($p instanceof \pocketmine\Player)) {
									return null;
								}
								new \pocketmine\math\Vector3($zo->getX(), $zo->getY(), $zo->getZ());
								$pos = new \pocketmine\math\Vector3($zo->getX(), $zo->getY(), $zo->getZ());
								if (($p->distance($pos) <= 1.5)) {
									$this->AIHolder->Creeper[$zo->getId()]['boomed'] = true;
									$zom['boom'] = ($zom['boom'] - 1);
									if (($zom['boom'] <= 0)) {
										new \pocketmine\level\Position($zo->getX(), $zo->getY(), $zo->getZ(), $level);
										new \pocketmine\level\Explosion(new \pocketmine\level\Position($zo->getX(), $zo->getY(), $zo->getZ(), $level), $this->bomb, $zo);
										$e = new \pocketmine\level\Explosion(new \pocketmine\level\Position($zo->getX(), $zo->getY(), $zo->getZ(), $level), $this->bomb, $zo);
										if (($this->AIHolder->getServer()->aiConfig['creeperexplode'] && !($this->AIHolder->getServer()->isWorldCreeperBlockDamageDisabled($level)))) {
											$e->explode();
										} else {
											$e->explodeB();
										}
										$level->removeEntity($level->getEntity($zo->getId()));
									}
								}
							}
						}
					}
					/* goto */
				}
				/* goto */
			}
		}

}
