<?php

namespace pocketmine\entity\behavior;

class EatGrassBehavior extends \pocketmine\entity\behavior\Behavior {
	public const MAX_LOOK_DISTANCE = 6.0;
	public const START_CHANCE = 400;
	public const EATING_DURATION = 30;
	public const GRASS_BLOCK_ID = 2;
	public const DIRT_BLOCK_ID = 3;
	public const EAT_ANIMATION_TIME = 30;

	public $player = NULL;
	public $timeLeft = 0;
	private $animationPlayed = false;

	public function getName(): string
	    {
	        // TODO body via opdump
	    }

	public function shouldStart(): bool
	    {
	        // TODO body via opdump
	    }

	public function canContinue(): bool
	    {
	        // TODO body via opdump
	    }

	public function onTick()
	    {
	        // TODO body via opdump
	    }

	public function onEnd()
	    {
	        // TODO body via opdump
	    }

	private function isStandingOnGrass(): bool
	    {
	        // TODO body via opdump
	    }

	private function playEatGrassAnimation()
	    {
	        // TODO body via opdump
	    }

	private function completeEating()
	    {
	        // TODO body via opdump
	    }

	private function convertGrassToDirt(pocketmine\math\Vector3 $position)
	    {
	        // TODO body via opdump
	    }

	public function reset()
	    {
	        // TODO body via opdump
	    }

}
