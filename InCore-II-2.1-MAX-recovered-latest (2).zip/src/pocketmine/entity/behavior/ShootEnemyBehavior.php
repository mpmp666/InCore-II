<?php

namespace pocketmine\entity\behavior;

class ShootEnemyBehavior extends \pocketmine\entity\behavior\Behavior {
	public $speed = NULL;
	public $speedMultiplier = NULL;
	public $lookDistance = 16.0;
	public $shootDistance = 10.0;
	public $NetworkID = NULL;
	public $enemy = NULL;
	public $timeLeft = 0;
	public $projectileName = NULL;

	public function __construct($entity = null, $NetWorkID = null, $projectileName = null, $speed = null, $speedMultiplier = null) {
			/* decompiled (structured CF) */
			parent::__construct($entity);
			$this->speed = $speed;
			$this->speedMultiplier = $speedMultiplier;
			$this->NetworkID = $NetWorkID;
			$this->projectileName = $projectileName;
			return;
		}

	public function getName() {
			return "\xe6\x8a\x95\xe6\x8e\xb7\xe7\xb1\xbb\xe6\x95\x8c\xe5\xaf\xb9\xe5\xae\x9e\xe4\xbd\x93\xe6\x94\xbb\xe5\x87\xbb";
		}

	public function shouldStart() {
			/* decompiled (structured CF) */
			$entities = $this->entity->level->getEntities();
			$find = false;
			$MinDistance = 9999;
			foreach ($entities as $entity) {
				if ((in_array($entity::NETWORK_ID, $this->NetworkID) && ($this->entity->distance($entity) < $this->lookDistance))) {
					if (($this->entity->distance($entity) < $MinDistance)) {
						$this->enemy = $entity;
						$MinDistance = $this->entity->distance($entity);
						$find = true;
					}
				}
				/* goto */
			}
			return $find;
		}

	public function canContinue() {
			/* decompiled (structured CF) */
			if (($this->enemy instanceof \pocketmine\entity\Entity && $this->enemy->isAlive())) {
				return ($this->entity->distance($this->enemy) < $this->lookDistance);
			}
			return false;
		}

	public function onTick() {
			/* decompiled (structured CF) */
			if ((!($this->enemy instanceof \pocketmine\entity\Entity) || !($this->enemy->isAlive()))) {
				return null;
			}
			$distance = $this->entity->distance($this->enemy);
			$entity = $this->entity;
			$entity->setPm1eFollowTarget($this->enemy);
			if (($distance < 4)) {
			} else {
			}
			$entity->setPm1eMoveMultiplier($this->speedMultiplier);
			$entity->setPm1eStayTime(0);
			if ((($distance <= $this->shootDistance) && ($this->timeLeft <= 0))) {
				$this->shootProjectile();
				$this->timeLeft = 40;
			} else {
				if ((0 < $this->timeLeft)) {
				}
			}
			$this->swimming();
		}

	public function onEnd() {
			$this->entity->setPm1eFollowTarget(null);
			$this->entity->setPm1eMoveMultiplier(1);
			return null;
		}

	protected function shootProjectile() {
			/* decompiled (structured CF) */
			$entity = $this->entity;
			$target = $this->enemy;
			$originY = ($entity->y + $entity->getEyeHeight());
			$targetY = ($target->y + $target->getEyeHeight());
			$motionX = ($target->x - $entity->x);
			$motionY = ($targetY - $originY);
			$motionZ = ($target->z - $entity->z);
			$length = sqrt(((($motionX * $motionX) + ($motionY * $motionY)) + ($motionZ * $motionZ)));
			if (($length <= 0)) {
				return null;
			}
			$motionX /= $length;
			$motionY /= $length;
			$motionZ /= $length;
			$yaw = ((atan2($motionX, $motionZ) * 180) / \M_PI);
			$pitch = ((atan2($motionY, sqrt((($motionX * $motionX) + ($motionZ * $motionZ)))) * 180) / \M_PI);
			new \pocketmine\nbt\tag\DoubleTag('', $entity->x);
			new \pocketmine\nbt\tag\DoubleTag('', $originY);
			new \pocketmine\nbt\tag\DoubleTag('', $entity->z);
			new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $entity->x), new \pocketmine\nbt\tag\DoubleTag('', $originY), new \pocketmine\nbt\tag\DoubleTag('', $entity->z)]);
			new \pocketmine\nbt\tag\DoubleTag('', $motionX);
			new \pocketmine\nbt\tag\DoubleTag('', $motionY);
			new \pocketmine\nbt\tag\DoubleTag('', $motionZ);
			new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', $motionX), new \pocketmine\nbt\tag\DoubleTag('', $motionY), new \pocketmine\nbt\tag\DoubleTag('', $motionZ)]);
			new \pocketmine\nbt\tag\FloatTag('', $yaw);
			new \pocketmine\nbt\tag\FloatTag('', $pitch);
			new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $yaw), new \pocketmine\nbt\tag\FloatTag('', $pitch)]);
			new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $entity->x), new \pocketmine\nbt\tag\DoubleTag('', $originY), new \pocketmine\nbt\tag\DoubleTag('', $entity->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', $motionX), new \pocketmine\nbt\tag\DoubleTag('', $motionY), new \pocketmine\nbt\tag\DoubleTag('', $motionZ)]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $yaw), new \pocketmine\nbt\tag\FloatTag('', $pitch)])]);
			$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $entity->x), new \pocketmine\nbt\tag\DoubleTag('', $originY), new \pocketmine\nbt\tag\DoubleTag('', $entity->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', $motionX), new \pocketmine\nbt\tag\DoubleTag('', $motionY), new \pocketmine\nbt\tag\DoubleTag('', $motionZ)]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $yaw), new \pocketmine\nbt\tag\FloatTag('', $pitch)])]);
			$projectile = $this->createProjectile($nbt);
			if ($projectile instanceof \pocketmine\entity\Projectile) {
				$projectile->setMotion($projectile->getMotion()->multiply(1.5));
				new \pocketmine\event\entity\ProjectileLaunchEvent($projectile);
				$ev = new \pocketmine\event\entity\ProjectileLaunchEvent($projectile);
				$entity->level->getServer()->getPluginManager()->callEvent($ev);
				if ($ev->isCancelled()) {
					$projectile->close();
				} else {
					$projectile->spawnToAll();
				}
			}
		}

	protected function createProjectile($nbt = null) {
			return \pocketmine\entity\Entity::createEntity($this->projectileName, $this->entity->chunk, $nbt, $this->entity);
		}

}
