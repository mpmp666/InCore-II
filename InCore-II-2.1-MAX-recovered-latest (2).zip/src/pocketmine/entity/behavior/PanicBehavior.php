<?php

namespace pocketmine\entity\behavior;

class PanicBehavior extends \pocketmine\entity\behavior\StrollBehavior {
	public const DEFAULT_PANIC_DURATION = 60;
	public const DEFAULT_PANIC_SPEED = 0.27;
	public const DEFAULT_SPEED_MULTIPLIER = 0.75;

	public function __construct($entity = null, $speed = null, $speedMultiplier = null) {
			parent::__construct($entity, self::DEFAULT_PANIC_DURATION, $speed, $speedMultiplier);
			return;
		}

	public function getName() {
			return "\xe5\x8f\x97\xe4\xbc\xa4\xe4\xb9\x8b\xe5\x90\x8e\xe8\xa1\x8c\xe8\xb5\xb0";
		}

	public function shouldStart() {
			return ($this->entity->getLastDamageCause() !== null);
		}

	public function onEnd() {
			parent::onEnd();
			$this->resetDamageCause();
			return null;
		}

	private function resetDamageCause() {
			/* decompiled (structured CF) */
			if (method_exists($this->entity, 'resetLastDamageCause')) {
				$this->entity->resetLastDamageCause();
			}
			return null;
		}

}
