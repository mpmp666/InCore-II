<?php

namespace pocketmine\entity\behavior;

class RandomLookaroundBehavior extends \pocketmine\entity\behavior\Behavior {
	public const START_CHANCE = 3;
	public const MIN_DURATION = 20;
	public const MAX_DURATION = 40;
	public const MIN_ROTATION = -180;
	public const MAX_ROTATION = 180;
	public const ROTATION_SPEED = 10;

	public $duration = 0;
	public $rotation = 0;
	private $rotationDirection = 0;

	public function getName() {
			return "\xe9\x9a\x8f\xe6\x9c\xba\xe7\x9c\x8b";
		}

	public function shouldStart() {
			/* decompiled (structured CF) */
			if ((mt_rand(0, (self::START_CHANCE - 1)) !== 0)) {
				return false;
			}
			$this->duration = mt_rand(self::MIN_DURATION, self::MAX_DURATION);
			$this->rotation = mt_rand(self::MIN_ROTATION, self::MAX_ROTATION);
			$this->rotationDirection = $this->getSign($this->rotation);
			return true;
		}

	public function canContinue() {
			return ((0 < $t0) && (0 < abs($this->rotation)));
		}

	public function onTick() {
			/* decompiled (structured CF) */
			$this->handleSwimming();
			$this->updateRotation();
			$this->broadcastMovement();
			return null;
		}

	public function onEnd() {
			return null;
		}

	private function updateRotation() {
			/* decompiled (structured CF) */
			$rotationStep = $this->calculateRotationStep();
			$this->entity->yaw += $rotationStep;
			$this->rotation -= $rotationStep;
			return null;
		}

	private function calculateRotationStep() {
			/* decompiled (structured CF) */
			$absRotation = abs($this->rotation);
			if (($absRotation < self::ROTATION_SPEED)) {
				return $this->rotation;
			}
			return ($this->rotationDirection * self::ROTATION_SPEED);
		}

	private function getSign($value = null) {
			/* decompiled (structured CF) */
			if ((0 < $value)) {
				return 1;
			}
			if (($value < 0)) {
				return -1;
			}
			return 0;
		}

	private function broadcastMovement() {
			$this->entity->getLevel()->addEntityMovement($this->entity->chunk->getX(), $this->entity->chunk->getZ(), $this->entity->getId(), $this->entity->x, ($this->entity->y + $this->entity->getEyeHeight()), $this->entity->z, $this->entity->yaw, $this->entity->pitch, $this->entity->yaw);
			return null;
		}

	private function handleSwimming() {
			/* decompiled (structured CF) */
			if (method_exists($this->entity, 'swimming')) {
				$this->entity->swimming();
			}
			return null;
		}

}
