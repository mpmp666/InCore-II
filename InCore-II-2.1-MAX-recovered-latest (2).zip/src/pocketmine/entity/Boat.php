<?php

namespace pocketmine\entity;

class Boat extends \pocketmine\entity\Vehicle {
	public const NETWORK_ID = 90;

	public $height = 0.7;
	public $width = 1.6;
	public $gravity = 0.5;
	public $drag = 0.1;

	public function __construct($chunk = null, $nbt = null) {
			/* decompiled (structured CF) */
			if (!(isset($nbt->WoodID))) {
				new \pocketmine\nbt\tag\IntTag('WoodID', 0);
				$nbt->WoodID = new \pocketmine\nbt\tag\IntTag('WoodID', 0);
			}
			parent::__construct($chunk, $nbt);
			$this->setDataProperty(self::DATA_WOOD_ID, self::DATA_TYPE_BYTE, $this->getWoodID());
			return;
		}

	public function initEntity() {
			$this->setMaxHealth(10);
			parent::initEntity();
			return null;
		}

	public function getWoodID() {
			return ($this->namedtag['WoodID']);
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->eid = $this->getId();
			$pk->type = 90;
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = 0;
			$pk->speedY = 0;
			$pk->speedZ = 0;
			$pk->yaw = 0;
			$pk->pitch = 0;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

	public function attack($damage = null, $source = null) {
			/* decompiled (structured CF) */
			parent::attack($damage, $source);
			if (!($source->isCancelled())) {
				new \pocketmine\network\protocol\EntityEventPacket();
				$pk = new \pocketmine\network\protocol\EntityEventPacket();
				$pk->eid = $this->id;
				$pk->event = \pocketmine\network\protocol\EntityEventPacket::HURT_ANIMATION;
				foreach ($this->getLevel()->getPlayers() as $player) {
					$player->dataPacket($pk);
					/* goto */
				}
			}
			return null;
		}

	public function close() {
			/* decompiled (structured CF) */
			if ((!($this->closed) && !($this->getLevel()->getServer()->isWorldNonLivingEntityDropsDisabled($this->getLevel())))) {
				foreach ($this->getDrops() as $item) {
					$this->getLevel()->dropItem($this, $item);
					/* goto */
				}
			}
			parent::close();
			return null;
		}

	public function onUpdate($currentTick = null) {
			/* decompiled (structured CF) */
			if ($this->closed) {
				return false;
			}
			$tickDiff = ($currentTick - $this->lastUpdate);
			if ((($tickDiff <= 0) && !($this->justCreated))) {
				return true;
			}
			$this->lastUpdate = $currentTick;
			$this->timings->startTiming();
			$hasUpdate = $this->entityBaseTick($tickDiff);
			new \pocketmine\math\Vector3($this->x, $this->y, $this->z);
			if (((!($this->level->getBlock(new \pocketmine\math\Vector3($this->x, $this->y, $this->z))->getBoundingBox()) == null) || $this->isInsideOfWater())) {
				$this->motionY = 0.1;
			} else {
				$this->motionY = -0.08;
			}
			$this->move($this->motionX, $this->motionY, $this->motionZ);
			$this->updateMovement();
			$this->linkedType = 0;
			if ((($this->linkedEntity == null) || $t35)) {
				if ((1500 < $this->age)) {
					$this->close();
					$hasUpdate = true;
					$this->age = 0;
				}
			} else {
				$this->age = 0;
			}
			$this->timings->stopTiming();
			return (((($hasUpdate || !($this->onGround)) || (1e-05 < abs($this->motionX))) || (1e-05 < abs($this->motionY))) || (1e-05 < abs($this->motionZ)));
		}

	public function getDrops() {
			return [\pocketmine\item\Item::get(\pocketmine\item\Item::BOAT, $this->getWoodID(), 1)];
		}

	public function getSaveId() {
			new \ReflectionClass($t2);
			$class = new \ReflectionClass($t2);
			return $class->getShortName();
		}

}
