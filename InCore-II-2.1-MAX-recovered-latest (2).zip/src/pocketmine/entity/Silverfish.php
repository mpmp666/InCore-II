<?php

namespace pocketmine\entity;

class Silverfish extends \pocketmine\entity\Monster {
	public const NETWORK_ID = 39;

	public $width = 0.4;
	public $length = 0.4;
	public $height = 0.3;
	public $dropExp = array (
  0 => 5,
  1 => 5,
);

	public function getName() {
			return 'Silverfish';
		}

	public function usesPm1eGroundAi() {
			return true;
		}

	public function initEntity() {
			/* decompiled (structured CF) */
			$this->setMaxHealth(8);
			new \pocketmine\entity\behavior\attackEnemyBehavior($this, ['__array_ptr' => '2aaaadd5d508'], true);
			$this->addBehavior(new \pocketmine\entity\behavior\attackEnemyBehavior($this, ['__array_ptr' => '2aaaadd5d508'], true));
			parent::initEntity();
			return null;
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->eid = $this->getId();
			$pk->type = 39;
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->yaw = $this->yaw;
			$pk->pitch = $this->pitch;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

}
