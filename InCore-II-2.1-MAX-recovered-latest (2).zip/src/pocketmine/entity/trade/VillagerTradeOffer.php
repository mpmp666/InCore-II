<?php

namespace pocketmine\entity\trade;

class VillagerTradeOffer {
	public const FAIL_NONE = 0;
	public const FAIL_EXHAUSTED = 1;
	public const FAIL_MISSING_ITEMS = 2;
	public const FAIL_NO_SPACE = 3;

	private $buyA = NULL;
	private $buyB = NULL;
	private $sell = NULL;
	private $maxUses = NULL;
	private $uses = NULL;

	public function __construct($buyA = null, $buyB = null, $sell = null, $maxUses = null, $uses = null) {
			/* decompiled (structured CF) */
			$this->buyA = clone $buyA;
			if (($buyB !== null)) {
			} else {
			}
			$this->buyB = null;
			$this->sell = clone $sell;
			$this->maxUses = max(1, $maxUses);
			$this->uses = max(0, min($uses, $this->maxUses));
			return;
		}

	public function getBuyA() {
			return clone $this->buyA;
		}

	public function getBuyB() {
			/* decompiled (structured CF) */
			if (($this->buyB !== null)) {
			} else {
			}
			return null;
		}

	public function getSell() {
			return clone $this->sell;
		}

	public function getMaxUses() {
			return $this->maxUses;
		}

	public function getUses() {
			return $this->uses;
		}

	public function isExhausted() {
			return ($this->maxUses <= $this->uses);
		}

	public function canExecute($inventory = null) {
			return ($this->getFailureReason($inventory) === self::FAIL_NONE);
		}

	public function getFailureReason($inventory = null) {
			/* decompiled (structured CF) */
			if ($this->isExhausted()) {
				return self::FAIL_EXHAUSTED;
			}
			if (!($this->hasItemCount($inventory, $this->buyA))) {
				return self::FAIL_MISSING_ITEMS;
			}
			if ((($this->buyB !== null) && !($this->hasItemCount($inventory, $this->buyB)))) {
				return self::FAIL_MISSING_ITEMS;
			}
			if (!($this->canAddSellAfterRemovingCosts($inventory))) {
				return self::FAIL_NO_SPACE;
			}
			return self::FAIL_NONE;
		}

	public function execute($inventory = null) {
			/* decompiled (structured CF) */
			if (($this->getFailureReason($inventory) !== self::FAIL_NONE)) {
				return false;
			}
			$this->removeItemCount($inventory, $this->buyA);
			if (($this->buyB !== null)) {
				$this->removeItemCount($inventory, $this->buyB);
			}
			$inventory->addItem($this->sell);
			$this->recordUse();
			return true;
		}

	public function recordUse() {
			if (($this->uses < $this->maxUses)) {
			}
			return null;
		}

	private function hasItemCount($inventory = null, $required = null) {
			/* decompiled (structured CF) */
			$remaining = $required->getCount();
			foreach ($inventory->getContents() as $item) {
				if ($required->equals($item, true, true)) {
					$remaining -= $item->getCount();
					if (($remaining <= 0)) {
						return true;
					}
				}
				/* goto */
			}
			return false;
		}

	private function removeItemCount($inventory = null, $required = null) {
			/* decompiled (structured CF) */
			$remaining = $required->getCount();
			foreach ($inventory->getContents() as $slot => $item) {
				if (!($required->equals($item, true, true))) {
					/* goto */
				}
				if (($remaining < $item->getCount())) {
					$item->setCount(($item->getCount() - $remaining));
					$inventory->setItem($slot, $item);
					return null;
				}
				$remaining -= $item->getCount();
				$inventory->clear($slot);
				if (($remaining <= 0)) {
				}
				/* goto */
			}
		}

	private function canAddSellAfterRemovingCosts($inventory = null) {
			/* decompiled (structured CF) */
			$slots = ['__array_ptr' => '2aaaac9fc9a0'];
			$i = 0;
			while (($i < $inventory->getSize())) {
				$slots[$i] = $inventory->getItem($i);
				$i++;
			}
			if (!($this->removeItemCountFromSlots($slots, $this->buyA))) {
				return false;
			}
			if ((($this->buyB !== null) && !($this->removeItemCountFromSlots($slots, $this->buyB)))) {
				return false;
			}
			return $this->canAddItemToSlots($slots, $this->sell, $inventory->getMaxStackSize());
		}

	private function removeItemCountFromSlots($slots = null, $required = null) {
			/* decompiled (structured CF) */
			$remaining = $required->getCount();
			foreach ($slots as $slot => $item) {
				if (!($required->equals($item, true, true))) {
					/* goto */
				}
				if (($remaining < $item->getCount())) {
					$item->setCount(($item->getCount() - $remaining));
					$slots[$slot] = $item;
					return true;
				}
				$remaining -= $item->getCount();
				$slots[$slot] = \pocketmine\item\Item::get(\pocketmine\item\Item::AIR, 0, 0);
				if (($remaining <= 0)) {
					return true;
				}
				/* goto */
			}
			return false;
		}

	private function canAddItemToSlots($slots = null, $item = null, $inventoryMaxStackSize = null) {
			/* decompiled (structured CF) */
			$remaining = $item->getCount();
			foreach ($slots as $slot) {
				if ($item->equals($slot, true, true)) {
					$remaining -= max(0, (min($item->getMaxStackSize(), $inventoryMaxStackSize) - $slot->getCount()));
				} else {
					if ((($slot->getId() === \pocketmine\item\Item::AIR) || ($slot->getCount() <= 0))) {
						$remaining -= min($item->getMaxStackSize(), $inventoryMaxStackSize);
					}
				}
				if (($remaining <= 0)) {
					return true;
				}
				/* goto */
			}
			return false;
		}

	public function toNBT($index = null) {
			/* decompiled (structured CF) */
			$buyA = \pocketmine\nbt\NBT::putItemHelper($this->buyA);
			$buyA->setName('buyA');
			$sell = \pocketmine\nbt\NBT::putItemHelper($this->sell);
			$sell->setName('sell');
			new \pocketmine\nbt\tag\IntTag('maxUses', $this->maxUses);
			new \pocketmine\nbt\tag\IntTag('uses', $this->uses);
			new \pocketmine\nbt\tag\CompoundTag(($index), [$buyA, $sell, new \pocketmine\nbt\tag\IntTag('maxUses', $this->maxUses), new \pocketmine\nbt\tag\IntTag('uses', $this->uses)]);
			$tag = new \pocketmine\nbt\tag\CompoundTag(($index), [$buyA, $sell, new \pocketmine\nbt\tag\IntTag('maxUses', $this->maxUses), new \pocketmine\nbt\tag\IntTag('uses', $this->uses)]);
			if (($this->buyB !== null)) {
				$buyB = \pocketmine\nbt\NBT::putItemHelper($this->buyB);
				$buyB->setName('buyB');
				$tag->buyB = $buyB;
			}
			return $tag;
		}

	public static function fromNBT($tag = null) {
			/* decompiled (structured CF) */
			if ((isset($tag->buyA) && $tag->buyA instanceof \pocketmine\nbt\tag\CompoundTag)) {
			} else {
			}
			$buyA = \pocketmine\item\Item::get(\pocketmine\item\Item::AIR, 0, 0);
			if ((isset($tag->buyB) && $tag->buyB instanceof \pocketmine\nbt\tag\CompoundTag)) {
			} else {
			}
			$buyB = null;
			if ((isset($tag->sell) && $tag->sell instanceof \pocketmine\nbt\tag\CompoundTag)) {
			} else {
			}
			$sell = \pocketmine\item\Item::get(\pocketmine\item\Item::AIR, 0, 0);
			if (isset($tag->maxUses)) {
			} else {
			}
			$maxUses = 1;
			if (isset($tag->uses)) {
			} else {
			}
			$uses = 0;
			new self($buyA, $buyB, $sell, $maxUses, $uses);
			return new self($buyA, $buyB, $sell, $maxUses, $uses);
		}

	public function fingerprint() {
			/* decompiled (structured CF) */
			if (($this->buyB !== null)) {
			} else {
			}
			$parts = [$this->itemFingerprint($this->buyA), '0:0:0', $this->itemFingerprint($this->sell), $this->maxUses, $this->uses];
			return implode('>', $parts);
		}

	private function itemFingerprint($item = null) {
			return (((($item->getId() . ':') . $item->getDamage()) . ':') . $item->getCount());
		}

}
