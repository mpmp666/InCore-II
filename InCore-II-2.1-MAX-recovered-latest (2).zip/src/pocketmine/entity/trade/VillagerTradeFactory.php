<?php

namespace pocketmine\entity\trade;

class VillagerTradeFactory {
	public static function generateOffers($profession = null, $seed = null) {
			/* decompiled (structured CF) */
			if (($seed === null)) {
			} else {
			}
			$state = $seed;
			$offers = ['__array_ptr' => '2aaaac9fc9a0'];
			foreach (self::templatesForProfession($profession) as $template) {
				$buyA = self::itemFromSpec($template['buyA'], $state);
				if (isset($template['buyB'])) {
				} else {
				}
				$buyB = null;
				$sell = self::itemFromSpec($template['sell'], $state);
				$maxUses = self::randomBetween($template['maxUses'][0], $template['maxUses'][1], $state);
				new \pocketmine\entity\trade\VillagerTradeOffer($buyA, $buyB, $sell, $maxUses, 0);
				$offers[] = new \pocketmine\entity\trade\VillagerTradeOffer($buyA, $buyB, $sell, $maxUses, 0);
				/* goto */
			}
			return $offers;
		}

	public static function fingerprint($offers = null) {
			return implode('|', array_map(function () { /* unrecovered lambda E:/Desktop/src/src/pocketmine/entity/trade/VillagerTradeFact */ return null; }, $offers));
		}

	private static function itemFromSpec($spec = null, $state = null) {
			/* decompiled (structured CF) */
			if (isset($spec['count'])) {
			} else {
			}
			$count = 1;
			if (is_array($count)) {
				$count = self::randomBetween($count[0], $count[1], $state);
			}
			if (isset($spec['damage'])) {
			} else {
			}
			$damage = 0;
			if (is_array($damage)) {
				$damage = self::randomBetween($damage[0], $damage[1], $state);
			}
			return \pocketmine\item\Item::get($spec['id'], $damage, $count);
		}

	private static function randomBetween($min = null, $max = null, $state = null) {
			/* decompiled (structured CF) */
			if (($max <= $min)) {
				return $min;
			}
			$state = (((($state * 1103515245) + 12345) & 2147483647));
			return ($min + ($state % (($max - $min) + 1)));
		}

	private static function spec($id = null, $count = null, $damage = null) {
			return [$id, $damage, $count];
		}

	private static function offer($buyA = null, $sell = null, $minUses = null, $maxUses = null, $buyB = null) {
			/* decompiled (structured CF) */
			$template = [$buyA, $sell, [$minUses, $maxUses]];
			if (($buyB !== null)) {
				$template['buyB'] = $buyB;
			}
			return $template;
		}

	private static function templatesForProfession($profession = null) {
			/* decompiled (structured CF) */
			if (!(($profession == \pocketmine\entity\Villager::PROFESSION_LIBRARIAN))) {
				if (!(($profession == \pocketmine\entity\Villager::PROFESSION_PRIEST))) {
					if (!(($profession == \pocketmine\entity\Villager::PROFESSION_BLACKSMITH))) {
						if (!(($profession == \pocketmine\entity\Villager::PROFESSION_BUTCHER))) {
							if (!(($profession == \pocketmine\entity\Villager::PROFESSION_FARMER))) {
								/* jump */
								return [self::offer(self::spec(\pocketmine\item\Item::PAPER, ['__array_ptr' => '2aaaadd5d540']), self::spec(\pocketmine\item\Item::EMERALD, 1), 8, 12), self::offer(self::spec(\pocketmine\item\Item::BOOK, ['__array_ptr' => '2aaaadd5d578']), self::spec(\pocketmine\item\Item::EMERALD, 1), 8, 12), self::offer(self::spec(\pocketmine\item\Item::EMERALD, ['__array_ptr' => '2aaaadd5d5b0']), self::spec(\pocketmine\item\Item::BOOKSHELF, 1), 6, 10), self::offer(self::spec(\pocketmine\item\Item::EMERALD, ['__array_ptr' => '2aaaadd5d5e8']), self::spec(\pocketmine\item\Item::COMPASS, 1), 3, 6), self::offer(self::spec(\pocketmine\item\Item::EMERALD, ['__array_ptr' => '2aaaadd5d620']), self::spec(\pocketmine\item\Item::CLOCK, 1), 3, 6)];
							}
						}
					}
				}
				return [self::offer(self::spec(\pocketmine\item\Item::WHEAT, ['__array_ptr' => '2aaaadd5da10']), self::spec(\pocketmine\item\Item::EMERALD, 1), 8, 12), self::offer(self::spec(\pocketmine\item\Item::POTATO, ['__array_ptr' => '2aaaadd5da48']), self::spec(\pocketmine\item\Item::EMERALD, 1), 8, 12), self::offer(self::spec(\pocketmine\item\Item::CARROT, ['__array_ptr' => '2aaaadd5da80']), self::spec(\pocketmine\item\Item::EMERALD, 1), 8, 12), self::offer(self::spec(\pocketmine\item\Item::EMERALD, 1), self::spec(\pocketmine\item\Item::BREAD, ['__array_ptr' => '2aaaadd5dab8']), 8, 12), self::offer(self::spec(\pocketmine\item\Item::EMERALD, ['__array_ptr' => '2aaaadd5daf0']), self::spec(\pocketmine\item\Item::PUMPKIN_PIE, ['__array_ptr' => '2aaaadd5db28']), 6, 10)];
			}
		}

}
