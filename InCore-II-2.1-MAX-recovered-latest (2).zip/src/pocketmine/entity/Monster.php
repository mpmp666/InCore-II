<?php

namespace pocketmine\entity;

abstract class Monster extends \pocketmine\entity\Mob {
	public const DAYLIGHT_BURN_SKY_LIGHT = 15;

	public function onUpdate($tick = null) {
			/* decompiled (structured CF) */
			$hasUpdate = parent::onUpdate($tick);
			if ((!($this->closed) && $this->isAlive())) {
				$this->applyDaylightBurning();
			}
			return $hasUpdate;
		}

	protected function shouldBurnInDaylight() {
			return (($this instanceof \pocketmine\entity\Zombie || $this instanceof \pocketmine\entity\ZombieVillager) || $this instanceof \pocketmine\entity\Skeleton);
		}

	protected function hasSunBlockingHelmet() {
			/* decompiled (structured CF) */
			if (!(method_exists($this, 'getArmorContents'))) {
				return false;
			}
			$armor = $this->getArmorContents();
			if ((!(isset($armor[0])) || !($armor[0] instanceof \pocketmine\item\Item))) {
				return false;
			}
			return ($armor[0]->getId() !== \pocketmine\item\Item::AIR);
		}

	protected function applyDaylightBurning() {
			/* decompiled (structured CF) */
			if ((!($this->shouldBurnInDaylight()) || $this->hasSunBlockingHelmet())) {
				return null;
			}
			$level = $this->getLevel();
			if ((!($level instanceof \pocketmine\level\Level) || ($level->getDimension() !== \pocketmine\level\Level::DIMENSION_NORMAL))) {
			}
			$time = ($level->getTime() % \pocketmine\level\Level::TIME_FULL);
			if (!((((\pocketmine\level\Level::TIME_DAY <= $time) && ($time < \pocketmine\level\Level::TIME_NIGHT)) || (\pocketmine\level\Level::TIME_SUNRISE <= $time)))) {
			}
			$x = (floor($this->x));
			$y = (floor(($this->y + $this->height)));
			$z = (floor($this->z));
			if ((($y < 0) || (\pocketmine\level\Level::Y_MAX <= $y))) {
			}
			if (((self::DAYLIGHT_BURN_SKY_LIGHT <= $level->getRealBlockSkyLightAt($x, $y, $z)) && $this->hasDirectDaylight($level, $x, $y, $z))) {
				$this->setOnFire(2);
			}
		}

	protected function hasDirectDaylight($level = null, $x = null, $y = null, $z = null) {
			/* decompiled (structured CF) */
			$checkY = $y;
			while (($checkY < $t12)) {
				if (!($level->getBlock($this->temporalVector->setComponents($x, $checkY, $z))->canPassThrough())) {
					return false;
				}
				$checkY++;
			}
			return true;
		}

}
