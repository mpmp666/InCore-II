<?php

namespace pocketmine\entity;

class Egg extends \pocketmine\entity\Projectile {
	public const NETWORK_ID = 82;

	public $width = 0.25;
	public $length = 0.25;
	public $height = 0.25;
	protected $gravity = 0.03;
	protected $drag = 0.01;

	public function __construct($chunk = null, $nbt = null, $shootingEntity = null) {
			parent::__construct($chunk, $nbt, $shootingEntity);
			return;
		}

	public function onUpdate($currentTick = null) {
			/* decompiled (structured CF) */
			if ($this->closed) {
				return false;
			}
			$this->timings->startTiming();
			$hasUpdate = parent::onUpdate($currentTick);
			if (((1200 < $this->age) || $this->isCollided)) {
				$this->kill();
				$hasUpdate = true;
			}
			$this->timings->stopTiming();
			return $hasUpdate;
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->type = 82;
			$pk->eid = $this->getId();
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

}
