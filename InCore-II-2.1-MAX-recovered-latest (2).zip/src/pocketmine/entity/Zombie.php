<?php

namespace pocketmine\entity;

class Zombie extends \pocketmine\entity\Monster implements \pocketmine\entity\Ageable {
	public const NETWORK_ID = 32;
	public const BABY_ZOMBIE_PM1E_BASE_SPEED = 0.35;

	public $width = 0.6;
	public $length = 0.6;
	public $height = 1.8;
	public $dropExp = array (
  0 => 5,
  1 => 5,
);
	private $hurt = 8;
	protected $armor = array (
);
	protected $weapon = NULL;

	public function getName() {
			return 'Zombie';
		}

	public function initEntity() {
			/* decompiled (structured CF) */
			$this->setMaxHealth(20);
			if (!(isset($this->namedtag->IsBaby))) {
				new \pocketmine\nbt\tag\ByteTag('IsBaby', 1);
				$this->namedtag->IsBaby = new \pocketmine\nbt\tag\ByteTag('IsBaby', 1);
				$this->setBaby(false);
			}
			$this->setBaby($this->isBaby());
			new \pocketmine\entity\behavior\attackEnemyBehavior($this, ['__array_ptr' => '2aaaadd5db28'], true);
			$this->addBehavior(new \pocketmine\entity\behavior\attackEnemyBehavior($this, ['__array_ptr' => '2aaaadd5db28'], true));
			parent::initEntity();
			$equipment = \pocketmine\entity\VanillaMobEquipment::generateZombieEquipment($this->server->getDifficulty());
			$this->weapon = $equipment['weapon'];
			$this->armor = $equipment['armor'];
			return null;
		}

	public function usesPm1eGroundAi() {
			return true;
		}

	protected function getPm1eBaseSpeed($liquidType = null) {
			/* decompiled (structured CF) */
			$speed = parent::getPm1eBaseSpeed($liquidType);
			if (($this->isBaby() && ($liquidType === null))) {
			} else {
			}
			return $speed;
		}

	public function getHurt() {
			return $this->hurt;
		}

	public function setHurt($hurt = null) {
			$this->hurt = $hurt;
		}

	public function getWeapon() {
			/* decompiled (structured CF) */
			if ($this->weapon instanceof \pocketmine\item\Item) {
			} else {
			}
			return \pocketmine\item\Item::get(\pocketmine\item\Item::AIR, 0, 0);
		}

	public function getArmorContents() {
			/* decompiled (structured CF) */
			if ((count($this->armor) === 4)) {
			} else {
			}
			return \pocketmine\entity\VanillaMobEquipment::emptyArmor();
		}

	protected function handlesLootingDrops() {
			return true;
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->eid = $this->getId();
			$pk->type = self::NETWORK_ID;
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->yaw = $this->yaw;
			$pk->pitch = $this->pitch;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			$this->sendMobEquipment($player);
			return null;
		}

	protected function sendMobEquipment($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\MobEquipmentPacket();
			$pk = new \pocketmine\network\protocol\MobEquipmentPacket();
			$pk->eid = $this->getId();
			$pk->item = $this->getWeapon();
			$pk->slot = 0;
			$pk->selectedSlot = 0;
			$player->dataPacket($pk);
			new \pocketmine\network\protocol\MobArmorEquipmentPacket();
			$pk = new \pocketmine\network\protocol\MobArmorEquipmentPacket();
			$pk->eid = $this->getId();
			$pk->slots = $this->getArmorContents();
			$player->dataPacket($pk);
			return null;
		}

	public function getDrops() {
			/* decompiled (structured CF) */
			$rareDrops = ['__array_ptr' => '2aaaac9fc9a0'];
			$looting = $this->getLastDamageLootingLevel();
			if ((mt_rand(1, 1000) <= \pocketmine\entity\VanillaMobEquipment::rareDropChance($looting))) {
				switch (mt_rand(0, 2)) {
					case 0:
					$rareDrops[] = \pocketmine\item\Item::get(\pocketmine\item\Item::IRON_INGOT, 0, 1);
					break;
					case 1:
					$rareDrops[] = \pocketmine\item\Item::get(\pocketmine\item\Item::CARROT, 0, 1);
					break;
					case 2:
					$rareDrops[] = \pocketmine\item\Item::get(\pocketmine\item\Item::POTATO, 0, 1);
					break;
				}
			}
			$drops = [\pocketmine\item\Item::get(\pocketmine\item\Item::ROTTEN_FLESH, 0, mt_rand(0, 2))];
			$drops = \pocketmine\entity\VanillaMobEquipment::applyLootingToCommonDrops($drops, $looting);
			foreach ($rareDrops as $drop) {
				$drops[] = $drop;
				/* goto */
			}
			foreach (\pocketmine\entity\VanillaMobEquipment::maybeDropEquipment($this->getArmorContents(), $this->getWeapon(), $looting) as $drop) {
				$drops[] = $drop;
				/* goto */
			}
			return $drops;
		}

	public function isBaby() {
			/* decompiled (structured CF) */
			if (($this->namedtag['IsBaby'] == 0)) {
			} else {
			}
			return true;
		}

	public function setBaby($resting = null) {
			/* decompiled (structured CF) */
			if ($resting) {
			} else {
			}
			$this->setDataProperty(self::DATA_ZOMBIE_IS_BABY, self::DATA_TYPE_BYTE, 0);
			if ($resting) {
			} else {
			}
			new \pocketmine\nbt\tag\ByteTag('IsBaby', 0);
			$this->namedtag->IsBaby = new \pocketmine\nbt\tag\ByteTag('IsBaby', 0);
			return null;
		}

}
