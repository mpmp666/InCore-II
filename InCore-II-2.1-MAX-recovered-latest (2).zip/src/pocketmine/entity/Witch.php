<?php

namespace pocketmine\entity;

class Witch extends \pocketmine\entity\Monster {
	public const NETWORK_ID = 45;

	public $width = 0.6;
	public $length = 0.6;
	public $height = 1.8;

	public function getName() {
			return 'Witch';
		}

	public function initEntity() {
			/* decompiled (structured CF) */
			$this->setMaxHealth(26);
			new \pocketmine\entity\behavior\ShootPlayerBehavior($this, 86);
			$this->addBehavior(new \pocketmine\entity\behavior\ShootPlayerBehavior($this, 86));
			parent::initEntity();
			return null;
		}

	public function usesPm1eGroundAi() {
			return true;
		}

	public function getDrops() {
			if ((mt_rand(1, 8) == 1)) { /* unresolved jump */ }
			return ['__array_ptr' => '2aaaac9fc9a0'];
		}

	public function getXpDropAmount() {
			return 5;
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->eid = $this->getId();
			$pk->type = 45;
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->yaw = $this->yaw;
			$pk->pitch = $this->pitch;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

}
