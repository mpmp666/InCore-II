<?php

namespace pocketmine\entity;

class LeashKnot extends \pocketmine\entity\Entity {
	public const NETWORK_ID = 88;

	public $width = 0.375;
	public $length = 0.375;
	public $height = 0.5;
	public $canCollide = false;

	public function initEntity() {
			$this->setMaxHealth(1);
			parent::initEntity();
			return null;
		}

	public function getName() {
			return;
		}

	public static function isSupportedFence($block = null) {
			return ($block instanceof \pocketmine\block\Fence || $block instanceof \pocketmine\block\NetherBrickFence);
		}

	public static function getOrCreate($level = null, $fence = null) {
			/* decompiled (structured CF) */
			$knot = self::findOnFence($level, $fence);
			if ($knot instanceof \pocketmine\entity\LeashKnot) {
				return $knot;
			}
			$chunk = $level->getChunk(($fence->getX() >> 4), ($fence->getZ() >> 4), true);
			if (!($chunk instanceof \pocketmine\level\format\FullChunk)) {
			}
			new self($chunk, self::createNBT($fence));
			$knot = new self($chunk, self::createNBT($fence));
			$knot->spawnToAll();
			return $knot;
		}

	public static function findOnFence($level = null, $fence = null) {
			/* decompiled (structured CF) */
			new \pocketmine\math\AxisAlignedBB($fence->getX(), $fence->getY(), $fence->getZ(), ($fence->getX() + 1), ($fence->getY() + 1), ($fence->getZ() + 1));
			$bb = new \pocketmine\math\AxisAlignedBB($fence->getX(), $fence->getY(), $fence->getZ(), ($fence->getX() + 1), ($fence->getY() + 1), ($fence->getZ() + 1));
			foreach ($level->getNearbyEntities($bb) as $entity) {
				if (($entity instanceof \pocketmine\entity\LeashKnot && $entity->isOnFence($fence))) {
					return $entity;
				}
				/* goto */
			}
		}

	public static function createNBT($fence = null) {
			/* decompiled (structured CF) */
			new \pocketmine\nbt\tag\DoubleTag('', ($fence->getX() + 0.5));
			new \pocketmine\nbt\tag\DoubleTag('', ($fence->getY() + 0.5));
			new \pocketmine\nbt\tag\DoubleTag('', ($fence->getZ() + 0.5));
			new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', ($fence->getX() + 0.5)), new \pocketmine\nbt\tag\DoubleTag('', ($fence->getY() + 0.5)), new \pocketmine\nbt\tag\DoubleTag('', ($fence->getZ() + 0.5))]);
			new \pocketmine\nbt\tag\DoubleTag('', 0);
			new \pocketmine\nbt\tag\DoubleTag('', 0);
			new \pocketmine\nbt\tag\DoubleTag('', 0);
			new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]);
			new \pocketmine\nbt\tag\FloatTag('', 0);
			new \pocketmine\nbt\tag\FloatTag('', 0);
			new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', 0), new \pocketmine\nbt\tag\FloatTag('', 0)]);
			new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', ($fence->getX() + 0.5)), new \pocketmine\nbt\tag\DoubleTag('', ($fence->getY() + 0.5)), new \pocketmine\nbt\tag\DoubleTag('', ($fence->getZ() + 0.5))]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', 0), new \pocketmine\nbt\tag\FloatTag('', 0)])]);
			return new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', ($fence->getX() + 0.5)), new \pocketmine\nbt\tag\DoubleTag('', ($fence->getY() + 0.5)), new \pocketmine\nbt\tag\DoubleTag('', ($fence->getZ() + 0.5))]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', 0), new \pocketmine\nbt\tag\FloatTag('', 0)])]);
		}

	public function isOnFence($fence = null) {
			return ((($fence->getX() === (floor($this->x))) && ($fence->getY() === (floor($this->y)))) && ($fence->getZ() === (floor($this->z))));
		}

	protected function updateMovement() {
			return null;
		}

	public function onUpdate($currentTick = null) {
			/* decompiled (structured CF) */
			if ($this->closed) {
				return false;
			}
			new \pocketmine\math\Vector3((floor($this->x)), (floor($this->y)), (floor($this->z)));
			$block = $this->level->getBlock(new \pocketmine\math\Vector3((floor($this->x)), (floor($this->y)), (floor($this->z))));
			if (!(self::isSupportedFence($block))) {
				$this->close();
				return false;
			}
			return parent::onUpdate($currentTick);
		}

	public function attack($damage = null, $source = null) {
			/* decompiled (structured CF) */
			$result = parent::attack($damage, $source);
			if (!($source->isCancelled())) {
				$this->close();
			}
			return $result;
		}

	public function close() {
			/* decompiled (structured CF) */
			if (((!($this->closed) && ($this->level !== null)) && !($this->level->getServer()->isWorldNonLivingEntityDropsDisabled($this->level)))) {
				foreach ($this->getDrops() as $item) {
					$this->level->dropItem($this, $item);
					/* goto */
				}
			}
			parent::close();
			return null;
		}

	public function getDrops() {
			/* decompiled (structured CF) */
			$count = 0;
			if (($this->level !== null)) {
				foreach ($this->level->getEntities() as $entity) {
					if (((($entity !== $this) && $entity instanceof \pocketmine\entity\Entity) && $entity->isLeashedTo($this))) {
						$count++;
					}
					/* goto */
				}
			}
			if ((0 < $count)) {
			} else {
			}
			return ['__array_ptr' => '2aaaac9fc9a0'];
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			if (!(\pocketmine\network\protocol\ProtocolCompatibility::isProtocol015(($player->getProtocol())))) {
				return null;
			}
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->eid = $this->getId();
			$pk->type = self::NETWORK_ID;
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = 0;
			$pk->speedY = 0;
			$pk->speedZ = 0;
			$pk->yaw = 0;
			$pk->pitch = 0;
			$pk->modifiers = 0;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
		}

}
