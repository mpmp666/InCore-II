<?php

namespace pocketmine\entity;

class Creeper extends \pocketmine\entity\Monster {
	public const NETWORK_ID = 33;
	public const DATA_SWELL = 16;
	public const DATA_POWERED = 19;

	public $width = 0.6;
	public $length = 0.6;
	public $height = 1.8;
	public $dropExp = array (
  0 => 5,
  1 => 5,
);
	private $pm1eSeenTarget = NULL;
	private $pm1eBombTime = 0;
	private $forceExploding = false;

	public function getName() {
			return 'Creeper';
		}

	public function initEntity() {
			/* decompiled (structured CF) */
			$this->setMaxHealth(20);
			parent::initEntity();
			if (!(isset($this->namedtag->powered))) {
				$this->setPowered(false);
			}
			return null;
		}

	public function setPowered($powered = null, $lightning = null) {
			/* decompiled (structured CF) */
			if (($lightning != null)) {
				$powered = true;
				$cause = \pocketmine\event\entity\CreeperPowerEvent::CAUSE_LIGHTNING;
			} else {
				if ($powered) {
				} else {
				}
				$cause = \pocketmine\event\entity\CreeperPowerEvent::CAUSE_SET_OFF;
			}
			new \pocketmine\event\entity\CreeperPowerEvent($this, $lightning, $cause);
			$ev = new \pocketmine\event\entity\CreeperPowerEvent($this, $lightning, $cause);
			$this->getLevel()->getServer()->getPluginManager()->callEvent($ev);
			if (!($ev->isCancelled())) {
				if ($powered) {
				} else {
				}
				new \pocketmine\nbt\tag\ByteTag('powered', 0);
				$this->namedtag->powered = new \pocketmine\nbt\tag\ByteTag('powered', 0);
				if ($powered) {
				} else {
				}
				$this->setDataProperty(self::DATA_POWERED, self::DATA_TYPE_BYTE, 0);
			}
			return null;
		}

	public function isPowered() {
			/* decompiled (structured CF) */
			if (($this->namedtag['powered'] == 0)) {
			} else {
			}
			return true;
		}

	public function setSwelled($swelled = null) {
			/* decompiled (structured CF) */
			if ($swelled) {
			} else {
			}
			$this->setDataProperty(self::DATA_CREPPER_SWELL_DIRECTION, self::DATA_TYPE_BYTE, 0);
			if (!($swelled)) {
				$this->forceExploding = false;
				$this->setDataProperty(self::DATA_CREPPER_SWELL, self::DATA_TYPE_BYTE, 0);
				$this->setDataProperty(self::DATA_CREPPER_SWELL_2, self::DATA_TYPE_BYTE, 0);
			}
			return null;
		}

	public function isSwelled() {
			return ($this->getDataProperty(self::DATA_CREPPER_SWELL_DIRECTION) == 1);
		}

	public function onInteract($player = null, $item = null) {
			/* decompiled (structured CF) */
			if (($item->getId() !== \pocketmine\item\Item::FLINT_STEEL)) {
				return false;
			}
			$this->forceExploding = true;
			$this->setSwelled(true);
			if (($player->isSurvival() && method_exists($item, 'useOn'))) {
				$item->useOn($this, 2);
				$player->getInventory()->setItemInHand($item);
			}
			return true;
		}

	public function onUpdate($currentTick = null) {
			/* decompiled (structured CF) */
			if ($this->closed) {
				return false;
			}
			$hasUpdate = parent::onUpdate($currentTick);
			if ((!($this->closed) && $this->isAlive())) {
				$this->tickPm1eCreeperLogic();
			}
			if ($this->isSwelled()) {
				$num = $this->getDataProperty(self::DATA_CREPPER_SWELL);
				if (($num < 30)) {
					$num++;
					$this->setDataProperty(self::DATA_CREPPER_SWELL, self::DATA_TYPE_BYTE, $num);
					$this->setDataProperty(self::DATA_CREPPER_SWELL_2, self::DATA_TYPE_BYTE, $num);
				} else {
					$this->setSwelled(false);
					new \pocketmine\level\Position($this->getX(), $this->getY(), $this->getZ(), $this->getLevel());
					new \pocketmine\level\Explosion(new \pocketmine\level\Position($this->getX(), $this->getY(), $this->getZ(), $this->getLevel()), 5, $this);
					$e = new \pocketmine\level\Explosion(new \pocketmine\level\Position($this->getX(), $this->getY(), $this->getZ(), $this->getLevel()), 5, $this);
					if (($this->getLevel()->getServer()->aiConfig['creeperexplode'] && !($this->getLevel()->getServer()->isWorldCreeperBlockDamageDisabled($this->getLevel())))) {
						$e->explode();
					} else {
						$e->explodeB();
					}
					$this->getLevel()->removeEntity($this);
				}
			}
			return $hasUpdate;
		}

	public function usesPm1eGroundAi() {
			return true;
		}

	protected function tickPm1eCreeperLogic() {
			/* decompiled (structured CF) */
			if (($this->forceExploding && $this->isSwelled())) {
				$this->setPm1eFollowTarget(null);
				$this->setPm1eMoveMultiplier(1);
				return null;
			}
			$cat = $this->findPm1eCatThreat();
			if ($cat instanceof \pocketmine\entity\Ocelot) {
				$this->pm1eSeenTarget = $cat->getId();
				$this->setPm1eFollowTarget($cat);
				$this->setPm1eMoveMultiplier(-1.5);
				$this->setPm1eStayTime(0);
				$this->resetPm1eCreeperCharge();
			}
			$target = $this->findPm1eCreeperTarget();
			if ($target instanceof \pocketmine\math\Vector3) {
				$this->pm1eSeenTarget = $target->getId();
				$this->setPm1eFollowTarget($target);
				$this->setPm1eMoveMultiplier(0.4);
				$distance = $this->distanceSquared($target);
				if (($distance <= 16)) {
					if (!($this->isSwelled())) {
						$this->setSwelled(true);
					}
					if (($distance <= 1)) {
						$this->setPm1eStayTime(10);
					}
				} else {
					$this->resetPm1eCreeperCharge();
				}
			} else {
				$this->setPm1eFollowTarget(null);
				$this->setPm1eMoveMultiplier(1);
				$this->resetPm1eCreeperCharge();
			}
		}

	protected function findPm1eCatThreat($maxDistanceSquared = null) {
			/* decompiled (structured CF) */
			$level = $this->getLevel();
			if ((($level === null) || !(method_exists($level, 'getEntities')))) {
				return null;
			}
			$closest = null;
			$bestDistance = $maxDistanceSquared;
			foreach ($level->getEntities() as $entity) {
				if ((((!($entity instanceof \pocketmine\entity\Ocelot) || ($entity === $this)) || $entity->closed) || !($entity->isAlive()))) {
					/* goto */
				}
				$distance = $this->distanceSquared($entity);
				if (($distance <= $bestDistance)) {
					$bestDistance = $distance;
					$closest = $entity;
				}
				/* goto */
			}
			return $closest;
		}

	protected function findPm1eCreeperTarget() {
			return $this->findPm1eMobTarget(256);
		}

	protected function resetPm1eCreeperCharge() {
			/* decompiled (structured CF) */
			$this->pm1eBombTime = 0;
			if ($this->isSwelled()) {
				$this->setSwelled(false);
			}
			return null;
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->eid = $this->getId();
			$pk->type = 33;
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->yaw = $this->yaw;
			$pk->pitch = $this->pitch;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

	public function getDrops() {
			$drops = ['__array_ptr' => '2aaaac9fc9a0'];
			$drops[] = \pocketmine\item\Item::get(\pocketmine\item\Item::GUNPOWDER, 0, 1);
			return $drops;
		}

}
