<?php

namespace pocketmine\entity;

class Human extends \pocketmine\entity\Creature implements \pocketmine\entity\ProjectileSource, \pocketmine\inventory\InventoryHolder {
	protected $inventory = NULL;
	protected $uuid = NULL;
	protected $rawUUID = NULL;
	public $width = 0.6;
	public $length = 0.6;
	public $height = 1.8;
	public $eyeHeight = 1.62;
	protected $skinName = NULL;
	protected $skin = NULL;
	protected $foodTickTimer = 0;
	protected $totalXp = 0;
	protected $xpSeed = NULL;

	public function getSkinData() {
			return $this->skin;
		}

	public function getSkinName() {
			return $this->skinName;
		}

	public function getUniqueId() {
			return $this->uuid;
		}

	public function getRawUniqueId() {
			return $this->rawUUID;
		}

	public function setSkin($str = null, $skinName = null) {
			$this->skin = $str;
			$this->skinName = $skinName;
		}

	public function getFood() {
			return $this->attributeMap->getAttribute(\pocketmine\entity\Attribute::HUNGER)->getValue();
		}

	public function setFood($new = null) {
			/* decompiled (structured CF) */
			$attr = $this->attributeMap->getAttribute(\pocketmine\entity\Attribute::HUNGER);
			$old = $attr->getValue();
			$attr->setValue($new);
			foreach (['__array_ptr' => '2aaaaddf6a10'] as $bound) {
				if ((($bound < $old) !== ($bound < $new))) {
					$reset = true;
				}
				/* goto */
			}
			if ($t17) {
				$this->foodTickTimer = 0;
			}
			return null;
		}

	public function getMaxFood() {
			return $this->attributeMap->getAttribute(\pocketmine\entity\Attribute::HUNGER)->getMaxValue();
		}

	public function addFood($amount = null) {
			/* decompiled (structured CF) */
			$attr = $this->attributeMap->getAttribute(\pocketmine\entity\Attribute::HUNGER);
			$amount += $attr->getValue();
			$amount = max(min($amount, $attr->getMaxValue()), $attr->getMinValue());
			$this->setFood($amount);
			return null;
		}

	public function getSaturation() {
			return $this->attributeMap->getAttribute(\pocketmine\entity\Attribute::SATURATION)->getValue();
		}

	public function setSaturation($saturation = null) {
			$this->attributeMap->getAttribute(\pocketmine\entity\Attribute::SATURATION)->setValue($saturation);
			return null;
		}

	public function addSaturation($amount = null) {
			$attr = $this->attributeMap->getAttribute(\pocketmine\entity\Attribute::SATURATION);
			$attr->setValue(($attr->getValue() + $amount), true);
			return null;
		}

	public function getExhaustion() {
			return $this->attributeMap->getAttribute(\pocketmine\entity\Attribute::EXHAUSTION)->getValue();
		}

	public function setExhaustion($exhaustion = null) {
			$this->attributeMap->getAttribute(\pocketmine\entity\Attribute::EXHAUSTION)->setValue($exhaustion);
			return null;
		}

	public function exhaust($amount = null, $cause = null) {
			/* decompiled (structured CF) */
			new \pocketmine\event\player\PlayerExhaustEvent($this, $amount, $cause);
			$ev = new \pocketmine\event\player\PlayerExhaustEvent($this, $amount, $cause);
			$this->server->getPluginManager()->callEvent($ev);
			if ($ev->isCancelled()) {
				return 0;
			}
			$exhaustion = $this->getExhaustion();
			$exhaustion += $ev->getAmount();
			while ((4 <= $exhaustion)) {
				$exhaustion -= 4;
				$saturation = $this->getSaturation();
				if ((0 < $saturation)) {
					$saturation = max(0, ($saturation - 1));
					$this->setSaturation($saturation);
				} else {
					$food = $this->getFood();
					if ((0 < $food)) {
						$food--;
						$this->setFood($food);
					}
				}
			}
			$this->setExhaustion($exhaustion);
			return $ev->getAmount();
		}

	public function getXpLevel() {
			return ($this->attributeMap->getAttribute(\pocketmine\entity\Attribute::EXPERIENCE_LEVEL)->getValue());
		}

	public function setXpLevel($level = null) {
			$this->attributeMap->getAttribute(\pocketmine\entity\Attribute::EXPERIENCE_LEVEL)->setValue($level);
			return null;
		}

	public function getXpProgress() {
			return $this->attributeMap->getAttribute(\pocketmine\entity\Attribute::EXPERIENCE)->getValue();
		}

	public function setXpProgress($progress = null) {
			$this->attributeMap->getAttribute(\pocketmine\entity\Attribute::EXPERIENCE)->setValue($progress);
			return null;
		}

	public function getTotalXp() {
			return $this->totalXp;
		}

	public function getRemainderXp() {
			return ($this->getTotalXp() - self::getTotalXpForLevel($this->getXpLevel()));
		}

	public static function getTotalXpForLevel($level = null) {
			/* decompiled (structured CF) */
			if (($level <= 16)) {
				return ($t2 + ($level * 6));
			} else {
				if (($level < 32)) {
					return ((($t6 * 2.5) - ($level * 40.5)) + 360);
				}
			}
			return ((($t11 * 4.5) - ($level * 162.5)) + 2220);
		}

	public function getInventory() {
			return $this->inventory;
		}

	protected function initEntity() {
			/* decompiled (structured CF) */
			$this->setDataFlag(self::DATA_PLAYER_FLAGS, self::DATA_PLAYER_FLAG_SLEEP, false);
			$this->setDataProperty(self::DATA_PLAYER_BED_POSITION, self::DATA_TYPE_POS, ['__array_ptr' => '2aaaaddf6a48']);
			new \pocketmine\inventory\PlayerInventory($this);
			$this->inventory = new \pocketmine\inventory\PlayerInventory($this);
			if ($this instanceof \pocketmine\Player) {
				$this->addWindow($this->inventory, 0);
			} else {
				if (isset($this->namedtag->NameTag)) {
					$this->setNameTag($this->namedtag['NameTag']);
				}
				if ((isset($this->namedtag->Skin) && $this->namedtag->Skin instanceof \pocketmine\nbt\tag\CompoundTag)) {
					$this->setSkin($this->namedtag->Skin['Data'], $this->namedtag->Skin['Name']);
				}
				$this->uuid = \pocketmine\utils\UUID::fromData($this->getId(), $this->getSkinData(), $this->getNameTag());
			}
			if ((isset($this->namedtag->Inventory) && $this->namedtag->Inventory instanceof \pocketmine\nbt\tag\ListTag)) {
				foreach ($this->namedtag->Inventory as $item) {
					if (((0 <= $item['Slot']) && ($item['Slot'] < 9))) {
						if (isset($item['TrueSlot'])) {
						} else {
						}
						$this->inventory->setHotbarSlotIndex($item['Slot'], -1);
					} else {
						if (((100 <= $item['Slot']) && ($item['Slot'] < 104))) {
							$this->inventory->setItem((($this->inventory->getSize() + $item['Slot']) - 100), \pocketmine\nbt\NBT::getItemHelper($item));
						} else {
							$this->inventory->setItem(($item['Slot'] - 9), \pocketmine\nbt\NBT::getItemHelper($item));
						}
					}
					/* goto */
				}
			}
			parent::initEntity();
			if ((!(isset($this->namedtag->XpLevel)) || !($this->namedtag->XpLevel instanceof \pocketmine\nbt\tag\IntTag))) {
				new \pocketmine\nbt\tag\IntTag('XpLevel', $this->getXpLevel());
				$this->namedtag->XpLevel = new \pocketmine\nbt\tag\IntTag('XpLevel', $this->getXpLevel());
			} else {
				$this->setXpLevel($this->namedtag['XpLevel']);
			}
			if ((!(isset($this->namedtag->XpP)) || !($this->namedtag->XpP instanceof \pocketmine\nbt\tag\FloatTag))) {
				new \pocketmine\nbt\tag\FloatTag('XpP', $this->getXpProgress());
				$this->namedtag->XpP = new \pocketmine\nbt\tag\FloatTag('XpP', $this->getXpProgress());
			}
			if ((!(isset($this->namedtag->XpTotal)) || !($this->namedtag->XpTotal instanceof \pocketmine\nbt\tag\IntTag))) {
				new \pocketmine\nbt\tag\IntTag('XpTotal', $this->totalXp);
				$this->namedtag->XpTotal = new \pocketmine\nbt\tag\IntTag('XpTotal', $this->totalXp);
			} else {
				$this->totalXp = $this->namedtag['XpTotal'];
			}
			if ((!(isset($this->namedtag->XpSeed)) || !($this->namedtag->XpSeed instanceof \pocketmine\nbt\tag\IntTag))) {
				$this->xpSeed = mt_rand(\PHP_INT_MIN, \PHP_INT_MAX);
				new \pocketmine\nbt\tag\IntTag('XpSeed', $t127);
				$this->namedtag->XpSeed = new \pocketmine\nbt\tag\IntTag('XpSeed', $t127);
			} else {
				$this->xpSeed = $this->namedtag['XpSeed'];
			}
			return null;
		}

	protected function addAttributes() {
			/* decompiled (structured CF) */
			parent::addAttributes();
			$this->attributeMap->addAttribute(\pocketmine\entity\Attribute::getAttribute(\pocketmine\entity\Attribute::SATURATION));
			$this->attributeMap->addAttribute(\pocketmine\entity\Attribute::getAttribute(\pocketmine\entity\Attribute::EXHAUSTION));
			$this->attributeMap->addAttribute(\pocketmine\entity\Attribute::getAttribute(\pocketmine\entity\Attribute::HUNGER));
			$this->attributeMap->addAttribute(\pocketmine\entity\Attribute::getAttribute(\pocketmine\entity\Attribute::EXPERIENCE_LEVEL));
			$this->attributeMap->addAttribute(\pocketmine\entity\Attribute::getAttribute(\pocketmine\entity\Attribute::EXPERIENCE));
			$this->attributeMap->addAttribute(\pocketmine\entity\Attribute::getAttribute(\pocketmine\entity\Attribute::HEALTH));
			$this->attributeMap->addAttribute(\pocketmine\entity\Attribute::getAttribute(\pocketmine\entity\Attribute::MOVEMENT_SPEED));
			return null;
		}

	public function entityBaseTick($tickDiff = null) {
			$hasUpdate = parent::entityBaseTick($tickDiff);
			return $hasUpdate;
		}

	public function getName() {
			return $this->getNameTag();
		}

	public function getDrops() {
			/* decompiled (structured CF) */
			$drops = ['__array_ptr' => '2aaaac9fc9a0'];
			if (($this->inventory !== null)) {
				foreach ($this->inventory->getContents() as $item) {
					$drops[] = $item;
					/* goto */
				}
			}
			return $drops;
		}

	public function saveNBT() {
			/* decompiled (structured CF) */
			parent::saveNBT();
			new \pocketmine\nbt\tag\ListTag('Inventory', ['__array_ptr' => '2aaaac9fc9a0']);
			$this->namedtag->Inventory = new \pocketmine\nbt\tag\ListTag('Inventory', ['__array_ptr' => '2aaaac9fc9a0']);
			$this->namedtag->Inventory->setTagType(\pocketmine\nbt\NBT::TAG_Compound);
			if (($this->inventory !== null)) {
				$slot = 0;
				while (($slot < 9)) {
					$hotbarSlot = $this->inventory->getHotbarSlotIndex($slot);
					if (($hotbarSlot !== -1)) {
						$item = $this->inventory->getItem($hotbarSlot);
						if ((($item->getId() !== 0) && (0 < $item->getCount()))) {
							$tag = \pocketmine\nbt\NBT::putItemHelper($item, $slot);
							new \pocketmine\nbt\tag\ByteTag('TrueSlot', $hotbarSlot);
							$tag->TrueSlot = new \pocketmine\nbt\tag\ByteTag('TrueSlot', $hotbarSlot);
							$this->namedtag->Inventory[$slot] = $tag;
						} else {
							new \pocketmine\nbt\tag\ByteTag('Count', 0);
							new \pocketmine\nbt\tag\ShortTag('Damage', 0);
							new \pocketmine\nbt\tag\ByteTag('Slot', $slot);
							new \pocketmine\nbt\tag\ByteTag('TrueSlot', -1);
							new \pocketmine\nbt\tag\ShortTag('id', 0);
							new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ByteTag('Count', 0), new \pocketmine\nbt\tag\ShortTag('Damage', 0), new \pocketmine\nbt\tag\ByteTag('Slot', $slot), new \pocketmine\nbt\tag\ByteTag('TrueSlot', -1), new \pocketmine\nbt\tag\ShortTag('id', 0)]);
							$this->namedtag->Inventory[$slot] = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ByteTag('Count', 0), new \pocketmine\nbt\tag\ShortTag('Damage', 0), new \pocketmine\nbt\tag\ByteTag('Slot', $slot), new \pocketmine\nbt\tag\ByteTag('TrueSlot', -1), new \pocketmine\nbt\tag\ShortTag('id', 0)]);
						}
						$slot++;
						$slotCount = ($this->getLevel()->getServer()->inventoryNum + 9);
						$slot = 9;
						while (($slot < $slotCount)) {
							$item = $this->inventory->getItem(($slot - 9));
							$this->namedtag->Inventory[$slot] = \pocketmine\nbt\NBT::putItemHelper($item, $slot);
							$slot++;
						}
						$slot = 100;
						while (($slot < 104)) {
							$item = $this->inventory->getItem((($this->inventory->getSize() + $slot) - 100));
							if (($item instanceof \pocketmine\item\Item && ($item->getId() !== \pocketmine\item\Item::AIR))) {
								$this->namedtag->Inventory[$slot] = \pocketmine\nbt\NBT::putItemHelper($item, $slot);
							}
							$slot++;
						}
						if ((0 < strlen($this->getSkinData()))) {
							new \pocketmine\nbt\tag\StringTag('Data', $this->getSkinData());
							new \pocketmine\nbt\tag\StringTag('Name', $this->getSkinName());
							new \pocketmine\nbt\tag\CompoundTag('Skin', [new \pocketmine\nbt\tag\StringTag('Data', $this->getSkinData()), new \pocketmine\nbt\tag\StringTag('Name', $this->getSkinName())]);
							$this->namedtag->Skin = new \pocketmine\nbt\tag\CompoundTag('Skin', [new \pocketmine\nbt\tag\StringTag('Data', $this->getSkinData()), new \pocketmine\nbt\tag\StringTag('Name', $this->getSkinName())]);
						}
						return null;
					}
				}
			}
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			if ((($player !== $this) && !(isset($this->hasSpawned[$player->getLoaderId()])))) {
				$this->hasSpawned[$player->getLoaderId()] = $player;
				if ((strlen($this->skin) < 8192)) {
					$this->close();
				}
				if (!($this instanceof \pocketmine\Player)) {
					$this->server->updatePlayerListData($this->getUniqueId(), $this->getId(), $this->getName(), $this->skinName, $this->skin, [$player]);
				}
				new \pocketmine\network\protocol\AddPlayerPacket();
				$pk = new \pocketmine\network\protocol\AddPlayerPacket();
				$pk->uuid = $this->getUniqueId();
				$pk->username = $this->getName();
				$pk->eid = $this->getId();
				$pk->x = $this->x;
				$pk->y = $this->y;
				$pk->z = $this->z;
				$pk->speedX = $this->motionX;
				$pk->speedY = $this->motionY;
				$pk->speedZ = $this->motionZ;
				$pk->yaw = $this->yaw;
				$pk->pitch = $this->pitch;
				$pk->item = $this->getInventory()->getItemInHand();
				$pk->metadata = $this->dataProperties;
				$player->dataPacket($pk);
				$this->sendLinkedData();
				$this->inventory->sendArmorContents($player);
				if (!($this instanceof \pocketmine\Player)) {
					$this->server->removePlayerListData($this->getUniqueId(), [$player]);
				}
			}
			return null;
		}

	public function despawnFrom($player = null) {
			/* decompiled (structured CF) */
			if (isset($this->hasSpawned[$player->getLoaderId()])) {
				new \pocketmine\network\protocol\RemovePlayerPacket();
				$pk = new \pocketmine\network\protocol\RemovePlayerPacket();
				$pk->eid = $this->getId();
				$pk->clientId = $this->getUniqueId();
				$player->dataPacket($pk);
			}
			return null;
		}

	public function close() {
			/* decompiled (structured CF) */
			if (!($this->closed)) {
				if ((!($this instanceof \pocketmine\Player) || $this->loggedIn)) {
					foreach ($this->inventory->getViewers() as $viewer) {
						$viewer->removeWindow($this->inventory);
						/* goto */
					}
				}
				parent::close();
			}
			return null;
		}

}
