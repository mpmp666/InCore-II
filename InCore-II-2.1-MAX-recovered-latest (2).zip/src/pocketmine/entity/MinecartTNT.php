<?php

namespace pocketmine\entity;

class MinecartTNT extends \pocketmine\entity\Vehicle implements \pocketmine\entity\Explosive {
	public const NETWORK_ID = 97;
	public const TYPE_NORMAL = 1;
	public const TYPE_CHEST = 2;
	public const TYPE_HOPPER = 3;
	public const TYPE_TNT = 4;
	public const STATE_INITIAL = 0;
	public const STATE_ON_RAIL = 1;
	public const STATE_OFF_RAIL = 2;
	public const DATA_SWELL = 16;
	public const DATA_POWERED = 19;

	public $height = 0.7;
	public $width = 0.98;
	public $drag = 0.1;
	public $gravity = 0.5;
	public $isMoving = false;
	public $moveSpeed = 0.5;
	private $state = 0;
	private $direction = -1;
	private $moveVector = array (
);
	private $explodeOnClose = false;
	public $motionX = 0;
	public $motionY = 0;
	public $motionZ = 0;

	public function initEntity() {
			/* decompiled (structured CF) */
			$this->setMaxHealth(1);
			$this->setHealth(1);
			new \pocketmine\math\Vector3(-1, 0, 0);
			$this->moveVector[\pocketmine\entity\Entity::NORTH] = new \pocketmine\math\Vector3(-1, 0, 0);
			new \pocketmine\math\Vector3(1, 0, 0);
			$this->moveVector[\pocketmine\entity\Entity::SOUTH] = new \pocketmine\math\Vector3(1, 0, 0);
			new \pocketmine\math\Vector3(0, 0, -1);
			$this->moveVector[\pocketmine\entity\Entity::EAST] = new \pocketmine\math\Vector3(0, 0, -1);
			new \pocketmine\math\Vector3(0, 0, 1);
			$this->moveVector[\pocketmine\entity\Entity::WEST] = new \pocketmine\math\Vector3(0, 0, 1);
			parent::initEntity();
			if (!(isset($this->namedtag->powered))) {
				$this->setPowered(false);
			}
			return null;
		}

	public function setPowered($powered = null, $lightning = null) {
			/* decompiled (structured CF) */
			if (($lightning != null)) {
				$powered = true;
				$cause = \pocketmine\event\entity\CreeperPowerEvent::CAUSE_LIGHTNING;
			} else {
				if ($powered) {
				} else {
				}
				$cause = \pocketmine\event\entity\CreeperPowerEvent::CAUSE_SET_OFF;
			}
			if ($powered) {
			} else {
			}
			new \pocketmine\nbt\tag\ByteTag('powered', 0);
			$this->namedtag->powered = new \pocketmine\nbt\tag\ByteTag('powered', 0);
			if ($powered) {
			} else {
			}
			$this->setDataProperty(self::DATA_POWERED, self::DATA_TYPE_BYTE, 0);
			return null;
		}

	public function isPowered() {
			/* decompiled (structured CF) */
			if (($this->namedtag['powered'] == 0)) {
			} else {
			}
			return true;
		}

	public function setSwelled($swelled = null) {
			/* decompiled (structured CF) */
			if ($swelled) {
			} else {
			}
			$this->setDataProperty(self::DATA_CREPPER_SWELL_DIRECTION, self::DATA_TYPE_BYTE, 0);
			if (!($swelled)) {
				$this->setDataProperty(self::DATA_CREPPER_SWELL, self::DATA_TYPE_BYTE, 0);
				$this->setDataProperty(self::DATA_CREPPER_SWELL_2, self::DATA_TYPE_BYTE, 0);
			}
			return null;
		}

	public function isSwelled() {
			return ($this->getDataProperty(self::DATA_CREPPER_SWELL_DIRECTION) == 1);
		}

	protected function activateByRail($rail = null, $active = null) {
			$this->setSwelled(true);
			return null;
		}

	public function explode() {
			/* decompiled (structured CF) */
			if ($this->closed) {
				return null;
			}
			if (!($this->server->tntExplosionEnabled)) {
			}
			new \pocketmine\event\entity\ExplosionPrimeEvent($this, 5);
			$ev = new \pocketmine\event\entity\ExplosionPrimeEvent($this, 5);
			$this->server->getPluginManager()->callEvent($ev);
			if (!($ev->isCancelled())) {
				new \pocketmine\level\Position($this->getX(), $this->getY(), $this->getZ(), $this->getLevel());
				new \pocketmine\level\Explosion(new \pocketmine\level\Position($this->getX(), $this->getY(), $this->getZ(), $this->getLevel()), $ev->getForce(), $this);
				$explosion = new \pocketmine\level\Explosion(new \pocketmine\level\Position($this->getX(), $this->getY(), $this->getZ(), $this->getLevel()), $ev->getForce(), $this);
				if (((!($this->server->isWorldTntBlockDamageDisabled($this->getLevel())) && $this->server->getConfigString('use-tnt')) && $ev->isBlockBreaking())) {
					$explosion->explodeA();
				}
				$explosion->explodeB();
			}
			$this->explodeOnClose = true;
			$this->close();
		}

	public function canBeRidden() {
			return false;
		}

	public function getName() {
			return;
		}

	public function getType() {
			return self::TYPE_TNT;
		}

	public function onUpdate($currentTick = null) {
			/* decompiled (structured CF) */
			if (($this->closed !== false)) {
				return false;
			}
			$tickDiff = ($currentTick - $this->lastUpdate);
			if (($tickDiff <= 1)) {
				return false;
			}
			$this->lastUpdate = $currentTick;
			$this->timings->startTiming();
			$hasUpdate = false;
			if (($this->state === 0)) {
				$this->checkIfOnRail();
			} else {
				if (($this->state === 1)) {
					$hasUpdate = $this->forwardOnRail($this);
					$this->updateMovement();
				}
			}
			$this->timings->stopTiming();
			if ($this->isSwelled()) {
				$hasUpdate = true;
				$num = $this->getDataProperty(self::DATA_CREPPER_SWELL);
				if (($num < 20)) {
					$num++;
					$this->setDataProperty(self::DATA_CREPPER_SWELL, self::DATA_TYPE_BYTE, $num);
					$this->setDataProperty(self::DATA_CREPPER_SWELL_2, self::DATA_TYPE_BYTE, $num);
					new \pocketmine\math\Vector3($this->getX(), $this->getY(), $this->getZ());
					new \pocketmine\level\particle\AngryVillagerParticle(new \pocketmine\math\Vector3($this->getX(), $this->getY(), $this->getZ()));
					$particle = new \pocketmine\level\particle\AngryVillagerParticle(new \pocketmine\math\Vector3($this->getX(), $this->getY(), $this->getZ()));
					$this->getLevel()->addParticle($particle);
					new \pocketmine\math\Vector3($this->getX(), ($this->getY() + 1), $this->getZ());
					new \pocketmine\level\particle\AngryVillagerParticle(new \pocketmine\math\Vector3($this->getX(), ($this->getY() + 1), $this->getZ()));
					$particle = new \pocketmine\level\particle\AngryVillagerParticle(new \pocketmine\math\Vector3($this->getX(), ($this->getY() + 1), $this->getZ()));
					$this->getLevel()->addParticle($particle);
					new \pocketmine\math\Vector3($this->getX(), $this->getY(), ($this->getZ() + 1));
					new \pocketmine\level\particle\AngryVillagerParticle(new \pocketmine\math\Vector3($this->getX(), $this->getY(), ($this->getZ() + 1)));
					$particle = new \pocketmine\level\particle\AngryVillagerParticle(new \pocketmine\math\Vector3($this->getX(), $this->getY(), ($this->getZ() + 1)));
					$this->getLevel()->addParticle($particle);
					new \pocketmine\math\Vector3(($this->getX() + 1), $this->getY(), $this->getZ());
					new \pocketmine\level\particle\AngryVillagerParticle(new \pocketmine\math\Vector3(($this->getX() + 1), $this->getY(), $this->getZ()));
					$particle = new \pocketmine\level\particle\AngryVillagerParticle(new \pocketmine\math\Vector3(($this->getX() + 1), $this->getY(), $this->getZ()));
					$this->getLevel()->addParticle($particle);
				} else {
					$this->setSwelled(false);
					$this->explode();
				}
			}
			return (((($hasUpdate || !($this->onGround)) || (1e-05 < abs($this->motionX))) || (1e-05 < abs($this->motionY))) || (1e-05 < abs($this->motionZ)));
		}

	private function checkIfOnRail() {
			/* decompiled (structured CF) */
			$y = -1;
			while (($this->state === 0)) {
				$positionToCheck = $this->temporalVector->setComponents($this->x, ($this->y + $y), $this->z);
				$block = $this->level->getBlock($positionToCheck);
				if ($this->isRail($block)) {
					$minecartPosition = $positionToCheck->floor()->add(0.5, 0.75, 0.5);
					$this->setPosition($minecartPosition);
					$this->state = 1;
				}
				$y++;
			}
			if (($this->state !== 1)) {
				$this->state = 2;
			}
			return null;
		}

	private function isRail($rail = null) {
			return (($rail !== null) && in_array($rail->getId(), [\pocketmine\block\Block::RAIL, \pocketmine\block\Block::ACTIVATOR_RAIL, \pocketmine\block\Block::DETECTOR_RAIL, \pocketmine\block\Block::POWERED_RAIL]));
		}

	private function getCurrentRail() {
			/* decompiled (structured CF) */
			$block = $this->getLevel()->getBlock($this);
			if ($this->isRail($block)) {
				return $block;
			}
			$down = $this->temporalVector->setComponents($this->x, ($this->y - 1), $this->z);
			$block = $this->getLevel()->getBlock($down);
			if ($this->isRail($block)) {
				return $block;
			}
		}

	private function forwardOnRail($player = null) {
			/* decompiled (structured CF) */
			if (($this->direction === -1)) {
				$candidateDirection = $player->getDirection();
			} else {
				$candidateDirection = $this->direction;
			}
			$rail = $this->getCurrentRail();
			if (($rail !== null)) {
				$this->applyRailEffects($rail);
				$railType = $rail->getRealMeta();
				$nextDirection = $this->getDirectionToMove($railType, $candidateDirection);
				if (($nextDirection !== -1)) {
					$this->direction = $nextDirection;
					$moved = $this->checkForVertical($railType, $nextDirection);
					if (!($moved)) {
						return $this->moveIfRail();
					} else {
						return true;
					}
				} else {
					$this->direction = -1;
				}
			} else {
				$this->state = 0;
			}
			return false;
		}

	private function getDirectionToMove($railType = null, $candidateDirection = null) {
			/* decompiled (structured CF) */
			if (!(($railType == \pocketmine\block\Rail::STRAIGHT_NORTH_SOUTH))) {
				if (!(($railType == \pocketmine\block\Rail::SLOPED_ASCENDING_NORTH))) {
					if (!(($railType == \pocketmine\block\Rail::SLOPED_ASCENDING_SOUTH))) {
						if (!(($railType == \pocketmine\block\Rail::STRAIGHT_EAST_WEST))) {
							if (!(($railType == \pocketmine\block\Rail::SLOPED_ASCENDING_EAST))) {
								if (!(($railType == \pocketmine\block\Rail::SLOPED_ASCENDING_WEST))) {
									if (!(($railType == \pocketmine\block\Rail::CURVED_SOUTH_EAST))) {
										if (!(($railType == \pocketmine\block\Rail::CURVED_SOUTH_WEST))) {
											if (!(($railType == \pocketmine\block\Rail::CURVED_NORTH_WEST))) {
												if (!(($railType == \pocketmine\block\Rail::CURVED_NORTH_EAST))) {
												} else {
													if (!(($candidateDirection == \pocketmine\entity\Entity::NORTH))) {
														if (!(($candidateDirection == \pocketmine\entity\Entity::SOUTH))) {
														} else {
															return $candidateDirection;
														}
														/* jump */
														if (!(($candidateDirection == \pocketmine\entity\Entity::WEST))) {
															if (!(($candidateDirection == \pocketmine\entity\Entity::EAST))) {
															} else {
																return $candidateDirection;
															}
															/* jump */
															if (!(($candidateDirection == \pocketmine\entity\Entity::SOUTH))) {
																if (!(($candidateDirection == \pocketmine\entity\Entity::EAST))) {
																	if (!(($candidateDirection == \pocketmine\entity\Entity::NORTH))) {
																		if (!(($candidateDirection == \pocketmine\entity\Entity::WEST))) {
																			/* jump */
																			return $candidateDirection;
																		}
																	}
																	return $this->checkForTurn($candidateDirection, \pocketmine\entity\Entity::SOUTH);
																	/* jump */
																	if (!(($candidateDirection == \pocketmine\entity\Entity::SOUTH))) {
																		if (!(($candidateDirection == \pocketmine\entity\Entity::WEST))) {
																			if (!(($candidateDirection == \pocketmine\entity\Entity::NORTH))) {
																				if (!(($candidateDirection == \pocketmine\entity\Entity::EAST))) {
																					/* jump */
																					return $candidateDirection;
																				}
																			}
																			return $this->checkForTurn($candidateDirection, \pocketmine\entity\Entity::SOUTH);
																			/* jump */
																			if (!(($candidateDirection == \pocketmine\entity\Entity::NORTH))) {
																				if (!(($candidateDirection == \pocketmine\entity\Entity::WEST))) {
																					if (!(($candidateDirection == \pocketmine\entity\Entity::SOUTH))) {
																						if (!(($candidateDirection == \pocketmine\entity\Entity::EAST))) {
																							/* jump */
																							return $candidateDirection;
																						}
																					}
																					return $this->checkForTurn($candidateDirection, \pocketmine\entity\Entity::NORTH);
																					/* jump */
																					if (!(($candidateDirection == \pocketmine\entity\Entity::NORTH))) {
																						if (!(($candidateDirection == \pocketmine\entity\Entity::EAST))) {
																							if (!(($candidateDirection == \pocketmine\entity\Entity::SOUTH))) {
																								if (!(($candidateDirection == \pocketmine\entity\Entity::WEST))) {
																									/* jump */
																									return $candidateDirection;
																								}
																							}
																							return $this->checkForTurn($candidateDirection, \pocketmine\entity\Entity::NORTH);
																							/* jump */
																							return -1;
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

	private function checkForTurn($currentDirection = null, $newDirection = null) {
			/* decompiled (structured CF) */
			if (!(($currentDirection == \pocketmine\entity\Entity::NORTH))) {
				if (!(($currentDirection == \pocketmine\entity\Entity::SOUTH))) {
					if (!(($currentDirection == \pocketmine\entity\Entity::EAST))) {
						if (!(($currentDirection == \pocketmine\entity\Entity::WEST))) {
						} else {
							$diff = ($this->x - $this->getFloorX());
							if ((($diff !== 0) && ($diff <= 0.5))) {
								$dx = (($this->getFloorX() + 0.5) - $this->x);
								$this->move($dx, 0, 0);
								return $newDirection;
							}
							/* jump */
							$diff = ($this->x - $this->getFloorX());
							if ((($diff !== 0) && (0.5 <= $diff))) {
								$dx = (($this->getFloorX() + 0.5) - $this->x);
								$this->move($dx, 0, 0);
								return $newDirection;
							}
							/* jump */
							$diff = ($this->z - $this->getFloorZ());
							if ((($diff !== 0) && ($diff <= 0.5))) {
								$dz = (($this->getFloorZ() + 0.5) - $this->z);
								$this->move(0, 0, $dz);
								return $newDirection;
							}
							/* jump */
							$diff = ($this->z - $this->getFloorZ());
							if ((($diff !== 0) && (0.5 <= $diff))) {
								$dz = (($this->getFloorZ() + 0.5) - $this->z);
								$dz = $dz;
								$this->move(0, 0, $dz);
								return $newDirection;
							}
							/* jump */
						}
						return $currentDirection;
					}
				}
			}
		}

	private function checkForVertical($railType = null, $currentDirection = null) {
			/* decompiled (structured CF) */
			if (!(($railType == \pocketmine\block\Rail::SLOPED_ASCENDING_NORTH))) {
				if (!(($railType == \pocketmine\block\Rail::SLOPED_ASCENDING_SOUTH))) {
					if (!(($railType == \pocketmine\block\Rail::SLOPED_ASCENDING_EAST))) {
						if (!(($railType == \pocketmine\block\Rail::SLOPED_ASCENDING_WEST))) {
						} else {
							if (!(($currentDirection == \pocketmine\entity\Entity::NORTH))) {
								if (!(($currentDirection == \pocketmine\entity\Entity::SOUTH))) {
								} else {
									$diff = ($this->x - $this->getFloorX());
									if ((($diff !== 0) && ($diff <= 0.5))) {
										$dx = (($this->getFloorX() - 0.1) - $this->x);
										$this->move($dx, -1, 0);
										return true;
									}
									/* jump */
									$diff = ($this->x - $this->getFloorX());
									if ((($diff !== 0) && (0.5 <= $diff))) {
										$dx = (($this->getFloorX() + 1) - $this->x);
										$this->move($dx, 1, 0);
										return true;
									}
									/* jump */
								}
								/* jump */
								if (!(($currentDirection == \pocketmine\entity\Entity::SOUTH))) {
									if (!(($currentDirection == \pocketmine\entity\Entity::NORTH))) {
									} else {
										$diff = ($this->x - $this->getFloorX());
										if ((($diff !== 0) && (0.5 <= $diff))) {
											$dx = (($this->getFloorX() + 1) - $this->x);
											$this->move($dx, -1, 0);
											return true;
										}
										/* jump */
										$diff = ($this->x - $this->getFloorX());
										if ((($diff !== 0) && ($diff <= 0.5))) {
											$dx = (($this->getFloorX() - 0.1) - $this->x);
											$this->move($dx, 1, 0);
											return true;
										}
										/* jump */
									}
									/* jump */
									if (!(($currentDirection == \pocketmine\entity\Entity::EAST))) {
										if (!(($currentDirection == \pocketmine\entity\Entity::WEST))) {
										} else {
											$diff = ($this->z - $this->getFloorZ());
											if ((($diff !== 0) && ($diff <= 0.5))) {
												$dz = (($this->getFloorZ() - 0.1) - $this->z);
												$this->move(0, 1, $dz);
												return true;
											}
											/* jump */
											$diff = ($this->z - $this->getFloorZ());
											if ((($diff !== 0) && (0.5 <= $diff))) {
												$dz = (($this->getFloorZ() + 1) - $this->z);
												$this->move(0, -1, $dz);
												return true;
											}
											/* jump */
										}
										/* jump */
										if (!(($currentDirection == \pocketmine\entity\Entity::WEST))) {
											if (!(($currentDirection == \pocketmine\entity\Entity::EAST))) {
											} else {
												$diff = ($this->z - $this->getFloorZ());
												if ((($diff !== 0) && (0.5 <= $diff))) {
													$dz = (($this->getFloorZ() + 1) - $this->z);
													$this->move(0, 1, $dz);
													return true;
												}
												/* jump */
												$diff = ($this->z - $this->getFloorZ());
												if ((($diff !== 0) && ($diff <= 0.5))) {
													$dz = (($this->getFloorZ() - 0.1) - $this->z);
													$this->move(0, -1, $dz);
													return true;
												}
												/* jump */
											}
											/* jump */
											return false;
										}
									}
								}
							}
						}
					}
				}
			}
		}

	private function moveIfRail() {
			/* decompiled (structured CF) */
			$nextMoveVector = $this->moveVector[$this->direction];
			$nextMoveVector = $nextMoveVector->multiply($this->moveSpeed);
			$newVector = $this->add($nextMoveVector->x, $nextMoveVector->y, $nextMoveVector->z);
			$possibleRail = $this->getCurrentRail();
			if (in_array($possibleRail->getId(), [\pocketmine\block\Block::RAIL, \pocketmine\block\Block::ACTIVATOR_RAIL, \pocketmine\block\Block::DETECTOR_RAIL, \pocketmine\block\Block::POWERED_RAIL])) {
				$this->moveUsingVector($newVector);
				return true;
			}
			return false;
		}

	private function moveUsingVector($desiredPosition = null) {
			/* decompiled (structured CF) */
			$dx = ($desiredPosition->x - $this->x);
			$dy = ($desiredPosition->y - $this->y);
			$dz = ($desiredPosition->z - $this->z);
			$this->move($dx, $dy, $dz);
			return null;
		}

	public function getNearestRail() {
			/* decompiled (structured CF) */
			$minX = \pocketmine\math\Math::floorFloat($this->boundingBox->minX);
			$minY = \pocketmine\math\Math::floorFloat($this->boundingBox->minY);
			$minZ = \pocketmine\math\Math::floorFloat($this->boundingBox->minZ);
			$maxX = \pocketmine\math\Math::ceilFloat($this->boundingBox->maxX);
			$maxY = \pocketmine\math\Math::ceilFloat($this->boundingBox->maxY);
			$maxZ = \pocketmine\math\Math::ceilFloat($this->boundingBox->maxZ);
			$rails = ['__array_ptr' => '2aaaac9fc9a0'];
			$z = $minZ;
			while (($z <= $maxZ)) {
				$x = $minX;
				while (($x <= $maxX)) {
					$y = $minY;
					while (($y <= $maxY)) {
						$block = $this->level->getBlock($this->temporalVector->setComponents($x, $y, $z));
						if (in_array($block->getId(), [\pocketmine\block\Block::RAIL, \pocketmine\block\Block::ACTIVATOR_RAIL, \pocketmine\block\Block::DETECTOR_RAIL, \pocketmine\block\Block::POWERED_RAIL])) {
							$rails[] = $block;
						}
						$y++;
					}
					$x++;
				}
				$z++;
			}
			$minDistance = \PHP_INT_MAX;
			$nearestRail = null;
			foreach ($rails as $rail) {
				$dis = $this->distance($rail);
				if (($dis < $minDistance)) {
					$nearestRail = $rail;
					$minDistance = $dis;
				}
				/* goto */
			}
			return $nearestRail;
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->eid = $this->getId();
			$pk->type = 97;
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = 0;
			$pk->speedY = 0;
			$pk->speedZ = 0;
			$pk->yaw = 0;
			$pk->pitch = 0;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

	public function attack($damage = null, $source = null) {
			/* decompiled (structured CF) */
			parent::attack($damage, $source);
			if (!($source->isCancelled())) {
				new \pocketmine\network\protocol\EntityEventPacket();
				$pk = new \pocketmine\network\protocol\EntityEventPacket();
				$pk->eid = $this->id;
				$pk->event = \pocketmine\network\protocol\EntityEventPacket::HURT_ANIMATION;
				foreach ($this->getLevel()->getPlayers() as $player) {
					$player->dataPacket($pk);
					/* goto */
				}
			}
			return null;
		}

	public function getDrops() {
			return [\pocketmine\item\Item::get(\pocketmine\item\Item::MINECART_WITH_TNT, 0, 1)];
		}

	public function getSaveId() {
			new \ReflectionClass($t2);
			$class = new \ReflectionClass($t2);
			return $class->getShortName();
		}

	public function close() {
			/* decompiled (structured CF) */
			if (!($this->closed)) {
				if ($this->explodeOnClose) {
					parent::close();
					return null;
				}
				if (!($this->getLevel()->getServer()->isWorldNonLivingEntityDropsDisabled($this->getLevel()))) {
					foreach ($this->getDrops() as $item) {
						$this->getLevel()->dropItem($this, $item);
						/* goto */
					}
				}
			}
			parent::close();
		}

}
