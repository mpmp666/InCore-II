<?php

namespace pocketmine\entity;

abstract class Animal extends \pocketmine\entity\Mob implements \pocketmine\entity\Ageable {
	public function initEntity() {
			/* decompiled (structured CF) */
			parent::initEntity();
			if (!(isset($this->namedtag->IsBaby))) {
				new \pocketmine\nbt\tag\ByteTag('IsBaby', 1);
				$this->namedtag->IsBaby = new \pocketmine\nbt\tag\ByteTag('IsBaby', 1);
				$this->setBaby(false);
			}
			$this->setBaby($this->isBaby());
			return null;
		}

	public function isBaby() {
			/* decompiled (structured CF) */
			if (($this->namedtag['IsBaby'] == 0)) {
			} else {
			}
			return true;
		}

	public function setBaby($resting = null) {
			/* decompiled (structured CF) */
			if ($resting) {
			} else {
			}
			$this->setDataProperty(self::DATA_IS_BABY, self::DATA_TYPE_BYTE, 0);
			if ($resting) {
			} else {
			}
			new \pocketmine\nbt\tag\ByteTag('IsBaby', 0);
			$this->namedtag->IsBaby = new \pocketmine\nbt\tag\ByteTag('IsBaby', 0);
			return null;
		}

	public function isInLove() {
			return ($this->getDataProperty(self::DATA_IN_LOVE) === 1);
		}

	public function setInLove($resting = null) {
			/* decompiled (structured CF) */
			if ($resting) {
			} else {
			}
			$this->setDataProperty(self::DATA_IN_LOVE, self::DATA_TYPE_BYTE, 0);
			return null;
		}

	public function onInteract($player = null, $item = null) {
			/* decompiled (structured CF) */
			if ($item instanceof \pocketmine\item\Lead) {
				return $item->leashEntity($player, $this);
			}
			return false;
		}

	public function canBreedWith($item = null) {
			return in_array($item->getId(), $this->getBreedingItemIds(), true);
		}

	protected function getBreedingItemIds() {
			return ['__array_ptr' => '2aaaac9fc9a0'];
		}

	protected function replaceInteractionItem($player = null, $source = null, $result = null) {
			/* decompiled (structured CF) */
			if ($player->isCreative()) {
				return true;
			}
			$inventory = $player->getInventory();
			if (($source->getCount() <= 1)) {
				$inventory->setItemInHand($result);
				return true;
			}
			$source->setCount(($source->getCount() - 1));
			$inventory->setItemInHand($source);
			$leftovers = $inventory->addItem($result);
			if ((0 < count($leftovers))) {
				$level = $player->getLevel();
				if ((($level !== null) && method_exists($level, 'dropItem'))) {
					foreach ($leftovers as $leftover) {
						$level->dropItem($player, $leftover);
						/* goto */
					}
				}
			}
			return true;
		}

}
