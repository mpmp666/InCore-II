<?php

namespace pocketmine\entity;

abstract class Creature extends \pocketmine\entity\Living {
	public $attackingTick = 0;

	public function onUpdate($tick = null) {
			/* decompiled (structured CF) */
			if (($this instanceof \pocketmine\entity\Mob && $this->usesPm1eGroundAi())) {
				return parent::onUpdate($tick);
			}
			if (!($this instanceof \pocketmine\entity\Human)) {
				if ((0 < $this->attackingTick)) {
				}
				if ((!($this->isAlive()) && $this->hasSpawned)) {
					if ((20 <= $this->deadTicks)) {
						$this->despawnFromAll();
					}
					return true;
				}
				if ($this->isAlive()) {
					$this->motionY -= $this->gravity;
					$this->move($this->motionX, $this->motionY, $this->motionZ);
					$friction = (1 - $this->drag);
					if (($this->onGround && ((1e-05 < abs($this->motionX)) || (1e-05 < abs($this->motionZ))))) {
						$friction = ($friction * $this->getLevel()->getBlock($this->temporalVector->setComponents((floor($this->x)), (floor(($this->y - 1))), ((floor($this->z)) - 1)))->getFrictionFactor());
					}
					$this->motionX *= $friction;
					$this->motionY *= (1 - $this->drag);
					$this->motionZ *= $friction;
					if ($this->onGround) {
						$this->motionY *= -0.5;
					}
					$this->updateMovement();
				}
			}
			parent::entityBaseTick();
			return parent::onUpdate($tick);
		}

	public function willMove($distance = null) {
			/* decompiled (structured CF) */
			foreach ($this->getViewers() as $viewer) {
				if (($this->distance($viewer->getLocation()) <= $distance)) {
					return true;
				}
				/* goto */
			}
			return false;
		}

	public function attack($damage = null, $source = null) {
			/* decompiled (structured CF) */
			$result = parent::attack($damage, $source);
			if ((!($source->isCancelled()) && ($source->getCause() == \pocketmine\event\entity\EntityDamageEvent::CAUSE_ENTITY_ATTACK))) {
				$this->attackingTick = 20;
			}
			return $result;
		}

	public function ifjump($level = null, $v3 = null, $hate = null, $reason = null) {
			/* decompiled (structured CF) */
			$x = floor($v3->getX());
			$y = floor($v3->getY());
			$z = floor($v3->getZ());
			new \pocketmine\math\Vector3($x, $y, $z);
			if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, $y, $z)) == 'air')) {
				new \pocketmine\math\Vector3($x, ($y - 1), $z);
				new \pocketmine\math\Vector3($x, ($y - 1), $z);
				if ((($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y - 1), $z)) == 'block') || (new \pocketmine\math\Vector3($x, ($y - 1), $z) == 'climb'))) {
					new \pocketmine\math\Vector3($x, ($y + 1), $z);
					new \pocketmine\math\Vector3($x, ($y + 1), $z);
					new \pocketmine\math\Vector3($x, ($y + 1), $z);
					if (((($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y + 1), $z)) == 'block') || ($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y + 1), $z)) == 'half')) || ($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y + 1), $z)) == 'high'))) {
						if ($reason) {
							return 'up!';
						}
						return false;
					} else {
						if ($reason) {
							return 'GO';
						}
						return $y;
					}
				} else {
					new \pocketmine\math\Vector3($x, ($y - 1), $z);
					if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y - 1), $z)) == 'water')) {
						if ($reason) {
							return 'swim';
						}
						return ($y - 1);
					} else {
						new \pocketmine\math\Vector3($x, ($y - 1), $z);
						if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y - 1), $z)) == 'half')) {
							if ($reason) {
								return 'half';
							}
							return ($y - 0.5);
						} else {
							new \pocketmine\math\Vector3($x, ($y - 1), $z);
							if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y - 1), $z)) == 'lava')) {
								if ($reason) {
									return 'lava';
								}
								return false;
							} else {
								new \pocketmine\math\Vector3($x, ($y - 1), $z);
								if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y - 1), $z)) == 'air')) {
									new \pocketmine\math\Vector3($x, ($y - 2), $z);
									if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y - 2), $z)) == 'block')) {
										if ($reason) {
											return 'down';
										}
										return ($y - 1);
									} else {
										if ($reason) {
											return 'fall';
										}
										if (($hate === false)) {
											return false;
										} else {
											return ($y - 1);
										}
									}
								}
							}
						}
					}
				}
			} else {
				new \pocketmine\math\Vector3($x, $y, $z);
				if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, $y, $z)) == 'water')) {
					new \pocketmine\math\Vector3($x, ($y + 1), $z);
					if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y + 1), $z)) == 'water')) {
						if ($reason) {
							return 'inwater';
						}
						return ($y + 1);
					} else {
						new \pocketmine\math\Vector3($x, ($y + 1), $z);
						new \pocketmine\math\Vector3($x, ($y + 1), $z);
						if ((($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y + 1), $z)) == 'block') || ($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y + 1), $z)) == 'half'))) {
							new \pocketmine\math\Vector3($x, ($y - 1), $z);
							new \pocketmine\math\Vector3($x, ($y - 1), $z);
							if ((($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y - 1), $z)) == 'block') || ($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y - 1), $z)) == 'half'))) {
								if ($reason) {
									return 'up!_down!';
								}
								return false;
							} else {
								if ($reason) {
									return 'up!';
								}
								return ($y - 1);
							}
						} else {
							if ($reason) {
								return 'swim...';
							}
							return $y;
						}
					}
				} else {
					new \pocketmine\math\Vector3($x, $y, $z);
					if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, $y, $z)) == 'half')) {
						new \pocketmine\math\Vector3($x, ($y + 1), $z);
						new \pocketmine\math\Vector3($x, ($y + 1), $z);
						new \pocketmine\math\Vector3($x, ($y + 1), $z);
						if (((($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y + 1), $z)) == 'block') || ($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y + 1), $z)) == 'half')) || ($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y + 1), $z)) == 'high'))) {
						} else {
							if ($reason) {
								return 'halfGO';
							}
							return ($y + 0.5);
						}
					} else {
						new \pocketmine\math\Vector3($x, $y, $z);
						if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, $y, $z)) == 'lava')) {
							if ($reason) {
								return 'lava';
							}
							return false;
						} else {
							new \pocketmine\math\Vector3($x, $y, $z);
							if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, $y, $z)) == 'high')) {
								if ($reason) {
									return 'high';
								}
								return false;
							} else {
								new \pocketmine\math\Vector3($x, $y, $z);
								if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, $y, $z)) == 'climb')) {
									if ($reason) {
										return 'climb';
									}
									if ($hate) {
										return ($y + 0.7);
									} else {
										return ($y + 0.5);
									}
								} else {
									new \pocketmine\math\Vector3($x, ($y + 1), $z);
									if (($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y + 1), $z)) != 'air')) {
										if ($reason) {
											return 'wall';
										}
										return false;
									} else {
										new \pocketmine\math\Vector3($x, ($y + 2), $z);
										new \pocketmine\math\Vector3($x, ($y + 2), $z);
										new \pocketmine\math\Vector3($x, ($y + 2), $z);
										if (((($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y + 2), $z)) == 'block') || ($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y + 2), $z)) == 'half')) || ($this->whatBlock($level, new \pocketmine\math\Vector3($x, ($y + 2), $z)) == 'high'))) {
											if ($reason) {
												return 'up2!';
											}
											return false;
										} else {
											if ($reason) {
												return 'upGO';
											}
											return ($y + 1);
										}
									}
								}
							}
						}
					}
				}
			}
			return false;
		}

	public function whatBlock($level = null, $v3 = null) {
			/* decompiled (structured CF) */
			$id = $level->getBlockIdAt($v3->x, $v3->y, $v3->z);
			$damage = $level->getBlockDataAt($v3->x, $v3->y, $v3->z);
			if (!(($id == 0))) {
				if (!(($id == 6))) {
					if (!(($id == 27))) {
						if (!(($id == 30))) {
							if (!(($id == 31))) {
								if (!(($id == 37))) {
									if (!(($id == 38))) {
										if (!(($id == 39))) {
											if (!(($id == 40))) {
												if (!(($id == 50))) {
													if (!(($id == 51))) {
														if (!(($id == 63))) {
															if (!(($id == 66))) {
																if (!(($id == 68))) {
																	if (!(($id == 78))) {
																		if (!(($id == 111))) {
																			if (!(($id == 141))) {
																				if (!(($id == 142))) {
																					if (!(($id == 171))) {
																						if (!(($id == 175))) {
																							if (!(($id == 244))) {
																								if (!(($id == 323))) {
																									if (!(($id == 8))) {
																										if (!(($id == 9))) {
																											if (!(($id == 10))) {
																												if (!(($id == 11))) {
																													if (!(($id == 44))) {
																														if (!(($id == 158))) {
																															if (!(($id == 64))) {
																																if (!(($id == 85))) {
																																	if (!(($id == 107))) {
																																		if (!(($id == 113))) {
																																			if (!(($id == 139))) {
																																				if (!(($id == 183))) {
																																					if (!(($id == 184))) {
																																						if (!(($id == 185))) {
																																							if (!(($id == 186))) {
																																								if (!(($id == 187))) {
																																									if (!(($id == 65))) {
																																										if (!(($id == 106))) {
																																											/* jump */
																																											return 'air';
																																										} else {
																																											return 'water';
																																											/* jump */
																																											return 'lava';
																																											/* jump */
																																											if ((8 <= $damage)) {
																																												return 'block';
																																											} else {
																																												return 'half';
																																											}
																																											/* jump */
																																											if ((($damage & 8) === 8)) {
																																												return 'air';
																																											} else {
																																												return 'block';
																																											}
																																											/* jump */
																																											return 'high';
																																											/* jump */
																																											return 'climb';
																																											/* jump */
																																											return 'block';
																																											/* jump */
																																										}
																																									}
																																								}
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

	public function getMyYaw($mx = null, $mz = null) {
			/* decompiled (structured CF) */
			if (($mz == 0)) {
				if (($mx < 0)) {
					$yaw = -90;
				} else {
					$yaw = 90;
				}
			} else {
				if (((0 <= $mx) && (0 < $mz))) {
					$atan = atan(($mx / $mz));
					$yaw = rad2deg($atan);
				} else {
					if (((0 <= $mx) && ($mz < 0))) {
						$atan = atan(($mx / abs($mz)));
						$yaw = (180 - rad2deg($atan));
					} else {
						if ((($mx < 0) && ($mz < 0))) {
							$atan = atan(($mx / $mz));
							$yaw = ((180 - rad2deg($atan)) * -1);
						} else {
							if ((($mx < 0) && (0 < $mz))) {
								$atan = atan((abs($mx) / $mz));
								$yaw = (rad2deg($atan) * -1);
							} else {
								$yaw = 0;
							}
						}
					}
				}
			}
			$yaw = ($yaw * -1);
			return $yaw;
		}

	public function getMyPitch($from = null, $to = null) {
			/* decompiled (structured CF) */
			$distance = $from->distance($to);
			$height = ($to->y - $from->y);
			if ((0 < $height)) {
				return (rad2deg(asin(($height / $distance))) * -1);
			} else {
				if (($height < 0)) {
					return rad2deg(asin((($height * -1) / $distance)));
				} else {
					return 0;
				}
			}
		}

}
