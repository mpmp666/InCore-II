<?php

namespace pocketmine\entity;

class SmallFireball extends \pocketmine\entity\Projectile {
	public const NETWORK_ID = 94;

	public $width = 0.3125;
	public $length = 0.3125;
	public $height = 0.3125;
	protected $gravity = 0.0;
	protected $drag = 0.01;
	protected $damage = 2;

	public function __construct($chunk = null, $nbt = null, $shootingEntity = null) {
			parent::__construct($chunk, $nbt, $shootingEntity);
			return;
		}

	protected function initEntity() {
			/* decompiled (structured CF) */
			parent::initEntity();
			if (isset($this->namedtag->damage)) {
				$this->damage = ($this->namedtag['damage']);
			}
			return null;
		}

	public function onUpdate($currentTick = null) {
			/* decompiled (structured CF) */
			if ($this->closed) {
				return false;
			}
			$this->timings->startTiming();
			$hasUpdate = parent::onUpdate($currentTick);
			if (((1200 < $this->age) || $this->isCollided)) {
				$this->kill();
				$hasUpdate = true;
			}
			$this->timings->stopTiming();
			return $hasUpdate;
		}

	protected function onHitEntity($entityHit = null) {
			/* decompiled (structured CF) */
			$hit = parent::onHitEntity($entityHit);
			if (($hit && !($entityHit->closed))) {
				new \pocketmine\event\entity\EntityCombustByEntityEvent($this, $entityHit, 5);
				$combustEvent = new \pocketmine\event\entity\EntityCombustByEntityEvent($this, $entityHit, 5);
				$this->server->getPluginManager()->callEvent($combustEvent);
				if (!($combustEvent->isCancelled())) {
					$entityHit->setOnFire($combustEvent->getDuration());
				}
			}
			return $hit;
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->type = self::NETWORK_ID;
			$pk->eid = $this->getId();
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

}
