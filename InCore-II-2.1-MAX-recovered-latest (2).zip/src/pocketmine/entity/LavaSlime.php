<?php

namespace pocketmine\entity;

class LavaSlime extends \pocketmine\entity\Mob {
	public const NETWORK_ID = 42;

	public $width = 0.3;
	public $length = 0.9;
	public $height = 2.04;
	public $dropExp = array (
  0 => 1,
  1 => 4,
);

	public function getName() {
			return 'LavaSlime';
		}

	public function initEntity() {
			$this->setDataProperty(self::DATA_SLIME_SIZE, self::DATA_TYPE_BYTE, mt_rand(1, 4));
			parent::initEntity();
			return null;
		}

	public function usesPm1eGroundAi() {
			return true;
		}

	protected function usesPm1eJumpingAi() {
			return true;
		}

	protected function getPm1eJumpStrength() {
			/* decompiled (structured CF) */
			if ((4 <= $this->getSize())) {
				return 0.42;
			} else {
				if ((2 <= $this->getSize())) {
					return 0.4;
				}
			}
			return 0.38;
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->eid = $this->getId();
			$pk->type = 42;
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->yaw = $this->yaw;
			$pk->pitch = $this->pitch;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

	public function getDrops() {
			/* decompiled (structured CF) */
			$drops = [\pocketmine\item\Item::get(\pocketmine\item\Item::SLIMEBALL, 0, 1)];
			if (($this->lastDamageCause instanceof \pocketmine\event\entity\EntityDamageByEntityEvent && $this->lastDamageCause->getEntity() instanceof \pocketmine\Player)) {
				if ((mt_rand(0, 199) < 5)) {
					switch (mt_rand(0, 2)) {
						case 0:
						$drops[] = \pocketmine\item\Item::get(\pocketmine\item\Item::IRON_INGOT, 0, 1);
						break;
						case 1:
						$drops[] = \pocketmine\item\Item::get(\pocketmine\item\Item::CARROT, 0, 1);
						break;
						case 2:
						$drops[] = \pocketmine\item\Item::get(\pocketmine\item\Item::POTATO, 0, 1);
						break;
					}
				}
			}
			return $drops;
		}

	public function getSize() {
			return $this->getDataProperty(self::DATA_SLIME_SIZE);
		}

	public function setSize($resting = null) {
			$this->setDataProperty(self::DATA_SLIME_SIZE, self::DATA_TYPE_BYTE, $resting);
			return null;
		}

}
