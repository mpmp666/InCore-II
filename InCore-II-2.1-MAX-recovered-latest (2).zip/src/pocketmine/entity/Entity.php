<?php

namespace pocketmine\entity;

abstract class Entity extends \pocketmine\level\Location implements \pocketmine\metadata\Metadatable {
	public const NETWORK_ID = -1;
	public const DATA_TYPE_BYTE = 0;
	public const DATA_TYPE_SHORT = 1;
	public const DATA_TYPE_INT = 2;
	public const DATA_TYPE_FLOAT = 3;
	public const DATA_TYPE_STRING = 4;
	public const DATA_TYPE_SLOT = 5;
	public const DATA_TYPE_POS = 6;
	public const DATA_TYPE_ROTATION = 7;
	public const DATA_TYPE_LONG = 7;
	public const DATA_FLAGS = 0;
	public const DATA_AIR = 1;
	public const DATA_NAMETAG = 2;
	public const DATA_SHOW_NAMETAG = 3;
	public const DATA_SILENT = 4;
	public const DATA_POTION_COLOR = 7;
	public const DATA_POTION_AMBIENT = 8;
	public const DATA_AGEABLE_FLAGS = 14;
	public const DATA_IS_BABY = 14;
	public const DATA_NO_AI = 15;
	public const DATA_PROFESSION_ID = 16;
	public const DATA_POTION_ID = 16;
	public const DATA_SLIME_SIZE = 16;
	public const DATA_COLOR_INFO = 16;
	public const DATA_CREPPER_SWELL_DIRECTION = 16;
	public const DATA_SHOOTER_ID = 17;
	public const DATA_CREPPER_SWELL = 17;
	public const DATA_CREPPER_SWELL_2 = 18;
	public const DATA_RABBIT_TYPE = 18;
	public const DATA_CAT_TYPE = 18;
	public const DATA_JUMP_TYPE = 19;
	public const DATA_BLOCK_INFO = 20;
	public const DATA_WOOD_ID = 20;
	public const DATA_IN_LOVE = 21;
	public const DATA_ONFIRE = 32;
	public const DATA_ZOMBIE_IS_BABY = 44;
	public const DATA_VILLAGER_IS_BABY = 46;
	public const DATA_ENDERMAN_HELD_ITEM_ID = 48;
	public const DATA_ENDERMAN_HELD_ITEM_DAMAGE = 49;
	public const DATA_ENDERMAN_TREMBLE = 50;
	public const DATA_FLAG_ONFIRE = 0;
	public const DATA_FLAG_SNEAKING = 1;
	public const DATA_FLAG_RIDING = 2;
	public const DATA_FLAG_SPRINTING = 3;
	public const DATA_FLAG_ACTION = 4;
	public const DATA_FLAG_INVISIBLE = 5;
	public const DATA_FLAG_SADDLED = 8;
	public const DATA_FLAG_SITTING = 24;
	public const DATA_FLAG_ANGRY = 25;
	public const DATA_FLAG_TAMED = 28;
	public const DATA_PLAYER_FLAG_SLEEP = 1;
	public const DATA_PLAYER_FLAG_DEAD = 2;
	public const DATA_PLAYER_FLAGS = 16;
	public const DATA_PLAYER_BED_POSITION = 17;
	public const DATA_LEAD_HOLDER = 23;
	public const DATA_LEAD = 24;
	public const SOUTH = 0;
	public const WEST = 1;
	public const NORTH = 2;
	public const EAST = 3;

	public static $entityCount = 1;
	private static $knownEntities = array (
);
	private static $shortNames = array (
);
	protected $hasSpawned = array (
);
	protected $effects = array (
);
	protected $id = NULL;
	protected $dataFlags = 0;
	protected $dataProperties = array (
  0 => 
  array (
    0 => 7,
    1 => 0,
  ),
  1 => 
  array (
    0 => 1,
    1 => 300,
  ),
  2 => 
  array (
    0 => 4,
    1 => '',
  ),
  3 => 
  array (
    0 => 0,
    1 => 1,
  ),
  4 => 
  array (
    0 => 0,
    1 => 0,
  ),
  15 => 
  array (
    0 => 0,
    1 => 0,
  ),
  23 => 
  array (
    0 => 7,
    1 => -1,
  ),
  24 => 
  array (
    0 => 0,
    1 => 0,
  ),
);
	public $passenger = NULL;
	public $vehicle = NULL;
	public $chunk = NULL;
	protected $lastDamageCause = NULL;
	private $blocksAround = array (
);
	public $lastX = NULL;
	public $lastY = NULL;
	public $lastZ = NULL;
	public $motionX = NULL;
	public $motionY = NULL;
	public $motionZ = NULL;
	public $temporalVector = NULL;
	public $lastMotionX = NULL;
	public $lastMotionY = NULL;
	public $lastMotionZ = NULL;
	public $lastYaw = NULL;
	public $lastPitch = NULL;
	public $boundingBox = NULL;
	public $onGround = NULL;
	public $inBlock = false;
	public $positionChanged = NULL;
	public $motionChanged = NULL;
	public $deadTicks = 0;
	protected $age = 0;
	public $height = NULL;
	public $eyeHeight = NULL;
	public $width = NULL;
	public $length = NULL;
	private $health = 20;
	private $maxHealth = 20;
	protected $ySize = 0;
	protected $stepHeight = 0;
	public $keepMovement = false;
	public $fallDistance = 0;
	public $ticksLived = 0;
	public $lastUpdate = NULL;
	public $maxFireTicks = NULL;
	public $fireTicks = 0;
	public $namedtag = NULL;
	public $canCollide = true;
	protected $isStatic = false;
	public $isCollided = false;
	public $isCollidedHorizontally = false;
	public $isCollidedVertically = false;
	public $noDamageTicks = NULL;
	protected $justCreated = NULL;
	protected $fireProof = NULL;
	private $invulnerable = NULL;
	protected $attributeMap = NULL;
	protected $gravity = NULL;
	protected $drag = NULL;
	protected $server = NULL;
	public $closed = false;
	protected $timings = NULL;
	protected $isPlayer = false;
	protected $linkedEntity = NULL;
	protected $linkedType = NULL;
	protected $riding = NULL;
	protected $activatedPressurePlates = array (
);
	public $dropExp = array (
  0 => 0,
  1 => 0,
);

	public function __construct($chunk = null, $nbt = null) {
			/* decompiled (structured CF) */
			assert((($chunk !== null) && ($chunk->getProvider() !== null)), $this);
			$this->timings = \pocketmine\event\Timings::getEntityTimings($this);
			$this->isPlayer = $this instanceof \pocketmine\Player;
			new \pocketmine\math\Vector3();
			$this->temporalVector = new \pocketmine\math\Vector3();
			if (($this->eyeHeight === null)) {
				$this->eyeHeight = (($this->height / 2) + 0.1);
			}
			$this->id = $t22;
			$this->justCreated = true;
			$this->namedtag = $nbt;
			$this->chunk = $chunk;
			$this->setLevel($chunk->getProvider()->getLevel());
			$this->server = $chunk->getProvider()->getLevel()->getServer();
			new \pocketmine\math\AxisAlignedBB(0, 0, 0, 0, 0, 0);
			$this->boundingBox = new \pocketmine\math\AxisAlignedBB(0, 0, 0, 0, 0, 0);
			$this->setPositionAndRotation($this->temporalVector->setComponents($this->namedtag['Pos'][0], $this->namedtag['Pos'][1], $this->namedtag['Pos'][2]), $this->namedtag->Rotation[0], $this->namedtag->Rotation[1]);
			$this->setMotion($this->temporalVector->setComponents($this->namedtag['Motion'][0], $this->namedtag['Motion'][1], $this->namedtag['Motion'][2]));
			assert((((((!(is_nan($this->x)) && !(is_infinite($this->x))) && !(is_nan($this->y))) && !(is_infinite($this->y))) && !(is_nan($this->z))) && !(is_infinite($this->z))), 'string(145)"assert(!is_nan($this->x');
			if (!(isset($this->namedtag->FallDistance))) {
				new \pocketmine\nbt\tag\FloatTag('FallDistance', 0);
				$this->namedtag->FallDistance = new \pocketmine\nbt\tag\FloatTag('FallDistance', 0);
			}
			$this->fallDistance = $this->namedtag['FallDistance'];
			if (!(isset($this->namedtag->Fire))) {
				new \pocketmine\nbt\tag\ShortTag('Fire', 0);
				$this->namedtag->Fire = new \pocketmine\nbt\tag\ShortTag('Fire', 0);
			}
			$this->fireTicks = $this->namedtag['Fire'];
			if (!(isset($this->namedtag->Air))) {
				new \pocketmine\nbt\tag\ShortTag('Air', 300);
				$this->namedtag->Air = new \pocketmine\nbt\tag\ShortTag('Air', 300);
			}
			$this->setDataProperty(self::DATA_AIR, self::DATA_TYPE_SHORT, $this->namedtag['Air']);
			if (!(isset($this->namedtag->OnGround))) {
				new \pocketmine\nbt\tag\ByteTag('OnGround', 0);
				$this->namedtag->OnGround = new \pocketmine\nbt\tag\ByteTag('OnGround', 0);
			}
			if ((0 < $this->namedtag['OnGround'])) {
			} else {
			}
			$this->onGround = false;
			if (!(isset($this->namedtag->Invulnerable))) {
				new \pocketmine\nbt\tag\ByteTag('Invulnerable', 0);
				$this->namedtag->Invulnerable = new \pocketmine\nbt\tag\ByteTag('Invulnerable', 0);
			}
			if ((0 < $this->namedtag['Invulnerable'])) {
			} else {
			}
			$this->invulnerable = false;
			new \pocketmine\entity\AttributeMap();
			$this->attributeMap = new \pocketmine\entity\AttributeMap();
			$this->chunk->addEntity($this);
			$this->level->addEntity($this);
			$this->initEntity();
			$this->lastUpdate = $this->server->getTick();
			new \pocketmine\event\entity\EntitySpawnEvent($this);
			$this->server->getPluginManager()->callEvent(new \pocketmine\event\entity\EntitySpawnEvent($this));
			$this->scheduleUpdate();
			return;
		}

	public function getDropExpMin() {
			return $this->dropExp[0];
		}

	public function getDropExpMax() {
			return $this->dropExp[1];
		}

	public function getNameTag() {
			return $this->getDataProperty(self::DATA_NAMETAG);
		}

	public function isNameTagVisible() {
			return (0 < $this->getDataProperty(self::DATA_SHOW_NAMETAG));
		}

	public function setNameTag($name = null) {
			$this->setDataProperty(self::DATA_NAMETAG, self::DATA_TYPE_STRING, $name);
			return null;
		}

	public function setNameTagVisible($value = null) {
			/* decompiled (structured CF) */
			if ($value) {
			} else {
			}
			$this->setDataProperty(self::DATA_SHOW_NAMETAG, self::DATA_TYPE_BYTE, 0);
			return null;
		}

	public function isSneaking() {
			return $this->getDataFlag(self::DATA_FLAGS, self::DATA_FLAG_SNEAKING);
		}

	public function setSneaking($value = null) {
			$this->setDataFlag(self::DATA_FLAGS, self::DATA_FLAG_SNEAKING, $value);
			return null;
		}

	public function isSprinting() {
			return $this->getDataFlag(self::DATA_FLAGS, self::DATA_FLAG_SPRINTING);
		}

	public function setSprinting($value = null) {
			$this->setDataFlag(self::DATA_FLAGS, self::DATA_FLAG_SPRINTING, $value);
			return null;
		}

	public function getEffects() {
			return $this->effects;
		}

	public function removeAllEffects() {
			/* decompiled (structured CF) */
			foreach ($this->effects as $effect) {
				$this->removeEffect($effect->getId());
				/* goto */
			}
			return null;
		}

	public function removeEffect($effectId = null) {
			/* decompiled (structured CF) */
			if (isset($this->effects[$effectId])) {
				$effect = $this->effects[$effectId];
				$effect->remove($this);
				$this->recalculateEffectColor();
			}
			return null;
		}

	public function getEffect($effectId = null) {
			/* decompiled (structured CF) */
			if (isset($this->effects[$effectId])) {
			} else {
			}
			return null;
		}

	public function hasEffect($effectId = null) {
			return isset($this->effects[$effectId]);
		}

	public function addEffect($effect = null) {
			/* decompiled (structured CF) */
			if (isset($this->effects[$effect->getId()])) {
				$oldEffect = $this->effects[$effect->getId()];
				if (((abs($effect->getAmplifier()) <= $oldEffect->getAmplifier()) || ((abs($effect->getAmplifier()) === abs($oldEffect->getAmplifier())) && ($effect->getDuration() < $oldEffect->getDuration())))) {
					return null;
				}
				$effect->add($this, true);
			} else {
				$effect->add($this, false);
			}
			$this->effects[$effect->getId()] = $effect;
			$this->recalculateEffectColor();
			if (($effect->getId() === \pocketmine\entity\Effect::HEALTH_BOOST)) {
				$this->setHealth(($this->getHealth() + (($effect->getAmplifier() + 1) * 4)));
			}
		}

	protected function recalculateEffectColor() {
			/* decompiled (structured CF) */
			$color = ['__array_ptr' => '2aaaadda5380'];
			$count = 0;
			$ambient = true;
			foreach ($this->effects as $effect) {
				if ($effect->isVisible()) {
					$c = $effect->getColor();
					$color[0] += ($c[0] * ($effect->getAmplifier() + 1));
					$color[1] += ($c[1] * ($effect->getAmplifier() + 1));
					$color[2] += ($c[2] * ($effect->getAmplifier() + 1));
					$count += ($effect->getAmplifier() + 1);
					if (!($effect->isAmbient())) {
						$ambient = false;
					}
				}
				/* goto */
			}
			if ((0 < $count)) {
				$r = (($color[0] / $count) & 255);
				$g = (($color[1] / $count) & 255);
				$b = (($color[2] / $count) & 255);
				$this->setDataProperty(7, 2, ((($r << 16) + ($g << 8)) + $b));
				if ($ambient) {
				} else {
				}
				$this->setDataProperty(8, 0, 0);
			} else {
				$this->setDataProperty(7, 2, 0);
				$this->setDataProperty(8, 0, 0);
			}
			return null;
		}

	public static function createEntity($type = null, $chunk = null, $nbt = null) {
			/* decompiled (structured CF) */
			if (isset(self::$knownEntities[$type])) {
				$class = self::$knownEntities[$type];
				new $class($chunk, $nbt);
				return new $class($chunk, $nbt);
			}
		}

	public static function registerEntity($className = null, $force = null) {
			/* decompiled (structured CF) */
			new \ReflectionClass($className);
			$class = new \ReflectionClass($className);
			if ((is_a($className, 'pocketmine\\entity\\Entity', true) && !($class->isAbstract()))) {
				if (($className::NETWORK_ID !== -1)) {
					self::$knownEntities[$className::NETWORK_ID] = $className;
				} else {
					if (!($force)) {
						return false;
					}
				}
				self::$knownEntities[$class->getShortName()] = $className;
				self::$shortNames[$className] = $class->getShortName();
				return true;
			}
			return false;
		}

	public function getSaveId() {
			return self::$shortNames[$t1];
		}

	public function saveNBT() {
			/* decompiled (structured CF) */
			if (!($this instanceof \pocketmine\Player)) {
				new \pocketmine\nbt\tag\StringTag('id', $this->getSaveId());
				$this->namedtag->id = new \pocketmine\nbt\tag\StringTag('id', $this->getSaveId());
				if (($this->getNameTag() !== '')) {
					new \pocketmine\nbt\tag\StringTag('CustomName', $this->getNameTag());
					$this->namedtag->CustomName = new \pocketmine\nbt\tag\StringTag('CustomName', $this->getNameTag());
					new \pocketmine\nbt\tag\StringTag('CustomNameVisible', $this->isNameTagVisible());
					$this->namedtag->CustomNameVisible = new \pocketmine\nbt\tag\StringTag('CustomNameVisible', $this->isNameTagVisible());
				} else {
				}
			}
			new \pocketmine\nbt\tag\DoubleTag(0, $this->x);
			new \pocketmine\nbt\tag\DoubleTag(1, $this->y);
			new \pocketmine\nbt\tag\DoubleTag(2, $this->z);
			new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag(0, $this->x), new \pocketmine\nbt\tag\DoubleTag(1, $this->y), new \pocketmine\nbt\tag\DoubleTag(2, $this->z)]);
			$this->namedtag->Pos = new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag(0, $this->x), new \pocketmine\nbt\tag\DoubleTag(1, $this->y), new \pocketmine\nbt\tag\DoubleTag(2, $this->z)]);
			new \pocketmine\nbt\tag\DoubleTag(0, $this->motionX);
			new \pocketmine\nbt\tag\DoubleTag(1, $this->motionY);
			new \pocketmine\nbt\tag\DoubleTag(2, $this->motionZ);
			new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag(0, $this->motionX), new \pocketmine\nbt\tag\DoubleTag(1, $this->motionY), new \pocketmine\nbt\tag\DoubleTag(2, $this->motionZ)]);
			$this->namedtag->Motion = new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag(0, $this->motionX), new \pocketmine\nbt\tag\DoubleTag(1, $this->motionY), new \pocketmine\nbt\tag\DoubleTag(2, $this->motionZ)]);
			new \pocketmine\nbt\tag\FloatTag(0, $this->yaw);
			new \pocketmine\nbt\tag\FloatTag(1, $this->pitch);
			new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag(0, $this->yaw), new \pocketmine\nbt\tag\FloatTag(1, $this->pitch)]);
			$this->namedtag->Rotation = new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag(0, $this->yaw), new \pocketmine\nbt\tag\FloatTag(1, $this->pitch)]);
			new \pocketmine\nbt\tag\FloatTag('FallDistance', $this->fallDistance);
			$this->namedtag->FallDistance = new \pocketmine\nbt\tag\FloatTag('FallDistance', $this->fallDistance);
			new \pocketmine\nbt\tag\ShortTag('Fire', $this->fireTicks);
			$this->namedtag->Fire = new \pocketmine\nbt\tag\ShortTag('Fire', $this->fireTicks);
			new \pocketmine\nbt\tag\ShortTag('Air', $this->getDataProperty(self::DATA_AIR));
			$this->namedtag->Air = new \pocketmine\nbt\tag\ShortTag('Air', $this->getDataProperty(self::DATA_AIR));
			if ($this->onGround) {
			} else {
			}
			new \pocketmine\nbt\tag\ByteTag('OnGround', 0);
			$this->namedtag->OnGround = new \pocketmine\nbt\tag\ByteTag('OnGround', 0);
			if ($this->invulnerable) {
			} else {
			}
			new \pocketmine\nbt\tag\ByteTag('Invulnerable', 0);
			$this->namedtag->Invulnerable = new \pocketmine\nbt\tag\ByteTag('Invulnerable', 0);
			if ($this->isLeashed()) {
				new \pocketmine\nbt\tag\ByteTag('Leashed', 1);
				$this->namedtag->Leashed = new \pocketmine\nbt\tag\ByteTag('Leashed', 1);
				$holder = $this->getLeashHolder();
				if ($holder instanceof \pocketmine\entity\LeashKnot) {
					new \pocketmine\nbt\tag\IntTag('X', (floor($holder->x)));
					new \pocketmine\nbt\tag\IntTag('Y', (floor($holder->y)));
					new \pocketmine\nbt\tag\IntTag('Z', (floor($holder->z)));
					new \pocketmine\nbt\tag\CompoundTag('Leash', [new \pocketmine\nbt\tag\IntTag('X', (floor($holder->x))), new \pocketmine\nbt\tag\IntTag('Y', (floor($holder->y))), new \pocketmine\nbt\tag\IntTag('Z', (floor($holder->z)))]);
					$this->namedtag->Leash = new \pocketmine\nbt\tag\CompoundTag('Leash', [new \pocketmine\nbt\tag\IntTag('X', (floor($holder->x))), new \pocketmine\nbt\tag\IntTag('Y', (floor($holder->y))), new \pocketmine\nbt\tag\IntTag('Z', (floor($holder->z)))]);
				} else {
					new \pocketmine\nbt\tag\LongTag('LeashHolder', $this->getLeashHolderEid());
					$this->namedtag->LeashHolder = new \pocketmine\nbt\tag\LongTag('LeashHolder', $this->getLeashHolderEid());
				}
			} else {
			}
			if ((0 < count($this->effects))) {
				$effects = ['__array_ptr' => '2aaaac9fc9a0'];
				foreach ($this->effects as $effect) {
					new \pocketmine\nbt\tag\ByteTag('Id', $effect->getId());
					new \pocketmine\nbt\tag\ByteTag('Amplifier', $effect->getAmplifier());
					new \pocketmine\nbt\tag\IntTag('Duration', $effect->getDuration());
					new \pocketmine\nbt\tag\ByteTag('Ambient', 0);
					if ($effect->isVisible()) {
					} else {
					}
					new \pocketmine\nbt\tag\ByteTag('ShowParticles', 0);
					new \pocketmine\nbt\tag\CompoundTag($effect->getId(), [new \pocketmine\nbt\tag\ByteTag('Id', $effect->getId()), new \pocketmine\nbt\tag\ByteTag('Amplifier', $effect->getAmplifier()), new \pocketmine\nbt\tag\IntTag('Duration', $effect->getDuration()), new \pocketmine\nbt\tag\ByteTag('Ambient', 0), new \pocketmine\nbt\tag\ByteTag('ShowParticles', 0)]);
					$effects[$effect->getId()] = new \pocketmine\nbt\tag\CompoundTag($effect->getId(), [new \pocketmine\nbt\tag\ByteTag('Id', $effect->getId()), new \pocketmine\nbt\tag\ByteTag('Amplifier', $effect->getAmplifier()), new \pocketmine\nbt\tag\IntTag('Duration', $effect->getDuration()), new \pocketmine\nbt\tag\ByteTag('Ambient', 0), new \pocketmine\nbt\tag\ByteTag('ShowParticles', 0)]);
					/* goto */
				}
				new \pocketmine\nbt\tag\ListTag('ActiveEffects', $effects);
				$this->namedtag->ActiveEffects = new \pocketmine\nbt\tag\ListTag('ActiveEffects', $effects);
			} else {
			}
			return null;
		}

	protected function initEntity() {
			/* decompiled (structured CF) */
			assert($this->namedtag instanceof \pocketmine\nbt\tag\CompoundTag, $this);
			if (isset($this->namedtag->CustomName)) {
				$this->setNameTag($this->namedtag['CustomName']);
				if (isset($this->namedtag->CustomNameVisible)) {
					$this->setNameTagVisible((0 < $this->namedtag['CustomNameVisible']));
				}
			}
			$this->scheduleUpdate();
			$this->addAttributes();
			if (isset($this->namedtag->ActiveEffects)) {
				foreach ($this->namedtag->ActiveEffects->getValue() as $e) {
					$effect = \pocketmine\entity\Effect::getEffect($e['Id']);
					if (($effect === null)) {
						/* goto */
					}
					$effect->setAmplifier($e['Amplifier'])->setDuration($e['Duration'])->setVisible((0 < $e['ShowParticles']));
					$this->addEffect($effect);
					/* goto */
				}
			}
			$this->restoreLeashFromNBT();
			return null;
		}

	protected function addAttributes() {
			return null;
		}

	public function getViewers() {
			return $this->hasSpawned;
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			if ((!(isset($this->hasSpawned[$player->getLoaderId()])) && isset($player->usedChunks[\pocketmine\level\Level::chunkHash($this->chunk->getX(), $this->chunk->getZ())]))) {
				$this->hasSpawned[$player->getLoaderId()] = $player;
			}
			return null;
		}

	public function sendPotionEffects($player = null) {
			/* decompiled (structured CF) */
			foreach ($this->effects as $effect) {
				new \pocketmine\network\protocol\MobEffectPacket();
				$pk = new \pocketmine\network\protocol\MobEffectPacket();
				$pk->eid = 0;
				$pk->effectId = $effect->getId();
				$pk->amplifier = $effect->getAmplifier();
				$pk->particles = $effect->isVisible();
				$pk->duration = $effect->getDuration();
				$pk->eventId = \pocketmine\network\protocol\MobEffectPacket::EVENT_ADD;
				$player->dataPacket($pk);
				/* goto */
			}
			return null;
		}

	public function sendMetadata($player = null) {
			$this->sendData($player);
			return null;
		}

	public function sendData($player = null, $data = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\SetEntityDataPacket();
			$pk = new \pocketmine\network\protocol\SetEntityDataPacket();
			if (($player === $this)) {
			} else {
			}
			$pk->eid = $this->getId();
			if (($data === null)) {
			} else {
			}
			$pk->metadata = $data;
			if (!(is_array($player))) {
				$player->dataPacket($pk);
			} else {
				\pocketmine\Server::broadcastPacket($player, $pk);
			}
			return null;
		}

	public function despawnFrom($player = null) {
			/* decompiled (structured CF) */
			if (isset($this->hasSpawned[$player->getLoaderId()])) {
				new \pocketmine\network\protocol\RemoveEntityPacket();
				$pk = new \pocketmine\network\protocol\RemoveEntityPacket();
				$pk->eid = $this->getId();
				$player->dataPacket($pk);
			}
			return null;
		}

	public function attack($damage = null, $source = null) {
			/* decompiled (structured CF) */
			if (($this->hasEffect(\pocketmine\entity\Effect::FIRE_RESISTANCE) && ((($source->getCause() === \pocketmine\event\entity\EntityDamageEvent::CAUSE_FIRE) || ($source->getCause() === \pocketmine\event\entity\EntityDamageEvent::CAUSE_FIRE_TICK)) || ($source->getCause() === \pocketmine\event\entity\EntityDamageEvent::CAUSE_LAVA)))) {
				$source->setCancelled();
			}
			$this->server->getPluginManager()->callEvent($source);
			if ($source->isCancelled()) {
				return false;
			}
			$this->setLastDamageCause($source);
			$this->setHealth(($this->getHealth() - $source->getFinalDamage()));
			return true;
		}

	public function heal($amount = null, $source = null) {
			/* decompiled (structured CF) */
			$this->server->getPluginManager()->callEvent($source);
			if ($source->isCancelled()) {
				return null;
			}
			$this->setHealth(($this->getHealth() + $source->getAmount()));
		}

	public function getHealth() {
			return $this->health;
		}

	public function isAlive() {
			return (0 < $this->health);
		}

	public function setHealth($amount = null) {
			/* decompiled (structured CF) */
			$amount = ($amount);
			if (($amount === $this->health)) {
				return null;
			}
			if (($amount <= 0)) {
				if ($this->isAlive()) {
					$this->kill();
				}
			} else {
				if ((($amount <= $this->getMaxHealth()) || ($amount < $this->health))) {
					$this->health = ($amount);
				} else {
					$this->health = $this->getMaxHealth();
				}
			}
		}

	public function setLastDamageCause($type = null) {
			$this->lastDamageCause = $type;
		}

	public function getLastDamageCause() {
			return $this->lastDamageCause;
		}

	public function resetLastDamageCause() {
			$this->lastDamageCause = null;
		}

	public function getAttributeMap() {
			return $this->attributeMap;
		}

	public function getMaxHealth() {
			/* decompiled (structured CF) */
			if ($this->hasEffect(\pocketmine\entity\Effect::HEALTH_BOOST)) {
			} else {
			}
			return ($this->maxHealth + 0);
		}

	public function setMaxHealth($amount = null) {
			$this->maxHealth = ($amount);
			return null;
		}

	public function canCollideWith($entity = null) {
			return (!($this->justCreated) && ($entity !== $this));
		}

	protected function checkObstruction($x = null, $y = null, $z = null) {
			/* decompiled (structured CF) */
			$i = \pocketmine\math\Math::floorFloat($x);
			$j = \pocketmine\math\Math::floorFloat($y);
			$k = \pocketmine\math\Math::floorFloat($z);
			$diffX = ($x - $i);
			$diffY = ($y - $j);
			$diffZ = ($z - $k);
			if (\pocketmine\block\Block::$solid[$this->level->getBlockIdAt($i, $j, $k)]) {
				$flag = !(\pocketmine\block\Block::$solid[$this->level->getBlockIdAt(($i - 1), $j, $k)]);
				$flag1 = !(\pocketmine\block\Block::$solid[$this->level->getBlockIdAt(($i + 1), $j, $k)]);
				$flag2 = !(\pocketmine\block\Block::$solid[$this->level->getBlockIdAt($i, ($j - 1), $k)]);
				$flag3 = !(\pocketmine\block\Block::$solid[$this->level->getBlockIdAt($i, ($j + 1), $k)]);
				$flag4 = !(\pocketmine\block\Block::$solid[$this->level->getBlockIdAt($i, $j, ($k - 1))]);
				$flag5 = !(\pocketmine\block\Block::$solid[$this->level->getBlockIdAt($i, $j, ($k + 1))]);
				$direction = -1;
				$limit = 9999;
				if ($flag) {
					$limit = $diffX;
					$direction = 0;
				}
				if (($flag1 && ((1 - $diffX) < $limit))) {
					$limit = (1 - $diffX);
					$direction = 1;
				}
				if (($flag2 && ($diffY < $limit))) {
					$limit = $diffY;
					$direction = 2;
				}
				if (($flag3 && ((1 - $diffY) < $limit))) {
					$limit = (1 - $diffY);
					$direction = 3;
				}
				if (($flag4 && ($diffZ < $limit))) {
					$limit = $diffZ;
					$direction = 4;
				}
				if (($flag5 && ((1 - $diffZ) < $limit))) {
					$direction = 5;
				}
				$force = ((lcg_value() * 0.2) + 0.1);
				if (($direction === 0)) {
					$this->motionX = ($force * -1);
					return true;
				}
				if (($direction === 1)) {
					$this->motionX = $force;
					return true;
				}
				if (($direction === 2)) {
					$this->motionY = ($force * -1);
					return true;
				}
				if (($direction === 3)) {
					$this->motionY = $force;
					return true;
				}
				if (($direction === 4)) {
					$this->motionZ = ($force * -1);
					return true;
				}
				if (($direction === 5)) {
					$this->motionZ = $force;
					return true;
				}
			}
			return false;
		}

	public function entityBaseTick($tickDiff = null) {
			/* decompiled (structured CF) */
			\pocketmine\event\Timings::$timerEntityBaseTick->startTiming();
			$this->blocksAround = null;
			$this->justCreated = false;
			if (!($this->isAlive())) {
				$this->removeAllEffects();
				$this->despawnFromAll();
				if (!($this->isPlayer)) {
					$this->close();
				}
				\pocketmine\event\Timings::$timerEntityBaseTick->stopTiming();
				return false;
			}
			if ((0 < count($this->effects))) {
				foreach ($this->effects as $effect) {
					if ($effect->canTick()) {
						$effect->applyEffect($this);
					}
					$effect->setDuration(($effect->getDuration() - $tickDiff));
					if (($effect->getDuration() <= 0)) {
						$this->removeEffect($effect->getId());
					}
					/* goto */
				}
			}
			$hasUpdate = false;
			$this->checkBlockCollision();
			if ((($this->y <= -16) && $this->isAlive())) {
				new \pocketmine\event\entity\EntityDamageEvent($this, \pocketmine\event\entity\EntityDamageEvent::CAUSE_VOID, 10);
				$ev = new \pocketmine\event\entity\EntityDamageEvent($this, \pocketmine\event\entity\EntityDamageEvent::CAUSE_VOID, 10);
				$this->attack($ev->getFinalDamage(), $ev);
				$hasUpdate = true;
			}
			if ((0 < $this->fireTicks)) {
				if ($this->fireProof) {
					$this->fireTicks -= ($tickDiff * 4);
					if (($this->fireTicks < 0)) {
						$this->fireTicks = 0;
					}
				} else {
					if ((!($this->hasEffect(\pocketmine\entity\Effect::FIRE_RESISTANCE)) && ((($this->fireTicks % 20) === 0) || (20 < $tickDiff)))) {
						new \pocketmine\event\entity\EntityDamageEvent($this, \pocketmine\event\entity\EntityDamageEvent::CAUSE_FIRE_TICK, 1);
						$ev = new \pocketmine\event\entity\EntityDamageEvent($this, \pocketmine\event\entity\EntityDamageEvent::CAUSE_FIRE_TICK, 1);
						$this->attack($ev->getFinalDamage(), $ev);
					}
					$this->fireTicks -= $tickDiff;
				}
				if ((($this->fireTicks <= 0) && (-10 < $this->fireTicks))) {
					$this->extinguish();
				} else {
					$this->setDataFlag(self::DATA_FLAGS, self::DATA_FLAG_ONFIRE, true);
					$hasUpdate = true;
				}
			}
			if ((0 < $this->noDamageTicks)) {
				$this->noDamageTicks -= $tickDiff;
				if (($this->noDamageTicks < 0)) {
					$this->noDamageTicks = 0;
				}
			}
			$this->age += $tickDiff;
			$this->ticksLived += $tickDiff;
			\pocketmine\event\Timings::$timerEntityBaseTick->stopTiming();
			return $hasUpdate;
		}

	protected function updateMovement() {
			/* decompiled (structured CF) */
			$diffPosition = (($t6 + $t10) + $t15);
			$diffRotation = ($t21 + $t25);
			$diffMotion = (($t31 + $t35) + $t40);
			if (((0.04 < $diffPosition) || ((2.25 < $diffRotation) && ((0.0001 < $diffMotion) && ($this->getMotion()->lengthSquared() <= 1e-05))))) {
				$this->lastX = $this->x;
				$this->lastY = $this->y;
				$this->lastZ = $this->z;
				$this->lastYaw = $this->yaw;
				$this->lastPitch = $this->pitch;
				$this->level->addEntityMovement($this->chunk->getX(), $this->chunk->getZ(), $this->id, $this->x, $this->y, $this->z, $this->yaw, $this->pitch, $this->yaw);
			}
			if (((0.0025 < $diffMotion) || ((0.0001 < $diffMotion) && ($this->getMotion()->lengthSquared() <= 0.0001)))) {
				$this->lastMotionX = $this->motionX;
				$this->lastMotionY = $this->motionY;
				$this->lastMotionZ = $this->motionZ;
				$this->level->addEntityMotion($this->chunk->getX(), $this->chunk->getZ(), $this->id, $this->motionX, $this->motionY, $this->motionZ);
			}
			return null;
		}

	public function getDirectionVector() {
			/* decompiled (structured CF) */
			$y = (sin(deg2rad($this->pitch)) * -1);
			$xz = cos(deg2rad($this->pitch));
			$x = (sin(deg2rad($this->yaw)) * ($xz * -1));
			$z = ($xz * cos(deg2rad($this->yaw)));
			return $this->temporalVector->setComponents($x, $y, $z)->normalize();
		}

	public function getDirectionPlane() {
			new \pocketmine\math\Vector2((cos((deg2rad($this->yaw) - \M_PI_2)) * -1), (sin((deg2rad($this->yaw) - \M_PI_2)) * -1));
			return (new \pocketmine\math\Vector2((cos((deg2rad($this->yaw) - \M_PI_2)) * -1), (sin((deg2rad($this->yaw) - \M_PI_2)) * -1)))->normalize();
		}

	public function onUpdate($currentTick = null) {
			/* decompiled (structured CF) */
			if ($this->closed) {
				return false;
			}
			if (!($this->isAlive())) {
				if ((10 <= $this->deadTicks)) {
					$this->despawnFromAll();
					if (!($this->isPlayer)) {
						$this->close();
					}
				}
				return ($this->deadTicks < 10);
			}
			$tickDiff = ($currentTick - $this->lastUpdate);
			if (($tickDiff <= 0)) {
				return false;
			}
			$this->lastUpdate = $currentTick;
			$this->timings->startTiming();
			$hasUpdate = $this->entityBaseTick($tickDiff);
			$this->updateMovement();
			$this->timings->stopTiming();
			return $hasUpdate;
		}

	public final function scheduleUpdate() {
			$this->level->updateEntities[$this->id] = $this;
			return null;
		}

	public function isOnFire() {
			return (0 < $this->fireTicks);
		}

	public function setOnFire($seconds = null) {
			/* decompiled (structured CF) */
			$ticks = ($seconds * 20);
			if (($this->fireTicks < $ticks)) {
				$this->fireTicks = $ticks;
			}
			return null;
		}

	public function getDirection() {
			/* decompiled (structured CF) */
			$rotation = (($this->yaw - 90) % 360);
			if (($rotation < 0)) {
				$rotation += 360;
			}
			if ((((0 <= $rotation) && ($rotation < 45)) || ((315 <= $rotation) && ($rotation < 360)))) {
				return 2;
			} else {
				if (((45 <= $rotation) && ($rotation < 135))) {
					return 3;
				} else {
					if (((135 <= $rotation) && ($rotation < 225))) {
						return 0;
					} else {
						if (((225 <= $rotation) && ($rotation < 315))) {
							return 1;
						} else {
						}
					}
				}
			}
		}

	public function extinguish() {
			$this->fireTicks = 0;
			$this->setDataFlag(self::DATA_FLAGS, self::DATA_FLAG_ONFIRE, false);
			return null;
		}

	public function canTriggerWalking() {
			return true;
		}

	public function resetFallDistance() {
			$this->fallDistance = 0;
		}

	protected function updateFallState($distanceThisTick = null, $onGround = null) {
			/* decompiled (structured CF) */
			if (($onGround === true)) {
				if ((0 < $this->fallDistance)) {
					if ($this instanceof \pocketmine\entity\Living) {
						$this->fall($this->fallDistance);
					}
					$this->resetFallDistance();
				}
			} else {
				if (($distanceThisTick < 0)) {
					$this->fallDistance -= $distanceThisTick;
				}
			}
			return null;
		}

	public function getBoundingBox() {
			return $this->boundingBox;
		}

	public function fall($fallDistance = null) {
			/* decompiled (structured CF) */
			if (($this instanceof \pocketmine\Player && $this->isSpectator())) {
				return null;
			}
			if (($this->getLevel()->getServer()->destroyBlockParticle && (3 < $fallDistance))) {
				$block = $this->getLevel()->getBlock($this->floor()->subtract(0, 1, 0));
				new \pocketmine\level\particle\DestroyBlockParticle($this, $block);
				$this->getLevel()->addParticle(new \pocketmine\level\particle\DestroyBlockParticle($this, $block));
				if ($block instanceof \pocketmine\block\Farmland) {
					$block->turnIntoDirt(true, true);
				}
			}
			if ($this->isInsideOfWater()) {
			}
			if ($this->hasEffect(\pocketmine\entity\Effect::JUMP)) {
			} else {
			}
			$damage = floor((($fallDistance - 3) - 0));
			$canUseSlimePhysics = !($this instanceof \pocketmine\Player);
			if (($canUseSlimePhysics && $this->getLevel()->getBlock($this->floor()->subtract(0, 1, 0)) instanceof \pocketmine\block\SlimeBlock)) {
				$damage = 0;
			}
			if ((0 < $damage)) {
				new \pocketmine\event\entity\EntityDamageEvent($this, \pocketmine\event\entity\EntityDamageEvent::CAUSE_FALL, $damage);
				$ev = new \pocketmine\event\entity\EntityDamageEvent($this, \pocketmine\event\entity\EntityDamageEvent::CAUSE_FALL, $damage);
				$this->attack($ev->getFinalDamage(), $ev);
			}
		}

	public function handleLavaMovement() {
			return null;
		}

	public function getEyeHeight() {
			return $this->eyeHeight;
		}

	public function moveFlying() {
			return null;
		}

	public function onCollideWithPlayer($entityPlayer = null) {
			return null;
		}

	protected function switchLevel($targetLevel = null) {
			/* decompiled (structured CF) */
			if ($this->closed) {
				return false;
			}
			if ($this->isValid()) {
				new \pocketmine\event\entity\EntityLevelChangeEvent($this, $this->level, $targetLevel);
				$ev = new \pocketmine\event\entity\EntityLevelChangeEvent($this, $this->level, $targetLevel);
				$this->server->getPluginManager()->callEvent($ev);
				if ($ev->isCancelled()) {
					return false;
				}
				$this->level->removeEntity($this);
				if (($this->chunk !== null)) {
					$this->chunk->removeEntity($this);
				}
				$this->despawnFromAll();
			}
			$this->setLevel($targetLevel);
			$this->level->addEntity($this);
			$this->chunk = null;
			return true;
		}

	public function getPosition() {
			new \pocketmine\level\Position($this->x, $this->y, $this->z, $this->level);
			return new \pocketmine\level\Position($this->x, $this->y, $this->z, $this->level);
		}

	public function getLocation() {
			new \pocketmine\level\Location($this->x, $this->y, $this->z, $this->yaw, $this->pitch, $this->level);
			return new \pocketmine\level\Location($this->x, $this->y, $this->z, $this->yaw, $this->pitch, $this->level);
		}

	public function isInsideOfPortal() {
			/* decompiled (structured CF) */
			$blocks = $this->getBlocksAround();
			foreach ($blocks as $block) {
				if ($block instanceof \pocketmine\block\Portal) {
					return true;
				}
				/* goto */
			}
			return false;
		}

	public function isInsideOfWater() {
			/* decompiled (structured CF) */
			$y = ($this->y + $this->getEyeHeight());
			$block = $this->level->getBlock($this->temporalVector->setComponents(\pocketmine\math\Math::floorFloat($this->x), \pocketmine\math\Math::floorFloat($y), \pocketmine\math\Math::floorFloat($this->z)));
			if ($block instanceof \pocketmine\block\Water) {
				$f = (($block->y + 1) - ($block->getFluidHeightPercent() - 0.1111111));
				return ($y < $f);
			}
			return false;
		}

	public function isInsideOfSolid() {
			/* decompiled (structured CF) */
			$y = ($this->y + $this->getEyeHeight());
			$block = $this->level->getBlock($this->temporalVector->setComponents(\pocketmine\math\Math::floorFloat($this->x), \pocketmine\math\Math::floorFloat($y), \pocketmine\math\Math::floorFloat($this->z)));
			$bb = $block->getBoundingBox();
			if ((((($bb !== null) && $block->isSolid()) && !($block->isTransparent())) && $bb->intersectsWith($this->getBoundingBox()))) {
				return true;
			}
			return false;
		}

	public function isInsideOfFire() {
			/* decompiled (structured CF) */
			foreach ($this->getBlocksAround() as $block) {
				if ($block instanceof \pocketmine\block\Fire) {
					return true;
				}
				/* goto */
			}
			return false;
		}

	public function fastMove($dx = null, $dy = null, $dz = null) {
			/* decompiled (structured CF) */
			if (((($dx == 0) && ($dz == 0)) && ($dy == 0))) {
				return true;
			}
			\pocketmine\event\Timings::$entityMoveTimer->startTiming();
			$this->x = (($this->boundingBox->minX + $this->boundingBox->maxX) / 2);
			$this->y = ($this->boundingBox->minY - $this->ySize);
			$this->z = (($this->boundingBox->minZ + $this->boundingBox->maxZ) / 2);
			$this->checkChunks();
			if ((!($this->onGround) || ($dy != 0))) {
				$bb = clone $this->boundingBox;
				$bb->minY -= 0.75;
				$this->onGround = false;
				if ($this->boundingBox instanceof \pocketmine\math\AxisAlignedBB) {
				} else {
				}
				$feetY = $this->y;
				new \pocketmine\math\Vector3($this->x, ($feetY - 0.01), $this->z);
				if (!($this->level->getBlock(new \pocketmine\math\Vector3($this->x, ($feetY - 0.01), $this->z))->isTransparent())) {
					$this->onGround = true;
				}
			}
			$this->isCollided = $this->onGround;
			$this->updateFallState($dy, $this->onGround);
			\pocketmine\event\Timings::$entityMoveTimer->stopTiming();
			return true;
		}

	public function move($dx = null, $dy = null, $dz = null) {
			/* decompiled (structured CF) */
			if (((($dx == 0) && ($dz == 0)) && ($dy == 0))) {
				return true;
			}
			if ($this->keepMovement) {
				$this->boundingBox->offset($dx, $dy, $dz);
				$this->setPosition($this->temporalVector->setComponents((($this->boundingBox->minX + $this->boundingBox->maxX) / 2), $this->boundingBox->minY, (($this->boundingBox->minZ + $this->boundingBox->maxZ) / 2)));
				if ($this->isPlayer) {
				} else {
				}
				$this->onGround = false;
				return true;
			} else {
				\pocketmine\event\Timings::$entityMoveTimer->startTiming();
				$this->ySize *= 0.4;
				$movX = $dx;
				$movY = $dy;
				$movZ = $dz;
				$axisalignedbb = clone $this->boundingBox;
				if ((1 < $this->level->getTickRate())) {
				} else {
				}
				$list = $this->level->getCollisionCubes($this, $this->boundingBox->addCoord($dx, $dy, $dz), false);
				foreach ($list as $bb) {
					$dy = $bb->calculateYOffset($this->boundingBox, $dy);
					/* goto */
				}
				$this->boundingBox->offset(0, $dy, 0);
				$fallingFlag = ($this->onGround || (($dy != $movY) && ($movY < 0)));
				foreach ($list as $bb) {
					$dx = $bb->calculateXOffset($this->boundingBox, $dx);
					/* goto */
				}
				$this->boundingBox->offset($dx, 0, 0);
				foreach ($list as $bb) {
					$dz = $bb->calculateZOffset($this->boundingBox, $dz);
					/* goto */
				}
				$this->boundingBox->offset(0, 0, $dz);
				if (((((0 < $this->stepHeight) && $fallingFlag) && ($this->ySize < 0.05)) && (($movX != $dx) || ($movZ != $dz)))) {
					$cx = $dx;
					$cy = $dy;
					$cz = $dz;
					$dx = $movX;
					$dy = $this->stepHeight;
					$dz = $movZ;
					$axisalignedbb1 = clone $this->boundingBox;
					$this->boundingBox->setBB($axisalignedbb);
					$list = $this->level->getCollisionCubes($this, $this->boundingBox->addCoord($dx, $dy, $dz), false);
					foreach ($list as $bb) {
						$dy = $bb->calculateYOffset($this->boundingBox, $dy);
						/* goto */
					}
					$this->boundingBox->offset(0, $dy, 0);
					foreach ($list as $bb) {
						$dx = $bb->calculateXOffset($this->boundingBox, $dx);
						/* goto */
					}
					$this->boundingBox->offset($dx, 0, 0);
					foreach ($list as $bb) {
						$dz = $bb->calculateZOffset($this->boundingBox, $dz);
						/* goto */
					}
					$this->boundingBox->offset(0, 0, $dz);
					if ((($t128 + $t129) <= ($t125 + $t126))) {
						$dx = $cx;
						$dy = $cy;
						$dz = $cz;
						$this->boundingBox->setBB($axisalignedbb1);
					} else {
						$this->ySize += 0.5;
					}
				}
				$this->x = (($this->boundingBox->minX + $this->boundingBox->maxX) / 2);
				$this->y = ($this->boundingBox->minY - $this->ySize);
				$this->z = (($this->boundingBox->minZ + $this->boundingBox->maxZ) / 2);
				$this->checkChunks();
				$this->checkGroundState($movX, $movY, $movZ, $dx, $dy, $dz);
				$this->updateFallState($dy, $this->onGround);
				if (($movX != $dx)) {
					$this->motionX = 0;
				}
				if (($movY != $dy)) {
					$this->motionY = 0;
				}
				if (($movZ != $dz)) {
					$this->motionZ = 0;
				}
				\pocketmine\event\Timings::$entityMoveTimer->stopTiming();
				return true;
			}
		}

	protected function checkGroundState($movX = null, $movY = null, $movZ = null, $dx = null, $dy = null, $dz = null) {
			/* decompiled (structured CF) */
			$this->isCollidedVertically = ($movY != $dy);
			$this->isCollidedHorizontally = (($movX != $dx) || ($movZ != $dz));
			$this->isCollided = ($this->isCollidedHorizontally || $this->isCollidedVertically);
			$this->onGround = (($movY != $dy) && ($movY < 0));
			return null;
		}

	public function getBlocksAround() {
			/* decompiled (structured CF) */
			if (($this->blocksAround === null)) {
				$minX = \pocketmine\math\Math::floorFloat($this->boundingBox->minX);
				$minY = \pocketmine\math\Math::floorFloat($this->boundingBox->minY);
				$minZ = \pocketmine\math\Math::floorFloat($this->boundingBox->minZ);
				$maxX = \pocketmine\math\Math::ceilFloat($this->boundingBox->maxX);
				$maxY = \pocketmine\math\Math::ceilFloat($this->boundingBox->maxY);
				$maxZ = \pocketmine\math\Math::ceilFloat($this->boundingBox->maxZ);
				$this->blocksAround = ['__array_ptr' => '2aaaac9fc9a0'];
				$z = $minZ;
				while (($z <= $maxZ)) {
					$x = $minX;
					while (($x <= $maxX)) {
						$y = $minY;
						while (($y <= $maxY)) {
							$block = $this->level->getBlock($this->temporalVector->setComponents($x, $y, $z));
							if ($block->hasEntityCollision()) {
								$this->blocksAround[\pocketmine\level\Level::blockHash($block->x, $block->y, $block->z)] = $block;
							}
							$y++;
						}
						$x++;
					}
					$z++;
				}
			}
			return $this->blocksAround;
		}

	protected function checkBlockCollision() {
			/* decompiled (structured CF) */
			new \pocketmine\math\Vector3(0, 0, 0);
			$vector = new \pocketmine\math\Vector3(0, 0, 0);
			$blocksaround = $this->getBlocksAround();
			foreach ($blocksaround as $block) {
				$block->onEntityCollide($this);
				if (($this->getLevel()->getServer()->redstoneEnabled && !($this->isPlayer))) {
					if ($block instanceof \pocketmine\block\PressurePlate) {
						$this->activatedPressurePlates[\pocketmine\level\Level::blockHash($block->x, $block->y, $block->z)] = $block;
					}
				}
				$block->addVelocityToEntity($this, $vector);
				/* goto */
			}
			if (($this->getLevel()->getServer()->redstoneEnabled && !($this->isPlayer))) {
				foreach ($this->activatedPressurePlates as $key => $block) {
					if (!(isset($blocksaround[$key]))) {
						$block->checkActivation();
					}
					/* goto */
				}
			}
			if ((0 < $vector->lengthSquared())) {
				$vector = $vector->normalize();
				$d = 0.014;
				$this->motionX += ($d * $vector->x);
				$this->motionY += ($d * $vector->y);
				$this->motionZ += ($d * $vector->z);
			}
			return null;
		}

	public function setPositionAndRotation($pos = null, $yaw = null, $pitch = null) {
			/* decompiled (structured CF) */
			if (($this->setPosition($pos) === true)) {
				$this->setRotation($yaw, $pitch);
				return true;
			}
			return false;
		}

	public function setRotation($yaw = null, $pitch = null) {
			/* decompiled (structured CF) */
			$this->yaw = $yaw;
			$this->pitch = $pitch;
			$this->scheduleUpdate();
			return null;
		}

	protected function checkChunks() {
			/* decompiled (structured CF) */
			if ((($this->chunk === null) || (($this->chunk->getX() !== ($this->x >> 4)) || ($this->chunk->getZ() !== ($this->z >> 4))))) {
				if (($this->chunk !== null)) {
					$this->chunk->removeEntity($this);
				}
				$this->chunk = $this->level->getChunk(($this->x >> 4), ($this->z >> 4), true);
				if (!($this->justCreated)) {
					$newChunk = $this->level->getChunkPlayers(($this->x >> 4), ($this->z >> 4));
					foreach ($this->hasSpawned as $player) {
						if (!(isset($newChunk[$player->getLoaderId()]))) {
							$this->despawnFrom($player);
						} else {
						}
						/* goto */
					}
					foreach ($newChunk as $player) {
						$this->spawnTo($player);
						/* goto */
					}
				}
				if (($this->chunk === null)) {
					return null;
				}
				$this->chunk->addEntity($this);
			}
		}

	public function setLocation($pos = null) {
			/* decompiled (structured CF) */
			if ($this->closed) {
				return false;
			}
			$this->setPositionAndRotation($pos, $pos->yaw, $pos->pitch);
			return true;
		}

	public function setPosition($pos = null) {
			/* decompiled (structured CF) */
			if ($this->closed) {
				return false;
			}
			if ((($pos instanceof \pocketmine\level\Position && ($pos->level !== null)) && ($pos->level !== $this->level))) {
				if (($this->switchLevel($pos->getLevel()) === false)) {
					return false;
				}
			}
			$this->x = $pos->x;
			$this->y = $pos->y;
			$this->z = $pos->z;
			$this->recalculateBoundingBox();
			$this->checkChunks();
			return true;
		}

	protected function recalculateBoundingBox() {
			$halfWidth = ($this->width / 2);
			$this->boundingBox->setBounds(($this->x - $halfWidth), $this->y, ($this->z - $halfWidth), ($this->x + $halfWidth), ($this->y + $this->height), ($this->z + $halfWidth));
			return null;
		}

	public function getMotion() {
			new \pocketmine\math\Vector3($this->motionX, $this->motionY, $this->motionZ);
			return new \pocketmine\math\Vector3($this->motionX, $this->motionY, $this->motionZ);
		}

	public function setMotion($motion = null) {
			/* decompiled (structured CF) */
			if (!($this->justCreated)) {
				new \pocketmine\event\entity\EntityMotionEvent($this, $motion);
				$ev = new \pocketmine\event\entity\EntityMotionEvent($this, $motion);
				$this->server->getPluginManager()->callEvent($ev);
				if ($ev->isCancelled()) {
					return false;
				}
			}
			$this->motionX = $motion->x;
			$this->motionY = $motion->y;
			$this->motionZ = $motion->z;
			if (!($this->justCreated)) {
				$this->updateMovement();
			}
			return true;
		}

	public function canBePushedByPiston() {
			return true;
		}

	public function onPushByPiston($piston = null) {
			return null;
		}

	public function isOnGround() {
			return ($this->onGround === true);
		}

	public function kill() {
			/* decompiled (structured CF) */
			$this->health = 0;
			$this->removeAllEffects();
			$this->scheduleUpdate();
			if (($this->getLevel()->getServer()->expEnabled && !($this->getLevel()->getServer()->isWorldMobDeathDropsAndExperienceDisabled($this->getLevel())))) {
				$exp = mt_rand($this->getDropExpMin(), $this->getDropExpMax());
				if ((0 < $exp)) {
					$this->getLevel()->spawnXPOrb($this, $exp);
				}
			}
			return null;
		}

	public function teleport($pos = null, $yaw = null, $pitch = null) {
			/* decompiled (structured CF) */
			if ($pos instanceof \pocketmine\level\Location) {
				if (($yaw === null)) {
				} else {
				}
				$yaw = $yaw;
				if (($pitch === null)) {
				} else {
				}
				$pitch = $pitch;
			}
			$from = \pocketmine\level\Position::fromObject($this, $this->level);
			if ($pos instanceof \pocketmine\level\Position) {
			} else {
			}
			$to = \pocketmine\level\Position::fromObject($pos, $this->level);
			new \pocketmine\event\entity\EntityTeleportEvent($this, $from, $to);
			$ev = new \pocketmine\event\entity\EntityTeleportEvent($this, $from, $to);
			$this->server->getPluginManager()->callEvent($ev);
			if ($ev->isCancelled()) {
				return false;
			}
			$this->ySize = 0;
			$pos = $ev->getTo();
			$this->setMotion($this->temporalVector->setComponents(0, 0, 0));
			if (($yaw === null)) {
			} else {
			}
			if (($pitch === null)) {
			} else {
			}
			if (($this->setPositionAndRotation($pos, $yaw, $pitch) !== false)) {
				$this->resetFallDistance();
				$this->onGround = true;
				$this->lastX = $this->x;
				$this->lastY = $this->y;
				$this->lastZ = $this->z;
				$this->lastYaw = $this->yaw;
				$this->lastPitch = $this->pitch;
				$this->updateMovement();
				return true;
			}
			return false;
		}

	public function getId() {
			return $this->id;
		}

	public function respawnToAll() {
			/* decompiled (structured CF) */
			foreach ($this->hasSpawned as $key => $player) {
				$this->spawnTo($player);
				/* goto */
			}
			return null;
		}

	public function spawnToAll() {
			/* decompiled (structured CF) */
			if ((($this->chunk === null) || $this->closed)) {
				return null;
			}
			foreach ($this->level->getChunkPlayers($this->chunk->getX(), $this->chunk->getZ()) as $player) {
				if ($player->isOnline()) {
					$this->spawnTo($player);
				}
				/* goto */
			}
		}

	public function despawnFromAll() {
			/* decompiled (structured CF) */
			foreach ($this->hasSpawned as $player) {
				$this->despawnFrom($player);
				/* goto */
			}
			return null;
		}

	protected function syncRiderPositionToVehicle($rider = null, $yOffset = null) {
			/* decompiled (structured CF) */
			if ((($this->level === null) || ($rider->getLevel() !== $this->level))) {
				return false;
			}
			$rider->setPosition($this->temporalVector->setComponents($this->x, ($this->y + $yOffset), $this->z));
			$rider->scheduleRidingChunkRefresh();
			return true;
		}

	protected function preloadRiderChunks($radius = null) {
			/* decompiled (structured CF) */
			$rider = $this->getLinkedEntity();
			if ((!($rider instanceof \pocketmine\Player) || ($this->level === null))) {
				return true;
			}
			$level = $this->getLevel();
			$chunkX = ((floor($this->x)) >> 4);
			$chunkZ = ((floor($this->z)) >> 4);
			$radius = max(0, $radius);
			$ready = true;
			$dx = ($radius * -1);
			while (($dx <= $radius)) {
				$dz = ($radius * -1);
				while (($dz <= $radius)) {
					$level->loadChunk(($chunkX + $dx), ($chunkZ + $dz), true);
					if (!($level->populateChunk(($chunkX + $dx), ($chunkZ + $dz), true))) {
						$ready = false;
					}
					$chunk = $level->getChunk(($chunkX + $dx), ($chunkZ + $dz), false);
					if (((($chunk === null) || !($chunk->isGenerated())) || !($chunk->isPopulated()))) {
						$ready = false;
					}
					/* jump */
					$ready = false;
					$dz++;
				}
				$dx++;
			}
			$rider->scheduleRidingChunkRefresh();
			return $ready;
		}

	public function close() {
			/* decompiled (structured CF) */
			if (!($this->closed)) {
				new \pocketmine\event\entity\EntityDespawnEvent($this);
				$this->server->getPluginManager()->callEvent(new \pocketmine\event\entity\EntityDespawnEvent($this));
				$this->closed = true;
				$this->removeEffect(\pocketmine\entity\Effect::HEALTH_BOOST);
				$this->despawnFromAll();
				if (($this->level !== null)) {
					foreach ($this->level->getEntities() as $entity) {
						if (((($entity !== $this) && $entity instanceof \pocketmine\entity\Entity) && $entity->isLeashedTo($this))) {
							$entity->unleash();
						}
						/* goto */
					}
				}
				if (($this->linkedType != 0)) {
					$this->linkedEntity->setLinked(0, $this);
				}
				if (($this->chunk !== null)) {
					$this->chunk->removeEntity($this);
				}
				if (($this->level !== null)) {
					$this->level->removeEntity($this);
				}
			}
			if ($this->getLevel()->getServer()->redstoneEnabled) {
				foreach ($this->activatedPressurePlates as $key => $block) {
					$block->checkActivation();
					/* goto */
				}
			}
			$this->activatedPressurePlates = ['__array_ptr' => '2aaaac9fc9a0'];
			if (($this->attributeMap != null)) {
				$this->attributeMap = null;
			}
			return null;
		}

	public function setDataProperty($id = null, $type = null, $value = null) {
			/* decompiled (structured CF) */
			if (($value !== $this->getDataProperty($id))) {
				$this->dataProperties[$id] = [$type, $value];
				$this->sendData($this->hasSpawned, [$this->dataProperties[$id]]);
				return true;
			}
			return false;
		}

	public function isLeashed() {
			return ((($this->getDataProperty(self::DATA_LEAD)) === 1) && (0 < $this->getLeashHolderEid()));
		}

	public function getLeashHolderEid() {
			return ($this->getDataProperty(self::DATA_LEAD_HOLDER));
		}

	public function getLeashHolder() {
			/* decompiled (structured CF) */
			if ((($this->level === null) || ($this->getLeashHolderEid() <= 0))) {
				return null;
			}
			return $this->level->getEntity($this->getLeashHolderEid());
		}

	public function isLeashedTo($holder = null) {
			return ($this->isLeashed() && ($this->getLeashHolderEid() === $holder->getId()));
		}

	public function setLeashedTo($holder = null) {
			/* decompiled (structured CF) */
			if ((($holder === $this) || !($holder->isAlive()))) {
				return false;
			}
			$this->setDataProperty(self::DATA_LEAD_HOLDER, self::DATA_TYPE_LONG, $holder->getId());
			$this->setDataProperty(self::DATA_LEAD, self::DATA_TYPE_BYTE, 1);
			return true;
		}

	public function unleash() {
			/* decompiled (structured CF) */
			if (!($this->isLeashed())) {
				return false;
			}
			$this->setDataProperty(self::DATA_LEAD_HOLDER, self::DATA_TYPE_LONG, -1);
			$this->setDataProperty(self::DATA_LEAD, self::DATA_TYPE_BYTE, 0);
			return true;
		}

	protected function restoreLeashFromNBT() {
			/* decompiled (structured CF) */
			if ((($this instanceof \pocketmine\entity\LeashKnot || !(isset($this->namedtag->Leashed))) || ($this->namedtag['Leashed'] <= 0))) {
				return null;
			}
			if ((isset($this->namedtag->Leash) && $this->namedtag->Leash instanceof \pocketmine\nbt\tag\CompoundTag)) {
				$tag = $this->namedtag->Leash;
				if (((isset($tag->X) && isset($tag->Y)) && isset($tag->Z))) {
					new \pocketmine\math\Vector3(($tag['X']), ($tag['Y']), ($tag['Z']));
					$block = $this->level->getBlock(new \pocketmine\math\Vector3(($tag['X']), ($tag['Y']), ($tag['Z'])));
					if (\pocketmine\entity\LeashKnot::isSupportedFence($block)) {
						$knot = \pocketmine\entity\LeashKnot::getOrCreate($this->level, $block);
						if ($knot instanceof \pocketmine\entity\LeashKnot) {
							$this->setLeashedTo($knot);
						}
					}
				}
			}
			if (isset($this->namedtag->LeashHolder)) {
				$this->setDataProperty(self::DATA_LEAD_HOLDER, self::DATA_TYPE_LONG, ($this->namedtag['LeashHolder']));
				$this->setDataProperty(self::DATA_LEAD, self::DATA_TYPE_BYTE, 1);
			}
		}

	public function linkEntity($entity = null) {
			return $this->setLinked(1, $entity);
		}

	public function sendLinkedData() {
			/* decompiled (structured CF) */
			if ($this->linkedEntity instanceof \pocketmine\entity\Entity) {
				$this->setLinked($this->linkedType, $this->linkedEntity);
			}
			return null;
		}

	public function setLinked($type = null, $entity = null) {
			/* decompiled (structured CF) */
			if ((($type != 0) && ($entity === null))) {
				return false;
			}
			if (($entity === $this)) {
				return false;
			}
			if (!(($type == 0))) {
				if (!(($type == 1))) {
					if (!(($type == 2))) {
						/* jump */
						if (($this->linkedType == 0)) {
							return true;
						}
						$this->linkedType = 0;
						$this->setDataFlag(self::DATA_FLAGS, self::DATA_FLAG_RIDING, false);
						new \pocketmine\network\protocol\SetEntityLinkPacket();
						$pk = new \pocketmine\network\protocol\SetEntityLinkPacket();
						$pk->from = $entity->getId();
						$pk->to = $this->getId();
						$pk->type = 3;
						$this->server->broadcastPacket($this->level->getPlayers(), $pk);
						if ($this instanceof \pocketmine\Player) {
							new \pocketmine\network\protocol\SetEntityLinkPacket();
							$pk = new \pocketmine\network\protocol\SetEntityLinkPacket();
							$pk->from = $entity->getId();
							$pk->to = 0;
							$pk->type = 3;
							$this->dataPacket($pk);
						}
						if ($this->linkedEntity->getLinkedType()) {
							$this->linkedEntity->setLinked(0, $this);
						}
						$this->linkedEntity = null;
						return true;
						if (($entity instanceof \pocketmine\entity\Vehicle && !($entity->canBeRidden()))) {
							return false;
						}
						if (($entity instanceof \pocketmine\entity\Ageable && $entity->isBaby())) {
							return false;
						}
						if (!($entity->isAlive())) {
							return false;
						}
						$this->linkedEntity = $entity;
						$this->linkedType = 1;
						$entity->linkedEntity = $this;
						$entity->linkedType = 1;
						$this->setDataFlag(self::DATA_FLAGS, self::DATA_FLAG_RIDING, true);
						new \pocketmine\network\protocol\SetEntityLinkPacket();
						$pk = new \pocketmine\network\protocol\SetEntityLinkPacket();
						$pk->from = $entity->getId();
						$pk->to = $this->getId();
						$pk->type = \pocketmine\network\protocol\SetEntityLinkPacket::TYPE_RIDE;
						$this->server->broadcastPacket($this->level->getPlayers(), $pk);
						if ($this instanceof \pocketmine\Player) {
							new \pocketmine\network\protocol\SetEntityLinkPacket();
							$pk = new \pocketmine\network\protocol\SetEntityLinkPacket();
							$pk->from = $entity->getId();
							$pk->to = 0;
							$pk->type = \pocketmine\network\protocol\SetEntityLinkPacket::TYPE_RIDE;
							$this->dataPacket($pk);
						}
						return true;
					}
				}
				if (!($entity->isAlive())) {
					return false;
				}
				if (($entity->getLinkedEntity() !== $this)) {
					return $entity->linkEntity($this);
				}
				$this->linkedEntity = $entity;
				$this->linkedType = 2;
				return true;
			}
		}

	public function getLinkedEntity() {
			return $this->linkedEntity;
		}

	public function getLinkedType() {
			return $this->linkedType;
		}

	public function getDataProperty($id = null) {
			/* decompiled (structured CF) */
			if (isset($this->dataProperties[$id])) {
			} else {
			}
			return null;
		}

	public function getDataPropertyType($id = null) {
			/* decompiled (structured CF) */
			if (isset($this->dataProperties[$id])) {
			} else {
			}
			return null;
		}

	public function setDataFlag($propertyId = null, $id = null, $value = null, $type = null) {
			/* decompiled (structured CF) */
			if (($value !== $this->getDataFlag($propertyId, $id))) {
				$flags = ($this->getDataProperty($propertyId));
				$flags ^= (1 << $id);
				$propertyType = $this->getDataPropertyType($propertyId);
				if (($propertyType === null)) {
				} else {
				}
				$this->setDataProperty($propertyId, $propertyType, $flags);
			}
			return null;
		}

	public function getDataFlag($propertyId = null, $id = null) {
			return (0 < (($this->getDataProperty($propertyId)) & (1 << $id)));
		}

	public function __destruct() {
			$this->close();
			return;
		}

	public function setMetadata($metadataKey = null, $metadataValue = null) {
			$this->server->getEntityMetadata()->setMetadata($this, $metadataKey, $metadataValue);
			return null;
		}

	public function getMetadata($metadataKey = null) {
			return $this->server->getEntityMetadata()->getMetadata($this, $metadataKey);
		}

	public function hasMetadata($metadataKey = null) {
			return $this->server->getEntityMetadata()->hasMetadata($this, $metadataKey);
		}

	public function removeMetadata($metadataKey = null, $plugin = null) {
			$this->server->getEntityMetadata()->removeMetadata($this, $metadataKey, $plugin);
			return null;
		}

	public function __toString() {
			new \ReflectionClass($this);
			return ((((new \ReflectionClass($this))->getShortName() . '(') . $this->getId()) . ')');
		}

}
