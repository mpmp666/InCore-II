<?php

namespace pocketmine\entity;

class Sheep extends \pocketmine\entity\Animal implements \pocketmine\entity\Colorable {
	public const NETWORK_ID = 13;

	public $width = 0.625;
	public $length = 1.4375;
	public $height = 0.5;

	public function getName() {
			return 'Sheep';
		}

	public function initEntity() {
			/* decompiled (structured CF) */
			$this->setMaxHealth(8);
			new \pocketmine\entity\behavior\inLoveBehavior($this);
			$this->addBehavior(new \pocketmine\entity\behavior\inLoveBehavior($this));
			new \pocketmine\entity\behavior\eatGrassBehavior($this);
			$this->addBehavior(new \pocketmine\entity\behavior\eatGrassBehavior($this));
			new \pocketmine\entity\behavior\findFoodBehavior($this, 296);
			$this->addBehavior(new \pocketmine\entity\behavior\findFoodBehavior($this, 296));
			parent::initEntity();
			return null;
		}

	public function usesPm1eGroundAi() {
			return true;
		}

	protected function getBreedingItemIds() {
			return [\pocketmine\item\Item::WHEAT];
		}

	public function onInteract($player = null, $item = null) {
			/* decompiled (structured CF) */
			if ((($this->isBaby() || !($this->hasWool())) || !($item instanceof \pocketmine\item\Shears))) {
				return parent::onInteract($player, $item);
			}
			if ($player->isSurvival()) {
				$item->useOn($this);
				$player->getInventory()->setItemInHand($item);
			}
			$this->sethasWool(false);
			foreach ($this->getDrops() as $drop) {
				$this->getLevel()->dropItem($this, $drop);
				/* goto */
			}
			return true;
		}

	public function __construct($chunk = null, $nbt = null) {
			/* decompiled (structured CF) */
			if (!(isset($nbt->Color))) {
				new \pocketmine\nbt\tag\ByteTag('Color', self::getRandomColor());
				$nbt->Color = new \pocketmine\nbt\tag\ByteTag('Color', self::getRandomColor());
			}
			parent::__construct($chunk, $nbt);
			$this->sethasWool(true);
			return;
		}

	public static function getRandomColor() {
			/* decompiled (structured CF) */
			$rand = '';
			$rand .= str_repeat((\pocketmine\block\Wool::WHITE . $this), 20);
			$rand .= str_repeat((\pocketmine\block\Wool::ORANGE . $this), 5);
			$rand .= str_repeat((\pocketmine\block\Wool::MAGENTA . $this), 5);
			$rand .= str_repeat((\pocketmine\block\Wool::LIME . $this), 5);
			$rand .= str_repeat((\pocketmine\block\Wool::LIGHT_BLUE . $this), 5);
			$rand .= str_repeat((\pocketmine\block\Wool::YELLOW . $this), 5);
			$rand .= str_repeat((\pocketmine\block\Wool::PINK . $this), 5);
			$rand .= str_repeat((\pocketmine\block\Wool::GRAY . $this), 10);
			$rand .= str_repeat((\pocketmine\block\Wool::LIGHT_GRAY . $this), 5);
			$rand .= str_repeat((\pocketmine\block\Wool::CYAN . $this), 5);
			$rand .= str_repeat((\pocketmine\block\Wool::PURPLE . $this), 5);
			$rand .= str_repeat((\pocketmine\block\Wool::BLUE . $this), 5);
			$rand .= str_repeat((\pocketmine\block\Wool::BROWN . $this), 5);
			$rand .= str_repeat((\pocketmine\block\Wool::GREEN . $this), 5);
			$rand .= str_repeat((\pocketmine\block\Wool::RED . $this), 5);
			$rand .= str_repeat((\pocketmine\block\Wool::BLACK . $this), 5);
			$arr = explode($this, $rand);
			return $arr[mt_rand(0, (count($arr) - 16))];
		}

	public function getColor() {
			return ($this->namedtag['Color']);
		}

	public function setColor($color = null) {
			new \pocketmine\nbt\tag\ByteTag('Color', $color);
			$this->namedtag->Color = new \pocketmine\nbt\tag\ByteTag('Color', $color);
			return null;
		}

	public function sethasWool($resting = null) {
			/* decompiled (structured CF) */
			if ($resting) {
				$this->setDataProperty(self::DATA_COLOR_INFO, self::DATA_TYPE_BYTE, $this->getColor());
			} else {
				$this->setDataProperty(self::DATA_COLOR_INFO, self::DATA_TYPE_BYTE, 16);
			}
			return null;
		}

	public function hasWool() {
			return ($this->getDataProperty(self::DATA_COLOR_INFO) !== 16);
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->eid = $this->getId();
			$pk->type = 13;
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->yaw = $this->yaw;
			$pk->pitch = $this->pitch;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

	public function getDrops() {
			$drops = [\pocketmine\item\Item::get(\pocketmine\item\Item::WOOL, $this->getColor(), 1)];
			return $drops;
		}

}
