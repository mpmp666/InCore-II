<?php

namespace pocketmine\entity;

class ThrownPotion extends \pocketmine\entity\Projectile {
	public const NETWORK_ID = 86;

	public $width = 0.25;
	public $length = 0.25;
	public $height = 0.25;
	protected $gravity = 0.1;
	protected $drag = 0.05;

	public function __construct($chunk = null, $nbt = null, $shootingEntity = null) {
			/* decompiled (structured CF) */
			if (!(isset($nbt->PotionId))) {
				new \pocketmine\nbt\tag\ShortTag('PotionId', \pocketmine\item\Potion::AWKWARD);
				$nbt->PotionId = new \pocketmine\nbt\tag\ShortTag('PotionId', \pocketmine\item\Potion::AWKWARD);
			}
			parent::__construct($chunk, $nbt, $shootingEntity);
			$this->setDataProperty(self::DATA_POTION_ID, self::DATA_TYPE_SHORT, $this->getPotionId());
			return;
		}

	public function getPotionId() {
			return ($this->namedtag['PotionId']);
		}

	public function kill() {
			/* decompiled (structured CF) */
			$color = \pocketmine\item\Potion::getColor($this->getPotionId());
			new \pocketmine\level\particle\SpellParticle($this, $color[0], $color[1], $color[2]);
			$this->getLevel()->addParticle(new \pocketmine\level\particle\SpellParticle($this, $color[0], $color[1], $color[2]));
			$affected = ['__array_ptr' => '2aaaac9fc9a0'];
			foreach ($this->getViewers() as $player) {
				if (($player->distance($this) <= 6)) {
					$this->applyPotionEffect($player);
					$affected[$player->getId()] = true;
				}
				/* goto */
			}
			foreach ($this->getLevel()->getNearbyEntities($this->boundingBox->grow(6, 6, 6), $this) as $entity) {
				if (((isset($affected[$entity->getId()]) || !($entity instanceof \pocketmine\entity\Living)) || (6 < $entity->distance($this)))) {
					/* goto */
				}
				$this->applyPotionEffect($entity);
				$affected[$entity->getId()] = true;
				/* goto */
			}
			parent::kill();
			return null;
		}

	protected function applyPotionEffect($entity = null) {
			/* decompiled (structured CF) */
			switch ($this->getPotionId()) {
				case \pocketmine\item\Potion::NIGHT_VISION:
				$entity->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::NIGHT_VISION)->setAmplifier(0)->setDuration(3600));
				break;
				case \pocketmine\item\Potion::NIGHT_VISION_T:
				$entity->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::NIGHT_VISION)->setAmplifier(0)->setDuration(7200));
				break;
				case \pocketmine\item\Potion::INVISIBILITY:
				$entity->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::INVISIBILITY)->setAmplifier(0)->setDuration(3600));
				break;
				case \pocketmine\item\Potion::INVISIBILITY_T:
				$entity->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::INVISIBILITY)->setAmplifier(0)->setDuration(7200));
				break;
				case \pocketmine\item\Potion::LEAPING:
				$entity->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::JUMP)->setAmplifier(0)->setDuration(3600));
				break;
				case \pocketmine\item\Potion::LEAPING_T:
				$entity->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::JUMP)->setAmplifier(0)->setDuration(7200));
				break;
				case \pocketmine\item\Potion::LEAPING_TWO:
				$entity->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::JUMP)->setAmplifier(1)->setDuration(1800));
				break;
				case \pocketmine\item\Potion::FIRE_RESISTANCE:
				$entity->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::FIRE_RESISTANCE)->setAmplifier(0)->setDuration(3600));
				break;
				case \pocketmine\item\Potion::FIRE_RESISTANCE_T:
				$entity->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::FIRE_RESISTANCE)->setAmplifier(0)->setDuration(7200));
				break;
				case \pocketmine\item\Potion::SPEED:
				$entity->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::SPEED)->setAmplifier(0)->setDuration(3600));
				break;
				case \pocketmine\item\Potion::SPEED_T:
				$entity->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::SPEED)->setAmplifier(0)->setDuration(7200));
				break;
				case \pocketmine\item\Potion::SPEED_TWO:
				$entity->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::SPEED)->setAmplifier(1)->setDuration(1800));
				break;
				case \pocketmine\item\Potion::SLOWNESS:
				$entity->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::SLOWNESS)->setAmplifier(0)->setDuration(1200));
				break;
				case \pocketmine\item\Potion::SLOWNESS_T:
				$entity->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::SLOWNESS)->setAmplifier(0)->setDuration(4800));
				break;
				case \pocketmine\item\Potion::WATER_BREATHING:
				$entity->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::WATER_BREATHING)->setAmplifier(0)->setDuration(3600));
				break;
				case \pocketmine\item\Potion::WATER_BREATHING_T:
				$entity->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::WATER_BREATHING)->setAmplifier(0)->setDuration(7200));
				break;
				case \pocketmine\item\Potion::POISON:
				$entity->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::POISON)->setAmplifier(0)->setDuration(900));
				break;
				case \pocketmine\item\Potion::POISON_T:
				$entity->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::POISON)->setAmplifier(0)->setDuration(2400));
				break;
				case \pocketmine\item\Potion::POISON_TWO:
				$entity->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::POISON)->setAmplifier(0)->setDuration(440));
				break;
				case \pocketmine\item\Potion::REGENERATION:
				$entity->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::REGENERATION)->setAmplifier(0)->setDuration(900));
				break;
				case \pocketmine\item\Potion::REGENERATION_T:
				$entity->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::REGENERATION)->setAmplifier(0)->setDuration(2400));
				break;
				case \pocketmine\item\Potion::REGENERATION_TWO:
				$entity->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::REGENERATION)->setAmplifier(1)->setDuration(440));
				break;
				case \pocketmine\item\Potion::STRENGTH:
				$entity->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::STRENGTH)->setAmplifier(0)->setDuration(3600));
				break;
				case \pocketmine\item\Potion::STRENGTH_T:
				$entity->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::STRENGTH)->setAmplifier(0)->setDuration(7200));
				break;
				case \pocketmine\item\Potion::STRENGTH_TWO:
				$entity->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::STRENGTH)->setAmplifier(1)->setDuration(1800));
				break;
				case \pocketmine\item\Potion::WEAKNESS:
				$entity->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::WEAKNESS)->setAmplifier(0)->setDuration(1800));
				break;
				case \pocketmine\item\Potion::WEAKNESS_T:
				$entity->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::WEAKNESS)->setAmplifier(0)->setDuration(4800));
				break;
				case \pocketmine\item\Potion::HEALING:
				$entity->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::HEALING)->setAmplifier(0)->setDuration(1));
				break;
				case \pocketmine\item\Potion::HEALING_TWO:
				$entity->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::HEALING)->setAmplifier(1)->setDuration(1));
				break;
				case \pocketmine\item\Potion::HARMING:
				$entity->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::HARMING)->setAmplifier(0)->setDuration(1));
				break;
				case \pocketmine\item\Potion::HARMING_TWO:
				$entity->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::HARMING)->setAmplifier(1)->setDuration(1));
				break;
			}
			return null;
		}

	public function onUpdate($currentTick = null) {
			/* decompiled (structured CF) */
			if ($this->closed) {
				return false;
			}
			$this->timings->startTiming();
			$hasUpdate = parent::onUpdate($currentTick);
			if (((1200 < $this->age) || $this->isCollided)) {
				$this->kill();
				$this->close();
				$hasUpdate = true;
			}
			if ($this->onGround) {
				$this->kill();
				$this->close();
			}
			$this->timings->stopTiming();
			return $hasUpdate;
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->type = 86;
			$pk->eid = $this->getId();
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

}
