<?php

namespace pocketmine\entity;

class XPOrb extends \pocketmine\entity\Entity {
	public const NETWORK_ID = 69;

	public $width = 0.25;
	public $length = 0.25;
	public $height = 0.25;
	protected $gravity = 0.04;
	protected $drag = 0;
	protected $experience = 0;

	public function initEntity() {
			/* decompiled (structured CF) */
			parent::initEntity();
			if (isset($this->namedtag->Experience)) {
				$this->experience = $this->namedtag['Experience'];
			} else {
				$this->close();
			}
			return null;
		}

	public function onUpdate($currentTick = null) {
			/* decompiled (structured CF) */
			if ($this->closed) {
				return false;
			}
			$tickDiff = ($currentTick - $this->lastUpdate);
			$this->lastUpdate = $currentTick;
			$this->timings->startTiming();
			$hasUpdate = $this->entityBaseTick($tickDiff);
			if ((1200 < $this->age)) {
				$this->kill();
				$this->close();
				$hasUpdate = true;
			}
			$minDistance = \PHP_INT_MAX;
			$expectedPos = null;
			foreach ($this->getLevel()->getEntities() as $e) {
				if ($e instanceof \pocketmine\Player) {
					if (($e->distance($this) <= $minDistance)) {
						$expectedPos = $e;
						$minDistance = $e->distance($this);
					}
				}
				/* goto */
			}
			if (($minDistance < \PHP_INT_MAX)) {
				$moveSpeed = 0.7;
				$motX = (($expectedPos->getX() - $this->x) / 8);
				$motY = ((($expectedPos->getY() + $expectedPos->getEyeHeight()) - $this->y) / 8);
				$motZ = (($expectedPos->getZ() - $this->z) / 8);
				$motSqrt = sqrt(((($motX * $motX) + ($motY * $motY)) + ($motZ * $motZ)));
				$motC = (1 - $motSqrt);
				if ((0 < $motC)) {
					$motC *= $motC;
					$this->motionX = ($moveSpeed * ($motC * ($motX / $motSqrt)));
					$this->motionY = ($moveSpeed * ($motC * ($motY / $motSqrt)));
					$this->motionZ = ($moveSpeed * ($motC * ($motZ / $motSqrt)));
				}
				$this->motionY -= $this->gravity;
				if ($this->checkObstruction($this->x, $this->y, $this->z)) {
					$hasUpdate = true;
				}
				if (($minDistance <= 1.3)) {
					if ($this->getLevel()->getServer()->expEnabled) {
						if ((0 < $this->getExperience())) {
							$this->kill();
							$this->close();
							new \pocketmine\event\player\PlayerPickupExpOrbEvent($expectedPos, $this->getExperience());
							$ev = new \pocketmine\event\player\PlayerPickupExpOrbEvent($expectedPos, $this->getExperience());
							$this->getLevel()->getServer()->getPluginManager()->callEvent($ev);
							if (!($ev->isCancelled())) {
								$expectedPos->addExperience($this->getExperience());
							}
						}
					}
				}
			}
			$this->move($this->motionX, $this->motionY, $this->motionZ);
			$this->updateMovement();
			$this->timings->stopTiming();
			return (((($hasUpdate || !($this->onGround)) || (1e-05 < abs($this->motionX))) || (1e-05 < abs($this->motionY))) || (1e-05 < abs($this->motionZ)));
		}

	public function canCollideWith($entity = null) {
			return false;
		}

	public function setExperience($exp = null) {
			$this->experience = $exp;
		}

	public function getExperience() {
			return $this->experience;
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			$this->setDataProperty(self::DATA_NO_AI, self::DATA_TYPE_BYTE, 1);
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->type = 69;
			$pk->eid = $this->getId();
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

}
