<?php

namespace pocketmine\entity;

class Horse extends \pocketmine\entity\Animal implements \pocketmine\inventory\InventoryHolder, \pocketmine\entity\Rideable {
	public const NETWORK_ID = 23;
	public const VARIANT_WHITE = 0;
	public const VARIANT_CREAMY = 1;
	public const VARIANT_CHESTNUT = 2;
	public const VARIANT_BROWN = 3;
	public const VARIANT_BLACK = 4;
	public const VARIANT_GRAY = 5;
	public const VARIANT_DARK_BROWN = 6;
	public const MARK_NONE = 0;
	public const MARK_WHITE = 1;
	public const MARK_WHITE_FIELD = 2;
	public const MARK_WHITE_DOTS = 3;
	public const MARK_BLACK_DOTS = 4;
	public const RIDER_INPUT_DEADZONE = 0.08;
	public const RIDER_BRAKE_PER_TICK = 0.45;
	public const RIDER_JUMP_INPUT_STRENGTH = 90.0;
	public const DATA_HORSE_FLAGS = 16;
	public const DATA_HORSE_TYPE = 19;
	public const DATA_HORSE_VARIANT = 20;

	public $width = 1.4;
	public $length = 1.4;
	public $height = 1.6;
	public $dropExp = array (
  0 => 1,
  1 => 3,
);
	protected $inventory = NULL;
	protected $riderInputX = 0.0;
	protected $riderInputY = 0.0;
	protected $riderJumping = false;
	protected $riderSneaking = false;
	protected $jumpPower = 0.0;
	protected $horseJumping = false;
	protected $variant = 0;
	protected $markVariant = 0;

	public function __construct($chunk = null, $nbt = null) {
			parent::__construct($chunk, $nbt);
			return;
		}

	public function getName() {
			return 'Horse';
		}

	public function initEntity() {
			/* decompiled (structured CF) */
			$this->setMaxHealth(30);
			parent::initEntity();
			$this->stepHeight = 1.0625;
			if (isset($this->namedtag->Variant)) {
			} else {
			}
			$this->variant = mt_rand(0, self::VARIANT_DARK_BROWN);
			if (isset($this->namedtag->MarkVariant)) {
			} else {
			}
			$this->markVariant = mt_rand(0, self::MARK_BLACK_DOTS);
			$this->syncHorseAppearanceData();
			new \pocketmine\inventory\HorseInventory($this);
			$this->inventory = new \pocketmine\inventory\HorseInventory($this);
			if ((isset($this->namedtag->Inventory) && $this->namedtag->Inventory instanceof \pocketmine\nbt\tag\ListTag)) {
				$this->inventory->loadFromNbt($this->namedtag->Inventory);
			} else {
				if ((isset($this->namedtag->SaddleItem) && $this->namedtag->SaddleItem instanceof \pocketmine\nbt\tag\CompoundTag)) {
					$this->inventory->setSaddle(\pocketmine\nbt\NBT::getItemHelper($this->namedtag->SaddleItem));
				}
				if ((isset($this->namedtag->ArmorItem) && $this->namedtag->ArmorItem instanceof \pocketmine\nbt\tag\CompoundTag)) {
					$this->inventory->setArmor(\pocketmine\nbt\NBT::getItemHelper($this->namedtag->ArmorItem));
				}
			}
			if (((isset($this->namedtag->Saddled) && (0 < ($this->namedtag['Saddled']))) && ($this->inventory->getSaddle()->getId() !== \pocketmine\item\Item::SADDLE))) {
				$this->inventory->setSaddle(\pocketmine\item\Item::get(\pocketmine\item\Item::SADDLE, 0, 1));
			}
			return null;
		}

	public function usesPm1eGroundAi() {
			return true;
		}

	public function getInventory() {
			return $this->inventory;
		}

	public function getVariant() {
			return $this->variant;
		}

	public function getMarkVariant() {
			return $this->markVariant;
		}

	protected function syncHorseAppearanceData() {
			$this->setDataProperty(self::DATA_HORSE_TYPE, self::DATA_TYPE_BYTE, 0);
			$this->setDataProperty(self::DATA_HORSE_VARIANT, self::DATA_TYPE_INT, ($this->variant | ($this->markVariant << 8)));
			return null;
		}

	public function canBeSaddled() {
			return !($this->isBaby());
		}

	public function isSaddled() {
			return $this->getDataFlag(self::DATA_FLAGS, self::DATA_FLAG_SADDLED);
		}

	public function setSaddled($saddled = null) {
			/* decompiled (structured CF) */
			if (($saddled && !($this->canBeSaddled()))) {
				return false;
			}
			$changed = ($saddled !== $this->isSaddled());
			$this->setDataFlag(self::DATA_FLAGS, self::DATA_FLAG_SADDLED, $saddled);
			if ($saddled) {
			} else {
			}
			new \pocketmine\nbt\tag\ByteTag('Saddled', 0);
			$this->namedtag->Saddled = new \pocketmine\nbt\tag\ByteTag('Saddled', 0);
			return $changed;
		}

	public function canBeRidden() {
			return (!($this->isBaby()) && $this->isSaddled());
		}

	public function canBeMounted() {
			return !($this->isBaby());
		}

	public function canBeControlledBy($rider = null) {
			return ($this->canBeRidden() && $rider instanceof \pocketmine\Player);
		}

	public function supportsPlayerProtocol($player = null) {
			return \pocketmine\network\protocol\ProtocolCompatibility::isProtocol015(($player->getProtocol()));
		}

	protected function getBreedingItemIds() {
			return [\pocketmine\item\Item::GOLDEN_APPLE, \pocketmine\item\Item::ENCHANTED_GOLDEN_APPLE, \pocketmine\item\Item::GOLDEN_CARROT];
		}

	public static function isHorseArmorItem($item = null) {
			return in_array($item->getId(), [\pocketmine\item\Item::LEATHER_HORSE_ARMOR, \pocketmine\item\Item::IRON_HORSE_ARMOR, \pocketmine\item\Item::GOLDEN_HORSE_ARMOR, \pocketmine\item\Item::DIAMOND_HORSE_ARMOR], true);
		}

	public function onInteract($player = null, $item = null) {
			/* decompiled (structured CF) */
			if (!($this->supportsPlayerProtocol($player))) {
				return false;
			}
			if ($item instanceof \pocketmine\item\Lead) {
				return $item->leashEntity($player, $this);
			}
			if ($this->isBaby()) {
				return false;
			}
			if ((($item->getId() === \pocketmine\item\Item::SADDLE) && !($this->isSaddled()))) {
				if ($this->inventory->setSaddle($item)) {
					$this->consumeInteractionItem($player, $item);
					return true;
				}
			}
			if ((self::isHorseArmorItem($item) && ($this->inventory->getArmor()->getId() === \pocketmine\item\Item::AIR))) {
				if ($this->inventory->setArmor($item)) {
					$this->consumeInteractionItem($player, $item);
					return true;
				}
			}
			if ($this->canBeMounted()) {
				return $this->mountPlayer($player);
			}
			return false;
		}

	public function handleRiderInventoryButton($player = null) {
			/* decompiled (structured CF) */
			if ((($player !== $this->getLinkedEntity()) || !($this->supportsPlayerProtocol($player)))) {
				return false;
			}
			return $this->equipHeldHorseEquipment($player);
		}

	private function equipHeldHorseEquipment($player = null) {
			/* decompiled (structured CF) */
			$item = $player->getInventory()->getItemInHand();
			if (($item->getCount() <= 0)) {
				return false;
			}
			if (($item->getId() === \pocketmine\item\Item::SADDLE)) {
				return $this->equipSaddleFromPlayer($player, $item);
			}
			if (self::isHorseArmorItem($item)) {
				return $this->equipHorseArmorFromPlayer($player, $item);
			}
			return false;
		}

	private function equipSaddleFromPlayer($player = null, $item = null) {
			/* decompiled (structured CF) */
			if (!($this->canBeSaddled())) {
				return false;
			}
			$oldSaddle = $this->inventory->getSaddle();
			$equipment = clone $item;
			$equipment->setCount(1);
			if (!($this->inventory->setSaddle($equipment))) {
				return false;
			}
			$this->consumeInteractionItem($player, $item);
			$this->returnReplacedEquipmentToPlayer($player, $oldSaddle);
			return true;
		}

	private function equipHorseArmorFromPlayer($player = null, $item = null) {
			/* decompiled (structured CF) */
			$oldArmor = $this->inventory->getArmor();
			$equipment = clone $item;
			$equipment->setCount(1);
			if (!($this->inventory->setArmor($equipment))) {
				return false;
			}
			$this->consumeInteractionItem($player, $item);
			$this->returnReplacedEquipmentToPlayer($player, $oldArmor);
			return true;
		}

	private function returnReplacedEquipmentToPlayer($player = null, $item = null) {
			/* decompiled (structured CF) */
			if ((($item->getId() === \pocketmine\item\Item::AIR) || ($item->getCount() <= 0))) {
				return null;
			}
			if ($player->isCreative()) {
			}
			$remaining = $player->getInventory()->addItem($item);
			foreach ($remaining as $drop) {
				$player->getLevel()->dropItem($player->getPosition(), $drop);
				/* goto */
			}
		}

	private function consumeInteractionItem($player = null, $item = null) {
			/* decompiled (structured CF) */
			if ($player->isCreative()) {
				return null;
			}
			$item->setCount(($item->getCount() - 1));
			if ((0 < $item->getCount())) {
			} else {
			}
			$player->getInventory()->setItemInHand(\pocketmine\item\Item::get(\pocketmine\item\Item::AIR, 0, 0));
		}

	public function mountPlayer($player = null) {
			/* decompiled (structured CF) */
			if (!($this->canBeMounted())) {
				return false;
			}
			if (($this->getLinkedEntity() instanceof \pocketmine\entity\Entity && ($player !== $this->getLinkedEntity()))) {
				return false;
			}
			if (($player->getLinkedEntity() instanceof \pocketmine\entity\Entity && ($player->getLinkedEntity() !== $this))) {
				return false;
			}
			$this->linkedEntity = $player;
			$this->linkedType = 1;
			$player->linkedEntity = $this;
			$player->linkedType = 1;
			$this->passenger = $player;
			$player->vehicle = $this;
			$player->setDataFlag(self::DATA_FLAGS, self::DATA_FLAG_RIDING, true);
			$this->syncRiderMount($player);
			return true;
		}

	public function dismountPlayer($player = null, $scheduleDelayedTeleport = null, $afterTeleport = null) {
			/* decompiled (structured CF) */
			if ((($player !== $this->getLinkedEntity()) && ($player->getLinkedEntity() !== $this))) {
				return false;
			}
			if ($scheduleDelayedTeleport) {
				$dismountPosition = $this->getRiderDismountPosition();
				$horse = $this;
				new \pocketmine\scheduler\CallbackTask(function () { /* unrecovered lambda E:/Desktop/src/src/pocketmine/entity/Horse.php.gOchlo:308$13 */ return null; }, [$player, $dismountPosition, $player->getYaw(), $player->getPitch(), $afterTeleport]);
				$this->server->getScheduler()->scheduleDelayedTask(new \pocketmine\scheduler\CallbackTask(function () { /* unrecovered lambda E:/Desktop/src/src/pocketmine/entity/Horse.php.gOchlo:308$13 */ return null; }, [$player, $dismountPosition, $player->getYaw(), $player->getPitch(), $afterTeleport]), 5);
			}
			$this->sendHorseLinkPacket($player, $player->getId(), \pocketmine\network\protocol\SetEntityLinkPacket::TYPE_REMOVE);
			$this->sendHorseLinkPacket($player, 0, \pocketmine\network\protocol\SetEntityLinkPacket::TYPE_REMOVE);
			$this->linkedEntity = null;
			$this->linkedType = 0;
			$this->passenger = null;
			$this->riderInputX = 0;
			$this->riderInputY = 0;
			$this->riderJumping = false;
			$this->riderSneaking = false;
			$this->jumpPower = 0;
			$this->horseJumping = false;
			$player->linkedEntity = null;
			$player->linkedType = 0;
			$player->vehicle = null;
			$player->setDataFlag(self::DATA_FLAGS, self::DATA_FLAG_RIDING, false);
			return true;
		}

	public function attack($damage = null, $source = null) {
			return parent::attack($damage, $source);
		}

	public function handleRiderInput($player = null, $motX = null, $motY = null, $jumping = null, $sneaking = null) {
			/* decompiled (structured CF) */
			if (($player !== $this->getLinkedEntity())) {
				return false;
			}
			if ($sneaking) {
				return $this->dismountPlayer($player, true);
			}
			$pressedJump = ($jumping && !($this->riderJumping));
			$this->riderInputX = max(-1, min(1, $motX));
			$this->riderInputY = max(-1, min(1, $motY));
			if ($pressedJump) {
				$this->handleRiderJump($player);
			}
			$this->riderJumping = $jumping;
			$this->riderSneaking = $sneaking;
			return true;
		}

	public function handleRiderJump($player = null) {
			/* decompiled (structured CF) */
			if ((($player !== $this->getLinkedEntity()) || !($this->supportsPlayerProtocol($player)))) {
				return false;
			}
			$this->queueRiderJump(self::RIDER_JUMP_INPUT_STRENGTH);
			return true;
		}

	protected function queueRiderJump($jumpPowerIn = null) {
			$this->jumpPower = $this->normalizeRiderJumpPower($jumpPowerIn);
			return null;
		}

	protected function normalizeRiderJumpPower($jumpPowerIn = null) {
			/* decompiled (structured CF) */
			if (($jumpPowerIn < 0)) {
				return 0;
			}
			if ((self::RIDER_JUMP_INPUT_STRENGTH <= $jumpPowerIn)) {
			} else {
			}
			return (0.4 + (($jumpPowerIn * 0.4) / self::RIDER_JUMP_INPUT_STRENGTH));
		}

	public function setJumpPower($jumpPowerIn = null) {
			/* decompiled (structured CF) */
			if ((!($this->isSaddled()) || ($jumpPowerIn < 0))) {
				$this->jumpPower = 0;
				return null;
			}
			$this->jumpPower = $this->normalizeRiderJumpPower($jumpPowerIn);
		}

	public function getJumpPower() {
			return $this->jumpPower;
		}

	public function isHorseJumping() {
			return $this->horseJumping;
		}

	public function setHorseJumping($jumping = null) {
			$this->horseJumping = $jumping;
		}

	protected function tickPm1eGroundAi($tickDiff = null) {
			/* decompiled (structured CF) */
			$rider = $this->getLinkedEntity();
			if ($rider instanceof \pocketmine\Player) {
				return $this->tickRiddenHorse($rider, $tickDiff);
			}
			return parent::tickPm1eGroundAi($tickDiff);
		}

	protected function tickRiddenHorse($rider = null, $tickDiff = null) {
			/* decompiled (structured CF) */
			$level = $this->getLevel();
			if (($level === null)) {
				return false;
			}
			$chunksReady = $this->preloadRiderChunks(2);
			if (!($chunksReady)) {
				$this->syncRiderSeatPosition($rider, \pocketmine\network\protocol\MovePlayerPacket::MODE_NORMAL, false);
				$this->syncLegacyRiderSeatPosition($rider);
				return true;
			}
			$liquidType = $this->getPm1eLiquidType();
			$inLiquid = ($liquidType !== null);
			if (!($this->canBeControlledBy($rider))) {
				if (!($inLiquid)) {
					$this->tryApplyRiderJump(0);
				}
				$updated = parent::tickPm1eGroundAi($tickDiff);
				$this->preloadRiderChunks(1);
				$this->syncRiderSeatPosition($rider, \pocketmine\network\protocol\MovePlayerPacket::MODE_NORMAL, false);
				$this->syncLegacyRiderSeatPosition($rider);
				return $updated;
			}
			$inputX = $this->riderInputX;
			$inputY = $this->riderInputY;
			if (($inputY < 0)) {
			} else {
			}
			$adjustedInputY = $inputY;
			$inputLength = sqrt((($inputX * $inputX) + ($adjustedInputY * $adjustedInputY)));
			if (($inputLength <= self::RIDER_INPUT_DEADZONE)) {
				$this->motionX *= (1 - self::RIDER_BRAKE_PER_TICK);
				$this->motionZ *= (1 - self::RIDER_BRAKE_PER_TICK);
				if (((($this->motionX * $this->motionX) + ($this->motionZ * $this->motionZ)) < 2.5e-05)) {
					$this->motionX = 0;
					$this->motionZ = 0;
				}
			} else {
				$yaw = deg2rad($rider->yaw);
				$dirX = ($inputX / $inputLength);
				$dirY = ($adjustedInputY / $inputLength);
				$wishX = (($dirY * (sin($yaw) * -1)) + ($dirX * cos($yaw)));
				$wishZ = (($dirY * cos($yaw)) + ($dirX * sin($yaw)));
				$strength = min(1, $inputLength);
				$strength = max(0, (($strength - self::RIDER_INPUT_DEADZONE) / (1 - self::RIDER_INPUT_DEADZONE)));
				$strength = pow($strength, 1.6);
				$speed = $this->getHorseRidingSpeed($liquidType);
				$targetX = ($strength * ($wishX * $speed));
				$targetZ = ($strength * ($wishZ * $speed));
				$this->motionX = $targetX;
				$this->motionZ = $targetZ;
				$currentSpeed = sqrt((($this->motionX * $this->motionX) + ($this->motionZ * $this->motionZ)));
				if ((($speed < $currentSpeed) && (1e-05 < $currentSpeed))) {
					$this->motionX *= ($speed / $currentSpeed);
					$this->motionZ *= ($speed / $currentSpeed);
				}
			}
			$this->yaw = $rider->yaw;
			if ($inLiquid) {
				$this->motionY = max($this->motionY, $this->getPm1eLiquidBuoyancy());
			} else {
				if (!($this->tryApplyRiderJump($inputY))) {
					if ($this->onGround) {
						$this->motionY = 0;
						$this->horseJumping = false;
						$this->jumpPower = 0;
					} else {
						$this->motionY -= $this->gravity;
					}
				}
			}
			$this->normalizePm1eGroundCollisionBox();
			$this->move($this->motionX, $this->motionY, $this->motionZ);
			$friction = (1 - $this->drag);
			if (($this->onGround && ((1e-05 < abs($this->motionX)) || (1e-05 < abs($this->motionZ))))) {
				$friction = ($friction * $this->getLevel()->getBlock($this->temporalVector->setComponents((floor($this->x)), (floor(($this->y - 1))), ((floor($this->z)) - 1)))->getFrictionFactor());
			}
			$this->motionX *= $friction;
			$this->motionZ *= $friction;
			if ($inLiquid) {
			} else {
			}
			$this->motionY *= (1 - $this->drag);
			if (($this->onGround && !($inLiquid))) {
				$this->motionY *= -0.5;
			}
			$chunksReady = $this->preloadRiderChunks(1);
			if (!($chunksReady)) {
				$this->syncRiderSeatPosition($rider, \pocketmine\network\protocol\MovePlayerPacket::MODE_NORMAL, false);
				$this->syncLegacyRiderSeatPosition($rider);
				return true;
			}
			$this->syncRiderSeatPosition($rider, \pocketmine\network\protocol\MovePlayerPacket::MODE_NORMAL, false);
			$this->syncLegacyRiderSeatPosition($rider);
			return true;
		}

	protected function tryApplyRiderJump($inputY = null) {
			/* decompiled (structured CF) */
			if ((($this->onGround && (0 < $this->jumpPower)) && !($this->horseJumping))) {
				$jumpPower = $this->jumpPower;
				$this->motionY = ($jumpPower * $this->getPm1eJumpStrength());
				$this->horseJumping = true;
				$this->onGround = false;
				if ((0 < $inputY)) {
					$yaw = deg2rad($this->yaw);
					$this->motionX += ($jumpPower * ((sin($yaw) * -1) * 0.4));
					$this->motionZ += ($jumpPower * (cos($yaw) * 0.4));
				}
				$this->jumpPower = 0;
				return true;
			}
			return false;
		}

	protected function getPm1eBaseSpeed($liquidType = null) {
			return ($this->getHorseRidingSpeed($liquidType) * 0.6);
		}

	protected function getHorseRidingSpeed($liquidType = null) {
			/* decompiled (structured CF) */
			if (($liquidType === 'lava')) {
				return 0.02;
			}
			if (($liquidType === 'water')) {
				return 0.05;
			}
			return 0.3375;
		}

	protected function getPm1eJumpStrength() {
			return 0.6;
		}

	protected function syncRiderMount($rider = null) {
			/* decompiled (structured CF) */
			$this->sendHorseLinkPacket($rider, $rider->getId(), \pocketmine\network\protocol\SetEntityLinkPacket::TYPE_RIDE);
			$this->sendHorseLinkPacket($rider, 0, \pocketmine\network\protocol\SetEntityLinkPacket::TYPE_RIDE);
			$this->syncRiderSeatPosition($rider, \pocketmine\network\protocol\MovePlayerPacket::MODE_RESET);
			$this->sendLegacyRiderSeatMetadata($rider);
			$this->syncLegacyRiderSeatPosition($rider);
			return null;
		}

	protected function sendHorseLinkPacket($rider = null, $riderId = null, $type = null) {
			/* decompiled (structured CF) */
			if ((($this->getId() === null) || ($rider->getId() === null))) {
				return null;
			}
			new \pocketmine\network\protocol\SetEntityLinkPacket();
			$pk = new \pocketmine\network\protocol\SetEntityLinkPacket();
			$pk->from = $this->getId();
			$pk->to = $riderId;
			$pk->type = $type;
			if (($riderId === 0)) {
				$rider->dataPacket($pk);
			} else {
				if (((($this->server !== null) && ($this->level !== null)) && method_exists($this->level, 'getPlayers'))) {
					$targets = $this->getProtocol015HorseLinkViewers($rider);
					if ((0 < count($targets))) {
						$this->server->broadcastPacket($targets, $pk);
					}
				} else {
					if (($riderId === $rider->getId())) {
						$rider->dataPacket($pk);
					}
				}
			}
		}

	protected function getProtocol015HorseLinkViewers($rider = null) {
			/* decompiled (structured CF) */
			$targets = ['__array_ptr' => '2aaaac9fc9a0'];
			if ((($this->level === null) || !(method_exists($this->level, 'getPlayers')))) {
				return $targets;
			}
			foreach ($this->level->getPlayers() as $viewer) {
				if (\pocketmine\network\protocol\ProtocolCompatibility::isProtocol015(($viewer->getProtocol()))) {
					$targets[] = $viewer;
				}
				/* goto */
			}
			return $targets;
		}

	protected function getLegacyRiderViewers($rider = null) {
			/* decompiled (structured CF) */
			$targets = ['__array_ptr' => '2aaaac9fc9a0'];
			foreach ($rider->getViewers() as $viewer) {
				if (($viewer instanceof \pocketmine\Player && !(\pocketmine\network\protocol\ProtocolCompatibility::isProtocol015(($viewer->getProtocol()))))) {
					$targets[] = $viewer;
				}
				/* goto */
			}
			return $targets;
		}

	protected function sendLegacyRiderSeatMetadata($rider = null) {
			/* decompiled (structured CF) */
			$targets = $this->getLegacyRiderViewers($rider);
			if ((count($targets) === 0)) {
				return null;
			}
			$rider->sendData($targets, [[self::DATA_TYPE_LONG, ($rider->getDataProperty(self::DATA_FLAGS))]]);
		}

	protected function syncLegacyRiderSeatPosition($rider = null) {
			/* decompiled (structured CF) */
			if ((($this->server === null) || ($rider->getId() === null))) {
				return null;
			}
			$targets = $this->getLegacyRiderViewers($rider);
			if ((count($targets) === 0)) {
			}
			new \pocketmine\network\protocol\MoveEntityPacket();
			$pk = new \pocketmine\network\protocol\MoveEntityPacket();
			$pk->entities[] = [$rider->getId(), $rider->x, ($rider->y + $rider->getEyeHeight()), $rider->z, $rider->yaw, $rider->yaw, $rider->pitch];
			$this->server->broadcastPacket($targets, $pk);
		}

	protected function syncRiderSeatPosition($rider = null, $mode = null, $sendPacket = null) {
			/* decompiled (structured CF) */
			$rider->x = $this->getRiderSeatX();
			$rider->y = $this->getRiderSeatY();
			$rider->z = $this->getRiderSeatZ();
			if (((!($sendPacket) || ($this->getId() === null)) || ($rider->getId() === null))) {
				return null;
			}
			new \pocketmine\network\protocol\MovePlayerPacket();
			$pk = new \pocketmine\network\protocol\MovePlayerPacket();
			$pk->eid = 0;
			$pk->x = $rider->x;
			$pk->y = ($rider->y + $rider->getEyeHeight());
			$pk->z = $rider->z;
			$pk->yaw = $rider->yaw;
			$pk->bodyYaw = $rider->yaw;
			$pk->pitch = $rider->pitch;
			$pk->mode = $mode;
			$pk->onGround = $this->onGround;
			$rider->dataPacket($pk);
		}

	protected function getRiderSeatY() {
			return ($this->y + 1.1);
		}

	protected function getRiderSeatX() {
			return ($this->x - (sin(deg2rad($this->yaw)) * -0.2));
		}

	protected function getRiderSeatZ() {
			return ($this->z + (cos(deg2rad($this->yaw)) * -0.2));
		}

	protected function getRiderDismountPosition() {
			/* decompiled (structured CF) */
			$yaw = deg2rad($this->yaw);
			$distance = (($this->width / 2) + 0.6);
			new \pocketmine\level\Position(($this->x + ($distance * cos($yaw))), $this->y, ($this->z + ($distance * sin($yaw))), $this->level);
			return new \pocketmine\level\Position(($this->x + ($distance * cos($yaw))), $this->y, ($this->z + ($distance * sin($yaw))), $this->level);
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->eid = $this->getId();
			$pk->type = self::NETWORK_ID;
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->yaw = $this->yaw;
			$pk->pitch = $this->pitch;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			$this->inventory->sendArmor($player);
			parent::spawnTo($player);
			return null;
		}

	public function getDrops() {
			/* decompiled (structured CF) */
			$drops = ['__array_ptr' => '2aaaac9fc9a0'];
			$leather = mt_rand(0, 2);
			if ((0 < $leather)) {
				$drops[] = \pocketmine\item\Item::get(\pocketmine\item\Item::LEATHER, 0, $leather);
			}
			foreach ($this->inventory->getInventoryDrops() as $item) {
				$drops[] = $item;
				/* goto */
			}
			return $drops;
		}

	public function saveNBT() {
			/* decompiled (structured CF) */
			parent::saveNBT();
			if ($this->isSaddled()) {
			} else {
			}
			new \pocketmine\nbt\tag\ByteTag('Saddled', 0);
			$this->namedtag->Saddled = new \pocketmine\nbt\tag\ByteTag('Saddled', 0);
			new \pocketmine\nbt\tag\IntTag('Variant', $this->variant);
			$this->namedtag->Variant = new \pocketmine\nbt\tag\IntTag('Variant', $this->variant);
			new \pocketmine\nbt\tag\IntTag('MarkVariant', $this->markVariant);
			$this->namedtag->MarkVariant = new \pocketmine\nbt\tag\IntTag('MarkVariant', $this->markVariant);
			$this->namedtag->Inventory = $this->inventory->saveToNbt();
			return null;
		}

}
