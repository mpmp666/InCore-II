<?php

namespace pocketmine\entity;

class Ghast extends \pocketmine\entity\FlyingAnimal {
	public const NETWORK_ID = 41;

	public $width = 6;
	public $length = 6;
	public $height = 6;
	private $attackDelay = 0;

	public function getName() {
			return 'Ghast';
		}

	public function initEntity() {
			$this->setMaxHealth(10);
			parent::initEntity();
			return null;
		}

	public function onUpdate($currentTick = null) {
			/* decompiled (structured CF) */
			$hasUpdate = parent::onUpdate($currentTick);
			if ((!($this->closed) && $this->isAlive())) {
				if (($this->attackDelay < 100)) {
				}
				$this->attackNearestPlayer();
			}
			return $hasUpdate;
		}

	protected function attackNearestPlayer() {
			/* decompiled (structured CF) */
			$target = null;
			$bestDistance = 4096;
			foreach ($this->getLevel()->getPlayers() as $player) {
				if ((!($player->isAlive()) || $player->closed)) {
					/* goto */
				}
				if ((method_exists($player, 'isSurvival') && method_exists($player, 'isAdventure'))) {
					if ((!($player->isSurvival()) && !($player->isAdventure()))) {
						/* goto */
					}
				}
				$distance = $this->distanceSquared($player);
				if (($distance <= $bestDistance)) {
					$bestDistance = $distance;
					$target = $player;
				}
				/* goto */
			}
			if ($target instanceof \pocketmine\entity\Entity) {
				$this->setPm1eFlyFollowTarget($target);
				$this->shootFireball($target);
			} else {
				$this->setPm1eFlyFollowTarget(null);
			}
			return null;
		}

	protected function shootFireball($player = null) {
			/* decompiled (structured CF) */
			if ((($this->attackDelay < 60) || (4096 < $this->distanceSquared($player)))) {
				return false;
			}
			new \pocketmine\nbt\tag\DoubleTag('', $this->x);
			new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight()));
			new \pocketmine\nbt\tag\DoubleTag('', $this->z);
			new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight())), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]);
			new \pocketmine\nbt\tag\DoubleTag('', 0);
			new \pocketmine\nbt\tag\DoubleTag('', 0);
			new \pocketmine\nbt\tag\DoubleTag('', 0);
			new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]);
			new \pocketmine\nbt\tag\FloatTag('', $this->yaw);
			new \pocketmine\nbt\tag\FloatTag('', $this->pitch);
			new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $this->yaw), new \pocketmine\nbt\tag\FloatTag('', $this->pitch)]);
			new \pocketmine\nbt\tag\FloatTag('damage', 2);
			new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight())), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $this->yaw), new \pocketmine\nbt\tag\FloatTag('', $this->pitch)]), new \pocketmine\nbt\tag\FloatTag('damage', 2)]);
			$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight())), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $this->yaw), new \pocketmine\nbt\tag\FloatTag('', $this->pitch)]), new \pocketmine\nbt\tag\FloatTag('damage', 2)]);
			$fireball = \pocketmine\entity\Entity::createEntity('Fireball', $this->chunk, $nbt, $this);
			if ($fireball instanceof \pocketmine\entity\Fireball) {
				$direction = $player->add(0, $player->getEyeHeight(), 0)->subtract($this->add(0, $this->getEyeHeight(), 0))->normalize();
				$fireball->setMotion($direction->multiply(1));
				new \pocketmine\event\entity\ProjectileLaunchEvent($fireball);
				$ev = new \pocketmine\event\entity\ProjectileLaunchEvent($fireball);
				$this->server->getPluginManager()->callEvent($ev);
				if ($ev->isCancelled()) {
					$fireball->close();
					return false;
				}
				$fireball->spawnToAll();
				$this->attackDelay = 0;
				return true;
			}
			return false;
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->eid = $this->getId();
			$pk->type = self::NETWORK_ID;
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = $this->motionX;
			$pk->speedY = $this->motionY;
			$pk->speedZ = $this->motionZ;
			$pk->yaw = $this->yaw;
			$pk->pitch = $this->pitch;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

	public function getDrops() {
			/* decompiled (structured CF) */
			$drops = ['__array_ptr' => '2aaaac9fc9a0'];
			$mt = mt_rand(0, 2);
			if ((0 < $mt)) {
				$drops[] = \pocketmine\item\Item::get(\pocketmine\item\Item::GHAST_TEAR, 0, $mt);
			}
			return $drops;
		}

}
