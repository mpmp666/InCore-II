<?php

namespace pocketmine\entity;

abstract class Hanging extends \pocketmine\entity\Entity implements \pocketmine\entity\Attachable {
}
