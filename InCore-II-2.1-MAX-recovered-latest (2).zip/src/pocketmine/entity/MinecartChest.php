<?php

namespace pocketmine\entity;

class MinecartChest extends \pocketmine\entity\Vehicle {
	public const NETWORK_ID = 98;
	public const TYPE_NORMAL = 1;
	public const TYPE_CHEST = 2;
	public const TYPE_HOPPER = 3;
	public const TYPE_TNT = 4;
	public const STATE_INITIAL = 0;
	public const STATE_ON_RAIL = 1;
	public const STATE_OFF_RAIL = 2;

	public $height = 0.7;
	public $width = 0.98;
	public $drag = 0.1;
	public $gravity = 0.5;
	public $isMoving = false;
	public $moveSpeed = 0.5;
	public $linkplayer = NULL;
	private $state = 0;
	private $direction = -1;
	private $moveVector = array (
);
	public $motionX = 0.0;
	public $motionY = 0.0;
	public $motionZ = 0.0;
	public $chestx = 0;
	public $chesty = 0;
	public $chestz = 0;
	public $chestplaced = false;
	public $chestblock = NULL;
	public $chesttile = NULL;
	public $chestnbt = NULL;
	public $chestitems = NULL;
	public $chestitemsarr = NULL;
	public $chestinventory = NULL;
	public $blk = NULL;

	public function initEntity() {
			/* decompiled (structured CF) */
			$this->setMaxHealth(1);
			$this->setHealth(1);
			new \pocketmine\math\Vector3(-1, 0, 0);
			$this->moveVector[\pocketmine\entity\Entity::NORTH] = new \pocketmine\math\Vector3(-1, 0, 0);
			new \pocketmine\math\Vector3(1, 0, 0);
			$this->moveVector[\pocketmine\entity\Entity::SOUTH] = new \pocketmine\math\Vector3(1, 0, 0);
			new \pocketmine\math\Vector3(0, 0, -1);
			$this->moveVector[\pocketmine\entity\Entity::EAST] = new \pocketmine\math\Vector3(0, 0, -1);
			new \pocketmine\math\Vector3(0, 0, 1);
			$this->moveVector[\pocketmine\entity\Entity::WEST] = new \pocketmine\math\Vector3(0, 0, 1);
			parent::initEntity();
			return null;
		}

	public function getName() {
			return;
		}

	public function getTile() {
			return $this->chesttile;
		}

	public function getType() {
			return self::TYPE_CHEST;
		}

	public function onUpdate($currentTick = null) {
			/* decompiled (structured CF) */
			if (($this->closed !== false)) {
				return false;
			}
			$tickDiff = ($currentTick - $this->lastUpdate);
			if (($tickDiff <= 1)) {
				return false;
			}
			$this->lastUpdate = $currentTick;
			$this->timings->startTiming();
			$hasUpdate = false;
			$rider = $this->getLinkedEntity();
			if ($rider instanceof \pocketmine\Player) {
				$this->syncRiderPositionToVehicle($rider, 0.7);
			}
			$chunksReady = $this->preloadRiderChunks(2);
			if (!($chunksReady)) {
				if ($rider instanceof \pocketmine\Player) {
					$this->syncRiderPositionToVehicle($rider, 0.7);
				}
				$this->timings->stopTiming();
				return true;
			}
			if (($this->state === 0)) {
				$this->checkIfOnRail();
			} else {
				if (($this->state === 1)) {
					$hasUpdate = $this->forwardOnRail($this);
					$this->updateMovement();
				}
			}
			if ($this->isAlive()) {
				if ($this->transferFuelToFurnaceBelow()) {
					$hasUpdate = true;
				} else {
					if ($this->transferResultFromFurnaceBelow()) {
						$hasUpdate = true;
					} else {
						if ($this->transferToHopperBelow()) {
							$hasUpdate = true;
						}
					}
				}
			}
			$this->preloadRiderChunks(1);
			if ($rider instanceof \pocketmine\Player) {
				$this->syncRiderPositionToVehicle($rider, 0.7);
			}
			$this->timings->stopTiming();
			return (((($hasUpdate || !($this->onGround)) || (1e-05 < abs($this->motionX))) || (1e-05 < abs($this->motionY))) || (1e-05 < abs($this->motionZ)));
		}

	private function transferToHopperBelow() {
			/* decompiled (structured CF) */
			$hopper = $this->getHopperBelow();
			if (!($hopper instanceof \pocketmine\tile\Hopper)) {
				return false;
			}
			if (!($hopper->canUpdate())) {
				return true;
			}
			if ((($this->chesttile !== null) && !($this->chesttile->closed))) {
				$inventory = $this->chesttile->getInventory();
				foreach ($inventory->getContents() as $item) {
					if ((($item->getId() === \pocketmine\item\Item::AIR) || ($item->getCount() <= 0))) {
						/* goto */
					}
					$transfer = clone $item;
					$transfer->setCount(1);
					if ($hopper->getInventory()->canAddItem($transfer)) {
						$hopper->getInventory()->addItem($transfer);
						$inventory->removeItem($transfer);
						$this->chesttile->saveNBT();
						$this->syncNamedTagItemsFromInventory($inventory);
						$hopper->resetCooldownTicks();
					}
				}
				return true;
				/* goto */
				return true;
			}
			$this->ensureEntityItemList();
			foreach ($this->namedtag->Items as $index => $slot) {
				if (!($slot instanceof \pocketmine\nbt\tag\CompoundTag)) {
					/* goto */
				}
				$item = \pocketmine\nbt\NBT::getItemHelper($slot);
				if ((($item->getId() === \pocketmine\item\Item::AIR) || ($item->getCount() <= 0))) {
					/* goto */
				}
				$transfer = clone $item;
				$transfer->setCount(1);
				if ($hopper->getInventory()->canAddItem($transfer)) {
					$hopper->getInventory()->addItem($transfer);
					$item->setCount(($item->getCount() - 1));
					if (($item->getCount() <= 0)) {
					} else {
						if (isset($slot->Slot)) {
						} else {
						}
						$slotId = ($index);
						$this->namedtag->Items[$index] = \pocketmine\nbt\NBT::putItemHelper($item, $slotId);
					}
					$hopper->resetCooldownTicks();
				}
			}
			return true;
			/* goto */
			return true;
		}

	private function transferResultFromFurnaceBelow() {
			/* decompiled (structured CF) */
			$furnace = $this->getFurnaceBelow();
			if (!($furnace instanceof \pocketmine\tile\Furnace)) {
				return false;
			}
			$result = $furnace->getInventory()->getResult();
			if ((($result->getId() === \pocketmine\item\Item::AIR) || ($result->getCount() <= 0))) {
				return true;
			}
			$transfer = clone $result;
			$transfer->setCount(1);
			if ((($this->chesttile !== null) && !($this->chesttile->closed))) {
				$inventory = $this->chesttile->getInventory();
				if ($inventory->canAddItem($transfer)) {
					$inventory->addItem($transfer);
					$this->removeOneFurnaceResult($furnace, $result);
					$this->chesttile->saveNBT();
					$this->syncNamedTagItemsFromInventory($inventory);
				}
				return true;
			}
			$this->ensureEntityItemList();
			if ($this->addItemToEntityItemList($transfer)) {
				$this->removeOneFurnaceResult($furnace, $result);
			}
			return true;
		}

	private function removeOneFurnaceResult($furnace = null, $result = null) {
			/* decompiled (structured CF) */
			$result->setCount(($result->getCount() - 1));
			if (($result->getCount() <= 0)) {
				$result = \pocketmine\item\Item::get(\pocketmine\item\Item::AIR, 0, 0);
			}
			$furnace->getInventory()->setResult($result);
			$furnace->saveNBT();
			return null;
		}

	private function transferFuelToFurnaceBelow() {
			/* decompiled (structured CF) */
			$furnace = $this->getFurnaceBelow();
			if (!($furnace instanceof \pocketmine\tile\Furnace)) {
				return false;
			}
			if ((($this->chesttile !== null) && !($this->chesttile->closed))) {
				$inventory = $this->chesttile->getInventory();
				foreach ($inventory->getContents() as $item) {
					if (!($this->canFuelBeInserted($furnace, $item))) {
						/* goto */
					}
					$this->insertFuelIntoFurnace($furnace, $item);
					$transfer = clone $item;
					$transfer->setCount(1);
					$inventory->removeItem($transfer);
					$this->chesttile->saveNBT();
					$this->syncNamedTagItemsFromInventory($inventory);
				}
				return true;
				/* goto */
				return false;
			}
			$this->ensureEntityItemList();
			foreach ($this->namedtag->Items as $index => $slot) {
				if (!($slot instanceof \pocketmine\nbt\tag\CompoundTag)) {
					/* goto */
				}
				$item = \pocketmine\nbt\NBT::getItemHelper($slot);
				if (!($this->canFuelBeInserted($furnace, $item))) {
					/* goto */
				}
				$this->insertFuelIntoFurnace($furnace, $item);
				$this->removeOneItemFromEntitySlot($index, $slot, $item);
			}
			return true;
			/* goto */
			return false;
		}

	private function canFuelBeInserted($furnace = null, $item = null) {
			/* decompiled (structured CF) */
			if (((($item->getId() === \pocketmine\item\Item::AIR) || ($item->getCount() <= 0)) || ($item->getFuelTime() === null))) {
				return false;
			}
			$fuelSlot = $furnace->getInventory()->getFuel();
			if ((($fuelSlot->getId() === \pocketmine\item\Item::AIR) || ($fuelSlot->getCount() <= 0))) {
				return true;
			}
			return ($fuelSlot->equals($item, true, true) && ($fuelSlot->getCount() < $fuelSlot->getMaxStackSize()));
		}

	private function insertFuelIntoFurnace($furnace = null, $fuel = null) {
			/* decompiled (structured CF) */
			$fuelSlot = $furnace->getInventory()->getFuel();
			if ((($fuelSlot->getId() === \pocketmine\item\Item::AIR) || ($fuelSlot->getCount() <= 0))) {
				$newFuel = clone $fuel;
				$newFuel->setCount(1);
				$furnace->getInventory()->setFuel($newFuel);
			} else {
				$fuelSlot->setCount(($fuelSlot->getCount() + 1));
				$furnace->getInventory()->setFuel($fuelSlot);
			}
			$furnace->saveNBT();
			return null;
		}

	private function removeOneItemFromEntitySlot($index = null, $slot = null, $item = null) {
			/* decompiled (structured CF) */
			$item->setCount(($item->getCount() - 1));
			if (($item->getCount() <= 0)) {
				return null;
			}
			if (isset($slot->Slot)) {
			} else {
			}
			$slotId = ($index);
			$this->namedtag->Items[$index] = \pocketmine\nbt\NBT::putItemHelper($item, $slotId);
		}

	private function getFurnaceBelow() {
			/* decompiled (structured CF) */
			$level = $this->getLevel();
			if (($level === null)) {
				return null;
			}
			new \pocketmine\math\Vector3($this->getFloorX(), ($this->getFloorY() - 1), $this->getFloorZ());
			$tile = $level->getTile(new \pocketmine\math\Vector3($this->getFloorX(), ($this->getFloorY() - 1), $this->getFloorZ()));
			if ($tile instanceof \pocketmine\tile\Furnace) {
				return $tile;
			}
		}

	private function getHopperBelow() {
			/* decompiled (structured CF) */
			$level = $this->getLevel();
			if (($level === null)) {
				return null;
			}
			$x = $this->getFloorX();
			$z = $this->getFloorZ();
			$offset = 1;
			while (($offset <= 2)) {
				new \pocketmine\math\Vector3($x, ($this->getFloorY() - $offset), $z);
				$tile = $level->getTile(new \pocketmine\math\Vector3($x, ($this->getFloorY() - $offset), $z));
				if ($tile instanceof \pocketmine\tile\Hopper) {
					return $tile;
				}
				$offset++;
			}
		}

	private function ensureEntityItemList() {
			/* decompiled (structured CF) */
			if ((!(isset($this->namedtag->Items)) || !($this->namedtag->Items instanceof \pocketmine\nbt\tag\ListTag))) {
				new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']);
				$this->namedtag->Items = new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']);
				$this->namedtag->Items->setTagType(\pocketmine\nbt\NBT::TAG_Compound);
			}
			return null;
		}

	private function addItemToEntityItemList($item = null) {
			/* decompiled (structured CF) */
			if ((($item->getId() === \pocketmine\item\Item::AIR) || ($item->getCount() <= 0))) {
				return false;
			}
			$occupiedSlots = ['__array_ptr' => '2aaaac9fc9a0'];
			foreach ($this->namedtag->Items as $index => $slot) {
				if (!($slot instanceof \pocketmine\nbt\tag\CompoundTag)) {
					/* goto */
				}
				if (isset($slot->Slot)) {
				} else {
				}
				$slotId = ($index);
				$existing = \pocketmine\nbt\NBT::getItemHelper($slot);
				if ((($existing->getId() === \pocketmine\item\Item::AIR) || ($existing->getCount() <= 0))) {
					/* goto */
				}
				$occupiedSlots[$slotId] = true;
				if (($existing->equals($item, true, true) && ($existing->getCount() < $existing->getMaxStackSize()))) {
					$existing->setCount(($existing->getCount() + 1));
					$this->namedtag->Items[$index] = \pocketmine\nbt\NBT::putItemHelper($existing, $slotId);
					return true;
				}
				/* goto */
			}
			$slotId = 0;
			while (($slotId < 13)) {
				if (!(isset($occupiedSlots[$slotId]))) {
					$newItem = clone $item;
					$newItem->setCount(1);
					$index = 0;
					while ($t56) {
						$index++;
					}
					$this->namedtag->Items[$index] = \pocketmine\nbt\NBT::putItemHelper($newItem, $slotId);
					return true;
				}
				$slotId++;
			}
			return false;
		}

	private function syncNamedTagItemsFromInventory($inventory = null) {
			/* decompiled (structured CF) */
			$items = ['__array_ptr' => '2aaaac9fc9a0'];
			foreach ($inventory->getContents() as $slot => $item) {
				if ((($item->getId() !== \pocketmine\item\Item::AIR) && (0 < $item->getCount()))) {
					$items[] = \pocketmine\nbt\NBT::putItemHelper($item, $slot);
				}
				/* goto */
			}
			new \pocketmine\nbt\tag\ListTag('Items', $items);
			$this->namedtag->Items = new \pocketmine\nbt\tag\ListTag('Items', $items);
			$this->namedtag->Items->setTagType(\pocketmine\nbt\NBT::TAG_Compound);
			return null;
		}

	private function checkIfOnRail() {
			/* decompiled (structured CF) */
			$y = -1;
			while (($this->state === 0)) {
				$positionToCheck = $this->temporalVector->setComponents($this->x, ($this->y + $y), $this->z);
				$block = $this->level->getBlock($positionToCheck);
				if ($this->isRail($block)) {
					$minecartPosition = $positionToCheck->floor()->add(0.5, 0.75, 0.5);
					$this->setPosition($minecartPosition);
					$this->state = 1;
				}
				$y++;
			}
			if (($this->state !== 1)) {
				$this->state = 2;
			}
			return null;
		}

	private function isRail($rail = null) {
			return (($rail !== null) && in_array($rail->getId(), [\pocketmine\block\Block::RAIL, \pocketmine\block\Block::ACTIVATOR_RAIL, \pocketmine\block\Block::DETECTOR_RAIL, \pocketmine\block\Block::POWERED_RAIL]));
		}

	private function getCurrentRail() {
			/* decompiled (structured CF) */
			$block = $this->getLevel()->getBlock($this);
			if ($this->isRail($block)) {
				return $block;
			}
			$down = $this->temporalVector->setComponents($this->x, ($this->y - 1), $this->z);
			$block = $this->getLevel()->getBlock($down);
			if ($this->isRail($block)) {
				return $block;
			}
		}

	private function forwardOnRail($player = null) {
			/* decompiled (structured CF) */
			if (($this->direction === -1)) {
				$candidateDirection = $player->getDirection();
			} else {
				$candidateDirection = $this->direction;
			}
			$rail = $this->getCurrentRail();
			if (($rail !== null)) {
				$this->applyRailEffects($rail);
				$railType = $rail->getRealMeta();
				$nextDirection = $this->getDirectionToMove($railType, $candidateDirection);
				if (($nextDirection !== -1)) {
					$this->direction = $nextDirection;
					$moved = $this->checkForVertical($railType, $nextDirection);
					if (!($moved)) {
						return $this->moveIfRail();
					} else {
						return true;
					}
				} else {
					$this->direction = -1;
				}
			} else {
				$this->state = 0;
			}
			return false;
		}

	private function getDirectionToMove($railType = null, $candidateDirection = null) {
			/* decompiled (structured CF) */
			if (!(($railType == \pocketmine\block\Rail::STRAIGHT_NORTH_SOUTH))) {
				if (!(($railType == \pocketmine\block\Rail::SLOPED_ASCENDING_NORTH))) {
					if (!(($railType == \pocketmine\block\Rail::SLOPED_ASCENDING_SOUTH))) {
						if (!(($railType == \pocketmine\block\Rail::STRAIGHT_EAST_WEST))) {
							if (!(($railType == \pocketmine\block\Rail::SLOPED_ASCENDING_EAST))) {
								if (!(($railType == \pocketmine\block\Rail::SLOPED_ASCENDING_WEST))) {
									if (!(($railType == \pocketmine\block\Rail::CURVED_SOUTH_EAST))) {
										if (!(($railType == \pocketmine\block\Rail::CURVED_SOUTH_WEST))) {
											if (!(($railType == \pocketmine\block\Rail::CURVED_NORTH_WEST))) {
												if (!(($railType == \pocketmine\block\Rail::CURVED_NORTH_EAST))) {
												} else {
													if (!(($candidateDirection == \pocketmine\entity\Entity::NORTH))) {
														if (!(($candidateDirection == \pocketmine\entity\Entity::SOUTH))) {
														} else {
															return $candidateDirection;
														}
														/* jump */
														if (!(($candidateDirection == \pocketmine\entity\Entity::WEST))) {
															if (!(($candidateDirection == \pocketmine\entity\Entity::EAST))) {
															} else {
																return $candidateDirection;
															}
															/* jump */
															if (!(($candidateDirection == \pocketmine\entity\Entity::SOUTH))) {
																if (!(($candidateDirection == \pocketmine\entity\Entity::EAST))) {
																	if (!(($candidateDirection == \pocketmine\entity\Entity::NORTH))) {
																		if (!(($candidateDirection == \pocketmine\entity\Entity::WEST))) {
																			/* jump */
																			return $candidateDirection;
																		}
																	}
																	return $this->checkForTurn($candidateDirection, \pocketmine\entity\Entity::SOUTH);
																	/* jump */
																	if (!(($candidateDirection == \pocketmine\entity\Entity::SOUTH))) {
																		if (!(($candidateDirection == \pocketmine\entity\Entity::WEST))) {
																			if (!(($candidateDirection == \pocketmine\entity\Entity::NORTH))) {
																				if (!(($candidateDirection == \pocketmine\entity\Entity::EAST))) {
																					/* jump */
																					return $candidateDirection;
																				}
																			}
																			return $this->checkForTurn($candidateDirection, \pocketmine\entity\Entity::SOUTH);
																			/* jump */
																			if (!(($candidateDirection == \pocketmine\entity\Entity::NORTH))) {
																				if (!(($candidateDirection == \pocketmine\entity\Entity::WEST))) {
																					if (!(($candidateDirection == \pocketmine\entity\Entity::SOUTH))) {
																						if (!(($candidateDirection == \pocketmine\entity\Entity::EAST))) {
																							/* jump */
																							return $candidateDirection;
																						}
																					}
																					return $this->checkForTurn($candidateDirection, \pocketmine\entity\Entity::NORTH);
																					/* jump */
																					if (!(($candidateDirection == \pocketmine\entity\Entity::NORTH))) {
																						if (!(($candidateDirection == \pocketmine\entity\Entity::EAST))) {
																							if (!(($candidateDirection == \pocketmine\entity\Entity::SOUTH))) {
																								if (!(($candidateDirection == \pocketmine\entity\Entity::WEST))) {
																									/* jump */
																									return $candidateDirection;
																								}
																							}
																							return $this->checkForTurn($candidateDirection, \pocketmine\entity\Entity::NORTH);
																							/* jump */
																							return -1;
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

	private function checkForTurn($currentDirection = null, $newDirection = null) {
			/* decompiled (structured CF) */
			if (!(($currentDirection == \pocketmine\entity\Entity::NORTH))) {
				if (!(($currentDirection == \pocketmine\entity\Entity::SOUTH))) {
					if (!(($currentDirection == \pocketmine\entity\Entity::EAST))) {
						if (!(($currentDirection == \pocketmine\entity\Entity::WEST))) {
						} else {
							$diff = ($this->x - $this->getFloorX());
							if ((($diff !== 0) && ($diff <= 0.5))) {
								$dx = (($this->getFloorX() + 0.5) - $this->x);
								$this->move($dx, 0, 0);
								return $newDirection;
							}
							/* jump */
							$diff = ($this->x - $this->getFloorX());
							if ((($diff !== 0) && (0.5 <= $diff))) {
								$dx = (($this->getFloorX() + 0.5) - $this->x);
								$this->move($dx, 0, 0);
								return $newDirection;
							}
							/* jump */
							$diff = ($this->z - $this->getFloorZ());
							if ((($diff !== 0) && ($diff <= 0.5))) {
								$dz = (($this->getFloorZ() + 0.5) - $this->z);
								$this->move(0, 0, $dz);
								return $newDirection;
							}
							/* jump */
							$diff = ($this->z - $this->getFloorZ());
							if ((($diff !== 0) && (0.5 <= $diff))) {
								$dz = (($this->getFloorZ() + 0.5) - $this->z);
								$this->move(0, 0, $dz);
								return $newDirection;
							}
							/* jump */
						}
						return $currentDirection;
					}
				}
			}
		}

	private function checkForVertical($railType = null, $currentDirection = null) {
			/* decompiled (structured CF) */
			if (!(($railType == \pocketmine\block\Rail::SLOPED_ASCENDING_NORTH))) {
				if (!(($railType == \pocketmine\block\Rail::SLOPED_ASCENDING_SOUTH))) {
					if (!(($railType == \pocketmine\block\Rail::SLOPED_ASCENDING_EAST))) {
						if (!(($railType == \pocketmine\block\Rail::SLOPED_ASCENDING_WEST))) {
						} else {
							if (!(($currentDirection == \pocketmine\entity\Entity::NORTH))) {
								if (!(($currentDirection == \pocketmine\entity\Entity::SOUTH))) {
								} else {
									$diff = ($this->x - $this->getFloorX());
									if ((($diff !== 0) && ($diff <= 0.5))) {
										$dx = (($this->getFloorX() - 0.1) - $this->x);
										$this->move($dx, -1, 0);
										return true;
									}
									/* jump */
									$diff = ($this->x - $this->getFloorX());
									if ((($diff !== 0) && (0.5 <= $diff))) {
										$dx = (($this->getFloorX() + 1) - $this->x);
										$this->move($dx, 1, 0);
										return true;
									}
									/* jump */
								}
								/* jump */
								if (!(($currentDirection == \pocketmine\entity\Entity::SOUTH))) {
									if (!(($currentDirection == \pocketmine\entity\Entity::NORTH))) {
									} else {
										$diff = ($this->x - $this->getFloorX());
										if ((($diff !== 0) && (0.5 <= $diff))) {
											$dx = (($this->getFloorX() + 1) - $this->x);
											$this->move($dx, -1, 0);
											return true;
										}
										/* jump */
										$diff = ($this->x - $this->getFloorX());
										if ((($diff !== 0) && ($diff <= 0.5))) {
											$dx = (($this->getFloorX() - 0.1) - $this->x);
											$this->move($dx, 1, 0);
											return true;
										}
										/* jump */
									}
									/* jump */
									if (!(($currentDirection == \pocketmine\entity\Entity::EAST))) {
										if (!(($currentDirection == \pocketmine\entity\Entity::WEST))) {
										} else {
											$diff = ($this->z - $this->getFloorZ());
											if ((($diff !== 0) && ($diff <= 0.5))) {
												$dz = (($this->getFloorZ() - 0.1) - $this->z);
												$this->move(0, 1, $dz);
												return true;
											}
											/* jump */
											$diff = ($this->z - $this->getFloorZ());
											if ((($diff !== 0) && (0.5 <= $diff))) {
												$dz = (($this->getFloorZ() + 1) - $this->z);
												$this->move(0, -1, $dz);
												return true;
											}
											/* jump */
										}
										/* jump */
										if (!(($currentDirection == \pocketmine\entity\Entity::WEST))) {
											if (!(($currentDirection == \pocketmine\entity\Entity::EAST))) {
											} else {
												$diff = ($this->z - $this->getFloorZ());
												if ((($diff !== 0) && (0.5 <= $diff))) {
													$dz = (($this->getFloorZ() + 1) - $this->z);
													$this->move(0, 1, $dz);
													return true;
												}
												/* jump */
												$diff = ($this->z - $this->getFloorZ());
												if ((($diff !== 0) && ($diff <= 0.5))) {
													$dz = (($this->getFloorZ() - 0.1) - $this->z);
													$this->move(0, -1, $dz);
													return true;
												}
												/* jump */
											}
											/* jump */
											return false;
										}
									}
								}
							}
						}
					}
				}
			}
		}

	private function moveIfRail() {
			/* decompiled (structured CF) */
			$nextMoveVector = $this->moveVector[$this->direction];
			$nextMoveVector = $nextMoveVector->multiply($this->moveSpeed);
			$newVector = $this->add($nextMoveVector->x, $nextMoveVector->y, $nextMoveVector->z);
			$possibleRail = $this->getCurrentRail();
			if ((($possibleRail !== null) && in_array($possibleRail->getId(), [\pocketmine\block\Block::RAIL, \pocketmine\block\Block::ACTIVATOR_RAIL, \pocketmine\block\Block::DETECTOR_RAIL, \pocketmine\block\Block::POWERED_RAIL]))) {
				$this->moveUsingVector($newVector);
				return true;
			}
			return false;
		}

	private function moveUsingVector($desiredPosition = null) {
			/* decompiled (structured CF) */
			$dx = ($desiredPosition->x - $this->x);
			$dy = ($desiredPosition->y - $this->y);
			$dz = ($desiredPosition->z - $this->z);
			$this->move($dx, $dy, $dz);
			return null;
		}

	public function getNearestRail() {
			/* decompiled (structured CF) */
			$minX = \pocketmine\math\Math::floorFloat($this->boundingBox->minX);
			$minY = \pocketmine\math\Math::floorFloat($this->boundingBox->minY);
			$minZ = \pocketmine\math\Math::floorFloat($this->boundingBox->minZ);
			$maxX = \pocketmine\math\Math::ceilFloat($this->boundingBox->maxX);
			$maxY = \pocketmine\math\Math::ceilFloat($this->boundingBox->maxY);
			$maxZ = \pocketmine\math\Math::ceilFloat($this->boundingBox->maxZ);
			$rails = ['__array_ptr' => '2aaaac9fc9a0'];
			$z = $minZ;
			while (($z <= $maxZ)) {
				$x = $minX;
				while (($x <= $maxX)) {
					$y = $minY;
					while (($y <= $maxY)) {
						$block = $this->level->getBlock($this->temporalVector->setComponents($x, $y, $z));
						if (in_array($block->getId(), [\pocketmine\block\Block::RAIL, \pocketmine\block\Block::ACTIVATOR_RAIL, \pocketmine\block\Block::DETECTOR_RAIL, \pocketmine\block\Block::POWERED_RAIL])) {
							$rails[] = $block;
						}
						$y++;
					}
					$x++;
				}
				$z++;
			}
			$minDistance = \PHP_INT_MAX;
			$nearestRail = null;
			foreach ($rails as $rail) {
				$dis = $this->distance($rail);
				if (($dis < $minDistance)) {
					$nearestRail = $rail;
					$minDistance = $dis;
				}
				/* goto */
			}
			return $nearestRail;
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\AddEntityPacket();
			$pk = new \pocketmine\network\protocol\AddEntityPacket();
			$pk->eid = $this->getId();
			$pk->type = self::NETWORK_ID;
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->speedX = 0;
			$pk->speedY = 0;
			$pk->speedZ = 0;
			$pk->yaw = 0;
			$pk->pitch = 0;
			$pk->metadata = $this->dataProperties;
			$player->dataPacket($pk);
			parent::spawnTo($player);
			return null;
		}

	public function attack($damage = null, $source = null) {
			/* decompiled (structured CF) */
			parent::attack($damage, $source);
			if (!($source->isCancelled())) {
				new \pocketmine\network\protocol\EntityEventPacket();
				$pk = new \pocketmine\network\protocol\EntityEventPacket();
				$pk->eid = $this->id;
				$pk->event = \pocketmine\network\protocol\EntityEventPacket::HURT_ANIMATION;
				foreach ($this->getLevel()->getPlayers() as $player) {
					$player->dataPacket($pk);
					/* goto */
				}
			}
			return null;
		}

	public function getDrops() {
			/* decompiled (structured CF) */
			if (isset($this->chesttile->namedtag->Items)) {
				return $this->chesttile->getArrayItems();
			}
			if ((isset($this->namedtag->Items) && $this->namedtag->Items instanceof \pocketmine\nbt\tag\ListTag)) {
				$drops = ['__array_ptr' => '2aaaac9fc9a0'];
				foreach ($this->namedtag->Items as $slot) {
					if ($slot instanceof \pocketmine\nbt\tag\CompoundTag) {
						$item = \pocketmine\nbt\NBT::getItemHelper($slot);
						if ((($item->getId() !== \pocketmine\item\Item::AIR) && (0 < $item->getCount()))) {
							$drops[] = $item;
						}
					}
					/* goto */
				}
				return $drops;
			}
			return [\pocketmine\item\Item::get(0, 0)];
		}

	public function getSaveId() {
			new \ReflectionClass($t2);
			$class = new \ReflectionClass($t2);
			return $class->getShortName();
		}

	private function ensureChestTile() {
			/* decompiled (structured CF) */
			if ((($this->chesttile !== null) && !($this->chesttile->closed))) {
				return $this->chesttile;
			}
			$level = $this->getLevel();
			if ((($level === null) || ($this->linkplayer === null))) {
			}
			$this->chestx = $this->linkplayer->getFloorX();
			if ((6 < $this->linkplayer->y)) {
			} else {
			}
			$this->chesty = $this->linkplayer->getFloorY();
			$this->chestz = $this->linkplayer->getFloorZ();
			if ((isset($this->namedtag->Items) && $this->namedtag->Items instanceof \pocketmine\nbt\tag\ListTag)) {
			} else {
				new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']);
			}
			$items = new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']);
			$items->setTagType(\pocketmine\nbt\NBT::TAG_Compound);
			new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']);
			new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::MINECART_CHEST);
			new \pocketmine\nbt\tag\IntTag('x', $this->chestx);
			new \pocketmine\nbt\tag\IntTag('y', $this->chesty);
			new \pocketmine\nbt\tag\IntTag('z', $this->chestz);
			new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']), new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::MINECART_CHEST), new \pocketmine\nbt\tag\IntTag('x', $this->chestx), new \pocketmine\nbt\tag\IntTag('y', $this->chesty), new \pocketmine\nbt\tag\IntTag('z', $this->chestz)]);
			$this->chestnbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']), new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::MINECART_CHEST), new \pocketmine\nbt\tag\IntTag('x', $this->chestx), new \pocketmine\nbt\tag\IntTag('y', $this->chesty), new \pocketmine\nbt\tag\IntTag('z', $this->chestz)]);
			$this->chestnbt->Items->setTagType(\pocketmine\nbt\NBT::TAG_Compound);
			new \pocketmine\nbt\tag\StringTag('CustomName', "\xe7\xae\xb1\xe5\xad\x90\xe7\x9f\xbf\xe8\xbd\xa6");
			$this->chestnbt->CustomName = new \pocketmine\nbt\tag\StringTag('CustomName', "\xe7\xae\xb1\xe5\xad\x90\xe7\x9f\xbf\xe8\xbd\xa6");
			new \pocketmine\math\Vector3($this->chestx, $this->chesty, $this->chestz);
			new \pocketmine\block\Chest();
			$level->setBlock(new \pocketmine\math\Vector3($this->chestx, $this->chesty, $this->chestz), new \pocketmine\block\Chest(), true, true);
			$this->chesttile = \pocketmine\tile\Tile::createTile(\pocketmine\tile\Tile::MINECART_CHEST, $level->getChunk(($this->chestx >> 4), ($this->chestz >> 4)), $this->chestnbt);
			if (($this->chesttile !== null)) {
				$this->chesttile->setItems($items);
			}
			new \pocketmine\math\Vector3($this->chestx, $this->chesty, $this->chestz);
			$this->blk = $level->getBlock(new \pocketmine\math\Vector3($this->chestx, $this->chesty, $this->chestz));
			return $this->chesttile;
		}

	public function MinecartChestOpen() {
			/* decompiled (structured CF) */
			if ((($this->linkplayer === null) || !($this->linkplayer->isOnline()))) {
				return null;
			}
			$tile = $this->ensureChestTile();
			if (($tile === null)) {
			}
			$this->linkplayer->addWindow($tile->getInventory());
		}

	public function close() {
			/* decompiled (structured CF) */
			if (!($this->closed)) {
				if (!($this->getLevel()->getServer()->isWorldNonLivingEntityDropsDisabled($this->getLevel()))) {
					$this->getLevel()->dropItem($this, \pocketmine\item\Item::get(\pocketmine\item\Item::MINECART_WITH_CHEST, 0, 1));
					foreach ($this->getDrops() as $item) {
						if ((($item !== null) && ($item->getId() !== 0))) {
							$this->getLevel()->dropItem($this, $item);
						}
						/* goto */
					}
				}
				if (((($this->chestx !== 0) || ($this->chesty !== 0)) || ($this->chestz !== 0))) {
					new \pocketmine\math\Vector3($this->chestx, $this->chesty, $this->chestz);
					new \pocketmine\block\Air();
					$this->getLevel()->setBlock(new \pocketmine\math\Vector3($this->chestx, $this->chesty, $this->chestz), new \pocketmine\block\Air(), true, true);
				}
			}
			parent::close();
			return null;
		}

}
