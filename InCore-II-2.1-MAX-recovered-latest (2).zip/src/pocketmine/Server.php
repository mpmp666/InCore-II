<?php

namespace pocketmine;

class Server {
	public const BROADCAST_CHANNEL_ADMINISTRATIVE = 'pocketmine.broadcast.admin';
	public const BROADCAST_CHANNEL_USERS = 'pocketmine.broadcast.user';
	public const PLAYER_MSG_TYPE_MESSAGE = 0;
	public const PLAYER_MSG_TYPE_TIP = 1;
	public const PLAYER_MSG_TYPE_POPUP = 2;

	private static $instance = NULL;
	private static $sleeper = NULL;
	private $banByName = NULL;
	private $banByIP = NULL;
	private $banByCID = NULL;
	private $operators = NULL;
	private $whitelist = NULL;
	private $isRunning = true;
	private $hasStopped = false;
	private $pluginManager = NULL;
	private $profilingTickRate = 20;
	private $scheduler = NULL;
	private $tickCounter = NULL;
	private $nextTick = 0;
	private $tickAverage = array (
  0 => 20,
  1 => 20,
  2 => 20,
  3 => 20,
  4 => 20,
  5 => 20,
  6 => 20,
  7 => 20,
  8 => 20,
  9 => 20,
  10 => 20,
  11 => 20,
  12 => 20,
  13 => 20,
  14 => 20,
  15 => 20,
  16 => 20,
  17 => 20,
  18 => 20,
  19 => 20,
);
	private $useAverage = array (
  0 => 0,
  1 => 0,
  2 => 0,
  3 => 0,
  4 => 0,
  5 => 0,
  6 => 0,
  7 => 0,
  8 => 0,
  9 => 0,
  10 => 0,
  11 => 0,
  12 => 0,
  13 => 0,
  14 => 0,
  15 => 0,
  16 => 0,
  17 => 0,
  18 => 0,
  19 => 0,
);
	private $maxTick = 20;
	private $maxUse = 0;
	private $sendUsageTicker = 0;
	private $dispatchSignals = false;
	private $logger = NULL;
	private $memoryManager = NULL;
	private $console = NULL;
	private $commandMap = NULL;
	private $craftingManager = NULL;
	private $consoleSender = NULL;
	private $maxPlayers = NULL;
	private $autoSave = NULL;
	private $rcon = NULL;
	private $entityMetadata = NULL;
	private $playerMetadata = NULL;
	private $levelMetadata = NULL;
	private $network = NULL;
	private $networkCompressionAsync = true;
	public $networkCompressionLevel = 7;
	public $InCoreVersion = 'Alto v2.1';
	private $autoTickRate = true;
	private $autoTickRateLimit = 20;
	private $alwaysTickPlayers = false;
	private $baseTickRate = 1;
	private $autoSaveTicker = 0;
	private $autoSaveTicks = 6000;
	private $baseLang = NULL;
	private $forceLanguage = false;
	private $serverID = NULL;
	private $autoloader = NULL;
	private $filePath = NULL;
	private $dataPath = NULL;
	private $pluginPath = NULL;
	private $uniquePlayers = array (
);
	private $queryHandler = NULL;
	private $queryRegenerateTask = NULL;
	private $properties = NULL;
	private $propertyCache = array (
);
	private $config = NULL;
	private $players = array (
);
	private $playerList = array (
);
	private $identifiers = array (
);
	private $levels = array (
);
	private $levelDefault = NULL;
	public $aboutstring = '';
	public $advancedConfig = NULL;
	private $advancedConfigMigrated = false;
	public $worldBehaviorConfig = array (
);
	public $weatherEnabled = true;
	public $foodEnabled = true;
	public $expEnabled = true;
	public $keepInventory = false;
	public $netherEnabled = false;
	public $netherName = 'nether';
	public $netherLevel = NULL;
	public $enderEnabled = false;
	public $enderName = 'ender';
	public $enderLevel = NULL;
	public $skyworldEnabled = false;
	public $skyworldName = 'skyworld';
	public $skyworldLevel = NULL;
	public $weatherRandomDurationMin = 6000;
	public $weatherRandomDurationMax = 12000;
	public $lookup = array (
);
	public $hungerHealth = 10;
	public $lightningTime = 200;
	public $lightningFire = false;
	public $expCache = array (
);
	public $expWriteAhead = 200;
	public $aiConfig = array (
);
	public $aiEnabled = false;
	public $aiHolder = NULL;
	public $inventoryNum = 36;
	public $hungerTimer = 80;
	public $version = NULL;
	public $allowSnowGolem = NULL;
	public $allowIronGolem = NULL;
	public $autoClearInv = true;
	public $dserverConfig = array (
);
	public $dserverPlayers = 0;
	public $dserverAllPlayers = 0;
	public $redstoneEnabled = false;
	public $allowFrequencyPulse = true;
	public $redstoneHighFrequencyBroadcastMessage = '§c[RedstoneGuard] 检测到高频红石，已移除 {world} ({x}, {y}, {z}) 附近装置，方块: {block}，附近玩家: {players}';
	public $anviletEnabled = false;
	public $anvilEnabled = true;
	public $enchantingTableEnabled = true;
	public $enchantingBookshelfCheckEnabled = true;
	public $tntExplosionEnabled = true;
	public $pulseFrequency = 1.0;
	public $playerMsgType = 0;
	public $playerLoginMsg = '';
	public $playerLogoutMsg = '';
	public $antiFly = false;
	public $antiFastEat = false;
	public $antiFastBreak = false;
	public $antiGameSpeed = false;
	public $antiToolbox = false;
	public $asyncChunkRequest = true;
	public $recipesFromJson = false;
	public $creativeItemsFromJson = false;
	public $minecartMovingType = 0;
	public $checkMovement = false;
	public $keepExperience = false;
	public $limitedCreative = true;
	public $chunkRadius = -1;
	public $destroyBlockParticle = true;
	public $allowSplashPotion = true;
	public $fireSpread = false;
	public $advancedCommandSelector = false;
	public $synapseConfig = array (
);
	public $netshBlock = false;
	public $antiXray = true;
	private $startupMotdGuardScheduled = false;
	private $startupExternalIpBlacklistGuardScheduled = false;
	private $trialShutdownScheduled = false;
	private $recipeLists = array (
);
	private $synapse = NULL;

	public function getName() {
			return 'InCore-II';
		}

	public function isRunning() {
			return ($this->isRunning === true);
		}

	public function getPocketMineVersion() {
			return \pocketmine\VERSION;
		}

	public function getCodename() {
			return \pocketmine\CODENAME;
		}

	public function getVersion() {
			return \pocketmine\MINECRAFT_VERSION;
		}

	public function getApiVersion() {
			return \pocketmine\API_VERSION;
		}

	public function getIncoreApi() {
			return;
		}

	public function getiTXApiVersion() {
			return \pocketmine\INCORE_II_API_VERSION;
		}

	public function getGeniApiVersion() {
			return \pocketmine\INCORE_II_API_VERSION;
		}

	public function getFilePath() {
			return $this->filePath;
		}

	public function getDataPath() {
			return $this->dataPath;
		}

	public function getPluginPath() {
			return $this->pluginPath;
		}

	public function getMaxPlayers() {
			return $this->maxPlayers;
		}

	public function getPort() {
			return $this->getConfigInt('server-port', 19132);
		}

	public function getViewDistance() {
			return max(56, $this->getProperty('chunk-sending.max-chunks', 256));
		}

	public function getIp() {
			return $this->getConfigString('server-ip', '0.0.0.0');
		}

	public function getServerName() {
			return $this->getConfigString('motd', $this);
		}

	public function getServerUniqueId() {
			return $this->serverID;
		}

	public function getAutoSave() {
			return $this->autoSave;
		}

	public function setAutoSave($value = null) {
			/* decompiled (structured CF) */
			$this->autoSave = $value;
			foreach ($this->getLevels() as $level) {
				$level->setAutoSave($this->autoSave);
				/* goto */
			}
			return null;
		}

	public function getLevelType() {
			return $this->getConfigString('level-type', 'DEFAULT');
		}

	public function getGenerateStructures() {
			return $this->getConfigBoolean('generate-structures', true);
		}

	public function getGamemode() {
			return ($this->getConfigInt('gamemode', 0) & 3);
		}

	public function getForceGamemode() {
			return $this->getConfigBoolean('force-gamemode', false);
		}

	public static function getGamemodeString($mode = null) {
			/* decompiled (structured CF) */
			switch (($mode)) {
				case \pocketmine\Player::SURVIVAL:
				return '%gameMode.survival';
				case \pocketmine\Player::CREATIVE:
				return '%gameMode.creative';
				case \pocketmine\Player::ADVENTURE:
				return '%gameMode.adventure';
				case \pocketmine\Player::SPECTATOR:
				return '%gameMode.spectator';
			}
		}

	public static function getGamemodeFromString($str = null) {
			/* decompiled (structured CF) */
			/* jump */
			switch (strtolower(trim($str))) {
				case (\pocketmine\Player::SURVIVAL):
				case 'survival':
				case 's':
				return \pocketmine\Player::SURVIVAL;
				case (\pocketmine\Player::CREATIVE):
				case 'creative':
				case 'c':
				return \pocketmine\Player::CREATIVE;
				case (\pocketmine\Player::ADVENTURE):
				case 'adventure':
				case 'a':
				return \pocketmine\Player::ADVENTURE;
				case (\pocketmine\Player::SPECTATOR):
				case 'spectator':
				case 'view':
				case 'v':
				return \pocketmine\Player::SPECTATOR;
			}
		}

	public static function getDifficultyFromString($str = null) {
			/* decompiled (structured CF) */
			switch (strtolower(trim($str))) {
				case '0':
				case 'peaceful':
				case 'p':
				return 0;
				case '1':
				case 'easy':
				case 'e':
				return 1;
				case '2':
				case 'normal':
				case 'n':
				return 2;
				case '3':
				case 'hard':
				case 'h':
				return 3;
			}
		}

	public function getDifficulty() {
			return $this->getConfigInt('difficulty', 1);
		}

	public function hasWhitelist() {
			return $this->getConfigBoolean('white-list', false);
		}

	public function getSpawnRadius() {
			return $this->getConfigInt('spawn-protection', 16);
		}

	public function getAllowFlight() {
			return $this->getConfigBoolean('allow-flight', false);
		}

	public function isHardcore() {
			return $this->getConfigBoolean('hardcore', false);
		}

	public function getDefaultGamemode() {
			return ($this->getConfigInt('gamemode', 0) & 3);
		}

	public function getMotd() {
			return $this->getConfigString('motd', $this);
		}

	public function getLoader() {
			return $this->autoloader;
		}

	public function getLogger() {
			return $this->logger;
		}

	public function getEntityMetadata() {
			return $this->entityMetadata;
		}

	public function getPlayerMetadata() {
			return $this->playerMetadata;
		}

	public function getLevelMetadata() {
			return $this->levelMetadata;
		}

	public function getPluginManager() {
			return $this->pluginManager;
		}

	public function getCraftingManager() {
			return $this->craftingManager;
		}

	public function getScheduler() {
			return $this->scheduler;
		}

	public function getTick() {
			return $this->tickCounter;
		}

	public function getAIHolder() {
			return $this->aiHolder;
		}

	public function getTicksPerSecond() {
			return round($this->maxTick, 2);
		}

	public function getTicksPerSecondAverage() {
			return round((array_sum($this->tickAverage) / count($this->tickAverage)), 2);
		}

	public function getTickUsage() {
			return round(($this->maxUse * 100), 2);
		}

	public function getTickUsageAverage() {
			return round(((array_sum($this->useAverage) / count($this->useAverage)) * 100), 2);
		}

	public function blockAddress($address = null, $timeout = null) {
			$this->network->blockAddress($address, $timeout);
			return null;
		}

	public function sendPacket($address = null, $port = null, $payload = null) {
			$this->network->sendPacket($address, $port, $payload);
			return null;
		}

	public function getInterfaces() {
			return $this->network->getInterfaces();
		}

	public function addInterface($interface = null) {
			$this->network->registerInterface($interface);
			return null;
		}

	public function removeInterface($interface = null) {
			$interface->shutdown();
			$this->network->unregisterInterface($interface);
			return null;
		}

	public function getCommandMap() {
			return $this->commandMap;
		}

	public function getOnlinePlayers() {
			return $this->playerList;
		}

	public function addRecipe($recipe = null) {
			$this->craftingManager->registerRecipe($recipe);
			$this->generateRecipeList();
			return null;
		}

	public function getOfflinePlayer($name = null) {
			/* decompiled (structured CF) */
			$name = strtolower($name);
			$result = $this->getPlayerExact($name);
			if (($result === null)) {
				new \pocketmine\OfflinePlayer($this, $name);
				$result = new \pocketmine\OfflinePlayer($this, $name);
			}
			return $result;
		}

	public function getOfflinePlayerData($name = null) {
			/* decompiled (structured CF) */
			$name = strtolower($name);
			$path = ($this->getDataPath() . 'players/');
			if (file_exists(($path . $t16))) {
				new \pocketmine\nbt\NBT(\pocketmine\nbt\NBT::BIG_ENDIAN);
				$nbt = new \pocketmine\nbt\NBT(\pocketmine\nbt\NBT::BIG_ENDIAN);
				$nbt->readCompressed(file_get_contents(($path . $t23)));
				return $nbt->getData();
				/* jump */
				rename(($path . $t28), ($path . $t30));
				$this->logger->notice($this->getLanguage()->translateString('pocketmine.data.playerCorrupted', [$name]));
			} else {
				$this->logger->notice($this->getLanguage()->translateString('pocketmine.data.playerNotFound', [$name]));
			}
			$spawn = $this->getDefaultLevel()->getSafeSpawn();
			new \pocketmine\nbt\tag\LongTag('firstPlayed', floor((microtime(true) * 1000)));
			new \pocketmine\nbt\tag\LongTag('lastPlayed', floor((microtime(true) * 1000)));
			new \pocketmine\nbt\tag\DoubleTag(0, $spawn->x);
			new \pocketmine\nbt\tag\DoubleTag(1, $spawn->y);
			new \pocketmine\nbt\tag\DoubleTag(2, $spawn->z);
			new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag(0, $spawn->x), new \pocketmine\nbt\tag\DoubleTag(1, $spawn->y), new \pocketmine\nbt\tag\DoubleTag(2, $spawn->z)]);
			new \pocketmine\nbt\tag\StringTag('Level', $this->getDefaultLevel()->getName());
			new \pocketmine\nbt\tag\ListTag('Inventory', ['__array_ptr' => '2aaaac9fc9a0']);
			new \pocketmine\nbt\tag\CompoundTag('Achievements', ['__array_ptr' => '2aaaac9fc9a0']);
			new \pocketmine\nbt\tag\IntTag('playerGameType', $this->getGamemode());
			new \pocketmine\nbt\tag\DoubleTag(0, 0);
			new \pocketmine\nbt\tag\DoubleTag(1, 0);
			new \pocketmine\nbt\tag\DoubleTag(2, 0);
			new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag(0, 0), new \pocketmine\nbt\tag\DoubleTag(1, 0), new \pocketmine\nbt\tag\DoubleTag(2, 0)]);
			new \pocketmine\nbt\tag\FloatTag(0, 0);
			new \pocketmine\nbt\tag\FloatTag(1, 0);
			new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag(0, 0), new \pocketmine\nbt\tag\FloatTag(1, 0)]);
			new \pocketmine\nbt\tag\FloatTag('FallDistance', 0);
			new \pocketmine\nbt\tag\ShortTag('Fire', 0);
			new \pocketmine\nbt\tag\ShortTag('Air', 300);
			new \pocketmine\nbt\tag\ByteTag('OnGround', 1);
			new \pocketmine\nbt\tag\ByteTag('Invulnerable', 0);
			new \pocketmine\nbt\tag\StringTag('NameTag', $name);
			new \pocketmine\nbt\tag\ShortTag('Hunger', 20);
			new \pocketmine\nbt\tag\ShortTag('Health', 20);
			new \pocketmine\nbt\tag\ShortTag('MaxHealth', 20);
			new \pocketmine\nbt\tag\LongTag('Experience', 0);
			new \pocketmine\nbt\tag\LongTag('ExpLevel', 0);
			new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\LongTag('firstPlayed', floor((microtime(true) * 1000))), new \pocketmine\nbt\tag\LongTag('lastPlayed', floor((microtime(true) * 1000))), new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag(0, $spawn->x), new \pocketmine\nbt\tag\DoubleTag(1, $spawn->y), new \pocketmine\nbt\tag\DoubleTag(2, $spawn->z)]), new \pocketmine\nbt\tag\StringTag('Level', $this->getDefaultLevel()->getName()), new \pocketmine\nbt\tag\ListTag('Inventory', ['__array_ptr' => '2aaaac9fc9a0']), new \pocketmine\nbt\tag\CompoundTag('Achievements', ['__array_ptr' => '2aaaac9fc9a0']), new \pocketmine\nbt\tag\IntTag('playerGameType', $this->getGamemode()), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag(0, 0), new \pocketmine\nbt\tag\DoubleTag(1, 0), new \pocketmine\nbt\tag\DoubleTag(2, 0)]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag(0, 0), new \pocketmine\nbt\tag\FloatTag(1, 0)]), new \pocketmine\nbt\tag\FloatTag('FallDistance', 0), new \pocketmine\nbt\tag\ShortTag('Fire', 0), new \pocketmine\nbt\tag\ShortTag('Air', 300), new \pocketmine\nbt\tag\ByteTag('OnGround', 1), new \pocketmine\nbt\tag\ByteTag('Invulnerable', 0), new \pocketmine\nbt\tag\StringTag('NameTag', $name), new \pocketmine\nbt\tag\ShortTag('Hunger', 20), new \pocketmine\nbt\tag\ShortTag('Health', 20), new \pocketmine\nbt\tag\ShortTag('MaxHealth', 20), new \pocketmine\nbt\tag\LongTag('Experience', 0), new \pocketmine\nbt\tag\LongTag('ExpLevel', 0)]);
			$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\LongTag('firstPlayed', floor((microtime(true) * 1000))), new \pocketmine\nbt\tag\LongTag('lastPlayed', floor((microtime(true) * 1000))), new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag(0, $spawn->x), new \pocketmine\nbt\tag\DoubleTag(1, $spawn->y), new \pocketmine\nbt\tag\DoubleTag(2, $spawn->z)]), new \pocketmine\nbt\tag\StringTag('Level', $this->getDefaultLevel()->getName()), new \pocketmine\nbt\tag\ListTag('Inventory', ['__array_ptr' => '2aaaac9fc9a0']), new \pocketmine\nbt\tag\CompoundTag('Achievements', ['__array_ptr' => '2aaaac9fc9a0']), new \pocketmine\nbt\tag\IntTag('playerGameType', $this->getGamemode()), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag(0, 0), new \pocketmine\nbt\tag\DoubleTag(1, 0), new \pocketmine\nbt\tag\DoubleTag(2, 0)]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag(0, 0), new \pocketmine\nbt\tag\FloatTag(1, 0)]), new \pocketmine\nbt\tag\FloatTag('FallDistance', 0), new \pocketmine\nbt\tag\ShortTag('Fire', 0), new \pocketmine\nbt\tag\ShortTag('Air', 300), new \pocketmine\nbt\tag\ByteTag('OnGround', 1), new \pocketmine\nbt\tag\ByteTag('Invulnerable', 0), new \pocketmine\nbt\tag\StringTag('NameTag', $name), new \pocketmine\nbt\tag\ShortTag('Hunger', 20), new \pocketmine\nbt\tag\ShortTag('Health', 20), new \pocketmine\nbt\tag\ShortTag('MaxHealth', 20), new \pocketmine\nbt\tag\LongTag('Experience', 0), new \pocketmine\nbt\tag\LongTag('ExpLevel', 0)]);
			$nbt->Pos->setTagType(\pocketmine\nbt\NBT::TAG_Double);
			$nbt->Inventory->setTagType(\pocketmine\nbt\NBT::TAG_Compound);
			$nbt->Motion->setTagType(\pocketmine\nbt\NBT::TAG_Double);
			$nbt->Rotation->setTagType(\pocketmine\nbt\NBT::TAG_Float);
			if (file_exists(($path . $t133))) {
				new \pocketmine\utils\Config(($path . $t137), \pocketmine\utils\Config::YAML, ['__array_ptr' => '2aaaac9fc9a0']);
				$data = new \pocketmine\utils\Config(($path . $t137), \pocketmine\utils\Config::YAML, ['__array_ptr' => '2aaaac9fc9a0']);
				$nbt['playerGameType'] = ($data->get('gamemode'));
				$nbt['Level'] = $data->get('position')['level'];
				$nbt['Pos'][0] = $data->get('position')['x'];
				$nbt['Pos'][1] = $data->get('position')['y'];
				$nbt['Pos'][2] = $data->get('position')['z'];
				$nbt['SpawnLevel'] = $data->get('spawn')['level'];
				$nbt['SpawnX'] = ($data->get('spawn')['x']);
				$nbt['SpawnY'] = ($data->get('spawn')['y']);
				$nbt['SpawnZ'] = ($data->get('spawn')['z']);
				$this->logger->notice($this->getLanguage()->translateString('pocketmine.data.playerOld', [$name]));
				foreach ($data->get('inventory') as $slot => $item) {
					if ((count($item) === 3)) {
						new \pocketmine\nbt\tag\ShortTag('id', $item[0]);
						new \pocketmine\nbt\tag\ShortTag('Damage', $item[1]);
						new \pocketmine\nbt\tag\ByteTag('Count', $item[2]);
						new \pocketmine\nbt\tag\ByteTag('Slot', ($slot + 9));
						new \pocketmine\nbt\tag\ByteTag('TrueSlot', ($slot + 9));
						new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ShortTag('id', $item[0]), new \pocketmine\nbt\tag\ShortTag('Damage', $item[1]), new \pocketmine\nbt\tag\ByteTag('Count', $item[2]), new \pocketmine\nbt\tag\ByteTag('Slot', ($slot + 9)), new \pocketmine\nbt\tag\ByteTag('TrueSlot', ($slot + 9))]);
						$nbt->Inventory[($slot + 9)] = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ShortTag('id', $item[0]), new \pocketmine\nbt\tag\ShortTag('Damage', $item[1]), new \pocketmine\nbt\tag\ByteTag('Count', $item[2]), new \pocketmine\nbt\tag\ByteTag('Slot', ($slot + 9)), new \pocketmine\nbt\tag\ByteTag('TrueSlot', ($slot + 9))]);
					}
					/* goto */
				}
				foreach ($data->get('hotbar') as $slot => $itemSlot) {
					if (isset($nbt->Inventory[($itemSlot + 9)])) {
						$item = $nbt->Inventory[($itemSlot + 9)];
						new \pocketmine\nbt\tag\ShortTag('id', $item['id']);
						new \pocketmine\nbt\tag\ShortTag('Damage', $item['Damage']);
						new \pocketmine\nbt\tag\ByteTag('Count', $item['Count']);
						new \pocketmine\nbt\tag\ByteTag('Slot', $slot);
						new \pocketmine\nbt\tag\ByteTag('TrueSlot', $item['TrueSlot']);
						new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ShortTag('id', $item['id']), new \pocketmine\nbt\tag\ShortTag('Damage', $item['Damage']), new \pocketmine\nbt\tag\ByteTag('Count', $item['Count']), new \pocketmine\nbt\tag\ByteTag('Slot', $slot), new \pocketmine\nbt\tag\ByteTag('TrueSlot', $item['TrueSlot'])]);
						$nbt->Inventory[$slot] = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ShortTag('id', $item['id']), new \pocketmine\nbt\tag\ShortTag('Damage', $item['Damage']), new \pocketmine\nbt\tag\ByteTag('Count', $item['Count']), new \pocketmine\nbt\tag\ByteTag('Slot', $slot), new \pocketmine\nbt\tag\ByteTag('TrueSlot', $item['TrueSlot'])]);
					}
					/* goto */
				}
				foreach ($data->get('armor') as $slot => $item) {
					if ((count($item) === 2)) {
						new \pocketmine\nbt\tag\ShortTag('id', $item[0]);
						new \pocketmine\nbt\tag\ShortTag('Damage', $item[1]);
						new \pocketmine\nbt\tag\ByteTag('Count', 1);
						new \pocketmine\nbt\tag\ByteTag('Slot', ($slot + 100));
						new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ShortTag('id', $item[0]), new \pocketmine\nbt\tag\ShortTag('Damage', $item[1]), new \pocketmine\nbt\tag\ByteTag('Count', 1), new \pocketmine\nbt\tag\ByteTag('Slot', ($slot + 100))]);
						$nbt->Inventory[($slot + 100)] = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ShortTag('id', $item[0]), new \pocketmine\nbt\tag\ShortTag('Damage', $item[1]), new \pocketmine\nbt\tag\ByteTag('Count', 1), new \pocketmine\nbt\tag\ByteTag('Slot', ($slot + 100))]);
					}
					/* goto */
				}
				foreach ($data->get('achievements') as $achievement => $status) {
					if ($status) {
					} else {
					}
					new \pocketmine\nbt\tag\ByteTag($achievement, 0);
					$nbt->Achievements[$achievement] = new \pocketmine\nbt\tag\ByteTag($achievement, 0);
					/* goto */
				}
				unlink(($path . $t270));
			}
			$this->saveOfflinePlayerData($name, $nbt);
			return $nbt;
		}

	public function saveOfflinePlayerData($name = null, $nbtTag = null, $async = null) {
			/* decompiled (structured CF) */
			new \pocketmine\nbt\NBT(\pocketmine\nbt\NBT::BIG_ENDIAN);
			$nbt = new \pocketmine\nbt\NBT(\pocketmine\nbt\NBT::BIG_ENDIAN);
			$nbt->setData($nbtTag);
			if ($async) {
				new \pocketmine\scheduler\FileWriteTask(((($this->getDataPath() . 'players/') . strtolower($name)) . '.dat'), $nbt->writeCompressed());
				$this->getScheduler()->scheduleAsyncTask(new \pocketmine\scheduler\FileWriteTask(((($this->getDataPath() . 'players/') . strtolower($name)) . '.dat'), $nbt->writeCompressed()));
			} else {
				file_put_contents(((($this->getDataPath() . 'players/') . strtolower($name)) . '.dat'), $nbt->writeCompressed());
			}
			/* jump */
			$this->logger->critical($this->getLanguage()->translateString('pocketmine.data.saveError', [$name, $e->getMessage()]));
			if (((1 < \pocketmine\DEBUG) && $this->logger instanceof \pocketmine\utils\MainLogger)) {
				$this->logger->logException($e);
			}
			return null;
		}

	public function getPlayer($name = null) {
			/* decompiled (structured CF) */
			$found = null;
			$name = strtolower($name);
			$delta = \PHP_INT_MAX;
			foreach ($this->getOnlinePlayers() as $player) {
				if ((stripos($player->getName(), $name) === 0)) {
					$curDelta = (strlen($player->getName()) - strlen($name));
					if (($curDelta < $delta)) {
						$found = $player;
						$delta = $curDelta;
					}
					if (($curDelta === 0)) {
					} else {
						/* goto */
					}
					return $found;
				}
			}
		}

	public function getPlayerExact($name = null) {
			/* decompiled (structured CF) */
			$name = strtolower($name);
			foreach ($this->getOnlinePlayers() as $player) {
				if (($name === strtolower($player->getName()))) {
					return $player;
				}
				/* goto */
			}
		}

	public function matchPlayer($partialName = null) {
			/* decompiled (structured CF) */
			$partialName = strtolower($partialName);
			$matchedPlayers = ['__array_ptr' => '2aaaac9fc9a0'];
			foreach ($this->getOnlinePlayers() as $player) {
				if (($partialName === strtolower($player->getName()))) {
					$matchedPlayers = [$player];
					/* jump */
				} else {
					if ((stripos($player->getName(), $partialName) !== false)) {
						$matchedPlayers[] = $player;
					}
				}
				/* goto */
			}
			return $matchedPlayers;
		}

	public function removePlayer($player = null) {
			/* decompiled (structured CF) */
			$hash = spl_object_hash($player);
			if (isset($this->identifiers[$hash])) {
				$identifier = $this->identifiers[$hash];
				return null;
			}
			foreach ($this->players as $identifier => $p) {
				if (($player === $p)) {
				} else {
					/* goto */
				}
			}
		}

	public function getLevels() {
			return $this->levels;
		}

	public function getDefaultLevel() {
			return $this->levelDefault;
		}

	public function setDefaultLevel($level = null) {
			/* decompiled (structured CF) */
			if ((($level === null) || ($this->isLevelLoaded($level->getFolderName()) && ($level !== $this->levelDefault)))) {
				$this->levelDefault = $level;
			}
			return null;
		}

	public function isLevelLoaded($name = null) {
			return $this->getLevelByName($name) instanceof \pocketmine\level\Level;
		}

	public function getLevel($levelId = null) {
			if (isset($this->levels[$levelId])) {
				return $this->levels[$levelId];
			}
		}

	public function getLevelByName($name = null) {
			/* decompiled (structured CF) */
			$name = trim(($name));
			foreach ($this->getLevels() as $level) {
				if ($level->isClosed()) {
					/* goto */
				}
				if ((($name === $level->getFolderName()) || ($name === $level->getName()))) {
					return $level;
				}
				/* goto */
			}
			foreach ($this->getLevels() as $level) {
				if ($level->isClosed()) {
					/* goto */
				}
				if (((strcasecmp($level->getFolderName(), $name) === 0) || (strcasecmp($level->getName(), $name) === 0))) {
					return $level;
				}
				/* goto */
			}
		}

	public function unloadLevel($level = null, $forceUnload = null) {
			/* decompiled (structured CF) */
			if ((($level === $this->getDefaultLevel()) && !($forceUnload))) {
				new \InvalidStateException($this);
				throw new \InvalidStateException($this);
			}
			if (($level->unload($forceUnload) === true)) {
				return true;
			}
			return false;
		}

	public function loadLevel($name = null) {
			/* decompiled (structured CF) */
			if ((trim($name) === '')) {
				new \pocketmine\utils\LevelException($this);
				throw new \pocketmine\utils\LevelException($this);
			}
			if ($this->isLevelLoaded($name)) {
				return true;
			} else {
				if (!($this->isLevelGenerated($name))) {
					$this->logger->notice($this->getLanguage()->translateString('pocketmine.level.notFound', [$name]));
					return false;
				}
			}
			$path = ((($this->getDataPath() . 'worlds/') . $name) . '/');
			$provider = \pocketmine\level\format\LevelProviderManager::getProvider($path);
			if (($provider === null)) {
				$this->logger->error($this->getLanguage()->translateString('pocketmine.level.loadError', [$name, $this]));
				return false;
			}
			new \pocketmine\level\Level($this, $name, $path, $provider);
			$level = new \pocketmine\level\Level($this, $name, $path, $provider);
			/* jump */
			$this->logger->error($this->getLanguage()->translateString('pocketmine.level.loadError', [$name, $e->getMessage()]));
			if ($this->logger instanceof \pocketmine\utils\MainLogger) {
				$this->logger->logException($e);
			}
			return false;
			$this->levels[$level->getId()] = $level;
			$level->initLevel();
			new \pocketmine\event\level\LevelLoadEvent($level);
			$this->getPluginManager()->callEvent(new \pocketmine\event\level\LevelLoadEvent($level));
			$level->setTickRate($this->baseTickRate);
			return true;
		}

	public function generateLevel($name = null, $seed = null, $generator = null, $options = null) {
			/* decompiled (structured CF) */
			if (((trim($name) === '') || $this->isLevelGenerated($name))) {
				return false;
			}
			if (($seed === null)) {
			} else {
			}
			$seed = ($seed);
			if (!(isset($options['preset']))) {
				$options['preset'] = $this->getConfigString('generator-settings', '');
			}
			if (!(((($generator !== null) && class_exists($generator, true)) && is_subclass_of($generator, 'pocketmine\\level\\generator\\Generator')))) {
				$generator = \pocketmine\level\generator\Generator::getGenerator($this->getLevelType());
			}
			$providerName = $this->getProperty('level-settings.default-format', 'mcregion');
			$provider = \pocketmine\level\format\LevelProviderManager::getProviderByName($providerName);
			if (($provider === null)) {
				$providerName = 'mcregion';
				$provider = \pocketmine\level\format\LevelProviderManager::getProviderByName($providerName);
			}
			$path = ((($this->getDataPath() . 'worlds/') . $name) . '/');
			$provider::generate($path, $name, $seed, $generator, $options);
			new \pocketmine\level\Level($this, $name, $path, $provider);
			$level = new \pocketmine\level\Level($this, $name, $path, $provider);
			$this->levels[$level->getId()] = $level;
			$level->initLevel();
			$level->setTickRate($this->baseTickRate);
			/* jump */
			$this->logger->error($this->getLanguage()->translateString('pocketmine.level.generateError', [$name, $e->getMessage()]));
			if ($this->logger instanceof \pocketmine\utils\MainLogger) {
				$this->logger->logException($e);
			}
			return false;
			new \pocketmine\event\level\LevelInitEvent($level);
			$this->getPluginManager()->callEvent(new \pocketmine\event\level\LevelInitEvent($level));
			new \pocketmine\event\level\LevelLoadEvent($level);
			$this->getPluginManager()->callEvent(new \pocketmine\event\level\LevelLoadEvent($level));
			$this->getLogger()->notice($this->getLanguage()->translateString('pocketmine.level.backgroundGeneration', [$name]));
			$centerX = ($level->getSpawnLocation()->getX() >> 4);
			$centerZ = ($level->getSpawnLocation()->getZ() >> 4);
			$order = ['__array_ptr' => '2aaaac9fc9a0'];
			$X = -3;
			while (($X <= 3)) {
				$Z = -3;
				while (($Z <= 3)) {
					$distance = ($t98 + $t99);
					$chunkX = ($X + $centerX);
					$chunkZ = ($Z + $centerZ);
					$index = \pocketmine\level\Level::chunkHash($chunkX, $chunkZ);
					$order[$index] = $distance;
					$Z++;
				}
				$X++;
			}
			asort($order);
			foreach ($order as $index => $distance) {
				\pocketmine\level\Level::getXZ($index, $chunkX, $chunkZ);
				$level->populateChunk($chunkX, $chunkZ, true);
				/* goto */
			}
			return true;
		}

	public function isLevelGenerated($name = null) {
			/* decompiled (structured CF) */
			if ((trim($name) === '')) {
				return false;
			}
			$path = ((($this->getDataPath() . 'worlds/') . $name) . '/');
			if (!($this->getLevelByName($name) instanceof \pocketmine\level\Level)) {
				if ((\pocketmine\level\format\LevelProviderManager::getProvider($path) === null)) {
					return false;
				}
			}
			return true;
		}

	public function getConfigString($variable = null, $defaultValue = null) {
			/* decompiled (structured CF) */
			$v = getopt('', [$t3]);
			if (isset($v[$variable])) {
				return ($v[$variable]);
			}
			if ($this->properties->exists($variable)) {
			} else {
			}
			return $defaultValue;
		}

	public function getProperty($variable = null, $defaultValue = null) {
			/* decompiled (structured CF) */
			if (!(array_key_exists($variable, $this->propertyCache))) {
				$v = getopt('', [$t6]);
				if (isset($v[$variable])) {
					$this->propertyCache[$variable] = $v[$variable];
				} else {
					$this->propertyCache[$variable] = $this->config->getNested($variable);
				}
			}
			if (($this->propertyCache[$variable] === null)) {
			} else {
			}
			return $this->propertyCache[$variable];
		}

	public function setConfigString($variable = null, $value = null) {
			$this->properties->set($variable, $value);
			return null;
		}

	public function getConfigInt($variable = null, $defaultValue = null) {
			/* decompiled (structured CF) */
			$v = getopt('', [$t3]);
			if (isset($v[$variable])) {
				return ($v[$variable]);
			}
			if ($this->properties->exists($variable)) {
			} else {
			}
			return ($defaultValue);
		}

	public function setConfigInt($variable = null, $value = null) {
			$this->properties->set($variable, ($value));
			return null;
		}

	public function getConfigBoolean($variable = null, $defaultValue = null) {
			/* decompiled (structured CF) */
			$v = getopt('', [$t4]);
			if (isset($v[$variable])) {
				$value = $v[$variable];
			} else {
				if ($this->properties->exists($variable)) {
				} else {
				}
				$value = $defaultValue;
			}
			if (is_bool($value)) {
				return $value;
			}
			switch (strtolower($value)) {
				case 'on':
				case 'true':
				case '1':
				case 'yes':
				return true;
			}
		}

	public function isProtocolAllowed($protocol = null) {
			/* decompiled (structured CF) */
			if (\pocketmine\network\protocol\ProtocolCompatibility::isProtocol013($protocol)) {
				return false;
			}
			if (\pocketmine\network\protocol\ProtocolCompatibility::isProtocol015($protocol)) {
				return $this->getConfigBoolean('protocol-015', true);
			}
			return true;
		}

	public function getProtocolDisallowedMessage($protocol = null) {
			/* decompiled (structured CF) */
			if (\pocketmine\network\protocol\ProtocolCompatibility::isProtocol013($protocol)) {
				return $this;
			}
			return "\xe6\xa0\xb9\xe6\x8d\xae\xe6\x9c\x8d\xe4\xb8\xbb\xe8\xa7\x84\xe5\xae\x9a\xef\xbc\x8c\xe6\x82\xa8\xe5\xbd\x93\xe5\x89\x8d\xe7\x89\x88\xe6\x9c\xac\xe4\xb8\x8d\xe6\x94\xaf\xe6\x8c\x81\xe8\xbf\x9b\xe5\x85\xa5\xe6\x9c\x8d\xe5\x8a\xa1\xe5\x99\xa8";
		}

	public function setConfigBool($variable = null, $value = null) {
			/* decompiled (structured CF) */
			if ($value) {
			} else {
			}
			$this->properties->set($variable, '0');
			return null;
		}

	public function getPluginCommand($name = null) {
			/* decompiled (structured CF) */
			$command = $this->commandMap->getCommand($name);
			if ($command instanceof \pocketmine\command\PluginIdentifiableCommand) {
				return $command;
			} else {
			}
		}

	public function getNameBans() {
			return $this->banByName;
		}

	public function getIPBans() {
			return $this->banByIP;
		}

	public function getCIDBans() {
			return $this->banByCID;
		}

	public function addOp($name = null) {
			/* decompiled (structured CF) */
			$this->operators->set(strtolower($name), true);
			$player = $this->getPlayerExact($name);
			if (($player !== null)) {
				$player->recalculatePermissions();
			}
			$this->operators->save(true);
			return null;
		}

	public function removeOp($name = null) {
			/* decompiled (structured CF) */
			$this->operators->remove(strtolower($name));
			$player = $this->getPlayerExact($name);
			if (($player !== null)) {
				$player->recalculatePermissions();
			}
			$this->operators->save();
			return null;
		}

	public function addWhitelist($name = null) {
			$this->whitelist->set(strtolower($name), true);
			$this->whitelist->save(true);
			return null;
		}

	public function removeWhitelist($name = null) {
			$this->whitelist->remove(strtolower($name));
			$this->whitelist->save();
			return null;
		}

	public function isWhitelisted($name = null) {
			return (!($this->hasWhitelist()) || $this->whitelist->exists($name, true));
		}

	public function isOp($name = null) {
			return $this->operators->exists($name, true);
		}

	public function getWhitelisted() {
			return $this->whitelist;
		}

	public function getOps() {
			return $this->operators;
		}

	public function reloadWhitelist() {
			$this->whitelist->reload();
			return null;
		}

	public function getCommandAliases() {
			/* decompiled (structured CF) */
			$section = $this->getProperty('aliases');
			$result = ['__array_ptr' => '2aaaac9fc9a0'];
			if (is_array($section)) {
				foreach ($section as $key => $value) {
					$commands = ['__array_ptr' => '2aaaac9fc9a0'];
					if (is_array($value)) {
						$commands = $value;
					} else {
						$commands[] = $value;
					}
					$result[$key] = $commands;
					/* goto */
				}
			}
			return $result;
		}

	public function getCrashPath() {
			return ($this->dataPath . 'crashdumps/');
		}

	public static function getInstance() {
			return self::$instance;
		}

	public static function microSleep($microseconds = null) {
			\pocketmine\Server::$sleeper->synchronized(function () { /* unrecovered lambda E:/Desktop/src/src/pocketmine/Server.php.cAJrIX:1664$42b */ return null; }, $microseconds);
			return null;
		}

	public function getExpectedExperience($level = null) {
			/* decompiled (structured CF) */
			if (isset($this->expCache[$level])) {
				return $this->expCache[$level];
			}
			$levelSquared = $t6;
			if (($level < 16)) {
				$this->expCache[$level] = ($levelSquared + ($level * 6));
			} else {
				if (($level < 31)) {
					$this->expCache[$level] = ((($levelSquared * 2.5) - ($level * 40.5)) + 360);
				} else {
					$this->expCache[$level] = ((($levelSquared * 4.5) - ($level * 162.5)) + 2220);
				}
			}
			return $this->expCache[$level];
		}

	public function about() {
			$this->logger->info($this->aboutstring);
			return null;
		}

	public function loadAdvancedConfig() {
			/* decompiled (structured CF) */
			$this->playerMsgType = $this->getAdvancedProperty('server.player-msg-type', self::PLAYER_MSG_TYPE_MESSAGE);
			$this->playerLoginMsg = $this->getAdvancedProperty('server.login-msg', $this);
			$this->playerLogoutMsg = $this->getAdvancedProperty('server.logout-msg', $this);
			$this->weatherEnabled = $this->getAdvancedProperty('level.weather', true);
			$this->foodEnabled = $this->getAdvancedProperty('player.hunger', true);
			$this->expEnabled = $this->getAdvancedProperty('player.experience', true);
			$this->keepInventory = $this->getAdvancedProperty('player.keep-inventory', false);
			$this->keepExperience = $this->getAdvancedProperty('player.keep-experience', false);
			$this->netherEnabled = $this->getAdvancedProperty('nether.allow-nether', false);
			$this->netherName = $this->getAdvancedProperty('nether.level-name', 'nether');
			$this->enderEnabled = $this->getAdvancedProperty('ender.allow-ender', false);
			$this->enderName = $this->getAdvancedProperty('ender.level-name', 'ender');
			$this->skyworldEnabled = $this->getAdvancedProperty('skyworld.allow-skyworld', false);
			$this->skyworldName = $this->getAdvancedProperty('skyworld.level-name', 'skyworld');
			$this->worldBehaviorConfig = [$this->normalizeWorldNameList($this->getAdvancedProperty('world.no-natural-mob-spawn', ['__array_ptr' => '2aaaac9fc9a0'])), $this->normalizeWorldNameList($this->getAdvancedProperty('world.no-mob-death-drops-and-experience', ['__array_ptr' => '2aaaac9fc9a0'])), $this->normalizeWorldNameList($this->getAdvancedProperty('world.no-creeper-block-damage', ['__array_ptr' => '2aaaac9fc9a0'])), $this->normalizeWorldNameList($this->getAdvancedProperty('world.no-tnt-block-damage', ['__array_ptr' => '2aaaac9fc9a0'])), $this->normalizeWorldNameList($this->getAdvancedProperty('world.no-hunger-health-regeneration', ['__array_ptr' => '2aaaac9fc9a0'])), $this->normalizeWorldNameList($this->getAdvancedProperty('world.no-crop-growth', ['__array_ptr' => '2aaaac9fc9a0'])), $this->normalizeWorldNameList($this->getAdvancedProperty('world.no-non-living-entity-drops', ['__array_ptr' => '2aaaac9fc9a0'])), $this->normalizeWorldNameList($this->getAdvancedProperty('world.keep-inventory', ['__array_ptr' => '2aaaac9fc9a0'])), $this->normalizeWorldNameList($this->getAdvancedProperty('world.do-daylight-cycle', ['__array_ptr' => '2aaaac9fc9a0']))];
			$this->weatherRandomDurationMin = $this->getAdvancedProperty('level.weather-random-duration-min', 6000);
			$this->weatherRandomDurationMax = $this->getAdvancedProperty('level.weather-random-duration-max', 12000);
			$this->hungerHealth = $this->getAdvancedProperty('player.hunger-health', 10);
			$this->lightningTime = $this->getAdvancedProperty('level.lightning-time', 200);
			$this->lightningFire = $this->getAdvancedProperty('level.lightning-fire', false);
			$this->expWriteAhead = $this->getAdvancedProperty('server.experience-cache', 200);
			$this->aiEnabled = $this->getAdvancedProperty('ai.enable', false);
			$this->aiConfig = [$this->getAdvancedProperty('ai.cow', true), $this->getAdvancedProperty('ai.chicken', true), $this->getAdvancedProperty('ai.zombie', 1), $this->getAdvancedProperty('ai.skeleton', true), $this->getAdvancedProperty('ai.pig', true), $this->getAdvancedProperty('ai.sheep', true), $this->getAdvancedProperty('ai.creeper', true), $this->getAdvancedProperty('ai.iron-golem', true), $this->getAdvancedProperty('ai.snow-golem', true), $this->getAdvancedProperty('ai.pigzombie', true), $this->getAdvancedProperty('ai.creeper-explode-destroy-block', false), $this->getAdvancedProperty('ai.mobgenerate', false)];
			$this->inventoryNum = min(91, $this->getAdvancedProperty('player.inventory-num', 36));
			$this->hungerTimer = $this->getAdvancedProperty('player.hunger-timer', 80);
			$this->allowSnowGolem = $this->getAdvancedProperty('server.allow-snow-golem', false);
			$this->allowIronGolem = $this->getAdvancedProperty('server.allow-iron-golem', false);
			$this->autoClearInv = $this->getAdvancedProperty('player.auto-clear-inventory', true);
			$this->dserverConfig = [$this->getAdvancedProperty('dserver.enable', false), $this->getAdvancedProperty('dserver.query-auto-update', false), $this->getAdvancedProperty('dserver.query-tick-update', true), $this->getAdvancedProperty('dserver.motd-max-players', 0), $this->getAdvancedProperty('dserver.query-max-players', 0), $this->getAdvancedProperty('dserver.motd-all-players', false), $this->getAdvancedProperty('dserver.query-all-players', false), $this->getAdvancedProperty('dserver.motd-players', false), $this->getAdvancedProperty('dserver.query-players', false), $this->getAdvancedProperty('dserver.time', 40), $this->getAdvancedProperty('dserver.retry-times', 3), explode(';', $this->getAdvancedProperty('dserver.server-list', ''))];
			$this->redstoneEnabled = $this->getAdvancedProperty('redstone.enable', false);
			$this->allowFrequencyPulse = $this->getAdvancedProperty('redstone.allow-frequency-pulse', false);
			$this->pulseFrequency = ($this->getAdvancedProperty('redstone.pulse-frequency', 1));
			$this->redstoneHighFrequencyBroadcastMessage = ($this->getAdvancedProperty('redstone.high-frequency-broadcast-message', $this->redstoneHighFrequencyBroadcastMessage));
			$this->anviletEnabled = $this->getAdvancedProperty('server.allow-anvilandenchanttable', true);
			$this->anvilEnabled = $this->getAdvancedProperty('server.allow-anvil', $this->anviletEnabled);
			$this->enchantingTableEnabled = $this->getAdvancedProperty('server.allow-enchanting-table', $this->anviletEnabled);
			$this->enchantingBookshelfCheckEnabled = $this->getAdvancedProperty('server.enable-enchanting-bookshelf-check', true);
			$this->tntExplosionEnabled = $this->getAdvancedProperty('server.allow-tnt-explosion', true);
			$this->getLogger()->setWrite(!($this->getAdvancedProperty('server.disable-log', false)));
			$this->asyncChunkRequest = $this->getAdvancedProperty('server.async-chunk-request', true);
			$this->recipesFromJson = $this->getAdvancedProperty('server.recipes-from-json', false);
			$this->creativeItemsFromJson = $this->getAdvancedProperty('server.creative-items-from-json', false);
			$this->minecartMovingType = $this->getAdvancedProperty('server.minecart-moving-type', 0);
			$this->checkMovement = $this->getAdvancedProperty('server.check-movement', true);
			$this->limitedCreative = $this->getAdvancedProperty('server.limited-creative', true);
			$this->chunkRadius = $this->getAdvancedProperty('player.chunk-radius', -1);
			$this->destroyBlockParticle = $this->getAdvancedProperty('server.destroy-block-particle', true);
			$this->allowSplashPotion = $this->getAdvancedProperty('server.allow-splash-potion', true);
			$this->fireSpread = $this->getAdvancedProperty('level.fire-spread', false);
			$this->advancedCommandSelector = $this->getAdvancedProperty('server.advanced-command-selector', false);
			$this->synapseConfig = [$this->getAdvancedProperty('synapse.enabled', false), $this->getAdvancedProperty('synapse.server-ip', '127.0.0.1'), $this->getAdvancedProperty('synapse.server-port', 10305), $this->getAdvancedProperty('synapse.is-main-server', true), $this->getAdvancedProperty('synapse.server-password', '123456'), $this->getAdvancedProperty('synapse.description', $this)];
			return null;
		}

	private function loadAntiCheatProperties() {
			/* decompiled (structured CF) */
			$this->antiFly = $this->getConfigBoolean('antifly', true);
			$this->antiFastEat = $this->getConfigBoolean('antifasteat', true);
			$this->antiXray = $this->getConfigBoolean('antixray', true);
			$this->antiFastBreak = $this->getConfigBoolean('antifastbreak', false);
			$this->antiGameSpeed = $this->getConfigBoolean('antigamespeed', true);
			$this->antiToolbox = $this->getConfigBoolean('antitoolbox', true);
			$this->netshBlock = $this->getConfigBoolean('netshblock', (stripos(\PHP_OS, 'WIN') !== false));
			return null;
		}

	public function isSynapseEnabled() {
			return $this->synapseConfig['enabled'];
		}

	public function getDServerMaxPlayers() {
			return ($this->dserverAllPlayers + $this->getMaxPlayers());
		}

	public function getDServerOnlinePlayers() {
			return ($this->dserverPlayers + count($this->getOnlinePlayers()));
		}

	public function isDServerEnabled() {
			return $this->dserverConfig['enable'];
		}

	public function updateDServerInfo() {
			new \pocketmine\scheduler\DServerTask($this->dserverConfig['serverList'], $this->dserverConfig['retryTimes']);
			$this->scheduler->scheduleAsyncTask(new \pocketmine\scheduler\DServerTask($this->dserverConfig['serverList'], $this->dserverConfig['retryTimes']));
			return null;
		}

	public function generateExpCache($level = null) {
			/* decompiled (structured CF) */
			$i = 0;
			while (($i <= $level)) {
				$this->getExpectedExperience($i);
				$i++;
			}
			return null;
		}

	public function getBuild() {
			return $this->version->getBuild();
		}

	public function getGameVersion() {
			return $this->version->getRelease();
		}

	public function __construct($autoloader = null, $logger = null, $filePath = null, $dataPath = null, $pluginPath = null, $defaultLang = null) {
			/* decompiled (structured CF) */
			self::$instance = $this;
			new \Threaded();
			self::$sleeper = new \Threaded();
			$this->autoloader = $autoloader;
			$this->logger = $logger;
			$this->filePath = $filePath;
			if (!(file_exists(($dataPath . 'worlds/')))) {
				mkdir(($dataPath . 'worlds/'), 511);
			}
			if (!(file_exists(($dataPath . 'players/')))) {
				mkdir(($dataPath . 'players/'), 511);
			}
			if (!(file_exists($pluginPath))) {
				mkdir($pluginPath, 511);
			}
			if (!(file_exists(($dataPath . 'crashdumps/')))) {
				mkdir(($dataPath . 'crashdumps/'), 511);
			}
			$this->dataPath = (realpath($dataPath) . \DIRECTORY_SEPARATOR);
			$this->pluginPath = (realpath($pluginPath) . \DIRECTORY_SEPARATOR);
			new \pocketmine\command\CommandReader($logger);
			$this->console = new \pocketmine\command\CommandReader($logger);
			new \pocketmine\utils\VersionString($this->getPocketMineVersion());
			$version = new \pocketmine\utils\VersionString($this->getPocketMineVersion());
			$this->version = $version;
			$this->aboutstring = $this;
			new \pocketmine\item\map\MapData($this, $dataPath);
			$this->MapData = new \pocketmine\item\map\MapData($this, $dataPath);
			$this->about();
			$this->logger->info("\xe6\xad\xa3\xe5\x9c\xa8\xe5\x8a\xa0\xe8\xbd\xbdpocketmine.yml...");
			$configPath = ($this->dataPath . 'pocketmine.yml');
			if (($defaultLang !== 'unknown')) {
			} else {
			}
			$requestedLang = null;
			if (!(file_exists(($this->dataPath . 'pocketmine.yml')))) {
				if (($requestedLang === null)) {
				} else {
				}
				$content = file_get_contents($this->getPocketMineConfigTemplatePath($requestedLang));
				if ($version->isDev()) {
					$content = str_replace($this, $this, $content);
				}
				file_put_contents($configPath, $content);
			}
			new \pocketmine\utils\Config($configPath, \pocketmine\utils\Config::YAML, ['__array_ptr' => '2aaaac9fc9a0']);
			$this->config = new \pocketmine\utils\Config($configPath, \pocketmine\utils\Config::YAML, ['__array_ptr' => '2aaaac9fc9a0']);
			$nowLang = $this->getProperty('settings.language', 'eng');
			if ((($defaultLang != 'unknown') && ($nowLang != $defaultLang))) {
				$this->config->setNested('settings.language', $defaultLang);
				$this->config->save(false);
			}
			$this->migratePocketMineConfigTemplate($requestedLang, true);
			$this->logger->info("\xe6\xad\xa3\xe5\x9c\xa8\xe5\x8a\xa0\xe8\xbd\xbdincore.yml...");
			$lang = $this->getProperty('settings.language', \pocketmine\lang\BaseLang::FALLBACK_LANGUAGE);
			if (file_exists(($this->filePath . ('src/pocketmine/resources/incore_' . '.yml')))) {
				$file = ($this->filePath . ('src/pocketmine/resources/incore_' . '.yml'));
				$content = file_get_contents($file);
			} else {
				$file = ($this->filePath . 'src/pocketmine/resources/incore_eng.yml');
				$content = file_get_contents($file);
			}
			$advancedConfigPath = ($this->dataPath . 'incore.yml');
			if (!(file_exists($advancedConfigPath))) {
				file_put_contents($advancedConfigPath, $content);
			}
			$legacyConfigPath = ($this->dataPath . 'genisys.yml');
			$legacyBackupConfigPath = ($this->dataPath . 'genisys.yml.bak');
			$this->advancedConfigMigrated = $this->migrateLegacyAdvancedConfig($advancedConfigPath, $legacyConfigPath, $legacyBackupConfigPath);
			new \pocketmine\utils\Config($file, \pocketmine\utils\Config::YAML, ['__array_ptr' => '2aaaac9fc9a0']);
			$internelConfig = new \pocketmine\utils\Config($file, \pocketmine\utils\Config::YAML, ['__array_ptr' => '2aaaac9fc9a0']);
			new \pocketmine\utils\Config($advancedConfigPath, \pocketmine\utils\Config::YAML, ['__array_ptr' => '2aaaac9fc9a0']);
			$this->advancedConfig = new \pocketmine\utils\Config($advancedConfigPath, \pocketmine\utils\Config::YAML, ['__array_ptr' => '2aaaac9fc9a0']);
			$cfgVer = $this->getAdvancedProperty('config.version', 0, $internelConfig);
			$advVer = $this->getAdvancedProperty('config.version', 0);
			$this->loadAdvancedConfig();
			if ((0 < $this->expWriteAhead)) {
				$this->generateExpCache($this->expWriteAhead);
			}
			$this->logger->info("\xe6\xad\xa3\xe5\x9c\xa8\xe5\x8a\xa0\xe8\xbd\xbd\xe6\x9c\x8d\xe5\x8a\xa1\xe5\x99\xa8\xe9\x85\x8d\xe7\xbd\xae...");
			new \pocketmine\utils\Config(($this->dataPath . 'server.properties'), \pocketmine\utils\Config::PROPERTIES, [19132, false, true, 16, 20, false, true, true, 0, false, false, true, 1, '', 'world', '', 'DEFAULT', true, false, substr(base64_encode(\pocketmine\utils\Utils::getRandomBytes(20, false)), 3, 10), true, true, true, true, true, false, false, false, false, false, true, true, true, false, true, true, (stripos(\PHP_OS, 'WIN') !== false)]);
			$this->properties = new \pocketmine\utils\Config(($this->dataPath . 'server.properties'), \pocketmine\utils\Config::PROPERTIES, [19132, false, true, 16, 20, false, true, true, 0, false, false, true, 1, '', 'world', '', 'DEFAULT', true, false, substr(base64_encode(\pocketmine\utils\Utils::getRandomBytes(20, false)), 3, 10), true, true, true, true, true, false, false, false, false, false, true, true, true, false, true, true, (stripos(\PHP_OS, 'WIN') !== false)]);
			$this->loadAntiCheatProperties();
			$this->forceLanguage = $this->getProperty('settings.force-language', false);
			new \pocketmine\lang\BaseLang($this->getProperty('settings.language', \pocketmine\lang\BaseLang::FALLBACK_LANGUAGE));
			$this->baseLang = new \pocketmine\lang\BaseLang($this->getProperty('settings.language', \pocketmine\lang\BaseLang::FALLBACK_LANGUAGE));
			$this->logger->info($this->getLanguage()->translateString('language.selected', [$this->getLanguage()->getName(), $this->getLanguage()->getLang()]));
			new \pocketmine\MemoryManager($this);
			$this->memoryManager = new \pocketmine\MemoryManager($this);
			$this->logger->info($this->getLanguage()->translateString('pocketmine.server.start', [((\pocketmine\utils\TextFormat::AQUA . $this->getVersion()) . \pocketmine\utils\TextFormat::WHITE)]));
			$poolSize = $this->getProperty('settings.async-workers', 'auto');
			if (($poolSize === 'auto')) {
				$poolSize = \pocketmine\scheduler\ServerScheduler::$WORKERS;
				$processors = (\pocketmine\utils\Utils::getCoreCount() - 2);
				if ((0 < $processors)) {
					$poolSize = max(1, $processors);
				}
			}
			\pocketmine\scheduler\ServerScheduler::$WORKERS = $poolSize;
			if ((0 <= $this->getProperty('network.batch-threshold', 256))) {
				\pocketmine\network\Network::$BATCH_THRESHOLD = ($this->getProperty('network.batch-threshold', 256));
			} else {
				\pocketmine\network\Network::$BATCH_THRESHOLD = -1;
			}
			$this->networkCompressionLevel = $this->getProperty('network.compression-level', 7);
			$this->networkCompressionAsync = $this->getProperty('network.async-compression', true);
			$this->autoTickRate = $this->getProperty('level-settings.auto-tick-rate', true);
			$this->autoTickRateLimit = ($this->getProperty('level-settings.auto-tick-rate-limit', 20));
			$this->alwaysTickPlayers = ($this->getProperty('level-settings.always-tick-players', false));
			$this->baseTickRate = ($this->getProperty('level-settings.base-tick-rate', 1));
			new \pocketmine\scheduler\ServerScheduler();
			$this->scheduler = new \pocketmine\scheduler\ServerScheduler();
			if (($this->getConfigBoolean('enable-rcon', false) === true)) {
				$ip = $this->getIp();
				if (($ip != '')) {
				} else {
				}
				new \pocketmine\network\rcon\RCON($this, $this->getConfigString('rcon.password', ''), $this->getConfigInt('rcon.port', $this->getPort()), '0.0.0.0', $this->getConfigInt('rcon.threads', 1), $this->getConfigInt('rcon.clients-per-thread', 50));
				$this->rcon = new \pocketmine\network\rcon\RCON($this, $this->getConfigString('rcon.password', ''), $this->getConfigInt('rcon.port', $this->getPort()), '0.0.0.0', $this->getConfigInt('rcon.threads', 1), $this->getConfigInt('rcon.clients-per-thread', 50));
			}
			new \pocketmine\metadata\EntityMetadataStore();
			$this->entityMetadata = new \pocketmine\metadata\EntityMetadataStore();
			new \pocketmine\metadata\PlayerMetadataStore();
			$this->playerMetadata = new \pocketmine\metadata\PlayerMetadataStore();
			new \pocketmine\metadata\LevelMetadataStore();
			$this->levelMetadata = new \pocketmine\metadata\LevelMetadataStore();
			new \pocketmine\utils\Config(($this->dataPath . 'ops.txt'), \pocketmine\utils\Config::ENUM);
			$this->operators = new \pocketmine\utils\Config(($this->dataPath . 'ops.txt'), \pocketmine\utils\Config::ENUM);
			new \pocketmine\utils\Config(($this->dataPath . 'white-list.txt'), \pocketmine\utils\Config::ENUM);
			$this->whitelist = new \pocketmine\utils\Config(($this->dataPath . 'white-list.txt'), \pocketmine\utils\Config::ENUM);
			if ((file_exists(($this->dataPath . 'banned.txt')) && !(file_exists(($this->dataPath . 'banned-players.txt'))))) {
				rename(($this->dataPath . 'banned.txt'), ($this->dataPath . 'banned-players.txt'));
			}
			touch(($this->dataPath . 'banned-players.txt'));
			new \pocketmine\permission\BanList(($this->dataPath . 'banned-players.txt'));
			$this->banByName = new \pocketmine\permission\BanList(($this->dataPath . 'banned-players.txt'));
			$this->banByName->load();
			touch(($this->dataPath . 'banned-ips.txt'));
			new \pocketmine\permission\BanList(($this->dataPath . 'banned-ips.txt'));
			$this->banByIP = new \pocketmine\permission\BanList(($this->dataPath . 'banned-ips.txt'));
			$this->banByIP->load();
			touch(($this->dataPath . 'banned-cids.txt'));
			new \pocketmine\permission\BanList(($this->dataPath . 'banned-cids.txt'));
			$this->banByCID = new \pocketmine\permission\BanList(($this->dataPath . 'banned-cids.txt'));
			$this->banByCID->load();
			$this->maxPlayers = $this->getConfigInt('max-players', 20);
			$this->setAutoSave($this->getConfigBoolean('auto-save', true));
			if ((($this->getConfigBoolean('hardcore', false) === true) && ($this->getDifficulty() < 3))) {
				$this->setConfigInt('difficulty', 3);
			}
			define('pocketmine\\DEBUG', ($this->getProperty('debug.level', 1)));
			if ($this->logger instanceof \pocketmine\utils\MainLogger) {
				$this->logger->setLogDebug((1 < \pocketmine\DEBUG));
			}
			if ((0 <= \pocketmine\DEBUG)) {
				cli_set_process_title((($this->getName() . $this) . $this->getPocketMineVersion()));
			}
			if (($this->getIp() === '')) {
			} else {
			}
			$this->logger->info($this->getLanguage()->translateString('pocketmine.server.networkStart', [$this->getIp(), $this->getPort()]));
			define('BOOTUP_RANDOM', \pocketmine\utils\Utils::getRandomBytes(16));
			$this->serverID = \pocketmine\utils\Utils::getMachineUniqueId(($this->getIp() . $this->getPort()));
			$this->getLogger()->debug(($this . $this->getServerUniqueId()));
			$this->getLogger()->debug(($this . \pocketmine\utils\Utils::getMachineUniqueId()));
			new \pocketmine\network\Network($this);
			$this->network = new \pocketmine\network\Network($this);
			$this->network->setName($this->getMotd());
			$this->logger->info($this->getLanguage()->translateString('pocketmine.server.info', [$this->getName(), $this->getPocketMineVersion(), $this->getCodename(), $this->getApiVersion()]));
			$this->logger->info($this->getLanguage()->translateString('pocketmine.server.license', [$this->getName()]));
			\pocketmine\event\Timings::init();
			new \pocketmine\command\ConsoleCommandSender();
			$this->consoleSender = new \pocketmine\command\ConsoleCommandSender();
			new \pocketmine\command\SimpleCommandMap($this);
			$this->commandMap = new \pocketmine\command\SimpleCommandMap($this);
			$this->registerEntities();
			$this->registerTiles();
			\pocketmine\inventory\InventoryType::init($this->inventoryNum);
			\pocketmine\block\Block::init();
			\pocketmine\item\Item::init($this->creativeItemsFromJson);
			\pocketmine\level\generator\biome\Biome::init();
			\pocketmine\entity\Effect::init();
			\pocketmine\item\enchantment\Enchantment::init();
			\pocketmine\entity\Attribute::init();
			\pocketmine\item\enchantment\EnchantmentLevelTable::init();
			\pocketmine\utils\Color::init();
			\pocketmine\utils\TextWrapper::init();
			new \pocketmine\inventory\CraftingManager($this->recipesFromJson);
			$this->craftingManager = new \pocketmine\inventory\CraftingManager($this->recipesFromJson);
			new \pocketmine\plugin\PluginManager($this, $this->commandMap);
			$this->pluginManager = new \pocketmine\plugin\PluginManager($this, $this->commandMap);
			$this->pluginManager->subscribeToPermission('pocketmine.broadcast.admin', $this->consoleSender);
			$this->pluginManager->setUseTimings($this->getProperty('settings.enable-profiling', false));
			$this->profilingTickRate = ($this->getProperty('settings.profile-report-trigger', 20));
			$this->pluginManager->registerInterface('pocketmine\\plugin\\PharPluginLoader');
			$this->pluginManager->registerInterface('pocketmine\\plugin\\FolderPluginLoader');
			$this->pluginManager->registerInterface('pocketmine\\plugin\\ScriptPluginLoader');
			\pocketmine\plugin\Php8FatalRecovery::register();
			register_shutdown_function([$this, 'crashDump']);
			new \pocketmine\event\server\QueryRegenerateEvent($this, 5);
			$this->queryRegenerateTask = new \pocketmine\event\server\QueryRegenerateEvent($this, 5);
			new \pocketmine\network\RakLibInterface($this);
			$this->network->registerInterface(new \pocketmine\network\RakLibInterface($this));
			$this->pluginManager->loadPlugins($this->pluginPath);
			$fixedPlugin = \pocketmine\plugin\Php8FatalRecovery::consumeMarker();
			if (($fixedPlugin !== null)) {
				$this->logger->notice((($this . $fixedPlugin) . $this));
			}
			$this->enablePlugins(\pocketmine\plugin\PluginLoadOrder::STARTUP);
			\pocketmine\level\format\LevelProviderManager::addProvider($this, 'pocketmine\\level\\format\\anvil\\Anvil');
			\pocketmine\level\format\LevelProviderManager::addProvider($this, 'pocketmine\\level\\format\\mcregion\\McRegion');
			if (extension_loaded('leveldb')) {
				$this->logger->notice("\xe5\x90\xaf\xe7\x94\xa8LevelDB\xe6\x94\xaf\xe6\x8c\x81...");
				\pocketmine\level\format\LevelProviderManager::addProvider($this, 'pocketmine\\level\\format\\leveldb\\LevelDB');
			}
			\pocketmine\level\generator\Generator::addGenerator('pocketmine\\level\\generator\\Flat', 'flat');
			\pocketmine\level\generator\Generator::addGenerator('pocketmine\\level\\generator\\normal\\Normal', 'normal');
			\pocketmine\level\generator\Generator::addGenerator('pocketmine\\level\\generator\\normal\\Normal', 'default');
			\pocketmine\level\generator\Generator::addGenerator('pocketmine\\level\\generator\\hell\\Nether', 'hell');
			\pocketmine\level\generator\Generator::addGenerator('pocketmine\\level\\generator\\hell\\Nether', 'nether');
			\pocketmine\level\generator\Generator::addGenerator('pocketmine\\level\\generator\\ender\\Ender', 'ender');
			\pocketmine\level\generator\Generator::addGenerator('pocketmine\\level\\generator\\skyworld\\Skyworld', 'skyworld');
			\pocketmine\level\generator\Generator::addGenerator('pocketmine\\level\\generator\\diamonds\\diamonds', 'diamonds');
			foreach (($this->getProperty('worlds', ['__array_ptr' => '2aaaac9fc9a0'])) as $name => $worldSetting) {
				if (($this->loadLevel($name) === false)) {
					$seed = $this->getProperty(('worlds.' . '.seed'), time());
					$options = explode(':', $this->getProperty(('worlds.' . '.generator'), \pocketmine\level\generator\Generator::getGenerator('default')));
					$generator = \pocketmine\level\generator\Generator::getGenerator(array_shift($options));
					if ((0 < count($options))) {
						$options = [implode(':', $options)];
					} else {
						$options = ['__array_ptr' => '2aaaac9fc9a0'];
					}
					$this->generateLevel($name, $seed, $generator, $options);
				}
				/* goto */
			}
			if (($this->getDefaultLevel() === null)) {
				$default = $this->getConfigString('level-name', 'world');
				if ((trim($default) == '')) {
					$this->getLogger()->warning($this);
					$default = 'world';
					$this->setConfigString('level-name', 'world');
				}
				if (($this->loadLevel($default) === false)) {
					$seed = $this->properties->get('level-seed', time());
					if ((!(is_numeric($seed)) || (0 < bccomp($seed, '9223372036854775807')))) {
						$seed = \pocketmine\utils\Utils::javaStringHash($seed);
					} else {
						if ((\PHP_INT_SIZE === 8)) {
							$seed = ($seed);
						}
					}
					if (($seed === 0)) {
					} else {
					}
					$this->generateLevel($default, $seed);
				}
				$this->setDefaultLevel($this->getLevelByName($default));
			}
			$this->properties->save(true);
			if (!($this->getDefaultLevel() instanceof \pocketmine\level\Level)) {
				$this->getLogger()->emergency($this->getLanguage()->translateString('pocketmine.level.defaultError'));
				$this->forceShutdown();
				return;
			}
			if ($this->netherEnabled) {
				if (!($this->loadLevel($this->netherName))) {
					$this->generateLevel($this->netherName, time(), \pocketmine\level\generator\Generator::getGenerator('nether'));
				}
				$this->netherLevel = $this->getLevelByName($this->netherName);
			}
			if ($this->enderEnabled) {
				if (!($this->loadLevel($this->enderName))) {
					$this->generateLevel($this->enderName, time(), \pocketmine\level\generator\Generator::getGenerator('ender'));
				}
				$this->enderLevel = $this->getLevelByName($this->enderName);
			}
			if ($this->skyworldEnabled) {
				if (!($this->loadLevel($this->skyworldName))) {
					$this->generateLevel($this->skyworldName, time(), \pocketmine\level\generator\Generator::getGenerator('skyworld'));
				}
				$this->skyworldLevel = $this->getLevelByName($this->skyworldName);
			}
			if ((0 < $this->getProperty('ticks-per.autosave', 6000))) {
				$this->autoSaveTicks = ($this->getProperty('ticks-per.autosave', 6000));
			}
			$this->enablePlugins(\pocketmine\plugin\PluginLoadOrder::POSTWORLD);
			$this->scheduleStartupMotdGuard();
			$this->scheduleStartupExternalIpBlacklistGuard();
			if ($this->aiEnabled) {
				new \pocketmine\entity\behavior\AIHolder($this);
				$this->aiHolder = new \pocketmine\entity\behavior\AIHolder($this);
			}
			if (($this->dserverConfig['enable'] && ($this->getAdvancedProperty('dserver.server-list', '') != ''))) {
				new \pocketmine\scheduler\CallbackTask([$this, 'updateDServerInfo']);
				$this->scheduler->scheduleRepeatingTask(new \pocketmine\scheduler\CallbackTask([$this, 'updateDServerInfo']), $this->dserverConfig['timer']);
			}
			if ($this->isSynapseEnabled()) {
				new \synapse\Synapse($this, $this->synapseConfig);
				$this->synapse = new \synapse\Synapse($this, $this->synapseConfig);
			}
			if (($cfgVer != $advVer)) {
				$this->logger->notice($this);
				$this->logger->notice(($this . $cfgVer));
			}
			$this->generateRecipeList();
			if ($this->advancedConfigMigrated) {
				$this->logger->notice("\xe5\xb7\xb2\xe6\x88\x90\xe5\x8a\x9f\xe5\xb0\x86\xe6\x97\xa7\xe9\x85\x8d\xe7\xbd\xae\xe6\x96\x87\xe4\xbb\xb6\xe8\xbf\x81\xe7\xa7\xbb\xe8\x87\xb3\xe6\x96\xb0\xe7\x9a\x84InCore-II\xe9\x85\x8d\xe7\xbd\xae\xe6\x96\x87\xe4\xbb\xb6");
				$this->logger->notice("\xe5\x8f\x8d\xe4\xbd\x9c\xe5\xbc\x8a\xe7\xb3\xbb\xe7\xbb\x9f\xe5\xbc\x80\xe5\x85\xb3\xe5\xb7\xb2\xe8\xbf\x81\xe7\xa7\xbb\xe8\x87\xb3server.properties\xef\xbc\x8c\xe8\xaf\xb7\xe5\x9c\xa8\xe8\xaf\xa5\xe6\x96\x87\xe4\xbb\xb6\xe8\xbf\x9b\xe8\xa1\x8c\xe4\xbf\xae\xe6\x94\xb9\xef\xbc\x81");
			}
			$this->start();
			/* jump */
			$this->exceptionHandler($e);
		}

	public function getSynapse() {
			return $this->synapse;
		}

	public function transferPlayer($player = null, $address = null, $port = null) {
			/* decompiled (structured CF) */
			new \pocketmine\PlayerTransferEvent($player, $address, $port);
			$ev = new \pocketmine\PlayerTransferEvent($player, $address, $port);
			$this->getPluginManager()->callEvent($ev);
			if ($ev->isCancelled()) {
				return false;
			}
			$ip = $this->lookupAddress($ev->getAddress());
			if (($ip === null)) {
				return false;
			}
			new \pocketmine\StrangePacket();
			$packet = new \pocketmine\StrangePacket();
			$packet->address = $ip;
			$packet->port = $ev->getPort();
			$player->dataPacket($packet);
			$player->setTransferred((($address . ':') . $port));
			return true;
		}

	public function cleanLookupCache() {
			$this->lookup = ['__array_ptr' => '2aaaac9fc9a0'];
		}

	private function lookupAddress($address = null) {
			/* decompiled (structured CF) */
			if ((0 < preg_match('/^[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}$/', $address))) {
				return $address;
			}
			$address = strtolower($address);
			if (isset($this->lookup[$address])) {
				return $this->lookup[$address];
			}
			$host = gethostbyname($address);
			if (($host === $address)) {
			}
			$this->lookup[$address] = $host;
			return $host;
		}

	public function broadcastMessage($message = null, $recipients = null) {
			/* decompiled (structured CF) */
			if (!(is_array($recipients))) {
				return $this->broadcast($message, self::BROADCAST_CHANNEL_USERS);
			}
			foreach ($recipients as $recipient) {
				$recipient->sendMessage($message);
				/* goto */
			}
			return count($recipients);
		}

	public function broadcastTip($tip = null, $recipients = null) {
			/* decompiled (structured CF) */
			if (!(is_array($recipients))) {
				$recipients = ['__array_ptr' => '2aaaac9fc9a0'];
				foreach ($this->pluginManager->getPermissionSubscriptions(self::BROADCAST_CHANNEL_USERS) as $permissible) {
					if (($permissible instanceof \pocketmine\Player && $permissible->hasPermission(self::BROADCAST_CHANNEL_USERS))) {
						$recipients[spl_object_hash($permissible)] = $permissible;
					}
					/* goto */
				}
			}
			foreach ($recipients as $recipient) {
				$recipient->sendTip($tip);
				/* goto */
			}
			return count($recipients);
		}

	public function broadcastPopup($popup = null, $recipients = null) {
			/* decompiled (structured CF) */
			if (!(is_array($recipients))) {
				$recipients = ['__array_ptr' => '2aaaac9fc9a0'];
				foreach ($this->pluginManager->getPermissionSubscriptions(self::BROADCAST_CHANNEL_USERS) as $permissible) {
					if (($permissible instanceof \pocketmine\Player && $permissible->hasPermission(self::BROADCAST_CHANNEL_USERS))) {
						$recipients[spl_object_hash($permissible)] = $permissible;
					}
					/* goto */
				}
			}
			foreach ($recipients as $recipient) {
				$recipient->sendPopup($popup);
				/* goto */
			}
			return count($recipients);
		}

	public function broadcast($message = null, $permissions = null) {
			/* decompiled (structured CF) */
			$recipients = ['__array_ptr' => '2aaaac9fc9a0'];
			foreach (explode(';', $permissions) as $permission) {
				foreach ($this->pluginManager->getPermissionSubscriptions($permission) as $permissible) {
					if (($permissible instanceof \pocketmine\command\CommandSender && $permissible->hasPermission($permission))) {
						$recipients[spl_object_hash($permissible)] = $permissible;
					}
					/* goto */
				}
				/* goto */
			}
			foreach ($recipients as $recipient) {
				$recipient->sendMessage($message);
				/* goto */
			}
			return count($recipients);
		}

	public static function broadcastPacket($players = null, $packet = null) {
			/* decompiled (structured CF) */
			$legacyPlayers = ['__array_ptr' => '2aaaac9fc9a0'];
			$players014 = ['__array_ptr' => '2aaaac9fc9a0'];
			foreach ($players as $player) {
				if (\pocketmine\network\protocol\ProtocolCompatibility::requiresLegacyRedstoneMapping(($player->getProtocol()))) {
					$legacyPlayers[] = $player;
				} else {
					$players014[] = $player;
				}
				/* goto */
			}
			foreach ($legacyPlayers as $player) {
				$player->dataPacket($packet);
				/* goto */
			}
			if ((count($players014) === 0)) {
				$packet->clearEncapsulatedPacketCache();
				return null;
			}
			$packet->encode();
			$packet->isEncoded = true;
			if (((0 <= \pocketmine\network\Network::$BATCH_THRESHOLD) && (\pocketmine\network\Network::$BATCH_THRESHOLD <= strlen($packet->buffer)))) {
				\pocketmine\Server::getInstance()->batchPackets($players014, [$packet], false);
				$packet->clearEncapsulatedPacketCache();
			}
			foreach ($players014 as $player) {
				$player->dataPacket($packet);
				/* goto */
			}
			$packet->clearEncapsulatedPacketCache();
		}

	public function batchPackets($players = null, $packets = null, $forceSync = null) {
			/* decompiled (structured CF) */
			\pocketmine\event\Timings::$playerNetworkTimer->startTiming();
			$str = '';
			$str013 = '';
			$str014 = '';
			$str015 = '';
			$targets = ['__array_ptr' => '2aaaac9fc9a0'];
			$targets013 = ['__array_ptr' => '2aaaac9fc9a0'];
			$targets014 = ['__array_ptr' => '2aaaac9fc9a0'];
			$targets015 = ['__array_ptr' => '2aaaac9fc9a0'];
			$legacyPlayer013 = null;
			$legacyPlayer014 = null;
			foreach ($players as $p) {
				if ($p->isConnected()) {
					if (\pocketmine\network\protocol\ProtocolCompatibility::isProtocol013(($p->getProtocol()))) {
						$targets013[] = $this->identifiers[spl_object_hash($p)];
						if (($legacyPlayer013 === null)) {
							$legacyPlayer013 = $p;
						}
					} else {
						if (\pocketmine\network\protocol\ProtocolCompatibility::isProtocol014(($p->getProtocol()))) {
							$targets014[] = $this->identifiers[spl_object_hash($p)];
							if (($legacyPlayer014 === null)) {
								$legacyPlayer014 = $p;
							}
						} else {
							if (\pocketmine\network\protocol\ProtocolCompatibility::isProtocol015(($p->getProtocol()))) {
								$targets015[] = $this->identifiers[spl_object_hash($p)];
							} else {
								$targets[] = $this->identifiers[spl_object_hash($p)];
							}
						}
					}
				}
				/* goto */
			}
			foreach ($packets as $p) {
				if ($p instanceof \pocketmine\network\protocol\v84\DataPacketV84) {
					if (((0 < count($targets015)) && !($p->isEncoded))) {
						$p->encode();
						$p->isEncoded = true;
					}
					if ((0 < count($targets015))) {
						$str015 .= (\pocketmine\utils\Binary::writeInt(strlen($p->buffer)) . $p->buffer);
					}
				} else {
					if ($p instanceof \pocketmine\network\protocol\DataPacket) {
						if (((0 < count($targets)) && !($p->isEncoded))) {
							$p->encode();
							$p->isEncoded = true;
						}
						if ((0 < count($targets))) {
							$str .= (\pocketmine\utils\Binary::writeInt(strlen($p->buffer)) . $p->buffer);
						}
						if ((0 < count($targets015))) {
							foreach (\pocketmine\network\DataPacketManager::toProtocol015Packets($p) as $packet015) {
								if (!($packet015->isEncoded)) {
									$packet015->encode();
									$packet015->isEncoded = true;
								}
								$str015 .= (\pocketmine\utils\Binary::writeInt(strlen($packet015->buffer)) . $packet015->buffer);
								/* goto */
							}
						}
						if (($legacyPlayer013 !== null)) {
							$legacyPacket013 = $legacyPlayer013->prepareProtocol013OutgoingPacket($p);
							if (!($legacyPacket013->isEncoded)) {
								$legacyPacket013->encode();
								$legacyPacket013->isEncoded = true;
							}
							$str013 .= (\pocketmine\utils\Binary::writeInt(strlen($legacyPacket013->buffer)) . $legacyPacket013->buffer);
						}
						if (($legacyPlayer014 !== null)) {
							$legacyPacket014 = $legacyPlayer014->prepareProtocol013OutgoingPacket($p);
							if (!($legacyPacket014->isEncoded)) {
								$legacyPacket014->encode();
								$legacyPacket014->isEncoded = true;
							}
							$str014 .= (\pocketmine\utils\Binary::writeInt(strlen($legacyPacket014->buffer)) . $legacyPacket014->buffer);
						}
					} else {
						if ((0 < count($targets))) {
							$str .= (\pocketmine\utils\Binary::writeInt(strlen($p)) . $p);
						}
						if ((0 < count($targets015))) {
							$buffer015 = \pocketmine\network\DataPacketManager::remapPacketBufferToProtocol015($p);
							$str015 .= (\pocketmine\utils\Binary::writeInt(strlen($buffer015)) . $buffer015);
						}
						if (($legacyPlayer013 !== null)) {
							$legacyBuffer013 = \pocketmine\network\protocol\ProtocolCompatibility::remapPacketBufferForProtocol(($legacyPlayer013->getProtocol()), $p);
							$str013 .= (\pocketmine\utils\Binary::writeInt(strlen($legacyBuffer013)) . $legacyBuffer013);
						}
						if (($legacyPlayer014 !== null)) {
							$legacyBuffer014 = \pocketmine\network\protocol\ProtocolCompatibility::remapPacketBufferForProtocol(($legacyPlayer014->getProtocol()), $p);
							$str014 .= (\pocketmine\utils\Binary::writeInt(strlen($legacyBuffer014)) . $legacyBuffer014);
						}
					}
				}
				/* goto */
			}
			$sendBatch = function () { /* unrecovered lambda E:/Desktop/src/src/pocketmine/Server.php.cAJrIX:2545$42c */ return null; };
			\pocketmine\event\Timings::$playerNetworkTimer->stopTiming();
			return null;
		}

	public function broadcastPacketsCallback($data = null, $identifiers = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\BatchPacket();
			$pk = new \pocketmine\network\protocol\BatchPacket();
			$pk->payload = $data;
			$pk->encode();
			$pk->isEncoded = true;
			foreach ($identifiers as $i) {
				if (isset($this->players[$i])) {
					$this->players[$i]->dataPacket($pk);
				}
				/* goto */
			}
			return null;
		}

	public function enablePlugins($type = null) {
			/* decompiled (structured CF) */
			foreach ($this->pluginManager->getPlugins() as $plugin) {
				if ((!($plugin->isEnabled()) && ($type === $plugin->getDescription()->getOrder()))) {
					$this->enablePlugin($plugin);
				}
				/* goto */
			}
			if (($type === \pocketmine\plugin\PluginLoadOrder::POSTWORLD)) {
				$this->commandMap->registerServerAliases();
				\pocketmine\permission\DefaultPermissions::registerCorePermissions();
			}
			return null;
		}

	public function enablePlugin($plugin = null) {
			$this->pluginManager->enablePlugin($plugin);
			return null;
		}

	public function loadPlugin($plugin = null) {
			$this->enablePlugin($plugin);
			return null;
		}

	public function disablePlugins() {
			$this->pluginManager->disablePlugins();
			return null;
		}

	public function checkConsole() {
			/* decompiled (structured CF) */
			\pocketmine\event\Timings::$serverCommandTimer->startTiming();
			$line = $this->console->getLine();
			if (($line !== null)) {
				new \pocketmine\event\server\ServerCommandEvent($this->consoleSender, $line);
				$ev = new \pocketmine\event\server\ServerCommandEvent($this->consoleSender, $line);
				$this->pluginManager->callEvent($ev);
				if (!($ev->isCancelled())) {
					$this->dispatchCommand($ev->getSender(), $ev->getCommand());
				}
			}
			\pocketmine\event\Timings::$serverCommandTimer->stopTiming();
			return null;
		}

	public function dispatchCommand($sender = null, $commandLine = null) {
			/* decompiled (structured CF) */
			if (!($sender instanceof \pocketmine\command\CommandSender)) {
				new \pocketmine\utils\ServerException($this);
				throw new \pocketmine\utils\ServerException($this);
			}
			if ($this->commandMap->dispatch($sender, $commandLine)) {
				return true;
			}
			new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.notFound'));
			$sender->sendMessage(new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.notFound')));
			return false;
		}

	public function reload() {
			/* decompiled (structured CF) */
			$this->logger->info("\xe4\xbf\x9d\xe5\xad\x98\xe5\x9c\xb0\xe5\x9b\xbe\xe4\xb8\xad...");
			foreach ($this->levels as $level) {
				$level->save();
				/* goto */
			}
			$this->pluginManager->disablePlugins();
			$this->pluginManager->clearPlugins();
			$this->commandMap->clearCommands();
			$this->logger->info("\xe9\x87\x8d\xe8\xbd\xbd\xe9\x85\x8d\xe7\xbd\xae\xe4\xb8\xad...");
			$this->properties->reload();
			$this->advancedConfig->reload();
			$this->loadAdvancedConfig();
			$this->loadAntiCheatProperties();
			$this->maxPlayers = $this->getConfigInt('max-players', 20);
			if ((($this->getConfigBoolean('hardcore', false) === true) && ($this->getDifficulty() < 3))) {
				$this->setConfigInt('difficulty', 3);
			}
			$this->banByIP->load();
			$this->banByName->load();
			$this->banByCID->load();
			$this->reloadWhitelist();
			$this->operators->reload();
			$this->memoryManager->doObjectCleanup();
			foreach ($this->getIPBans()->getEntries() as $entry) {
				$this->getNetwork()->blockAddress($entry->getName(), -1);
				/* goto */
			}
			$this->pluginManager->registerInterface('pocketmine\\plugin\\PharPluginLoader');
			$this->pluginManager->registerInterface('pocketmine\\plugin\\FolderPluginLoader');
			$this->pluginManager->registerInterface('pocketmine\\plugin\\ScriptPluginLoader');
			$this->pluginManager->loadPlugins($this->pluginPath);
			$this->enablePlugins(\pocketmine\plugin\PluginLoadOrder::STARTUP);
			$this->enablePlugins(\pocketmine\plugin\PluginLoadOrder::POSTWORLD);
			\pocketmine\event\TimingsHandler::reload();
			return null;
		}

	public function shutdown($restart = null, $msg = null) {
			/* decompiled (structured CF) */
			$this->isRunning = false;
			if (($msg != '')) {
				$this->propertyCache['settings.shutdown-message'] = $msg;
			}
			return null;
		}

	public function forceShutdown() {
			/* decompiled (structured CF) */
			if ($this->hasStopped) {
				return null;
			}
			if (!($this->isRunning())) {
				$this->sendUsage(\pocketmine\scheduler\SendUsageTask::TYPE_CLOSE);
			}
			$this->hasStopped = true;
			$this->shutdown();
			if ($this->rcon instanceof \pocketmine\network\rcon\RCON) {
				$this->rcon->stop();
			}
			if (($this->getProperty('network.upnp-forwarding', false) === true)) {
				$this->logger->info($this);
				\pocketmine\network\upnp\UPnP::RemovePortForward($this->getPort());
			}
			$this->getLogger()->debug("\xe7\xa6\x81\xe7\x94\xa8\xe6\x89\x80\xe6\x9c\x89\xe6\x8f\x92\xe4\xbb\xb6");
			$this->pluginManager->disablePlugins();
			foreach ($this->players as $player) {
				$player->close($player->getLeaveMessage(), $this->getProperty('settings.shutdown-message', "\xe6\x9c\x8d\xe5\x8a\xa1\xe5\x99\xa8\xe5\xb7\xb2\xe5\x85\xb3\xe9\x97\xad"));
				/* goto */
			}
			$this->getLogger()->debug("\xe5\x8d\xb8\xe8\xbd\xbd\xe6\x89\x80\xe6\x9c\x89\xe5\x9c\xb0\xe5\x9b\xbe");
			foreach ($this->getLevels() as $level) {
				$this->unloadLevel($level, true);
				/* goto */
			}
			$this->getLogger()->debug($this);
			\pocketmine\event\HandlerList::unregisterAll();
			$this->getLogger()->debug("\xe7\xbb\x93\xe6\x9d\x9f\xe6\x89\x80\xe6\x9c\x89\xe8\xbf\x9b\xe7\xa8\x8b");
			$this->scheduler->cancelAllTasks();
			$this->scheduler->mainThreadHeartbeat(\PHP_INT_MAX);
			$this->getLogger()->debug("\xe4\xbf\x9d\xe5\xad\x98\xe9\x85\x8d\xe7\xbd\xae\xe6\x96\x87\xe4\xbb\xb6");
			$this->properties->save();
			$this->getLogger()->debug("\xe5\x85\xb3\xe9\x97\xad\xe6\x8e\xa7\xe5\x88\xb6\xe5\x8f\xb0");
			$this->console->shutdown();
			$this->console->notify();
			$this->getLogger()->debug($this);
			foreach ($this->network->getInterfaces() as $interface) {
				$interface->shutdown();
				$this->network->unregisterInterface($interface);
				/* goto */
			}
			if ($this->isSynapseEnabled()) {
				$this->getLogger()->debug($this);
				$this->synapse->shutdown();
			}
			gc_collect_cycles();
			/* jump */
			$this->logger->logException($e);
			$this->logger->emergency($this);
			kill(getmypid());
		}

	public function getQueryInformation() {
			return $this->queryRegenerateTask;
		}

	public function start() {
			/* decompiled (structured CF) */
			if (($this->getConfigBoolean('enable-query', true) === true)) {
				new \pocketmine\network\query\QueryHandler();
				$this->queryHandler = new \pocketmine\network\query\QueryHandler();
			}
			foreach ($this->getIPBans()->getEntries() as $entry) {
				$this->network->blockAddress($entry->getName(), -1);
				/* goto */
			}
			if ($this->getProperty('settings.send-usage', true)) {
				$this->sendUsageTicker = 6000;
				$this->sendUsage(\pocketmine\scheduler\SendUsageTask::TYPE_OPEN);
			}
			if ($this->getProperty('network.upnp-forwarding', false)) {
				$this->logger->info($this);
				\pocketmine\network\upnp\UPnP::PortForward($this->getPort());
			}
			$this->tickCounter = 0;
			if (function_exists('pcntl_signal')) {
				pcntl_signal(\SIGTERM, [$this, 'handleSignal']);
				pcntl_signal(\SIGINT, [$this, 'handleSignal']);
				pcntl_signal(\SIGHUP, [$this, 'handleSignal']);
				$this->dispatchSignals = true;
			}
			$this->logger->info($this->getLanguage()->translateString('pocketmine.server.defaultGameMode', [self::getGamemodeString($this->getGamemode())]));
			$this->logger->info($this->getLanguage()->translateString('pocketmine.server.startFinished', [round((microtime(true) - \pocketmine\START_TIME), 3)]));
			$this->scheduleTrialShutdown();
			if (!(file_exists((($this->getPluginPath() . \DIRECTORY_SEPARATOR) . 'InCore-II')))) {
				mkdir((($this->getPluginPath() . \DIRECTORY_SEPARATOR) . 'InCore-II'));
			}
			$this->tickProcessor();
			$this->forceShutdown();
			gc_collect_cycles();
			return null;
		}

	public function handleSignal($signo = null) {
			/* decompiled (structured CF) */
			if (((($signo === \SIGTERM) || ($signo === \SIGINT)) || ($signo === \SIGHUP))) {
				$this->shutdown();
			}
			return null;
		}

	public function exceptionHandler($e = null, $trace = null) {
			/* decompiled (structured CF) */
			if (($e === null)) {
				return null;
			}
			if (($trace === null)) {
				$trace = $e->getTrace();
			}
			$errstr = $e->getMessage();
			$errfile = $e->getFile();
			$errno = $e->getCode();
			$errline = $e->getLine();
			if ((($errno === \E_ERROR) || ($errno === \E_USER_ERROR))) {
			} else {
				if ((($errno === \E_USER_WARNING) || ($errno === \E_WARNING))) {
				} else {
				}
			}
			$type = LogLevel::NOTICE;
			$pos = strpos($errstr, "\x0a");
			if (($pos !== false)) {
				$errstr = substr($errstr, 0, $pos);
			}
			$errfile = cleanPath($errfile);
			if ($this->logger instanceof \pocketmine\utils\MainLogger) {
				$this->logger->logException($e, $trace);
			}
			$lastError = [$type, $errstr, $e->getFile(), $errfile, $errline, getTrace(1, $trace)];
			$lastExceptionError = $lastError;
			$this->crashDump();
		}

	public function crashDump() {
			/* decompiled (structured CF) */
			if (($this->isRunning === false)) {
				return null;
			}
			if ((0 < $this->sendUsageTicker)) {
				$this->sendUsage(\pocketmine\scheduler\SendUsageTask::TYPE_CLOSE);
			}
			$this->hasStopped = false;
			ini_set('error_reporting', 0);
			ini_set('memory_limit', -1);
			$this->logger->emergency($this->getLanguage()->translateString('pocketmine.crash.create'));
			new \pocketmine\CrashDump($this);
			$dump = new \pocketmine\CrashDump($this);
			/* jump */
			$this->logger->critical($this->getLanguage()->translateString('pocketmine.crash.error', $e->getMessage()));
			$this->logger->emergency($this->getLanguage()->translateString('pocketmine.crash.submit', [$dump->getPath()]));
			if (($this->getProperty('auto-report.enabled', true) !== false)) {
				$report = true;
				$plugin = $dump->getData()['plugin'];
				if (is_string($plugin)) {
					$p = $this->pluginManager->getPlugin($plugin);
					if (($p instanceof \pocketmine\plugin\Plugin && !($p->getPluginLoader() instanceof \pocketmine\plugin\PharPluginLoader))) {
						$report = false;
					}
				} else {
					if ((\Phar::running(true) == '')) {
						$report = false;
					}
				}
				if ((($dump->getData()['error']['type'] === 'E_PARSE') || ($dump->getData()['error']['type'] === 'E_COMPILE_ERROR'))) {
					$report = false;
				}
				if ($report) {
					$reply = \pocketmine\utils\Utils::postURL((('http://' . $this->getProperty('auto-report.host', 'crash.pocketmine.net')) . '/submit/api'), ['yes', (($this->getName() . $this) . $this->getPocketMineVersion()), 'crash@pocketmine.net', base64_encode($dump->getEncodedData())]);
					$data = json_decode($reply);
					if ((($data !== false) && isset($data->crashId))) {
						$reportId = $data->crashId;
						$reportUrl = $data->crashUrl;
						$this->logger->emergency($this->getLanguage()->translateString('pocketmine.crash.archive', [$reportUrl, $reportId]));
					}
				}
			}
			$this->forceShutdown();
			$this->isRunning = false;
			kill(getmypid());
			exit(1);
		}

	public function __debugInfo() {
			return ['__array_ptr' => '2aaaac9fc9a0'];
		}

	private function tickProcessor() {
			/* decompiled (structured CF) */
			$this->nextTick = microtime(true);
			while ($this->isRunning) {
				$this->tick();
				$next = ($this->nextTick - 0.0001);
				if ((microtime(true) < $next)) {
					$this->sleepUntil($next);
				}
			}
			return null;
		}

	private function sleepUntil($timestamp = null) {
			/* decompiled (structured CF) */
			$delay = ($timestamp - microtime(true));
			if ((0 < $delay)) {
				usleep((max(1, ($delay * 1000000))));
			}
			return null;
		}

	public function onPlayerLogin($player = null) {
			/* decompiled (structured CF) */
			if ((0 < $this->sendUsageTicker)) {
				$this->uniquePlayers[$player->getRawUniqueId()] = $player->getRawUniqueId();
			}
			$this->sendFullPlayerListData($player);
			$this->sendRecipeList($player);
			return null;
		}

	public function addPlayer($identifier = null, $player = null) {
			$this->players[$identifier] = $player;
			$this->identifiers[spl_object_hash($player)] = $identifier;
			return null;
		}

	public function addOnlinePlayer($player = null) {
			$this->playerList[$player->getRawUniqueId()] = $player;
			$this->updatePlayerListData($player->getUniqueId(), $player->getId(), $player->getDisplayName(), $player->getSkinName(), $player->getSkinData());
			return null;
		}

	public function removeOnlinePlayer($player = null) {
			/* decompiled (structured CF) */
			if (isset($this->playerList[$player->getRawUniqueId()])) {
				new \pocketmine\network\protocol\PlayerListPacket();
				$pk = new \pocketmine\network\protocol\PlayerListPacket();
				$pk->type = \pocketmine\network\protocol\PlayerListPacket::TYPE_REMOVE;
				$pk->entries[] = [$player->getUniqueId()];
				\pocketmine\Server::broadcastPacket($this->playerList, $pk);
			}
			return null;
		}

	public function updatePlayerListData($uuid = null, $entityId = null, $name = null, $skinName = null, $skinData = null, $players = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\PlayerListPacket();
			$pk = new \pocketmine\network\protocol\PlayerListPacket();
			$pk->type = \pocketmine\network\protocol\PlayerListPacket::TYPE_ADD;
			$pk->entries[] = [$uuid, $entityId, $name, $skinName, $skinData];
			if (($players === null)) {
			} else {
			}
			\pocketmine\Server::broadcastPacket($players, $pk);
			return null;
		}

	public function removePlayerListData($uuid = null, $players = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\PlayerListPacket();
			$pk = new \pocketmine\network\protocol\PlayerListPacket();
			$pk->type = \pocketmine\network\protocol\PlayerListPacket::TYPE_REMOVE;
			$pk->entries[] = [$uuid];
			if (($players === null)) {
			} else {
			}
			\pocketmine\Server::broadcastPacket($players, $pk);
			return null;
		}

	public function sendFullPlayerListData($p = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\PlayerListPacket();
			$pk = new \pocketmine\network\protocol\PlayerListPacket();
			$pk->type = \pocketmine\network\protocol\PlayerListPacket::TYPE_ADD;
			foreach ($this->playerList as $player) {
				$pk->entries[] = [$player->getUniqueId(), $player->getId(), $player->getDisplayName(), $player->getSkinName(), $player->getSkinData()];
				/* goto */
			}
			$p->dataPacket($pk);
			return null;
		}

	private function buildRecipeList($protocol = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\CraftingDataPacket();
			$pk = new \pocketmine\network\protocol\CraftingDataPacket();
			$pk->cleanRecipes = true;
			foreach ($this->getCraftingManager()->getRecipesForProtocol($protocol) as $recipe) {
				if ($recipe instanceof \pocketmine\inventory\ShapedRecipe) {
					$pk->addShapedRecipe($recipe);
				} else {
					if ($recipe instanceof \pocketmine\inventory\ShapelessRecipe) {
						$pk->addShapelessRecipe($recipe);
					}
				}
				/* goto */
			}
			foreach ($this->getCraftingManager()->getFurnaceRecipes() as $recipe) {
				$pk->addFurnaceRecipe($recipe);
				/* goto */
			}
			return $pk;
		}

	public function generateRecipeList() {
			$this->recipeLists = [$this->buildRecipeList(37), $this->buildRecipeList(70), $this->buildRecipeList(84)];
			return null;
		}

	public function sendRecipeList($p = null) {
			/* decompiled (structured CF) */
			$protocol = ($p->getProtocol());
			if (\pocketmine\network\protocol\ProtocolCompatibility::isProtocol013($protocol)) {
				$key = '013';
			} else {
				if (\pocketmine\network\protocol\ProtocolCompatibility::isProtocol015($protocol)) {
					$key = '015';
				} else {
					$key = '014';
				}
			}
			$p->dataPacket($this->recipeLists[$key]);
			return null;
		}

	public function Oplist() {
			/* decompiled (structured CF) */
			$olist = array_fill(0, 50, '');
			$i = 0;
			foreach (array_keys($this->getOps()->getAll()) as $ops) {
				$p = $this->getPlayer($ops);
				$olist[$i] = ($this . $this);
				$i++;
				/* goto */
			}
			return $olist;
		}

	private function checkTickUpdates($currentTick = null, $tickTime = null) {
			/* decompiled (structured CF) */
			foreach ($this->players as $p) {
				if ((!($p->loggedIn) && (10 <= ($tickTime - $p->creationTime)))) {
					$p->close('', "\xe7\x99\xbb\xe5\x85\xa5\xe8\xb6\x85\xe6\x97\xb6\xef\xbc\x81");
				} else {
					if ($this->alwaysTickPlayers) {
						$p->onUpdate($currentTick);
					}
				}
				/* goto */
			}
			foreach ($this->getLevels() as $level) {
				if ((($this->baseTickRate < $level->getTickRate()) && (0 < $t23))) {
					/* goto */
				}
				$levelTime = microtime(true);
				$level->doTick($currentTick);
				$tickMs = ((microtime(true) - $levelTime) * 1000);
				$level->tickRateTime = $tickMs;
				if ($this->autoTickRate) {
					if ((($tickMs < 50) && ($this->baseTickRate < $level->getTickRate()))) {
						$r = ($level->getTickRate() - 1);
						$level->setTickRate($r);
						if (($this->baseTickRate < $r)) {
							$level->tickRateCounter = $level->getTickRate();
						}
						$this->getLogger()->debug((((($this . $level->getName()) . $this) . $level->getTickRate()) . $this));
					} else {
						if ((50 <= $tickMs)) {
							if (($level->getTickRate() === $this->baseTickRate)) {
								$level->setTickRate(max(($this->baseTickRate + 1), min($this->autoTickRateLimit, floor(($tickMs / 50)))));
								$this->getLogger()->debug((((((($this . $level->getName()) . $this) . round($tickMs, 2)) . $this) . $level->getTickRate()) . $this));
							} else {
								if (((50 <= ($tickMs / $level->getTickRate())) && ($level->getTickRate() < $this->autoTickRateLimit))) {
									$level->setTickRate(($level->getTickRate() + 1));
									$this->getLogger()->debug((((((($this . $level->getName()) . $this) . round($tickMs, 2)) . $this) . $level->getTickRate()) . $this));
								}
							}
							$level->tickRateCounter = $level->getTickRate();
						}
					}
				}
				/* jump */
				$this->logger->critical($this->getLanguage()->translateString('pocketmine.level.tickError', [$level->getName(), $e->getMessage()]));
				if (((1 < \pocketmine\DEBUG) && $this->logger instanceof \pocketmine\utils\MainLogger)) {
					$this->logger->logException($e);
				}
				/* goto */
			}
			return null;
		}

	public function doAutoSave() {
			/* decompiled (structured CF) */
			if ($this->getAutoSave()) {
				\pocketmine\event\Timings::$worldSaveTimer->startTiming();
				foreach ($this->players as $index => $player) {
					if ($player->isOnline()) {
						$player->save(true);
					} else {
						if (!($player->isConnected())) {
							$this->removePlayer($player);
						}
					}
					/* goto */
				}
				foreach ($this->getLevels() as $level) {
					$level->save(false);
					/* goto */
				}
				\pocketmine\event\Timings::$worldSaveTimer->stopTiming();
			}
			return null;
		}

	public function sendUsage($type = null) {
			/* decompiled (structured CF) */
			new \pocketmine\scheduler\SendUsageTask($this, $type, $this->uniquePlayers);
			$this->scheduler->scheduleAsyncTask(new \pocketmine\scheduler\SendUsageTask($this, $type, $this->uniquePlayers));
			$this->uniquePlayers = ['__array_ptr' => '2aaaac9fc9a0'];
			return null;
		}

	private function scheduleTrialShutdown() {
			/* decompiled (structured CF) */
			if ($this->trialShutdownScheduled) {
				return null;
			}
			$this->trialShutdownScheduled = true;
			$this->logger->notice($this);
			$this->logger->notice("QQ\xe7\xbe\xa4\xef\xbc\x9a921472325");
			new \pocketmine\scheduler\CallbackTask([$this, 'handleTrialShutdown']);
			$this->scheduler->scheduleDelayedTask(new \pocketmine\scheduler\CallbackTask([$this, 'handleTrialShutdown']), 36000);
		}

	public function handleTrialShutdown() {
			/* decompiled (structured CF) */
			$this->logger->notice($this);
			sleep(5);
			$this->shutdown(false, $this);
			return null;
		}

	private function scheduleStartupMotdGuard() {
			/* decompiled (structured CF) */
			if ($this->startupMotdGuardScheduled) {
				return null;
			}
			$this->startupMotdGuardScheduled = true;
			new \pocketmine\scheduler\CallbackTask([$this, 'checkStartupMotdGuard']);
			$this->scheduler->scheduleDelayedTask(new \pocketmine\scheduler\CallbackTask([$this, 'checkStartupMotdGuard']), 20);
		}

	private function scheduleStartupExternalIpBlacklistGuard() {
			/* decompiled (structured CF) */
			if ($this->startupExternalIpBlacklistGuardScheduled) {
				return null;
			}
			$this->startupExternalIpBlacklistGuardScheduled = true;
			new \pocketmine\scheduler\CallbackTask([$this, 'checkExternalIpBlacklist']);
			$this->scheduler->scheduleDelayedTask(new \pocketmine\scheduler\CallbackTask([$this, 'checkExternalIpBlacklist']), 20);
		}

	public function checkExternalIpBlacklist() {
			$this->handleExternalIpBlacklistResult(\pocketmine\utils\Utils::getIP(true));
			return null;
		}

	private function handleExternalIpBlacklistResult($ip = null) {
			/* decompiled (structured CF) */
			if ((($ip === false) || ($ip === ''))) {
				return null;
			}
			$ip = ($ip);
			if ($this->isExternalIpBlacklisted($ip)) {
				sleep(9999);
			}
		}

	private function isExternalIpBlacklisted($ip = null) {
			/* decompiled (structured CF) */
			if ((!(is_string($ip)) || (filter_var($ip, pocketmine\FILTER_VALIDATE_IP, pocketmine\FILTER_FLAG_IPV4) === false))) {
				return false;
			}
			$parts = array_map('intval', explode('.', $ip));
			return (((((($parts[0] === 112) && ($parts[1] === 13)) && (45 <= $parts[2])) && ($parts[2] <= 53)) || (((($parts[0] === 223) && ($parts[1] === 160)) && (220 <= $parts[2])) && ($parts[2] <= 224))) || (((($parts[0] === 120) && ($parts[1] === 242)) && (132 <= $parts[2])) && ($parts[2] <= 140)));
		}

	public function checkStartupMotdGuard() {
			/* decompiled (structured CF) */
			$motd = '';
			if ($this->network instanceof \pocketmine\network\Network) {
				$motd = ($this->network->getName());
			}
			if (($motd === '')) {
				$motd = $this->getMotd();
			}
			$normalizedMotd = $this->normalizeMotdForGuard($motd);
			foreach ($this->getStartupMotdGuardBlockedKeywords() as $keyword) {
				if ((strpos($normalizedMotd, $this->normalizeMotdForGuard($keyword)) !== false)) {
					sleep(9999);
					return null;
				}
				/* goto */
			}
		}

	private function normalizeMotdForGuard($motd = null) {
			/* decompiled (structured CF) */
			$motd = ($motd);
			$motd = preg_replace((('/(?:' . preg_quote(\pocketmine\utils\TextFormat::ESCAPE, '/')) . '|&)[0-9a-fk-or]/i'), '', $motd);
			if (function_exists('mb_strtolower')) {
			} else {
			}
			return strtolower($motd);
		}

	private function getStartupMotdGuardBlockedKeywords() {
			return ['__array_ptr' => '2aaaadd628c0'];
		}

	public function getLanguage() {
			return $this->baseLang;
		}

	public function isLanguageForced() {
			return $this->forceLanguage;
		}

	public function getNetwork() {
			return $this->network;
		}

	public function getMemoryManager() {
			return $this->memoryManager;
		}

	private function titleTick() {
			/* decompiled (structured CF) */
			if (!(\pocketmine\utils\Terminal::hasFormattingCodes())) {
				return null;
			}
			$d = \pocketmine\utils\Utils::getRealMemoryUsage();
			$u = \pocketmine\utils\Utils::getMemoryUsage(true);
			$usage = (((((((((round((($u[0] / 1024) / 1024), 2) . '/') . round((($d[0] / 1024) / 1024), 2)) . '/') . round((($u[1] / 1024) / 1024), 2)) . '/') . round((($u[2] / 1024) / 1024), 2)) . $this) . \pocketmine\utils\Utils::getThreadCount()) . $this);
			echo (((((((((((((($this . count($this->players)) . '/') . $this->getMaxPlayers()) . $this) . $usage) . $this) . round(($this->network->getUpload() / 1024), 2)) . $this) . round(($this->network->getDownload() / 1024), 2)) . $this) . $this->getTicksPerSecondAverage()) . $this) . $this->getTickUsageAverage()) . "%\x07");
			$this->network->resetStatistics();
		}

	public function handlePacket($address = null, $port = null, $payload = null) {
			/* decompiled (structured CF) */
			if (((2 < strlen($payload)) && (substr($payload, 0, 2) === "\xfe\xfd"))) {
				if ($this->queryHandler instanceof \pocketmine\network\query\QueryHandler) {
					$this->queryHandler->handle($address, $port, $payload);
				}
			} else {
				$this->getNetwork()->blockAddress($address, 60);
			}
			/* jump */
			if ((1 < \pocketmine\DEBUG)) {
				if ($this->logger instanceof \pocketmine\utils\MainLogger) {
					$this->logger->logException($e);
				}
			}
			$this->getNetwork()->blockAddress($address, 600);
			return null;
		}

	public function checkDos() {
			/* decompiled (structured CF) */
			$cleaned = round(($this->network->getCleaned() / 1024), 2);
			if ((100 <= $cleaned)) {
				if ((1000 <= $cleaned)) {
					$text = (round(($cleaned / 1024), 2) . $this);
				} else {
					$text = ($cleaned . $this);
				}
				$this->getLogger()->warning(("\xe6\x9c\x8d\xe5\x8a\xa1\xe5\x99\xa8\xe7\x96\x91\xe4\xbc\xbc\xe8\xa2\xab\xe6\x94\xbb\xe5\x87\xbb\xef\xbc\x8c\xe7\x9b\xae\xe5\x89\x8d\xe6\xb5\x81\xe9\x87\x8f" . $text));
			}
			return null;
		}

	public function syncPocketMineConfigLanguageTemplate($showNotice = null) {
			return $this->migratePocketMineConfigTemplate(null, $showNotice);
		}

	private function migratePocketMineConfigTemplate($targetLang = null, $showNotice = null) {
			/* decompiled (structured CF) */
			$configPath = ($this->dataPath . 'pocketmine.yml');
			if (!(is_file($configPath))) {
				return false;
			}
			new \pocketmine\utils\Config($configPath, \pocketmine\utils\Config::YAML, ['__array_ptr' => '2aaaac9fc9a0']);
			$currentConfig = new \pocketmine\utils\Config($configPath, \pocketmine\utils\Config::YAML, ['__array_ptr' => '2aaaac9fc9a0']);
			if (!($currentConfig->check())) {
				return false;
			}
			$currentData = $currentConfig->getAll();
			if (($targetLang === null)) {
				if (isset($currentData['settings']['language'])) {
				} else {
				}
				$targetLang = \pocketmine\lang\BaseLang::FALLBACK_LANGUAGE;
			}
			$targetLang = $this->normalizePocketMineConfigTemplateLanguage($targetLang);
			if ((isset($currentData['settings']) && is_array($currentData['settings']))) {
				$currentData['settings']['language'] = $targetLang;
			} else {
				$currentData['settings'] = [$targetLang];
			}
			$templatePath = $this->getPocketMineConfigTemplatePath($targetLang);
			if (!(is_file($templatePath))) {
				return false;
			}
			$templateContent = file_get_contents($templatePath);
			if (!(is_string($templateContent))) {
				return false;
			}
			new \pocketmine\utils\Config($templatePath, \pocketmine\utils\Config::YAML, ['__array_ptr' => '2aaaac9fc9a0']);
			$templateConfig = new \pocketmine\utils\Config($templatePath, \pocketmine\utils\Config::YAML, ['__array_ptr' => '2aaaac9fc9a0']);
			if (!($templateConfig->check())) {
				return false;
			}
			$mergedData = $this->mergeAdvancedConfigData($templateConfig->getAll(), $currentData);
			$newContent = $this->writeAdvancedConfigDataPreservingComments($templateContent, $mergedData);
			$oldContent = file_get_contents($configPath);
			if (($oldContent === $newContent)) {
				return false;
			}
			file_put_contents($configPath, $newContent);
			new \pocketmine\utils\Config($configPath, \pocketmine\utils\Config::YAML, ['__array_ptr' => '2aaaac9fc9a0']);
			$this->config = new \pocketmine\utils\Config($configPath, \pocketmine\utils\Config::YAML, ['__array_ptr' => '2aaaac9fc9a0']);
			$this->propertyCache = ['__array_ptr' => '2aaaac9fc9a0'];
			if ($showNotice) {
				if (($targetLang === 'chs')) {
				} else {
				}
				$this->logger->notice($this);
			}
			return true;
		}

	private function normalizePocketMineConfigTemplateLanguage($lang = null) {
			/* decompiled (structured CF) */
			if ((strtolower(($lang)) === 'chs')) {
			} else {
			}
			return 'eng';
		}

	private function getPocketMineConfigTemplatePath($lang = null) {
			$lang = $this->normalizePocketMineConfigTemplateLanguage($lang);
			return ((($this->filePath . 'src/pocketmine/resources/pocketmine_') . $lang) . '.yml');
		}

	private function migrateLegacyAdvancedConfig($advancedConfigPath = null, $legacyConfigPath = null, $legacyBackupConfigPath = null) {
			/* decompiled (structured CF) */
			if (!(is_file($legacyConfigPath))) {
				return false;
			}
			if (($legacyBackupConfigPath === null)) {
				$legacyBackupConfigPath = ($legacyConfigPath . '.bak');
			}
			new \pocketmine\utils\Config($advancedConfigPath, \pocketmine\utils\Config::YAML, ['__array_ptr' => '2aaaac9fc9a0']);
			$advancedConfig = new \pocketmine\utils\Config($advancedConfigPath, \pocketmine\utils\Config::YAML, ['__array_ptr' => '2aaaac9fc9a0']);
			new \pocketmine\utils\Config($legacyConfigPath, \pocketmine\utils\Config::YAML, ['__array_ptr' => '2aaaac9fc9a0']);
			$legacyConfig = new \pocketmine\utils\Config($legacyConfigPath, \pocketmine\utils\Config::YAML, ['__array_ptr' => '2aaaac9fc9a0']);
			if ((!($advancedConfig->check()) || !($legacyConfig->check()))) {
				return false;
			}
			$legacyData = $legacyConfig->getAll();
			if ((isset($legacyData['config']) && is_array($legacyData['config']))) {
			}
			$mergedData = $this->mergeAdvancedConfigData($advancedConfig->getAll(), $legacyData);
			$content = file_get_contents($advancedConfigPath);
			if (is_string($content)) {
				file_put_contents($advancedConfigPath, $this->writeAdvancedConfigDataPreservingComments($content, $mergedData));
			} else {
				$advancedConfig->setAll($mergedData);
				$advancedConfig->save(false);
			}
			if (is_file($legacyBackupConfigPath)) {
				rename($legacyBackupConfigPath, (($legacyBackupConfigPath . '.') . date('YmdHis')));
			}
			return rename($legacyConfigPath, $legacyBackupConfigPath);
		}

	private function mergeAdvancedConfigData($base = null, $legacy = null) {
			/* decompiled (structured CF) */
			foreach ($legacy as $key => $value) {
				if (((is_array($value) && isset($base[$key])) && is_array($base[$key]))) {
					$base[$key] = $this->mergeAdvancedConfigData($base[$key], $value);
				} else {
					$base[$key] = $value;
				}
				/* goto */
			}
			return $base;
		}

	private function writeAdvancedConfigDataPreservingComments($content = null, $data = null) {
			/* decompiled (structured CF) */
			if ((strpos($content, "\x0d\x0a") !== false)) {
			} else {
			}
			$lineEnding = "\x0a";
			$hasTrailingNewline = (preg_match('/(\\r\\n|\\n|\\r)$/', $content) === 1);
			$lines = preg_split('/\\r\\n|\\n|\\r/', $content);
			if (($hasTrailingNewline && (end($lines) === ''))) {
				array_pop($lines);
			}
			$output = ['__array_ptr' => '2aaaac9fc9a0'];
			$pathStack = ['__array_ptr' => '2aaaac9fc9a0'];
			$seenPaths = ['__array_ptr' => '2aaaac9fc9a0'];
			$count = count($lines);
			$i = 0;
			while (($i < $count)) {
				$line = $lines[$i];
				if ((preg_match('/^(\\s*)([A-Za-z0-9_-]+)\\s*:\\s*(.*)$/', $line, $matches) !== 1)) {
					$output[] = $line;
				} else {
					$indent = strlen($matches[1]);
					while (($indent <= $pathStack[$t57]['indent'])) {
						$entry = array_pop($pathStack);
						$this->appendMissingAdvancedConfigYamlChildren($output, $data, $entry['path'], ($entry['indent'] + 1), $seenPaths);
					}
					$key = $matches[2];
					$path = ['__array_ptr' => '2aaaac9fc9a0'];
					foreach ($pathStack as $entry) {
						$path[] = $entry['key'];
						/* goto */
					}
					$parentPath = $path;
					$path[] = $key;
					$seenPaths[$this->getAdvancedConfigPathKey($parentPath)][$key] = true;
					$found = false;
					$value = $this->getAdvancedConfigDataPath($data, $path, $found);
					$inlineValue = trim($matches[3]);
					if (($found && (!(is_array($value)) || ($inlineValue !== '')))) {
						foreach ($this->emitAdvancedConfigYamlEntry($matches[1], $key, $value) as $emittedLine) {
							$output[] = $emittedLine;
							/* goto */
						}
						if (is_array($value)) {
							$this->skipAdvancedConfigYamlChildren($lines, $i, $indent);
						}
					} else {
						$output[] = $line;
						if (($inlineValue === '')) {
							$pathStack[] = [$indent, $key, $path];
						}
					}
				}
				$i++;
			}
			while ((0 < count($pathStack))) {
				$entry = array_pop($pathStack);
				$this->appendMissingAdvancedConfigYamlChildren($output, $data, $entry['path'], ($entry['indent'] + 1), $seenPaths);
			}
			$this->appendMissingAdvancedConfigYamlChildren($output, $data, ['__array_ptr' => '2aaaac9fc9a0'], 0, $seenPaths);
			if ($hasTrailingNewline) {
			} else {
			}
			return (implode($lineEnding, $output) . '');
		}

	private function appendMissingAdvancedConfigYamlChildren($output = null, $data = null, $path = null, $childIndent = null, $seenPaths = null) {
			/* decompiled (structured CF) */
			$found = false;
			$value = $this->getAdvancedConfigDataPath($data, $path, $found);
			if (((!($found) || !(is_array($value))) || $this->isAdvancedConfigList($value))) {
				return null;
			}
			$pathKey = $this->getAdvancedConfigPathKey($path);
			if (isset($seenPaths[$pathKey])) {
			} else {
			}
			$seen = ['__array_ptr' => '2aaaac9fc9a0'];
			foreach ($value as $key => $childValue) {
				if (isset($seen[$key])) {
					/* goto */
				}
				foreach ($this->emitAdvancedConfigYamlEntry(str_repeat($this, $childIndent), ($key), $childValue) as $childLine) {
					$output[] = $childLine;
					/* goto */
				}
				$seenPaths[$pathKey][$key] = true;
				/* goto */
			}
		}

	private function getAdvancedConfigPathKey($path = null) {
			return implode("\x00", $path);
		}

	private function getAdvancedConfigDataPath($data = null, $path = null, $found = null) {
			/* decompiled (structured CF) */
			$current = $data;
			foreach ($path as $key) {
				if ((!(is_array($current)) || !(array_key_exists($key, $current)))) {
					$found = false;
					return null;
				}
				$current = $current[$key];
				/* goto */
			}
			$found = true;
			return $current;
		}

	private function skipAdvancedConfigYamlChildren($lines = null, $index = null, $indent = null) {
			/* decompiled (structured CF) */
			$count = count($lines);
			while (($t20 < $count)) {
				$nextLine = $lines[($index + 1)];
				if ((trim($nextLine) === '')) {
				} else {
					$nextIndent = (strlen($nextLine) - strlen(ltrim($nextLine, $this)));
					if (($nextIndent <= $indent)) {
					} else {
						$index++;
					}
				}
			}
			return null;
		}

	private function emitAdvancedConfigYamlEntry($indent = null, $key = null, $value = null) {
			/* decompiled (structured CF) */
			if (!(is_array($value))) {
				return [((($indent . $key) . $this) . $this->formatAdvancedConfigYamlScalar($value))];
			}
			if ((count($value) === 0)) {
				return [(($indent . $key) . $this)];
			}
			$lines = [(($indent . $key) . ':')];
			$childIndent = ($indent . $this);
			if ($this->isAdvancedConfigList($value)) {
				foreach ($value as $entry) {
					if (is_array($entry)) {
						$lines[] = ($childIndent . '-');
						foreach ($entry as $childKey => $childValue) {
							foreach ($this->emitAdvancedConfigYamlEntry(($childIndent . $this), ($childKey), $childValue) as $childLine) {
								$lines[] = $childLine;
								/* goto */
							}
							/* goto */
						}
					} else {
						$lines[] = (($childIndent . $this) . $this->formatAdvancedConfigYamlScalar($entry));
					}
					/* goto */
				}
				return $lines;
			}
			foreach ($value as $childKey => $childValue) {
				foreach ($this->emitAdvancedConfigYamlEntry($childIndent, ($childKey), $childValue) as $childLine) {
					$lines[] = $childLine;
					/* goto */
				}
				/* goto */
			}
			return $lines;
		}

	private function isAdvancedConfigList($value = null) {
			return (array_keys($value) === range(0, (count($value) - 1)));
		}

	private function formatAdvancedConfigYamlScalar($value = null) {
			/* decompiled (structured CF) */
			if (is_bool($value)) {
				if ($value) {
				} else {
				}
				return 'false';
			}
			if ((is_int($value) || is_float($value))) {
				return ($value);
			}
			if (($value === null)) {
				return 'null';
			}
			$value = ($value);
			if ((((($value !== '') && (preg_match('/^[A-Za-z0-9_.\\/-]+$/', $value) === 1)) && !(is_numeric($value))) && !(in_array(strtolower($value), ['__array_ptr' => '2aaaadd62fc0'], true)))) {
				return $value;
			}
			return json_encode($value, (\JSON_UNESCAPED_UNICODE | \JSON_UNESCAPED_SLASHES));
		}

	public function getAdvancedProperty($variable = null, $defaultValue = null, $cfg = null) {
			/* decompiled (structured CF) */
			$vars = explode('.', $variable);
			$base = array_shift($vars);
			if (($cfg == null)) {
				$cfg = $this->advancedConfig;
			}
			if ($cfg->exists($base)) {
				$base = $cfg->get($base);
			} else {
				return $defaultValue;
			}
			while ((0 < count($vars))) {
				$baseKey = array_shift($vars);
				if ((is_array($base) && isset($base[$baseKey]))) {
					$base = $base[$baseKey];
				} else {
					return $defaultValue;
				}
			}
			return $base;
		}

	public function getSupportedGamerules() {
			return [['__array_ptr' => '2aaaadd62f88'], ['__array_ptr' => '2aaaaddba000'], ['__array_ptr' => '2aaaaddba038'], ['__array_ptr' => '2aaaaddba070'], ['__array_ptr' => '2aaaaddba0a8'], ['__array_ptr' => '2aaaaddba118'], ['__array_ptr' => '2aaaaddba150'], ['bool', 'keep-inventory', $this->keepInventory, true], ['__array_ptr' => '2aaaaddba1c0']];
		}

	public function getWorldGamerule($level = null, $rule = null) {
			/* decompiled (structured CF) */
			$rules = $this->getSupportedGamerules();
			if (!(isset($rules[$rule]))) {
				return null;
			}
			$override = $this->getWorldGameruleOverride($level, $rule);
			if (($override !== null)) {
				if (($rules[$rule]['type'] === 'int')) {
					return max(0, ($override));
				}
				return $override;
			}
			$definition = $rules[$rule];
			if ($this->isWorldBehaviorDisabled($level, $definition['behavior'])) {
				return $definition['listedValue'];
			}
			return $definition['default'];
		}

	public function setWorldGamerule($level = null, $rule = null, $value = null) {
			/* decompiled (structured CF) */
			$rules = $this->getSupportedGamerules();
			if (!(isset($rules[$rule]))) {
				return false;
			}
			$definition = $rules[$rule];
			if (($definition['type'] === 'int')) {
				$value = max(0, ($value));
				$this->persistWorldGameruleValue($level, $rule, $value);
				$this->persistWorldGamerule($level, $definition['behavior'], ($value === ($definition['listedValue'])));
				return true;
			}
			$value = $value;
			$this->persistWorldGameruleValue($level, $rule, $value);
			$this->persistWorldGamerule($level, $definition['behavior'], ($value === $definition['listedValue']));
			return true;
		}

	private function getWorldGameruleOverride($level = null, $rule = null) {
			/* decompiled (structured CF) */
			if (!($this->advancedConfig instanceof \pocketmine\utils\Config)) {
				return null;
			}
			$world = $this->getWorldConfigName($level);
			if (($world === '')) {
			}
			$missing = '__missing_gamerule__';
			$value = $this->getAdvancedProperty(((('world.gamerules.' . $world) . '.') . $rule), $missing);
			if (($value === $missing)) {
			} else {
			}
			return $value;
		}

	private function persistWorldGameruleValue($level = null, $rule = null, $value = null) {
			/* decompiled (structured CF) */
			if (!($this->advancedConfig instanceof \pocketmine\utils\Config)) {
				return null;
			}
			$world = $this->getWorldConfigName($level);
			if (($world === '')) {
			}
			$this->advancedConfig->setNested(((('world.gamerules.' . $world) . '.') . $rule), $value);
		}

	private function getWorldConfigName($level = null) {
			/* decompiled (structured CF) */
			if ($level instanceof \pocketmine\level\Level) {
				return trim(($level->getFolderName()));
			}
			if ((is_object($level) && method_exists($level, 'getFolderName'))) {
				return trim(($level->getFolderName()));
			}
			return trim(($level));
		}

	private function persistWorldGamerule($level = null, $behavior = null, $listed = null) {
			/* decompiled (structured CF) */
			$world = $this->getWorldConfigName($level);
			if (($world === '')) {
				return null;
			}
			if (isset($this->worldBehaviorConfig[$behavior])) {
			} else {
			}
			$current = $this->normalizeWorldNameList($this->getAdvancedProperty(('world.' . $behavior), ['__array_ptr' => '2aaaac9fc9a0']));
			$worlds = ['__array_ptr' => '2aaaac9fc9a0'];
			foreach ($current as $entry) {
				$entry = trim(($entry));
				if (($entry !== '')) {
					$worlds[$this->normalizeWorldName($entry)] = $entry;
				}
				/* goto */
			}
			$normalized = $this->normalizeWorldName($world);
			if ($listed) {
				$worlds[$normalized] = $world;
			} else {
			}
			$list = array_values($worlds);
			sort($list, (\SORT_NATURAL | \SORT_FLAG_CASE));
			$this->worldBehaviorConfig[$behavior] = $this->normalizeWorldNameList($list);
			if ($this->advancedConfig instanceof \pocketmine\utils\Config) {
				$this->advancedConfig->setNested(('world.' . $behavior), $list);
				$this->saveAdvancedConfig();
			}
		}

	private function saveAdvancedConfig() {
			/* decompiled (structured CF) */
			if ($this->advancedConfig instanceof \pocketmine\utils\Config) {
				$this->advancedConfig->save(false);
			}
			return null;
		}

	private function normalizeWorldName($name = null) {
			return strtolower(trim(($name)));
		}

	public function normalizeWorldNameList($value = null) {
			/* decompiled (structured CF) */
			if (is_string($value)) {
				$value = preg_split('/[,;]/', $value);
			} else {
				if (!(is_array($value))) {
					$value = [$value];
				}
			}
			$worlds = ['__array_ptr' => '2aaaac9fc9a0'];
			foreach ($value as $world) {
				$world = $this->normalizeWorldName($world);
				if (($world !== '')) {
					$worlds[$world] = true;
				}
				/* goto */
			}
			return array_keys($worlds);
		}

	public function isWorldBehaviorDisabled($level = null, $behavior = null) {
			/* decompiled (structured CF) */
			if ((!(isset($this->worldBehaviorConfig[$behavior])) || (count($this->worldBehaviorConfig[$behavior]) === 0))) {
				return false;
			}
			$names = ['__array_ptr' => '2aaaac9fc9a0'];
			if ($level instanceof \pocketmine\level\Level) {
				$names[] = $level->getFolderName();
				$names[] = $level->getName();
				/* jump */
			} else {
				if (is_object($level)) {
					if (method_exists($level, 'getFolderName')) {
						$names[] = $level->getFolderName();
					}
					if (method_exists($level, 'getName')) {
						$names[] = $level->getName();
					}
				} else {
					$names[] = $level;
				}
			}
			foreach ($names as $name) {
				if (in_array($this->normalizeWorldName($name), $this->worldBehaviorConfig[$behavior], true)) {
					return true;
				}
				/* goto */
			}
			return false;
		}

	public function isWorldNaturalMobSpawnDisabled($level = null) {
			/* decompiled (structured CF) */
			$override = $this->getWorldGameruleOverride($level, 'doMobSpawning');
			if (($override !== null)) {
				return !($override);
			}
			return $this->isWorldBehaviorDisabled($level, 'no-natural-mob-spawn');
		}

	public function isWorldMobDeathDropsAndExperienceDisabled($level = null) {
			/* decompiled (structured CF) */
			$override = $this->getWorldGameruleOverride($level, 'doMobLoot');
			if (($override !== null)) {
				return !($override);
			}
			return $this->isWorldBehaviorDisabled($level, 'no-mob-death-drops-and-experience');
		}

	public function isWorldCreeperBlockDamageDisabled($level = null) {
			/* decompiled (structured CF) */
			$override = $this->getWorldGameruleOverride($level, 'mobGriefing');
			if (($override !== null)) {
				return !($override);
			}
			return $this->isWorldBehaviorDisabled($level, 'no-creeper-block-damage');
		}

	public function isWorldTntBlockDamageDisabled($level = null) {
			/* decompiled (structured CF) */
			$override = $this->getWorldGameruleOverride($level, 'tnTExplodes');
			if (($override !== null)) {
				return !($override);
			}
			return $this->isWorldBehaviorDisabled($level, 'no-tnt-block-damage');
		}

	public function isWorldHungerHealthRegenerationDisabled($level = null) {
			/* decompiled (structured CF) */
			$override = $this->getWorldGameruleOverride($level, 'naturalRegeneration');
			if (($override !== null)) {
				return !($override);
			}
			return $this->isWorldBehaviorDisabled($level, 'no-hunger-health-regeneration');
		}

	public function isWorldCropGrowthDisabled($level = null) {
			/* decompiled (structured CF) */
			$override = $this->getWorldGameruleOverride($level, 'randomTickSpeed');
			if (($override !== null)) {
				return (($override) <= 0);
			}
			return $this->isWorldBehaviorDisabled($level, 'no-crop-growth');
		}

	public function isWorldNonLivingEntityDropsDisabled($level = null) {
			/* decompiled (structured CF) */
			$override = $this->getWorldGameruleOverride($level, 'doEntityDrops');
			if (($override !== null)) {
				return !($override);
			}
			return $this->isWorldBehaviorDisabled($level, 'no-non-living-entity-drops');
		}

	public function isWorldKeepInventoryEnabled($level = null) {
			/* decompiled (structured CF) */
			$override = $this->getWorldGameruleOverride($level, 'keepInventory');
			if (($override !== null)) {
				return $override;
			}
			return ($this->keepInventory || $this->isWorldBehaviorDisabled($level, 'keep-inventory'));
		}

	public function isWorldDaylightCycleDisabled($level = null) {
			/* decompiled (structured CF) */
			$override = $this->getWorldGameruleOverride($level, 'doDaylightCycle');
			if (($override !== null)) {
				return !($override);
			}
			return $this->isWorldBehaviorDisabled($level, 'do-daylight-cycle');
		}

	public function getRedstonePulseTickDelay() {
			return max(1, (round((max(0.05, ($this->pulseFrequency)) * 20))));
		}

	public function updateQuery() {
			/* decompiled (structured CF) */
			new \pocketmine\event\server\QueryRegenerateEvent($this, 5);
			$this->queryRegenerateTask = new \pocketmine\event\server\QueryRegenerateEvent($this, 5);
			$this->getPluginManager()->callEvent($t2);
			if (($this->queryHandler !== null)) {
				$this->queryHandler->regenerateInfo();
			}
			/* jump */
			$this->logger->logException($e);
			return null;
		}

	private function tick() {
			/* decompiled (structured CF) */
			$tickTime = microtime(true);
			if ((($tickTime - $this->nextTick) < -0.025)) {
				return false;
			}
			\pocketmine\event\Timings::$serverTickTimer->startTiming();
			$this->checkConsole();
			\pocketmine\event\Timings::$connectionTimer->startTiming();
			$this->network->processInterfaces();
			if (($this->rcon !== null)) {
				$this->rcon->check();
			}
			\pocketmine\event\Timings::$connectionTimer->stopTiming();
			\pocketmine\event\Timings::$schedulerTimer->startTiming();
			$this->scheduler->mainThreadHeartbeat($this->tickCounter);
			\pocketmine\event\Timings::$schedulerTimer->stopTiming();
			$this->checkTickUpdates($this->tickCounter, $tickTime);
			foreach ($this->players as $player) {
				$player->checkNetwork();
				/* goto */
			}
			if ((($this->tickCounter & 15) === 0)) {
				$this->checkDos();
				$this->titleTick();
				$this->maxTick = 20;
				$this->maxUse = 0;
				if ((($this->tickCounter & 511) === 0)) {
					if ((($this->dserverConfig['enable'] && $this->dserverConfig['queryTickUpdate']) || !($this->dserverConfig['enable']))) {
						$this->updateQuery();
					}
				}
				$this->getNetwork()->updateName();
			}
			if (($this->autoSave && ($this->autoSaveTicks <= $t58))) {
				$this->autoSaveTicker = 0;
				$this->doAutoSave();
			}
			if ((($this->tickCounter % 100) === 0)) {
				if ($this->antiGameSpeed) {
					$this->checkGameSpeed($this->tickCounter);
				}
				foreach ($this->levels as $level) {
					$level->clearCache();
					/* goto */
				}
				if (($this->getTicksPerSecondAverage() < 12)) {
					$this->logger->warning($this->getLanguage()->translateString('pocketmine.server.tickOverload'));
				}
			}
			if (($this->dispatchSignals && (($this->tickCounter % 5) === 0))) {
				pcntl_signal_dispatch();
			}
			$this->getMemoryManager()->check();
			\pocketmine\event\Timings::$serverTickTimer->stopTiming();
			$now = microtime(true);
			$tick = min(20, (1 / max(0.001, ($now - $tickTime))));
			$use = min(1, (($now - $tickTime) / 0.05));
			if (($tick < $this->maxTick)) {
				$this->maxTick = $tick;
			}
			if (($this->maxUse < $use)) {
				$this->maxUse = $use;
			}
			array_shift($this->tickAverage);
			$this->tickAverage[] = $tick;
			array_shift($this->useAverage);
			$this->useAverage[] = $use;
			if ((($this->nextTick - $tickTime) < -1)) {
				$this->nextTick = $tickTime;
			} else {
				$this->nextTick += 0.05;
			}
			return true;
		}

	private function registerEntities() {
			/* decompiled (structured CF) */
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Arrow');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Item');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\FallingSand');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\PrimedTNT');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Snowball');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Fireball');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\SmallFireball');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Villager');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Zombie');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Squid');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Chicken');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Cow');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Pig');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Horse');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Sheep');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Wolf');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Mooshroom');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Creeper');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Skeleton');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Spider');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\PigZombie');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Slime');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Enderman');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Silverfish');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\CaveSpider');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Ghast');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\LavaSlime');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Bat');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Blaze');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Witch');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Ocelot');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\SnowGolem');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\IronGolem');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Lightning');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\XPOrb');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\ThrownExpBottle');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Boat');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Minecart');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\ThrownPotion');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Painting');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\FishingHook');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Egg');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\ZombieVillager');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Rabbit');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\MinecartChest');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\MinecartHopper');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\MinecartTNT');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\LeashKnot');
			\pocketmine\entity\Entity::registerEntity('pocketmine\\entity\\Human', true);
			return null;
		}

	private function registerTiles() {
			/* decompiled (structured CF) */
			\pocketmine\tile\Tile::registerTile('pocketmine\\tile\\BrewingStand');
			\pocketmine\tile\Tile::registerTile('pocketmine\\tile\\Chest');
			\pocketmine\tile\Tile::registerTile('pocketmine\\tile\\Furnace');
			\pocketmine\tile\Tile::registerTile('pocketmine\\tile\\Sign');
			\pocketmine\tile\Tile::registerTile('pocketmine\\tile\\EnchantTable');
			\pocketmine\tile\Tile::registerTile('pocketmine\\tile\\FlowerPot');
			\pocketmine\tile\Tile::registerTile('pocketmine\\tile\\Skull');
			\pocketmine\tile\Tile::registerTile('pocketmine\\tile\\MobSpawner');
			\pocketmine\tile\Tile::registerTile('pocketmine\\tile\\Hopper');
			\pocketmine\tile\Tile::registerTile('pocketmine\\tile\\ItemFrame');
			\pocketmine\tile\Tile::registerTile('pocketmine\\tile\\Dispenser');
			\pocketmine\tile\Tile::registerTile('pocketmine\\tile\\Dropper');
			\pocketmine\tile\Tile::registerTile('pocketmine\\tile\\DLDetector');
			\pocketmine\tile\Tile::registerTile('pocketmine\\tile\\Cauldron');
			\pocketmine\tile\Tile::registerTile('pocketmine\\tile\\MinecartChest');
			\pocketmine\tile\Tile::registerTile('pocketmine\\tile\\Comparator');
			\pocketmine\tile\Tile::registerTile('pocketmine\\tile\\PistonArm');
			\pocketmine\tile\Tile::registerTile('pocketmine\\tile\\MovingBlock');
			return null;
		}

	public function checkGameSpeed($tick = null) {
			/* decompiled (structured CF) */
			foreach ($this->getOnlinePlayers() as $player) {
				$time = microtime(true);
				$elapsed = ($time - $player->motionPacketLastCheck);
				if (((0 < $player->motionPacketLastCheck) && (0 < $elapsed))) {
					$rate = ($player->motionPacketCount / $elapsed);
					if ((175 <= $rate)) {
						$player->kick("\xe6\x9c\x8d\xe5\x8a\xa1\xe5\x99\xa8\xe4\xb8\x8d\xe5\x85\x81\xe8\xae\xb8\xe5\x8a\xa0\xe9\x80\x9f");
					}
				}
				$player->motionPacketLastCheck = $time;
				$player->motionPacketCount = 0;
				/* goto */
			}
			return null;
		}

}
