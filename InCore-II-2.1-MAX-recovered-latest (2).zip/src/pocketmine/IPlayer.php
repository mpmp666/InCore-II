<?php

namespace pocketmine;

interface IPlayer extends \pocketmine\permission\ServerOperator {
	public function isOnline();

	public function getName();

	public function isBanned();

	public function setBanned($banned);

	public function isWhitelisted();

	public function setWhitelisted($value);

	public function getPlayer();

	public function getFirstPlayed();

	public function getLastPlayed();

	public function hasPlayedBefore();

}
