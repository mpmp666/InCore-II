<?php

namespace pocketmine;

class MemoryManager {
	private $server = NULL;
	private $memoryLimit = NULL;
	private $globalMemoryLimit = NULL;
	private $checkRate = NULL;
	private $checkTicker = 0;
	private $lowMemory = false;
	private $continuousTrigger = true;
	private $continuousTriggerRate = NULL;
	private $continuousTriggerCount = 0;
	private $continuousTriggerTicker = 0;
	private $garbageCollectionPeriod = NULL;
	private $garbageCollectionTicker = 0;
	private $garbageCollectionTrigger = NULL;
	private $garbageCollectionAsync = NULL;
	private $chunkLimit = NULL;
	private $chunkCollect = NULL;
	private $chunkTrigger = NULL;
	private $chunkCache = NULL;
	private $cacheTrigger = NULL;
	private $leakWatch = array (
);
	private $leakInfo = array (
);
	private $leakSeed = 0;

	public function __construct($server = null) {
			$this->server = $server;
			$this->init();
			return;
		}

	private function init() {
			/* decompiled (structured CF) */
			$this->memoryLimit = ((($this->server->getProperty('memory.main-limit', 0)) * 1024) * 1024);
			$defaultMemory = 1024;
			if ((0 < preg_match('/([0-9]+)([KMGkmg])/', $this->server->getConfigString('memory-limit', ''), $matches))) {
				$m = ($matches[1]);
				if (($m <= 0)) {
					$defaultMemory = 0;
				} else {
					switch (strtoupper($matches[2])) {
						case 'K':
						$defaultMemory = ($m / 1024);
						break;
						case 'M':
						$defaultMemory = $m;
						break;
						case 'G':
						$defaultMemory = ($m * 1024);
						break;
						$defaultMemory = $m;
						break;
					}
				}
			}
			$hardLimit = ($this->server->getProperty('memory.main-hard-limit', $defaultMemory));
			if (($hardLimit <= 0)) {
				ini_set('memory_limit', -1);
			} else {
				ini_set('memory_limit', ($hardLimit . 'M'));
			}
			$this->globalMemoryLimit = ((($this->server->getProperty('memory.global-limit', 0)) * 1024) * 1024);
			$this->checkRate = ($this->server->getProperty('memory.check-rate', 20));
			$this->continuousTrigger = $this->server->getProperty('memory.continuous-trigger', true);
			$this->continuousTriggerRate = ($this->server->getProperty('memory.continuous-trigger-rate', 30));
			$this->garbageCollectionPeriod = ($this->server->getProperty('memory.garbage-collection.period', 36000));
			$this->garbageCollectionTrigger = $this->server->getProperty('memory.garbage-collection.low-memory-trigger', true);
			$this->garbageCollectionAsync = $this->server->getProperty('memory.garbage-collection.collect-async-worker', true);
			$this->chunkLimit = ($this->server->getProperty('memory.max-chunks.trigger-limit', 96));
			$this->chunkCollect = $this->server->getProperty('memory.max-chunks.trigger-chunk-collect', true);
			$this->chunkTrigger = $this->server->getProperty('memory.max-chunks.low-memory-trigger', true);
			$this->chunkCache = $this->server->getProperty('memory.world-caches.disable-chunk-cache', true);
			$this->cacheTrigger = $this->server->getProperty('memory.world-caches.low-memory-trigger', true);
			gc_enable();
			return null;
		}

	public function isLowMemory() {
			return $this->lowMemory;
		}

	public function canUseChunkCache() {
			return !(($this->lowMemory && $this->chunkTrigger));
		}

	public function getViewDistance($distance = null) {
			/* decompiled (structured CF) */
			if ($this->lowMemory) {
			} else {
			}
			return $distance;
		}

	public function trigger($memory = null, $limit = null, $global = null, $triggerCount = null) {
			/* decompiled (structured CF) */
			if ($global) {
			} else {
			}
			$this->server->getLogger()->debug((((((($this . '') . $this) . round((($limit / 1024) / 1024), 2)) . $this) . round((($memory / 1024) / 1024), 2)) . 'MB'));
			if ($this->cacheTrigger) {
				foreach ($this->server->getLevels() as $level) {
					$level->clearCache(true);
					/* goto */
				}
			}
			if (($this->chunkTrigger && $this->chunkCollect)) {
				foreach ($this->server->getLevels() as $level) {
					$level->doChunkGarbageCollection();
					/* goto */
				}
			}
			new \pocketmine\event\server\LowMemoryEvent($memory, $limit, $global, $triggerCount);
			$ev = new \pocketmine\event\server\LowMemoryEvent($memory, $limit, $global, $triggerCount);
			$this->server->getPluginManager()->callEvent($ev);
			$cycles = 0;
			if ($this->garbageCollectionTrigger) {
				$cycles = $this->triggerGarbageCollector();
			}
			$this->server->getLogger()->debug((($this . round((($ev->getMemoryFreed() / 1024) / 1024), 2)) . ($this . $this)));
			return null;
		}

	public function check() {
			/* decompiled (structured CF) */
			\pocketmine\event\Timings::$memoryManagerTimer->startTiming();
			if ((((0 < $this->memoryLimit) || (0 < $this->globalMemoryLimit)) && ($this->checkRate <= $t8))) {
				$this->checkTicker = 0;
				$memory = \pocketmine\utils\Utils::getMemoryUsage(true);
				$trigger = false;
				if (((0 < $this->memoryLimit) && ($this->memoryLimit < $memory[0]))) {
					$trigger = 0;
				} else {
					if (((0 < $this->globalMemoryLimit) && ($this->globalMemoryLimit < $memory[1]))) {
						$trigger = 1;
					}
				}
				if (($trigger !== false)) {
					if (($this->lowMemory && $this->continuousTrigger)) {
						if (($this->continuousTriggerRate <= $t30)) {
							$this->continuousTriggerTicker = 0;
							$this->trigger($memory[$trigger], $this->memoryLimit, (0 < $trigger), $t37);
						}
					} else {
						$this->lowMemory = true;
						$this->continuousTriggerCount = 0;
						$this->trigger($memory[$trigger], $this->memoryLimit, (0 < $trigger));
					}
				} else {
					$this->lowMemory = false;
				}
			}
			if (((0 < $this->garbageCollectionPeriod) && ($this->garbageCollectionPeriod <= $t48))) {
				$this->garbageCollectionTicker = 0;
				$this->triggerGarbageCollector();
			}
			\pocketmine\event\Timings::$memoryManagerTimer->stopTiming();
			return null;
		}

	public function triggerGarbageCollector() {
			/* decompiled (structured CF) */
			\pocketmine\event\Timings::$garbageCollectorTimer->startTiming();
			if ($this->garbageCollectionAsync) {
				$size = $this->server->getScheduler()->getAsyncTaskPoolSize();
				$i = 0;
				while (($i < $size)) {
					new \pocketmine\scheduler\GarbageCollectionTask();
					$this->server->getScheduler()->scheduleAsyncTaskToWorker(new \pocketmine\scheduler\GarbageCollectionTask(), $i);
					$i++;
				}
			}
			$cycles = gc_collect_cycles();
			foreach ($this->server->getLevels() as $level) {
				$level->doChunkGarbageCollection();
				/* goto */
			}
			\pocketmine\event\Timings::$garbageCollectorTimer->stopTiming();
			return $cycles;
		}

	public function addObjectWatcher($object = null) {
			/* decompiled (structured CF) */
			if (!(is_object($object))) {
				new \InvalidArgumentException($this);
				throw new \InvalidArgumentException($this);
			}
			$identifier = ((spl_object_hash($object) . ':') . get_class($object));
			if (isset($this->leakInfo[$identifier])) {
				return $this->leakInfo['id'];
			}
			$id = md5((($identifier . ':') . $t19));
			$this->leakInfo[$identifier] = [$id, get_class($object), $identifier];
			$this->leakInfo[$id] = $this->leakInfo[$identifier];
			new \WeakRef($object);
			$this->leakWatch[$id] = new \WeakRef($object);
			return $id;
		}

	public function isObjectAlive($id = null) {
			/* decompiled (structured CF) */
			if (isset($this->leakWatch[$id])) {
				return $this->leakWatch[$id]->valid();
			}
			return false;
		}

	public function removeObjectWatch($id = null) {
			if (!(isset($this->leakWatch[$id]))) {
				return null;
			}
		}

	public function doObjectCleanup() {
			/* decompiled (structured CF) */
			foreach ($this->leakWatch as $id => $w) {
				if (!($w->valid())) {
					$this->removeObjectWatch($id);
				}
				/* goto */
			}
			return null;
		}

	public function getObjectInformation($id = null, $includeObject = null) {
			/* decompiled (structured CF) */
			if (!(isset($this->leakWatch[$id]))) {
				return null;
			}
			$valid = false;
			$references = 0;
			$object = null;
			if ($this->leakWatch[$id]->acquire()) {
				$object = $this->leakWatch[$id]->get();
				$this->leakWatch[$id]->release();
				$valid = true;
				$references = getReferenceCount($object, false);
			}
			if ($includeObject) {
			} else {
			}
			return [$id, $this->leakInfo[$id]['class'], $this->leakInfo[$id]['hash'], $valid, $references, null];
		}

	public function dumpServerMemory($outputFolder = null, $maxNesting = null, $maxStringSize = null) {
			/* decompiled (structured CF) */
			gc_disable();
			if (!(file_exists($outputFolder))) {
				mkdir($outputFolder, 511, true);
			}
			$this->server->getLogger()->notice($this);
			$obData = fopen(($outputFolder . '/objects.js'), 'wb+');
			$staticProperties = ['__array_ptr' => '2aaaac9fc9a0'];
			$data = ['__array_ptr' => '2aaaac9fc9a0'];
			$objects = ['__array_ptr' => '2aaaac9fc9a0'];
			$refCounts = ['__array_ptr' => '2aaaac9fc9a0'];
			$this->continueDump($this->server, $data, $objects, $refCounts, 0, $maxNesting, $maxStringSize);
			$continue = false;
			foreach ($objects as $hash => $object) {
				if (!(is_object($object))) {
					/* goto */
				}
				$continue = true;
				$className = get_class($object);
				$objects[$hash] = true;
				new \ReflectionObject($object);
				$reflection = new \ReflectionObject($object);
				$info = [($hash . $className), ['__array_ptr' => '2aaaac9fc9a0']];
				if ($reflection->getParentClass()) {
					$info['parent'] = $reflection->getParentClass()->getName();
				}
				if ((0 < count($reflection->getInterfaceNames()))) {
					$info['implements'] = implode($this, $reflection->getInterfaceNames());
				}
				foreach ($reflection->getProperties() as $property) {
					if ($property->isStatic()) {
						/* goto */
					}
					if (!($property->isPublic())) {
						$property->setAccessible(true);
					}
					$this->continueDump($property->getValue($object), $info['properties'][$property->getName()], $objects, $refCounts, 0, $maxNesting, $maxStringSize);
					/* goto */
				}
				fwrite($obData, ((($hash . $this) . json_encode($info, \JSON_UNESCAPED_SLASHES)) . "\x0a"));
				if (!(isset($objects['staticProperties'][$className]))) {
					$staticProperties[$className] = ['__array_ptr' => '2aaaac9fc9a0'];
					foreach ($reflection->getProperties() as $property) {
						if ((!($property->isStatic()) || ($className !== $property->getDeclaringClass()->getName()))) {
							/* goto */
						}
						if (!($property->isPublic())) {
							$property->setAccessible(true);
						}
						$this->continueDump($property->getValue($object), $staticProperties[$className][$property->getName()], $objects, $refCounts, 0, $maxNesting, $maxStringSize);
						/* goto */
					}
				}
				/* goto */
			}
			echo (($this . count($objects)) . $this);
			if (!($continue)) { /* unresolved jump */ }
			file_put_contents(($outputFolder . '/staticProperties.js'), json_encode($staticProperties, (\JSON_UNESCAPED_SLASHES | \JSON_PRETTY_PRINT)));
			file_put_contents(($outputFolder . '/serverEntry.js'), json_encode($data, (\JSON_UNESCAPED_SLASHES | \JSON_PRETTY_PRINT)));
			file_put_contents(($outputFolder . '/referenceCounts.js'), json_encode($refCounts, (\JSON_UNESCAPED_SLASHES | \JSON_PRETTY_PRINT)));
			echo $this;
			gc_enable();
			$this->server->forceShutdown();
			return null;
		}

	private function continueDump($from = null, $data = null, $objects = null, $refCounts = null, $recursion = null, $maxNesting = null, $maxStringSize = null) {
			/* decompiled (structured CF) */
			if (($maxNesting <= 0)) {
				$data = 'string(29)"(error';
				return null;
			}
			$maxNesting--;
			if (is_object($from)) {
				$hash = spl_object_hash($from);
				if (!(isset($objects[$hash]))) {
					$objects[$hash] = $from;
					$refCounts[$hash] = 0;
				}
				$refCounts[$hash]++;
				$data = (('string(9)"(object' . '@') . get_class($from));
			} else {
				if (is_array($from)) {
					if ((5 <= $recursion)) {
						$data = 'string(37)"(error';
					}
					$data = ['__array_ptr' => '2aaaac9fc9a0'];
					foreach ($from as $key => $value) {
						$this->continueDump($value, $data[$key], $objects, $refCounts, ($recursion + 1), $maxNesting, $maxStringSize);
						/* goto */
					}
				} else {
					if (is_string($from)) {
						$data = ((('string(13)"(string' . strlen($from)) . 'string(2)"') . substr(\pocketmine\utils\Utils::printable($from), 0, $maxStringSize));
					} else {
						if (is_resource($from)) {
							$data = ('string(11)"(resource' . print_r($from, true));
						} else {
							$data = $from;
						}
					}
				}
			}
		}

}
