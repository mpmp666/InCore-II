<?php

namespace pocketmine\block;

class MonsterSpawner extends \pocketmine\block\Solid {
	protected $id = 52;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getHardness() {
			return 5;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function getName() {
			return;
		}

	public function canBeActivated() {
			return true;
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			if (($this->getDamage() == 0)) {
				if (($item->getId() == \pocketmine\item\Item::SPAWN_EGG)) {
					$tile = $this->getLevel()->getTile($this);
					if ($tile instanceof \pocketmine\tile\MobSpawner) {
						$this->meta = $item->getDamage();
						$tile->setEntityId($this->meta);
					}
					return true;
				}
			}
			return false;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$this->getLevel()->setBlock($block, $this, true, true);
			new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::MOB_SPAWNER);
			new \pocketmine\nbt\tag\IntTag('x', $block->x);
			new \pocketmine\nbt\tag\IntTag('y', $block->y);
			new \pocketmine\nbt\tag\IntTag('z', $block->z);
			new \pocketmine\nbt\tag\IntTag('EntityId', 0);
			new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::MOB_SPAWNER), new \pocketmine\nbt\tag\IntTag('x', $block->x), new \pocketmine\nbt\tag\IntTag('y', $block->y), new \pocketmine\nbt\tag\IntTag('z', $block->z), new \pocketmine\nbt\tag\IntTag('EntityId', 0)]);
			$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::MOB_SPAWNER), new \pocketmine\nbt\tag\IntTag('x', $block->x), new \pocketmine\nbt\tag\IntTag('y', $block->y), new \pocketmine\nbt\tag\IntTag('z', $block->z), new \pocketmine\nbt\tag\IntTag('EntityId', 0)]);
			if ($item->hasCustomBlockData()) {
				foreach ($item->getCustomBlockData() as $key => $v) {
					$nbt->prop = $v;
					/* goto */
				}
			}
			\pocketmine\tile\Tile::createTile(\pocketmine\tile\Tile::MOB_SPAWNER, $this->getLevel()->getChunk(($this->x >> 4), ($this->z >> 4)), $nbt);
			return true;
		}

	public function getDrops($item = null) {
			return ['__array_ptr' => '2aaaac9fc9a0'];
		}

}
