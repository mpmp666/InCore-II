<?php

namespace pocketmine\block;

class PumpkinStem extends \pocketmine\block\Crops {
	protected $id = 104;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				if ($this->getSide(0)->isTransparent()) {
					$this->getLevel()->useBreakOn($this);
					return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
				}
			} else {
				if (($type === \pocketmine\level\Level::BLOCK_UPDATE_RANDOM)) {
					if ((mt_rand(0, 2) == 1)) {
						if (($this->meta < 7)) {
							$block = clone $this;
							new \pocketmine\event\block\BlockGrowEvent($this, $block);
							$ev = new \pocketmine\event\block\BlockGrowEvent($this, $block);
							\pocketmine\Server::getInstance()->getPluginManager()->callEvent($ev);
							if (!($ev->isCancelled())) {
								$this->getLevel()->setBlock($this, $ev->getNewState(), true);
							}
							return \pocketmine\level\Level::BLOCK_UPDATE_RANDOM;
						} else {
							$side = 2;
							while (($side <= 5)) {
								$b = $this->getSide($side);
								if (($b->getId() === self::PUMPKIN)) {
									return \pocketmine\level\Level::BLOCK_UPDATE_RANDOM;
								}
								$side++;
							}
							$side = $this->getSide(mt_rand(2, 5));
							$d = $side->getSide(0);
							if ((($side->getId() === self::AIR) && ((($d->getId() === self::FARMLAND) || ($d->getId() === self::GRASS)) || ($d->getId() === self::DIRT)))) {
								new \pocketmine\block\Pumpkin();
								new \pocketmine\event\block\BlockGrowEvent($side, new \pocketmine\block\Pumpkin());
								$ev = new \pocketmine\event\block\BlockGrowEvent($side, new \pocketmine\block\Pumpkin());
								\pocketmine\Server::getInstance()->getPluginManager()->callEvent($ev);
								if (!($ev->isCancelled())) {
									$this->getLevel()->setBlock($side, $ev->getNewState(), true);
								}
							}
						}
					}
					return \pocketmine\level\Level::BLOCK_UPDATE_RANDOM;
				}
			}
			return false;
		}

	public function getDrops($item = null) {
			return [[\pocketmine\item\Item::PUMPKIN_SEEDS, 0, mt_rand(0, 2)]];
		}

}
