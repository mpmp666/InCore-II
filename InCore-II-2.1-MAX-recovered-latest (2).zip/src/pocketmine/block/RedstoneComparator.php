<?php

namespace pocketmine\block;

abstract class RedstoneComparator extends \pocketmine\block\RedstoneDiode {
	public const MODE_COMPARE = 0;
	public const MODE_SUBTRACT = 1;

	protected function getDelay() {
			return 2;
		}

	public function getMode() {
			/* decompiled (structured CF) */
			if ((0 < ($this->meta & 4))) {
			} else {
			}
			return self::MODE_COMPARE;
		}

	protected function getPowered() {
			return \pocketmine\block\Block::get(self::POWERED_COMPARATOR, $this->meta);
		}

	protected function getUnpowered() {
			return \pocketmine\block\Block::get(self::UNPOWERED_COMPARATOR, $this->meta);
		}

	public function isPowered() {
			return ($this->isPowered || (0 < ($this->meta & 8)));
		}

	protected function getComparatorTile() {
			/* decompiled (structured CF) */
			$tile = $this->level->getTile($this);
			if ($tile instanceof \pocketmine\tile\Comparator) {
				return $tile;
			}
			new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::COMPARATOR);
			new \pocketmine\nbt\tag\IntTag('x', $this->x);
			new \pocketmine\nbt\tag\IntTag('y', $this->y);
			new \pocketmine\nbt\tag\IntTag('z', $this->z);
			new \pocketmine\nbt\tag\IntTag('OutputSignal', 0);
			new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::COMPARATOR), new \pocketmine\nbt\tag\IntTag('x', $this->x), new \pocketmine\nbt\tag\IntTag('y', $this->y), new \pocketmine\nbt\tag\IntTag('z', $this->z), new \pocketmine\nbt\tag\IntTag('OutputSignal', 0)]);
			return \pocketmine\tile\Tile::createTile(\pocketmine\tile\Tile::COMPARATOR, $this->level->getChunk(($this->x >> 4), ($this->z >> 4)), new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::COMPARATOR), new \pocketmine\nbt\tag\IntTag('x', $this->x), new \pocketmine\nbt\tag\IntTag('y', $this->y), new \pocketmine\nbt\tag\IntTag('z', $this->z), new \pocketmine\nbt\tag\IntTag('OutputSignal', 0)]));
		}

	protected function getRedstoneSignal() {
			/* decompiled (structured CF) */
			$tile = $this->getComparatorTile();
			if ($tile instanceof \pocketmine\tile\Comparator) {
			} else {
			}
			return 0;
		}

	protected function calculateInputStrength() {
			/* decompiled (structured CF) */
			$power = parent::calculateInputStrength();
			$inputSide = $this->getInputSide();
			$block = $this->getSide($inputSide);
			if ($block->hasComparatorInputOverride()) {
				$power = $block->getComparatorInputOverride();
			} else {
				if ((($power < 15) && $block->isNormalBlock())) {
					$block = $block->getSide($inputSide);
					if ($block->hasComparatorInputOverride()) {
						$power = $block->getComparatorInputOverride();
					}
				}
			}
			return $power;
		}

	protected function calculateOutput() {
			/* decompiled (structured CF) */
			$input = $this->calculateInputStrength();
			if (($this->getMode() === self::MODE_SUBTRACT)) {
			} else {
			}
			return $input;
		}

	public function shouldBePowered() {
			/* decompiled (structured CF) */
			$input = $this->calculateInputStrength();
			if ((15 <= $input)) {
				return true;
			}
			if (($input === 0)) {
				return false;
			}
			$sidePower = $this->getPowerOnSides();
			return (($sidePower === 0) || ($sidePower <= $input));
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			if (($this->getMode() === self::MODE_SUBTRACT)) {
			} else {
			}
			$this->meta = ($this->meta + 4);
			$this->level->setBlock($this, $this, true, true);
			$this->onChange();
			return true;
		}

	protected function onChange() {
			/* decompiled (structured CF) */
			$output = $this->calculateOutput();
			$tile = $this->getComparatorTile();
			$currentOutput = 0;
			if ($tile instanceof \pocketmine\tile\Comparator) {
				$currentOutput = $tile->getOutputSignal();
				$tile->setOutputSignal($output);
			}
			if ((($currentOutput !== $output) || ($this->getMode() === self::MODE_COMPARE))) {
				$shouldBePowered = $this->shouldBePowered();
				if (($this->isPowered() && !($shouldBePowered))) {
					$this->level->setBlock($this, $this->getUnpowered(), true, true);
				} else {
					if ((!($this->isPowered()) && $shouldBePowered)) {
						$this->level->setBlock($this, $this->getPowered(), true, true);
					}
				}
				$this->level->updateAroundRedstone($this, null);
			}
			return null;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED)) {
				$this->onChange();
				return \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED;
			}
			return parent::onUpdate($type);
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			if (parent::place($item, $block, $target, $face, $fx, $fy, $fz, $player)) {
				$this->getComparatorTile();
				$this->onUpdate(\pocketmine\level\Level::BLOCK_UPDATE_REDSTONE);
				return true;
			}
			return false;
		}

	public function updateState() {
			/* decompiled (structured CF) */
			if ($this->level->isBlockTickPending($this, $this)) {
				return null;
			}
			$tile = $this->getComparatorTile();
			if ($tile instanceof \pocketmine\tile\Comparator) {
			} else {
			}
			$power = 0;
			if ((($power !== $this->calculateOutput()) || ($this->isPowered() !== $this->shouldBePowered()))) {
				$this->level->scheduleUpdate($this, $this->getPulseTickDelay());
			}
		}

	public function getDrops($item = null) {
			return [[\pocketmine\item\Item::COMPARATOR, 0, 1]];
		}

}
