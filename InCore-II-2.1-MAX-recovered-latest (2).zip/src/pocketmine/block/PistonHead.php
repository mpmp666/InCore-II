<?php

namespace pocketmine\block;

class PistonHead extends \pocketmine\block\Transparent {
	public const META_FACING_MASK = 7;
	public const META_STICKY = 8;

	protected $id = 34;

	public function __construct($meta = null) {
			$this->meta = ($meta & 15);
		}

	public function getName() {
			/* decompiled (structured CF) */
			if ($this->isSticky()) {
			} else {
			}
			return $this;
		}

	public function getHardness() {
			return 1.5;
		}

	public function getResistance() {
			return 1.5;
		}

	public function isSolid() {
			return false;
		}

	public function getFacing() {
			/* decompiled (structured CF) */
			$facing = ($this->meta & self::META_FACING_MASK);
			if ((($facing < \pocketmine\math\Vector3::SIDE_DOWN) || (\pocketmine\math\Vector3::SIDE_EAST < $facing))) {
				return \pocketmine\math\Vector3::SIDE_NORTH;
			}
			if (self::isHorizontalFacing($facing)) {
			} else {
			}
			return $facing;
		}

	public function setFacing($facing = null) {
			$stored = self::logicFacingToMeta($facing);
			$this->meta = (($this->meta & self::META_STICKY) | ($stored & self::META_FACING_MASK));
			return null;
		}

	public function isSticky() {
			return (($this->meta & self::META_STICKY) === self::META_STICKY);
		}

	public function setSticky($sticky = null) {
			/* decompiled (structured CF) */
			if ($sticky) {
				$this->meta |= self::META_STICKY;
			} else {
				$this->meta &= self::META_FACING_MASK;
			}
			return null;
		}

	public function canBePushedByPiston() {
			return false;
		}

	public function canBePulledByPiston() {
			return false;
		}

	public function onBreak($item = null) {
			/* decompiled (structured CF) */
			$facing = $this->getFacing();
			new \pocketmine\block\Air();
			$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), true, true);
			$piston = $this->getSide(\pocketmine\math\Vector3::getOppositeSide($facing));
			if (($piston instanceof \pocketmine\block\PistonBase && ($facing === $piston->getFacing()))) {
				$piston->onBreak($item);
			}
			return true;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if ((($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL) || ($type === \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED))) {
				$piston = $this->getSide(\pocketmine\math\Vector3::getOppositeSide($this->getFacing()));
				if (((!($piston instanceof \pocketmine\block\PistonBase) || ($piston->getFacing() !== $this->getFacing())) || !($piston->isExtended()))) {
					new \pocketmine\block\Air();
					$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), true, false);
				}
				return $type;
			}
			return false;
		}

	public function getDrops($item = null) {
			return ['__array_ptr' => '2aaaac9fc9a0'];
		}

	private static function isHorizontalFacing($facing = null) {
			return (((($facing === \pocketmine\math\Vector3::SIDE_NORTH) || ($facing === \pocketmine\math\Vector3::SIDE_SOUTH)) || ($facing === \pocketmine\math\Vector3::SIDE_WEST)) || ($facing === \pocketmine\math\Vector3::SIDE_EAST));
		}

	private static function logicFacingToMeta($facing = null) {
			/* decompiled (structured CF) */
			$facing = ($facing);
			if ((($facing < \pocketmine\math\Vector3::SIDE_DOWN) || (\pocketmine\math\Vector3::SIDE_EAST < $facing))) {
				return \pocketmine\math\Vector3::SIDE_NORTH;
			}
			if (self::isHorizontalFacing($facing)) {
			} else {
			}
			return $facing;
		}

}
