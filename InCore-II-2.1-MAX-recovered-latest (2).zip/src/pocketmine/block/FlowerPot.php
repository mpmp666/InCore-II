<?php

namespace pocketmine\block;

class FlowerPot extends \pocketmine\block\Flowable {
	protected $id = 140;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function canBeActivated() {
			return true;
		}

	public function getName() {
			return;
		}

	public function getBoundingBox() {
			new \pocketmine\math\AxisAlignedBB(($this->x + 0.3125), $this->y, ($this->z + 0.3125), ($this->x + 0.6875), ($this->y + 0.375), ($this->z + 0.6875));
			return new \pocketmine\math\AxisAlignedBB(($this->x + 0.3125), $this->y, ($this->z + 0.3125), ($this->x + 0.6875), ($this->y + 0.375), ($this->z + 0.6875));
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			if (($this->getSide(\pocketmine\math\Vector3::SIDE_DOWN)->isTransparent() === false)) {
				$this->getLevel()->setBlock($block, $this, true, true);
				new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::FLOWER_POT);
				new \pocketmine\nbt\tag\IntTag('x', $block->x);
				new \pocketmine\nbt\tag\IntTag('y', $block->y);
				new \pocketmine\nbt\tag\IntTag('z', $block->z);
				new \pocketmine\nbt\tag\ShortTag('item', 0);
				new \pocketmine\nbt\tag\IntTag('data', 0);
				new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::FLOWER_POT), new \pocketmine\nbt\tag\IntTag('x', $block->x), new \pocketmine\nbt\tag\IntTag('y', $block->y), new \pocketmine\nbt\tag\IntTag('z', $block->z), new \pocketmine\nbt\tag\ShortTag('item', 0), new \pocketmine\nbt\tag\IntTag('data', 0)]);
				$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::FLOWER_POT), new \pocketmine\nbt\tag\IntTag('x', $block->x), new \pocketmine\nbt\tag\IntTag('y', $block->y), new \pocketmine\nbt\tag\IntTag('z', $block->z), new \pocketmine\nbt\tag\ShortTag('item', 0), new \pocketmine\nbt\tag\IntTag('data', 0)]);
				if ($item->hasCustomBlockData()) {
					foreach ($item->getCustomBlockData() as $key => $v) {
						$nbt->prop = $v;
						/* goto */
					}
				}
				$pot = \pocketmine\tile\Tile::createTile('FlowerPot', $this->getLevel()->getChunk(($this->x >> 4), ($this->z >> 4)), $nbt);
				return true;
			}
			return false;
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			$tile = $this->getLevel()->getTile($this);
			if ($tile instanceof \pocketmine\tile\FlowerPot) {
				if (($tile->getFlowerPotItem() === \pocketmine\item\Item::AIR)) {
					switch ($item->getId()) {
						case \pocketmine\item\Item::TALL_GRASS:
						if (($item->getDamage() === 1)) {
						} else {
						}
						case \pocketmine\item\Item::SAPLING:
						case \pocketmine\item\Item::DEAD_BUSH:
						case \pocketmine\item\Item::DANDELION:
						case \pocketmine\item\Item::RED_FLOWER:
						case \pocketmine\item\Item::BROWN_MUSHROOM:
						case \pocketmine\item\Item::RED_MUSHROOM:
						case \pocketmine\item\Item::CACTUS:
						$tile->setFlowerPotData($item->getId(), $item->getDamage());
						$this->setDamage($item->getId());
						$this->getLevel()->setBlock($this, $this, true, false);
						if ($player->isSurvival()) {
							$item->setCount(($item->getCount() - 1));
							if ((0 < $item->getCount())) {
							} else {
							}
							$player->getInventory()->setItemInHand(\pocketmine\item\Item::get(\pocketmine\item\Item::AIR));
						}
						return true;
						/* jump */
						return false;
					}
				}
			}
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				if ($this->getSide(\pocketmine\math\Vector3::SIDE_DOWN)->isTransparent()) {
					$this->getLevel()->useBreakOn($this);
					return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
				}
			}
			return false;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			$items = [[\pocketmine\item\Item::FLOWER_POT, 0, 1]];
			$tile = $this->getLevel()->getTile($this);
			if ((($this->getLevel() != null) && $tile instanceof \pocketmine\tile\FlowerPot)) {
				if (($tile->getFlowerPotItem() !== \pocketmine\item\Item::AIR)) {
					$items[] = [$tile->getFlowerPotItem(), $tile->getFlowerPotData(), 1];
				}
			}
			return $items;
		}

}
