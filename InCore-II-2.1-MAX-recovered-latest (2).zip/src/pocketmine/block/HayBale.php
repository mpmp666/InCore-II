<?php

namespace pocketmine\block;

class HayBale extends \pocketmine\block\Solid {
	protected $id = 170;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return;
		}

	public function getHardness() {
			return 0.5;
		}

	public function getBurnChance() {
			return 60;
		}

	public function getBurnAbility() {
			return 20;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$faces = ['__array_ptr' => '2aaaadd5d460'];
			$this->meta = (($this->meta & 3) | $faces[$face]);
			$this->getLevel()->setBlock($block, $this, true, true);
			return true;
		}

	public function getDrops($item = null) {
			return [[$this->id, 0, 1]];
		}

}
