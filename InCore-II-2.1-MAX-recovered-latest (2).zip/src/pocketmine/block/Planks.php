<?php

namespace pocketmine\block;

class Planks extends \pocketmine\block\Solid {
	public const OAK = 0;
	public const SPRUCE = 1;
	public const BIRCH = 2;
	public const JUNGLE = 3;
	public const ACACIA = 4;
	public const DARK_OAK = 5;

	protected $id = 5;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getHardness() {
			return 2;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_AXE;
		}

	public function getBurnChance() {
			return 5;
		}

	public function getBurnAbility() {
			return 20;
		}

	public function getName() {
			return $names[($this->meta & 7)];
		}

}
