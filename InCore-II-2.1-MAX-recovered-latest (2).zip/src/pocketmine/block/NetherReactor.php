<?php

namespace pocketmine\block;

class NetherReactor extends \pocketmine\block\Solid {
	protected $id = 247;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return;
		}

	public function canBeActivated() {
			return true;
		}

}
