<?php

namespace pocketmine\block;

abstract class Crops extends \pocketmine\block\Flowable {
	public function canBeActivated() {
			return true;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$down = $this->getSide(0);
			if (($down->getId() === self::FARMLAND)) {
				$this->getLevel()->setBlock($block, $this, true, true);
				return true;
			}
			return false;
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			if ((($item->getId() === \pocketmine\item\Item::DYE) && ($item->getDamage() === 15))) {
				$block = clone $this;
				$block->meta += mt_rand(2, 5);
				if ((7 < $block->meta)) {
					$block->meta = 7;
				}
				new \pocketmine\event\block\BlockGrowEvent($this, $block);
				$ev = new \pocketmine\event\block\BlockGrowEvent($this, $block);
				\pocketmine\Server::getInstance()->getPluginManager()->callEvent($ev);
				if (!($ev->isCancelled())) {
					$this->getLevel()->setBlock($this, $ev->getNewState(), true, true);
				}
				return true;
			}
			return false;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				if (($this->getSide(0)->isTransparent() === true)) {
					$this->getLevel()->useBreakOn($this);
					return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
				}
			} else {
				if (($type === \pocketmine\level\Level::BLOCK_UPDATE_RANDOM)) {
					if ((mt_rand(0, 2) == 1)) {
						if (($this->meta < 7)) {
							$block = clone $this;
							new \pocketmine\event\block\BlockGrowEvent($this, $block);
							$ev = new \pocketmine\event\block\BlockGrowEvent($this, $block);
							\pocketmine\Server::getInstance()->getPluginManager()->callEvent($ev);
							if (!($ev->isCancelled())) {
								$this->getLevel()->setBlock($this, $ev->getNewState(), true, true);
							} else {
								return \pocketmine\level\Level::BLOCK_UPDATE_RANDOM;
							}
						}
					} else {
						return \pocketmine\level\Level::BLOCK_UPDATE_RANDOM;
					}
				}
			}
			return false;
		}

}
