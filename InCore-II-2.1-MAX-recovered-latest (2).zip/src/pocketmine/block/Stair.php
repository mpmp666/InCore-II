<?php

namespace pocketmine\block;

abstract class Stair extends \pocketmine\block\Transparent {
	protected function recalculateBoundingBox() {
			/* decompiled (structured CF) */
			if ((0 < ($this->getDamage() & 4))) {
				new \pocketmine\math\AxisAlignedBB($this->x, ($this->y + 0.5), $this->z, ($this->x + 1), ($this->y + 1), ($this->z + 1));
				return new \pocketmine\math\AxisAlignedBB($this->x, ($this->y + 0.5), $this->z, ($this->x + 1), ($this->y + 1), ($this->z + 1));
			} else {
				new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 0.5), ($this->z + 1));
				return new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 0.5), ($this->z + 1));
			}
		}

	public function getBurnChance() {
			return 5;
		}

	public function getBurnAbility() {
			return 20;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$faces = ['__array_ptr' => '2aaaadd5d6c8'];
			$this->meta = ($faces[$player->getDirection()] & 3);
			if ((((0.5 < $fy) && ($face !== 1)) || ($face === 0))) {
				$this->meta |= 4;
			}
			$this->getLevel()->setBlock($block, $this, true, true);
			return true;
		}

	public function getHardness() {
			return 2;
		}

	public function getResistance() {
			return 15;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((\pocketmine\item\Tool::TIER_WOODEN <= $item->isPickaxe())) {
				return [[$this->getId(), 0, 1]];
			} else {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
		}

}
