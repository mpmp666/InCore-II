<?php

namespace pocketmine\block;

class Leaves2 extends \pocketmine\block\Leaves {
	protected $id = 161;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return $names[($this->meta & 1)];
		}

	private function findLog($pos = null, $visited = null, $distance = null, $check = null, $fromSide = null) {
			/* decompiled (structured CF) */
			$check++;
			$index = (((($pos->x . '.') . $pos->y) . '.') . $pos->z);
			if (isset($visited[$index])) {
				return false;
			}
			if (($pos->getId() === self::WOOD2)) {
				return true;
			} else {
				if ((($pos->getId() === self::LEAVES2) && ($distance < 3))) {
					$visited[$index] = true;
					$down = $pos->getSide(0)->getId();
					if (($down === \pocketmine\item\Item::WOOD2)) {
						return true;
					}
					if (($fromSide === null)) {
						$side = 2;
						while (($side <= 5)) {
							if (($this->findLog($pos->getSide($side), $visited, ($distance + 1), $check, $side) === true)) {
								return true;
							}
							$side++;
						}
					} else {
						if (!(($fromSide == 2))) {
							if (!(($fromSide == 3))) {
								if (!(($fromSide == 4))) {
									if (!(($fromSide == 5))) {
									} else {
										if (($this->findLog($pos->getSide(2), $visited, ($distance + 1), $check, $fromSide) === true)) {
											return true;
										} else {
											if (($this->findLog($pos->getSide(4), $visited, ($distance + 1), $check, $fromSide) === true)) {
												return true;
											} else {
												if (($this->findLog($pos->getSide(5), $visited, ($distance + 1), $check, $fromSide) === true)) {
													return true;
												}
											}
										}
										/* jump */
										if (($this->findLog($pos->getSide(3), $visited, ($distance + 1), $check, $fromSide) === true)) {
											return true;
										} else {
											if (($this->findLog($pos->getSide(4), $visited, ($distance + 1), $check, $fromSide) === true)) {
												return true;
											} else {
												if (($this->findLog($pos->getSide(5), $visited, ($distance + 1), $check, $fromSide) === true)) {
													return true;
												}
											}
										}
										/* jump */
										if (($this->findLog($pos->getSide(2), $visited, ($distance + 1), $check, $fromSide) === true)) {
											return true;
										} else {
											if (($this->findLog($pos->getSide(3), $visited, ($distance + 1), $check, $fromSide) === true)) {
												return true;
											} else {
												if (($this->findLog($pos->getSide(4), $visited, ($distance + 1), $check, $fromSide) === true)) {
													return true;
												}
											}
										}
										/* jump */
										if (($this->findLog($pos->getSide(2), $visited, ($distance + 1), $check, $fromSide) === true)) {
											return true;
										} else {
											if (($this->findLog($pos->getSide(3), $visited, ($distance + 1), $check, $fromSide) === true)) {
												return true;
											} else {
												if (($this->findLog($pos->getSide(5), $visited, ($distance + 1), $check, $fromSide) === true)) {
													return true;
												}
											}
										}
										/* jump */
									}
									return false;
								}
							}
						}
					}
				}
			}
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				if ((($this->meta & 12) === 0)) {
					$this->meta |= 8;
					$this->getLevel()->setBlock($this, $this, false, false, true);
				}
			} else {
				if (($type === \pocketmine\level\Level::BLOCK_UPDATE_RANDOM)) {
					if ((($this->meta & 12) === 8)) {
						$this->meta &= 3;
						$visited = ['__array_ptr' => '2aaaac9fc9a0'];
						$check = 0;
						new \pocketmine\event\block\LeavesDecayEvent($this);
						$ev = new \pocketmine\event\block\LeavesDecayEvent($this);
						\pocketmine\Server::getInstance()->getPluginManager()->callEvent($ev);
						if (($ev->isCancelled() || ($this->findLog($this, $visited, 0, $check) === true))) {
							$this->getLevel()->setBlock($this, $this, false, false);
						} else {
							$this->getLevel()->useBreakOn($this);
							return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
						}
					}
				}
			}
			return false;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			$this->meta |= 4;
			$this->getLevel()->setBlock($this, $this, true);
			return null;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			$drops = ['__array_ptr' => '2aaaac9fc9a0'];
			if (($item->isShears() || (0 < $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_SILK_TOUCH)))) {
				$drops[] = [\pocketmine\item\Item::LEAVES2, ($this->meta & 3), 1];
			} else {
				$fortunel = $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_FORTUNE);
				if ((3 < $fortunel)) {
				} else {
				}
				$fortunel = $fortunel;
				$rates = ['__array_ptr' => '2aaaadd5d4d0'];
				if ((mt_rand(1, $rates[$fortunel]) === 1)) {
					$drops[] = [\pocketmine\item\Item::SAPLING, ($this->meta & 3), 1];
				}
			}
			return $drops;
		}

}
