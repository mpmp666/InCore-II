<?php

namespace pocketmine\block;

class Wood2 extends \pocketmine\block\Wood {
	public const ACACIA = 0;
	public const DARK_OAK = 1;
	public const RAINBOW = 2;

	protected $id = 162;

	public function getName() {
			/* decompiled (structured CF) */
			$meta = ($this->meta & 3);
			if (isset($names[$meta])) {
				return $names[$meta];
			}
			return $this;
		}

}
