<?php

namespace pocketmine\block;

class Redstone extends \pocketmine\block\RedstoneSource {
	protected $id = 152;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getLightLevel() {
			return 7;
		}

	public function getName() {
			return;
		}

	public function isSolid() {
			return true;
		}

	public function isTransparent() {
			return false;
		}

	public function canBeFlowedInto() {
			return false;
		}

	public function getBoundingBox() {
			/* decompiled (structured CF) */
			if (($this->boundingBox === null)) {
				$this->boundingBox = $this->recalculateBoundingBox();
			}
			return $this->boundingBox;
		}

	public function isPowerSource() {
			return true;
		}

	public function getWeakPower($side = null) {
			return 15;
		}

	public function getStrongPower($side = null) {
			return 15;
		}

	public function breaksWhenMovedByPiston() {
			return false;
		}

	public function sticksToPiston() {
			return true;
		}

	public function onUpdate($type = null) {
			return false;
		}

	public function onBreak($item = null) {
			/* decompiled (structured CF) */
			new \pocketmine\block\Air();
			$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), true, false);
			$this->getLevel()->updateAroundRedstone($this);
			return true;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			$this->getLevel()->setBlock($block, $this, true, true);
			$this->getLevel()->updateAroundRedstone($block);
			return true;
		}

	public function getDrops($item = null) {
			return [[\pocketmine\item\Item::REDSTONE_BLOCK, 0, 1]];
		}

	public function isActivated($from = null) {
			return true;
		}

}
