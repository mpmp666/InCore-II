<?php

namespace pocketmine\block;

class Dropper extends \pocketmine\block\Solid implements \pocketmine\block\ElectricalAppliance {
	protected $id = 125;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function canBeActivated() {
			return true;
		}

	public function getHardness() {
			return 3.5;
		}

	public function getName() {
			return 'Dropper';
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$dispenser = null;
			if ($player instanceof \pocketmine\Player) {
				$pitch = $player->getPitch();
				if ((45 <= abs($pitch))) {
					if (($pitch < 0)) {
						$f = 4;
					} else {
						$f = 5;
					}
				} else {
					$f = $player->getDirection();
				}
			} else {
				$f = 0;
			}
			$faces = ['__array_ptr' => '2aaaadd5d460'];
			$this->meta = $faces[$f];
			$this->getLevel()->setBlock($block, $this, true, true);
			new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']);
			new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::DROPPER);
			new \pocketmine\nbt\tag\IntTag('x', $this->x);
			new \pocketmine\nbt\tag\IntTag('y', $this->y);
			new \pocketmine\nbt\tag\IntTag('z', $this->z);
			new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']), new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::DROPPER), new \pocketmine\nbt\tag\IntTag('x', $this->x), new \pocketmine\nbt\tag\IntTag('y', $this->y), new \pocketmine\nbt\tag\IntTag('z', $this->z)]);
			$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']), new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::DROPPER), new \pocketmine\nbt\tag\IntTag('x', $this->x), new \pocketmine\nbt\tag\IntTag('y', $this->y), new \pocketmine\nbt\tag\IntTag('z', $this->z)]);
			$nbt->Items->setTagType(\pocketmine\nbt\NBT::TAG_Compound);
			if ($item->hasCustomName()) {
				new \pocketmine\nbt\tag\StringTag('CustomName', $item->getCustomName());
				$nbt->CustomName = new \pocketmine\nbt\tag\StringTag('CustomName', $item->getCustomName());
			}
			if ($item->hasCustomBlockData()) {
				foreach ($item->getCustomBlockData() as $key => $v) {
					$nbt->prop = $v;
					/* goto */
				}
			}
			\pocketmine\tile\Tile::createTile(\pocketmine\tile\Tile::DROPPER, $this->getLevel()->getChunk(($this->x >> 4), ($this->z >> 4)), $nbt);
			return true;
		}

	public function activate() {
			/* decompiled (structured CF) */
			$tile = $this->getLevel()->getTile($this);
			if ($tile instanceof \pocketmine\tile\Dropper) {
				$tile->activate();
			}
			return null;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if ((($type === \pocketmine\level\Level::BLOCK_UPDATE_REDSTONE) || ($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL))) {
				$powered = ($this->getLevel()->isBlockPowered($this) || $this->getLevel()->isBlockPowered($this->getSide(\pocketmine\math\Vector3::SIDE_UP)));
				$wasPowered = $this->getLevel()->getBlockTempData($this);
				if (($powered && !($wasPowered))) {
					$this->getLevel()->setBlockTempData($this, true);
					if (!($this->getLevel()->isBlockTickPending($this, $this))) {
						$this->getLevel()->scheduleUpdate($this, 4);
					}
				} else {
					if ((!($powered) && $wasPowered)) {
						$this->getLevel()->setBlockTempData($this, null);
					}
				}
				return $type;
			}
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED)) {
				if (($this->getLevel()->isBlockPowered($this) || $this->getLevel()->isBlockPowered($this->getSide(\pocketmine\math\Vector3::SIDE_UP)))) {
					$this->activate();
				}
				return \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED;
			}
			return false;
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			if ($player instanceof \pocketmine\Player) {
				$t = $this->getLevel()->getTile($this);
				$dropper = null;
				if ($t instanceof \pocketmine\tile\Dropper) {
					$dropper = $t;
				} else {
					new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']);
					new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::DROPPER);
					new \pocketmine\nbt\tag\IntTag('x', $this->x);
					new \pocketmine\nbt\tag\IntTag('y', $this->y);
					new \pocketmine\nbt\tag\IntTag('z', $this->z);
					new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']), new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::DROPPER), new \pocketmine\nbt\tag\IntTag('x', $this->x), new \pocketmine\nbt\tag\IntTag('y', $this->y), new \pocketmine\nbt\tag\IntTag('z', $this->z)]);
					$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']), new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::DROPPER), new \pocketmine\nbt\tag\IntTag('x', $this->x), new \pocketmine\nbt\tag\IntTag('y', $this->y), new \pocketmine\nbt\tag\IntTag('z', $this->z)]);
					$nbt->Items->setTagType(\pocketmine\nbt\NBT::TAG_Compound);
					$dropper = \pocketmine\tile\Tile::createTile(\pocketmine\tile\Tile::DROPPER, $this->getLevel()->getChunk(($this->x >> 4), ($this->z >> 4)), $nbt);
				}
				if (($player->isCreative() && $player->getServer()->limitedCreative)) {
					return true;
				}
				$player->addWindow($dropper->getInventory());
			}
			return true;
		}

	public function getDrops($item = null) {
			return [[$this->id, 0, 1]];
		}

	public function hasComparatorInputOverride() {
			return true;
		}

	public function getComparatorInputOverride() {
			/* decompiled (structured CF) */
			$tile = $this->getLevel()->getTile($this);
			if ($tile instanceof \pocketmine\tile\Dropper) {
			} else {
			}
			return 0;
		}

}
