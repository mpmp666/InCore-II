<?php

namespace pocketmine\block;

class Slab extends \pocketmine\block\Transparent {
	public const STONE = 0;
	public const SANDSTONE = 1;
	public const WOODEN = 2;
	public const COBBLESTONE = 3;
	public const BRICK = 4;
	public const STONE_BRICK = 5;
	public const QUARTZ = 6;
	public const NETHER_BRICK = 7;

	protected $id = 44;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getHardness() {
			return 2;
		}

	public function getName() {
			/* decompiled (structured CF) */
			if ((0 < ($this->meta & 8))) {
			} else {
			}
			return (('' . $names[($this->meta & 7)]) . $this);
		}

	public function getBurnChance() {
			/* decompiled (structured CF) */
			$type = ($this->meta & 7);
			if (($type == self::WOODEN)) {
				return 5;
			}
			return 0;
		}

	public function getBurnAbility() {
			/* decompiled (structured CF) */
			$type = ($this->meta & 7);
			if (($type == self::WOODEN)) {
				return 5;
			}
			return 0;
		}

	protected function recalculateBoundingBox() {
			/* decompiled (structured CF) */
			if ((0 < ($this->meta & 8))) {
				new \pocketmine\math\AxisAlignedBB($this->x, ($this->y + 0.5), $this->z, ($this->x + 1), ($this->y + 1), ($this->z + 1));
				return new \pocketmine\math\AxisAlignedBB($this->x, ($this->y + 0.5), $this->z, ($this->x + 1), ($this->y + 1), ($this->z + 1));
			} else {
				new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 0.5), ($this->z + 1));
				return new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 0.5), ($this->z + 1));
			}
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$this->meta &= 7;
			if (($face === 0)) {
				if (((($target->getId() === self::SLAB) && (($target->getDamage() & 8) === 8)) && (($target->getDamage() & 7) === ($this->meta & 7)))) {
					$this->getLevel()->setBlock($target, \pocketmine\block\Block::get(\pocketmine\item\Item::DOUBLE_SLAB, $this->meta), true);
					return true;
				} else {
					if ((($block->getId() === self::SLAB) && (($block->getDamage() & 7) === ($this->meta & 7)))) {
						$this->getLevel()->setBlock($block, \pocketmine\block\Block::get(\pocketmine\item\Item::DOUBLE_SLAB, $this->meta), true);
						return true;
					} else {
						$this->meta |= 8;
					}
				}
			} else {
				if (($face === 1)) {
					if (((($target->getId() === self::SLAB) && (($target->getDamage() & 8) === 0)) && (($target->getDamage() & 7) === ($this->meta & 7)))) {
						$this->getLevel()->setBlock($target, \pocketmine\block\Block::get(\pocketmine\item\Item::DOUBLE_SLAB, $this->meta), true);
						return true;
					} else {
						if ((($block->getId() === self::SLAB) && (($block->getDamage() & 7) === ($this->meta & 7)))) {
							$this->getLevel()->setBlock($block, \pocketmine\block\Block::get(\pocketmine\item\Item::DOUBLE_SLAB, $this->meta), true);
							return true;
						}
					}
				} else {
					if (($block->getId() === self::SLAB)) {
						if ((($block->getDamage() & 7) === ($this->meta & 7))) {
							$this->getLevel()->setBlock($block, \pocketmine\block\Block::get(\pocketmine\item\Item::DOUBLE_SLAB, $this->meta), true);
							return true;
						}
						return false;
					} else {
						if ((0.5 < $fy)) {
							$this->meta |= 8;
						}
					}
				}
			}
			if ((($block->getId() === self::SLAB) && (($target->getDamage() & 7) !== ($this->meta & 7)))) {
				return false;
			}
			$this->getLevel()->setBlock($block, $this, true, true);
			return true;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((1 <= $item->isPickaxe())) {
				return [[$this->id, ($this->meta & 7), 1]];
			} else {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

}
