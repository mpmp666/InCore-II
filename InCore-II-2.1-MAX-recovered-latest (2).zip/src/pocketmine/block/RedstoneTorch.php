<?php

namespace pocketmine\block;

class RedstoneTorch extends \pocketmine\block\RedstoneSource {
	protected $id = 76;
	protected $ignore = '';

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getLightLevel() {
			/* decompiled (structured CF) */
			if (($this->id === self::REDSTONE_TORCH)) {
			} else {
			}
			return 0;
		}

	private function getTorchTempData() {
			/* decompiled (structured CF) */
			$data = $this->getLevel()->getBlockTempData($this);
			if (is_array($data)) {
				return ($data + ['__array_ptr' => '2aaaadd5d690']);
			}
			return [$data, ''];
		}

	public function getLastUpdateTime() {
			$data = $this->getTorchTempData();
			return $data['lastUpdateTime'];
		}

	public function setLastUpdateTimeNow() {
			$this->getLevel()->setBlockTempData($this, [$this->getLevel()->getServer()->getTick(), '']);
			return null;
		}

	private function setScheduledIgnore($ignore = null) {
			/* decompiled (structured CF) */
			$data = $this->getTorchTempData();
			$this->ignore = $ignore;
			$this->getLevel()->setBlockTempData($this, [$data['lastUpdateTime'], $ignore]);
			return null;
		}

	private function popScheduledIgnore() {
			/* decompiled (structured CF) */
			$data = $this->getTorchTempData();
			$this->getLevel()->setBlockTempData($this, [$data['lastUpdateTime'], '']);
			$this->ignore = '';
			return $data['ignore'];
		}

	public function canCalcTurn() {
			/* decompiled (structured CF) */
			if (!(parent::canCalc())) {
				return false;
			}
			if (($this->getLevel()->getServer()->getTick() != $this->getLastUpdateTime())) {
				return true;
			}
			if ($this->canScheduleUpdate()) {
			} else {
			}
			return false;
		}

	public function canScheduleUpdate() {
			return $this->getLevel()->getServer()->allowFrequencyPulse;
		}

	public function getFrequency() {
			return $this->getLevel()->getServer()->pulseFrequency;
		}

	public function getPulseTickDelay() {
			/* decompiled (structured CF) */
			if ($this->canScheduleUpdate()) {
			} else {
			}
			return $this->tickRate();
		}

	public function tickRate() {
			return 2;
		}

	public function getName() {
			return;
		}

	private function getAttachedFace() {
			$faces = [\pocketmine\math\Vector3::SIDE_WEST, \pocketmine\math\Vector3::SIDE_EAST, \pocketmine\math\Vector3::SIDE_NORTH, \pocketmine\math\Vector3::SIDE_SOUTH, \pocketmine\math\Vector3::SIDE_DOWN, \pocketmine\math\Vector3::SIDE_DOWN, \pocketmine\math\Vector3::SIDE_DOWN];
			return \pocketmine\math\Vector3::SIDE_DOWN;
		}

	public function getWeakPower($side = null) {
			/* decompiled (structured CF) */
			if (!($this->isActivated())) {
				return 0;
			}
			if ((\pocketmine\math\Vector3::getOppositeSide($side) === $this->getAttachedFace())) {
			} else {
			}
			return $this->maxStrength;
		}

	public function getStrongPower($side = null) {
			/* decompiled (structured CF) */
			if (($side === \pocketmine\math\Vector3::SIDE_DOWN)) {
			} else {
			}
			return 0;
		}

	private function updateAroundRedstoneExcept($pos = null, $ignore = null) {
			$this->level->updateAroundRedstone($pos, $ignore);
			return null;
		}

	private function updateAllAroundRedstone($ignore = null) {
			/* decompiled (structured CF) */
			$this->updateAroundRedstoneExcept($this, $ignore);
			foreach (\pocketmine\block\Block::BLOCK_SIDES as $side) {
				if (!(in_array($side, $ignore, true))) {
					$this->updateAroundRedstoneExcept($this->getSide($side), [\pocketmine\math\Vector3::getOppositeSide($side)]);
				}
				/* goto */
			}
			return null;
		}

	private function getSupportSide() {
			$faces = ['__array_ptr' => '2aaaadd5d850'];
			return \pocketmine\math\Vector3::SIDE_DOWN;
		}

	private function updateAfterPlace() {
			/* decompiled (structured CF) */
			if (!($this->canCalc())) {
				return null;
			}
			$supportSide = $this->getSupportSide();
			if ($this->isPoweredFromSupportSide()) {
				$this->id = self::UNLIT_REDSTONE_TORCH;
				$this->getLevel()->setBlock($this, $this, true, false);
				$this->deactivateTorch([$supportSide]);
			} else {
				$this->activate([$supportSide]);
			}
		}

	private function isPoweredFromSupportSide() {
			/* decompiled (structured CF) */
			$supportSide = $this->getSupportSide();
			$side = $this->getSide($supportSide);
			if (($side instanceof \pocketmine\block\PistonBase && $side->isGettingPower())) {
				return true;
			}
			return $this->getLevel()->isSidePowered($side, $supportSide);
		}

	public function turnOn($ignore = null) {
			/* decompiled (structured CF) */
			$result = $this->canCalcTurn();
			$this->setLastUpdateTimeNow();
			if (($result === true)) {
				if ($this->getLevel()->checkAndHandleHighFrequencyRedstoneTransition($this, 'torch:on')) {
					return true;
				}
				$supportSide = $this->getSupportSide();
				$this->id = self::REDSTONE_TORCH;
				$this->getLevel()->setBlock($this, $this, true);
				$this->activateTorch([$supportSide], [$ignore]);
				return true;
			} else {
				if (($result === \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED)) {
					$this->setScheduledIgnore($ignore);
					$this->getLevel()->scheduleUpdate($this, $this->getPulseTickDelay());
					return true;
				}
			}
			return false;
		}

	public function turnOff($ignore = null) {
			/* decompiled (structured CF) */
			$result = $this->canCalcTurn();
			$this->setLastUpdateTimeNow();
			if (($result === true)) {
				if ($this->getLevel()->checkAndHandleHighFrequencyRedstoneTransition($this, 'torch:off')) {
					return true;
				}
				$supportSide = $this->getSupportSide();
				$this->id = self::UNLIT_REDSTONE_TORCH;
				$this->getLevel()->setBlock($this, $this, true);
				$this->deactivateTorch([$supportSide], [$ignore]);
				return true;
			} else {
				if (($result === \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED)) {
					$this->setScheduledIgnore($ignore);
					$this->getLevel()->scheduleUpdate($this, $this->getPulseTickDelay());
					return true;
				}
			}
			return false;
		}

	public function activateTorch($ignore = null, $notCheck = null) {
			/* decompiled (structured CF) */
			if ($this->canCalc()) {
				$this->activated = true;
				$sides = [\pocketmine\math\Vector3::SIDE_EAST, \pocketmine\math\Vector3::SIDE_WEST, \pocketmine\math\Vector3::SIDE_SOUTH, \pocketmine\math\Vector3::SIDE_NORTH, \pocketmine\math\Vector3::SIDE_UP, \pocketmine\math\Vector3::SIDE_DOWN];
				foreach ($sides as $side) {
					if (!(in_array($side, $ignore))) {
						$block = $this->getSide($side);
						$hash = \pocketmine\level\Level::blockHash($block->x, $block->y, $block->z);
						if (!(in_array($hash, $notCheck))) {
							$this->activateBlock($block);
						}
					}
					/* goto */
				}
				$this->updateAllAroundRedstone($ignore);
			}
			return null;
		}

	public function activate($ignore = null) {
			$this->activateTorch($ignore);
			return null;
		}

	public function deactivate($ignore = null) {
			$this->deactivateTorch($ignore);
			return null;
		}

	public function deactivateTorch($ignore = null, $notCheck = null) {
			/* decompiled (structured CF) */
			if ($this->canCalc()) {
				$this->activated = false;
				$sides = [\pocketmine\math\Vector3::SIDE_EAST, \pocketmine\math\Vector3::SIDE_WEST, \pocketmine\math\Vector3::SIDE_SOUTH, \pocketmine\math\Vector3::SIDE_NORTH];
				foreach ($sides as $side) {
					if (!(in_array($side, $ignore))) {
						$block = $this->getSide($side);
						$hash = \pocketmine\level\Level::blockHash($block->x, $block->y, $block->z);
						if (!(in_array($hash, $notCheck))) {
							$this->deactivateBlock($block);
						}
					}
					/* goto */
				}
				if (!(in_array(\pocketmine\math\Vector3::SIDE_DOWN, $ignore))) {
					$block = $this->getSide(\pocketmine\math\Vector3::SIDE_DOWN);
					$hash = \pocketmine\level\Level::blockHash($block->x, $block->y, $block->z);
					if (!(in_array($hash, $notCheck))) {
						if (!($this->checkPower($block))) {
							if (($block->getId() == \pocketmine\block\Block::ACTIVE_REDSTONE_LAMP)) {
								$block->turnOff();
							}
						}
						$block = $this->getSide(\pocketmine\math\Vector3::SIDE_DOWN, 2);
						$this->deactivateBlock($block);
					}
				}
				$this->updateAllAroundRedstone($ignore);
			}
			return null;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			$supportSide = $this->getSupportSide();
			if ((($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL) || ($type === \pocketmine\level\Level::BLOCK_UPDATE_REDSTONE))) {
				$below = $this->getSide(0);
				$side = $this->getDamage();
				if ((($this->getSide($supportSide)->isTransparent() === true) && !((($side === 0) && (($below->getId() === self::FENCE) || ($below->getId() === self::COBBLE_WALL)))))) {
					$this->getLevel()->useBreakOn($this);
					return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
				}
				if (!($this->getLevel()->isBlockTickPending($this, $this))) {
					$this->getLevel()->scheduleUpdate($this, $this->getPulseTickDelay());
				}
				return $type;
			}
			if (($type == \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED)) {
				$powered = $this->isPoweredFromSupportSide();
				$ignore = $this->popScheduledIgnore();
				if ((($this->id === self::REDSTONE_TORCH) && $powered)) {
					$this->turnOff($ignore);
				} else {
					if ((($this->id === self::UNLIT_REDSTONE_TORCH) && !($powered))) {
						$this->turnOn($ignore);
					}
				}
				return \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED;
			}
			return false;
		}

	public function onBreak($item = null) {
			/* decompiled (structured CF) */
			$level = $this->getLevel();
			new \pocketmine\block\Air();
			$air = new \pocketmine\block\Air();
			if (!($level->setBlock($this, $air, true, true))) {
				$level->setBlockIdAt($this->x, $this->y, $this->z, self::AIR);
				$level->setBlockDataAt($this->x, $this->y, $this->z, 0);
				$air->position($this);
				$level->sendBlocks($level->getChunkPlayers(($this->x >> 4), ($this->z >> 4)), [$air], \pocketmine\network\protocol\UpdateBlockPacket::FLAG_ALL_PRIORITY);
				$level->updateAround($this);
			}
			$this->deactivate([$this->getSupportSide()]);
			$level->setBlockTempData($this);
			return null;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$below = $this->getSide(0);
			if ((($target->isTransparent() === false) && ($face !== 0))) {
				$faces = ['__array_ptr' => '2aaaadd5d968'];
				$this->meta = $faces[$face];
				$this->getLevel()->setBlock($block, $this, true, true);
				$this->updateAfterPlace();
				return true;
			} else {
				if (((((($below->isTransparent() === false) || ($below->getId() === self::FENCE)) || ($below->getId() === self::COBBLE_WALL)) || ($below->getId() == \pocketmine\block\Block::INACTIVE_REDSTONE_LAMP)) || ($below->getId() == \pocketmine\block\Block::ACTIVE_REDSTONE_LAMP))) {
					$this->meta = 0;
					$this->getLevel()->setBlock($block, $this, true, true);
					$this->updateAfterPlace();
					return true;
				}
			}
			return false;
		}

	public function getDrops($item = null) {
			return [[\pocketmine\item\Item::LIT_REDSTONE_TORCH, 0, 1]];
		}

	public function isActivated($from = null) {
			return ($this->id === self::REDSTONE_TORCH);
		}

}
