<?php

namespace pocketmine\block;

class Block extends \pocketmine\level\Position implements \pocketmine\metadata\Metadatable {
	public const AIR = 0;
	public const STONE = 1;
	public const GRASS = 2;
	public const DIRT = 3;
	public const COBBLESTONE = 4;
	public const COBBLE = 4;
	public const PLANK = 5;
	public const PLANKS = 5;
	public const WOODEN_PLANK = 5;
	public const WOODEN_PLANKS = 5;
	public const SAPLING = 6;
	public const SAPLINGS = 6;
	public const BEDROCK = 7;
	public const WATER = 8;
	public const FLOWING_WATER = 8;
	public const STILL_WATER = 9;
	public const LAVA = 10;
	public const FLOWING_LAVA = 10;
	public const STILL_LAVA = 11;
	public const SAND = 12;
	public const GRAVEL = 13;
	public const GOLD_ORE = 14;
	public const IRON_ORE = 15;
	public const COAL_ORE = 16;
	public const WOOD = 17;
	public const TRUNK = 17;
	public const LOG = 17;
	public const LEAVES = 18;
	public const LEAVE = 18;
	public const SPONGE = 19;
	public const GLASS = 20;
	public const LAPIS_ORE = 21;
	public const LAPIS_BLOCK = 22;
	public const SANDSTONE = 24;
	public const DISPENSER = 23;
	public const NOTEBLOCK = 25;
	public const BED_BLOCK = 26;
	public const POWERED_RAIL = 27;
	public const DETECTOR_RAIL = 28;
	public const STICKY_PISTON = 29;
	public const COBWEB = 30;
	public const PISTON = 33;
	public const PISTON_HEAD = 34;
	public const PISTON_EXTENSION = 34;
	public const TALL_GRASS = 31;
	public const BUSH = 32;
	public const DEAD_BUSH = 32;
	public const WOOL = 35;
	public const MOVING_BLOCK = 36;
	public const DANDELION = 37;
	public const ROSE = 38;
	public const POPPY = 38;
	public const RED_FLOWER = 38;
	public const BROWN_MUSHROOM = 39;
	public const RED_MUSHROOM = 40;
	public const GOLD_BLOCK = 41;
	public const IRON_BLOCK = 42;
	public const DOUBLE_SLAB = 43;
	public const DOUBLE_SLABS = 43;
	public const DOUBLE_STONE_SLAB = 43;
	public const SLAB = 44;
	public const STONE_SLAB = 44;
	public const SLABS = 44;
	public const BRICKS = 45;
	public const BRICKS_BLOCK = 45;
	public const TNT = 46;
	public const BOOKSHELF = 47;
	public const MOSS_STONE = 48;
	public const MOSSY_STONE = 48;
	public const OBSIDIAN = 49;
	public const TORCH = 50;
	public const FIRE = 51;
	public const MONSTER_SPAWNER = 52;
	public const WOOD_STAIRS = 53;
	public const WOODEN_STAIRS = 53;
	public const OAK_WOOD_STAIRS = 53;
	public const OAK_WOODEN_STAIRS = 53;
	public const CHEST = 54;
	public const REDSTONE_WIRE = 55;
	public const DIAMOND_ORE = 56;
	public const DIAMOND_BLOCK = 57;
	public const CRAFTING_TABLE = 58;
	public const WORKBENCH = 58;
	public const WHEAT_BLOCK = 59;
	public const FARMLAND = 60;
	public const FURNACE = 61;
	public const BURNING_FURNACE = 62;
	public const LIT_FURNACE = 62;
	public const SIGN_POST = 63;
	public const DOOR_BLOCK = 64;
	public const WOODEN_DOOR_BLOCK = 64;
	public const WOOD_DOOR_BLOCK = 64;
	public const LADDER = 65;
	public const COBBLE_STAIRS = 67;
	public const COBBLESTONE_STAIRS = 67;
	public const WALL_SIGN = 68;
	public const IRON_DOOR_BLOCK = 71;
	public const LEVER = 69;
	public const STONE_PRESSURE_PLATE = 70;
	public const WOODEN_PRESSURE_PLATE = 72;
	public const REDSTONE_ORE = 73;
	public const GLOWING_REDSTONE_ORE = 74;
	public const LIT_REDSTONE_ORE = 74;
	public const UNLIT_REDSTONE_TORCH = 75;
	public const REDSTONE_TORCH = 76;
	public const STONE_BUTTON = 77;
	public const SNOW = 78;
	public const SNOW_LAYER = 78;
	public const ICE = 79;
	public const SNOW_BLOCK = 80;
	public const CACTUS = 81;
	public const CLAY_BLOCK = 82;
	public const REEDS = 83;
	public const SUGARCANE_BLOCK = 83;
	public const FENCE = 85;
	public const PUMPKIN = 86;
	public const NETHERRACK = 87;
	public const SOUL_SAND = 88;
	public const GLOWSTONE = 89;
	public const GLOWSTONE_BLOCK = 89;
	public const PORTAL = 90;
	public const LIT_PUMPKIN = 91;
	public const JACK_O_LANTERN = 91;
	public const CAKE_BLOCK = 92;
	public const UNPOWERED_REPEATER = 93;
	public const POWERED_REPEATER = 94;
	public const INVISIBLE_BEDROCK = 95;
	public const TRAPDOOR = 96;
	public const WOODEN_TRAPDOOR = 96;
	public const WOOD_TRAPDOOR = 96;
	public const MONSTER_EGG_BLOCK = 97;
	public const STONE_BRICKS = 98;
	public const STONE_BRICK = 98;
	public const BROWN_MUSHROOM_BLOCK = 99;
	public const RED_MUSHROOM_BLOCK = 100;
	public const IRON_BAR = 101;
	public const IRON_BARS = 101;
	public const GLASS_PANE = 102;
	public const GLASS_PANEL = 102;
	public const MELON_BLOCK = 103;
	public const PUMPKIN_STEM = 104;
	public const MELON_STEM = 105;
	public const VINE = 106;
	public const VINES = 106;
	public const FENCE_GATE = 107;
	public const BRICK_STAIRS = 108;
	public const STONE_BRICK_STAIRS = 109;
	public const MYCELIUM = 110;
	public const WATER_LILY = 111;
	public const LILY_PAD = 111;
	public const NETHER_BRICKS = 112;
	public const NETHER_BRICK_BLOCK = 112;
	public const NETHER_BRICKS_STAIRS = 114;
	public const NETHER_WART_BLOCK = 115;
	public const ENCHANTING_TABLE = 116;
	public const ENCHANT_TABLE = 116;
	public const ENCHANTMENT_TABLE = 116;
	public const BREWING_STAND_BLOCK = 117;
	public const CAULDRON_BLOCK = 118;
	public const END_PORTAL_FRAME = 120;
	public const END_STONE = 121;
	public const INACTIVE_REDSTONE_LAMP = 123;
	public const ACTIVE_REDSTONE_LAMP = 124;
	public const DROPPER = 125;
	public const ACTIVATOR_RAIL = 126;
	public const COCOA_BLOCK = 127;
	public const COCOA_PODS = 127;
	public const SANDSTONE_STAIRS = 128;
	public const EMERALD_ORE = 129;
	public const TRIPWIRE_HOOK = 131;
	public const TRIPWIRE = 132;
	public const EMERALD_BLOCK = 133;
	public const SPRUCE_WOOD_STAIRS = 134;
	public const SPRUCE_WOODEN_STAIRS = 134;
	public const BIRCH_WOOD_STAIRS = 135;
	public const BIRCH_WOODEN_STAIRS = 135;
	public const JUNGLE_WOOD_STAIRS = 136;
	public const JUNGLE_WOODEN_STAIRS = 136;
	public const COBBLE_WALL = 139;
	public const STONE_WALL = 139;
	public const COBBLESTONE_WALL = 139;
	public const FLOWER_POT_BLOCK = 140;
	public const CARROT_BLOCK = 141;
	public const POTATO_BLOCK = 142;
	public const WOODEN_BUTTON = 143;
	public const SKULL_BLOCK = 144;
	public const ANVIL = 145;
	public const TRAPPED_CHEST = 146;
	public const LIGHT_WEIGHTED_PRESSURE_PLATE = 147;
	public const HEAVY_WEIGHTED_PRESSURE_PLATE = 148;
	public const UNPOWERED_COMPARATOR = 149;
	public const POWERED_COMPARATOR = 150;
	public const DAYLIGHT_SENSOR = 151;
	public const DAYLIGHT_SENSOR_INVERTED = 178;
	public const REDSTONE_BLOCK = 152;
	public const NETHER_QUARTZ_ORE = 153;
	public const HOPPER_BLOCK = 154;
	public const QUARTZ_BLOCK = 155;
	public const QUARTZ_STAIRS = 156;
	public const DOUBLE_WOOD_SLAB = 157;
	public const DOUBLE_WOODEN_SLAB = 157;
	public const DOUBLE_WOOD_SLABS = 157;
	public const DOUBLE_WOODEN_SLABS = 157;
	public const WOOD_SLAB = 158;
	public const WOODEN_SLAB = 158;
	public const WOOD_SLABS = 158;
	public const WOODEN_SLABS = 158;
	public const STAINED_CLAY = 159;
	public const STAINED_HARDENED_CLAY = 159;
	public const LEAVES2 = 161;
	public const LEAVE2 = 161;
	public const WOOD2 = 162;
	public const TRUNK2 = 162;
	public const LOG2 = 162;
	public const ACACIA_WOOD_STAIRS = 163;
	public const ACACIA_WOODEN_STAIRS = 163;
	public const DARK_OAK_WOOD_STAIRS = 164;
	public const DARK_OAK_WOODEN_STAIRS = 164;
	public const SLIME_BLOCK = 165;
	public const IRON_TRAPDOOR = 167;
	public const HAY_BALE = 170;
	public const CARPET = 171;
	public const HARDENED_CLAY = 172;
	public const COAL_BLOCK = 173;
	public const PACKED_ICE = 174;
	public const DOUBLE_PLANT = 175;
	public const RED_SANDSTONE = 179;
	public const RED_SANDSTONE_STAIRS = 180;
	public const DOUBLE_RED_SANDSTONE_SLAB = 181;
	public const RED_SANDSTONE_SLAB = 182;
	public const STONE_SLAB2 = 182;
	public const FENCE_GATE_SPRUCE = 183;
	public const FENCE_GATE_BIRCH = 184;
	public const FENCE_GATE_JUNGLE = 185;
	public const FENCE_GATE_DARK_OAK = 186;
	public const FENCE_GATE_ACACIA = 187;
	public const SPRUCE_DOOR_BLOCK = 193;
	public const BIRCH_DOOR_BLOCK = 194;
	public const JUNGLE_DOOR_BLOCK = 195;
	public const ACACIA_DOOR_BLOCK = 196;
	public const DARK_OAK_DOOR_BLOCK = 197;
	public const GRASS_PATH = 198;
	public const ITEM_FRAME_BLOCK = 199;
	public const PODZOL = 243;
	public const BEETROOT_BLOCK = 244;
	public const STONECUTTER = 245;
	public const GLOWING_OBSIDIAN = 246;
	public const NETHER_REACTOR = 247;
	public const OBSERVER = 251;
	public const CAMERA = 439;
	public const NETHER_BRICK_FENCE = 113;
	public const RAIL = 66;
	public const BLOCK_SIDES = array (
  0 => 0,
  1 => 1,
  2 => 2,
  3 => 3,
  4 => 4,
  5 => 5,
);

	public static $list = NULL;
	public static $fullList = NULL;
	public static $light = NULL;
	public static $lightFilter = NULL;
	public static $solid = NULL;
	public static $hardness = NULL;
	public static $transparent = NULL;
	protected $id = NULL;
	protected $meta = 0;
	public $boundingBox = NULL;

	public function __get($key = null) {
			/* decompiled (structured CF) */
			if (isset($map[$key])) {
			} else {
			}
			return null;
		}

	public static function init() {
			/* decompiled (structured CF) */
			if ((self::$list === null)) {
				new \SplFixedArray(256);
				self::$list = new \SplFixedArray(256);
				new \SplFixedArray(4096);
				self::$fullList = new \SplFixedArray(4096);
				new \SplFixedArray(256);
				self::$light = new \SplFixedArray(256);
				new \SplFixedArray(256);
				self::$lightFilter = new \SplFixedArray(256);
				new \SplFixedArray(256);
				self::$solid = new \SplFixedArray(256);
				new \SplFixedArray(256);
				self::$hardness = new \SplFixedArray(256);
				new \SplFixedArray(256);
				self::$transparent = new \SplFixedArray(256);
				self::$list[self::AIR] = 'pocketmine\\block\\Air';
				self::$list[self::STONE] = 'pocketmine\\block\\Stone';
				self::$list[self::GRASS] = 'pocketmine\\block\\Grass';
				self::$list[self::DIRT] = 'pocketmine\\block\\Dirt';
				self::$list[self::COBBLESTONE] = 'pocketmine\\block\\Cobblestone';
				self::$list[self::PLANKS] = 'pocketmine\\block\\Planks';
				self::$list[self::SAPLING] = 'pocketmine\\block\\Sapling';
				self::$list[self::BEDROCK] = 'pocketmine\\block\\Bedrock';
				self::$list[self::WATER] = 'pocketmine\\block\\Water';
				self::$list[self::STILL_WATER] = 'pocketmine\\block\\StillWater';
				self::$list[self::LAVA] = 'pocketmine\\block\\Lava';
				self::$list[self::STILL_LAVA] = 'pocketmine\\block\\StillLava';
				self::$list[self::SAND] = 'pocketmine\\block\\Sand';
				self::$list[self::GRAVEL] = 'pocketmine\\block\\Gravel';
				self::$list[self::GOLD_ORE] = 'pocketmine\\block\\GoldOre';
				self::$list[self::IRON_ORE] = 'pocketmine\\block\\IronOre';
				self::$list[self::COAL_ORE] = 'pocketmine\\block\\CoalOre';
				self::$list[self::WOOD] = 'pocketmine\\block\\Wood';
				self::$list[self::LEAVES] = 'pocketmine\\block\\Leaves';
				self::$list[self::SPONGE] = 'pocketmine\\block\\Sponge';
				self::$list[self::GLASS] = 'pocketmine\\block\\Glass';
				self::$list[self::LAPIS_ORE] = 'pocketmine\\block\\LapisOre';
				self::$list[self::LAPIS_BLOCK] = 'pocketmine\\block\\Lapis';
				self::$list[self::SANDSTONE] = 'pocketmine\\block\\Sandstone';
				self::$list[self::RED_SANDSTONE] = 'pocketmine\\block\\RedSandstone';
				self::$list[self::RED_SANDSTONE_STAIRS] = 'pocketmine\\block\\RedSandstoneStairs';
				self::$list[self::BED_BLOCK] = 'pocketmine\\block\\Bed';
				self::$list[self::COBWEB] = 'pocketmine\\block\\Cobweb';
				self::$list[self::TALL_GRASS] = 'pocketmine\\block\\TallGrass';
				self::$list[self::DEAD_BUSH] = 'pocketmine\\block\\DeadBush';
				self::$list[self::WOOL] = 'pocketmine\\block\\Wool';
				self::$list[self::DANDELION] = 'pocketmine\\block\\Dandelion';
				self::$list[self::RED_FLOWER] = 'pocketmine\\block\\Flower';
				self::$list[self::BROWN_MUSHROOM] = 'pocketmine\\block\\BrownMushroom';
				self::$list[self::RED_MUSHROOM] = 'pocketmine\\block\\RedMushroom';
				self::$list[self::GOLD_BLOCK] = 'pocketmine\\block\\Gold';
				self::$list[self::IRON_BLOCK] = 'pocketmine\\block\\Iron';
				self::$list[self::DOUBLE_SLAB] = 'pocketmine\\block\\DoubleSlab';
				self::$list[self::SLAB] = 'pocketmine\\block\\Slab';
				self::$list[self::RED_SANDSTONE_SLAB] = 'pocketmine\\block\\RedSandstoneSlab';
				self::$list[self::DOUBLE_RED_SANDSTONE_SLAB] = 'pocketmine\\block\\DoubleRedSandstoneSlab';
				self::$list[self::BRICKS_BLOCK] = 'pocketmine\\block\\Bricks';
				self::$list[self::TNT] = 'pocketmine\\block\\TNT';
				self::$list[self::BOOKSHELF] = 'pocketmine\\block\\Bookshelf';
				self::$list[self::MOSS_STONE] = 'pocketmine\\block\\MossStone';
				self::$list[self::OBSIDIAN] = 'pocketmine\\block\\Obsidian';
				self::$list[self::TORCH] = 'pocketmine\\block\\Torch';
				self::$list[self::FIRE] = 'pocketmine\\block\\Fire';
				self::$list[self::MONSTER_SPAWNER] = 'pocketmine\\block\\MonsterSpawner';
				self::$list[self::WOOD_STAIRS] = 'pocketmine\\block\\WoodStairs';
				self::$list[self::CHEST] = 'pocketmine\\block\\Chest';
				self::$list[self::DIAMOND_ORE] = 'pocketmine\\block\\DiamondOre';
				self::$list[self::DIAMOND_BLOCK] = 'pocketmine\\block\\Diamond';
				self::$list[self::WORKBENCH] = 'pocketmine\\block\\Workbench';
				self::$list[self::WHEAT_BLOCK] = 'pocketmine\\block\\Wheat';
				self::$list[self::FARMLAND] = 'pocketmine\\block\\Farmland';
				self::$list[self::FURNACE] = 'pocketmine\\block\\Furnace';
				self::$list[self::BURNING_FURNACE] = 'pocketmine\\block\\BurningFurnace';
				self::$list[self::SIGN_POST] = 'pocketmine\\block\\SignPost';
				self::$list[self::WOOD_DOOR_BLOCK] = 'pocketmine\\block\\WoodDoor';
				self::$list[self::SPRUCE_DOOR_BLOCK] = 'pocketmine\\block\\SpruceDoor';
				self::$list[self::BIRCH_DOOR_BLOCK] = 'pocketmine\\block\\BirchDoor';
				self::$list[self::JUNGLE_DOOR_BLOCK] = 'pocketmine\\block\\JungleDoor';
				self::$list[self::ACACIA_DOOR_BLOCK] = 'pocketmine\\block\\AcaciaDoor';
				self::$list[self::DARK_OAK_DOOR_BLOCK] = 'pocketmine\\block\\DarkOakDoor';
				self::$list[self::LADDER] = 'pocketmine\\block\\Ladder';
				self::$list[self::COBBLESTONE_STAIRS] = 'pocketmine\\block\\CobblestoneStairs';
				self::$list[self::WALL_SIGN] = 'pocketmine\\block\\WallSign';
				self::$list[self::IRON_DOOR_BLOCK] = 'pocketmine\\block\\IronDoor';
				self::$list[self::REDSTONE_ORE] = 'pocketmine\\block\\RedstoneOre';
				self::$list[self::GLOWING_REDSTONE_ORE] = 'pocketmine\\block\\GlowingRedstoneOre';
				self::$list[self::SNOW_LAYER] = 'pocketmine\\block\\SnowLayer';
				self::$list[self::ICE] = 'pocketmine\\block\\Ice';
				self::$list[self::SNOW_BLOCK] = 'pocketmine\\block\\Snow';
				self::$list[self::CACTUS] = 'pocketmine\\block\\Cactus';
				self::$list[self::CLAY_BLOCK] = 'pocketmine\\block\\Clay';
				self::$list[self::SUGARCANE_BLOCK] = 'pocketmine\\block\\Sugarcane';
				self::$list[self::FENCE] = 'pocketmine\\block\\Fence';
				self::$list[self::PUMPKIN] = 'pocketmine\\block\\Pumpkin';
				self::$list[self::NETHERRACK] = 'pocketmine\\block\\Netherrack';
				self::$list[self::SOUL_SAND] = 'pocketmine\\block\\SoulSand';
				self::$list[self::GLOWSTONE_BLOCK] = 'pocketmine\\block\\Glowstone';
				self::$list[self::LIT_PUMPKIN] = 'pocketmine\\block\\LitPumpkin';
				self::$list[self::CAKE_BLOCK] = 'pocketmine\\block\\Cake';
				self::$list[self::TRAPDOOR] = 'pocketmine\\block\\Trapdoor';
				self::$list[self::IRON_TRAPDOOR] = 'pocketmine\\block\\IronTrapdoor';
				self::$list[self::STONE_BRICKS] = 'pocketmine\\block\\StoneBricks';
				self::$list[self::BROWN_MUSHROOM_BLOCK] = 'pocketmine\\block\\BrownMushroomBlock';
				self::$list[self::RED_MUSHROOM_BLOCK] = 'pocketmine\\block\\RedMushroomBlock';
				self::$list[self::IRON_BARS] = 'pocketmine\\block\\IronBars';
				self::$list[self::GLASS_PANE] = 'pocketmine\\block\\GlassPane';
				self::$list[self::MELON_BLOCK] = 'pocketmine\\block\\Melon';
				self::$list[self::PUMPKIN_STEM] = 'pocketmine\\block\\PumpkinStem';
				self::$list[self::MELON_STEM] = 'pocketmine\\block\\MelonStem';
				self::$list[self::VINE] = 'pocketmine\\block\\Vine';
				self::$list[self::FENCE_GATE] = 'pocketmine\\block\\FenceGate';
				self::$list[self::BRICK_STAIRS] = 'pocketmine\\block\\BrickStairs';
				self::$list[self::STONE_BRICK_STAIRS] = 'pocketmine\\block\\StoneBrickStairs';
				self::$list[self::MYCELIUM] = 'pocketmine\\block\\Mycelium';
				self::$list[self::WATER_LILY] = 'pocketmine\\block\\WaterLily';
				self::$list[self::NETHER_BRICKS] = 'pocketmine\\block\\NetherBrick';
				self::$list[self::PORTAL] = 'pocketmine\\block\\Portal';
				self::$list[self::NETHER_BRICKS_STAIRS] = 'pocketmine\\block\\NetherBrickStairs';
				self::$list[self::NETHER_WART_BLOCK] = 'pocketmine\\block\\NetherWart';
				self::$list[self::ENCHANTING_TABLE] = 'pocketmine\\block\\EnchantingTable';
				self::$list[self::BREWING_STAND_BLOCK] = 'pocketmine\\block\\BrewingStand';
				self::$list[self::END_PORTAL_FRAME] = 'pocketmine\\block\\EndPortalFrame';
				self::$list[self::END_STONE] = 'pocketmine\\block\\EndStone';
				self::$list[self::SANDSTONE_STAIRS] = 'pocketmine\\block\\SandstoneStairs';
				self::$list[self::EMERALD_ORE] = 'pocketmine\\block\\EmeraldOre';
				self::$list[self::EMERALD_BLOCK] = 'pocketmine\\block\\Emerald';
				self::$list[self::SPRUCE_WOOD_STAIRS] = 'pocketmine\\block\\SpruceWoodStairs';
				self::$list[self::BIRCH_WOOD_STAIRS] = 'pocketmine\\block\\BirchWoodStairs';
				self::$list[self::JUNGLE_WOOD_STAIRS] = 'pocketmine\\block\\JungleWoodStairs';
				self::$list[self::STONE_WALL] = 'pocketmine\\block\\StoneWall';
				self::$list[self::FLOWER_POT_BLOCK] = 'pocketmine\\block\\FlowerPot';
				self::$list[self::CARROT_BLOCK] = 'pocketmine\\block\\Carrot';
				self::$list[self::POTATO_BLOCK] = 'pocketmine\\block\\Potato';
				self::$list[self::ANVIL] = 'pocketmine\\block\\Anvil';
				self::$list[self::TRAPPED_CHEST] = 'pocketmine\\block\\TrappedChest';
				self::$list[self::UNPOWERED_COMPARATOR] = 'pocketmine\\block\\UnpoweredComparator';
				self::$list[self::POWERED_COMPARATOR] = 'pocketmine\\block\\PoweredComparator';
				self::$list[self::REDSTONE_BLOCK] = 'pocketmine\\block\\Redstone';
				self::$list[self::QUARTZ_BLOCK] = 'pocketmine\\block\\Quartz';
				self::$list[self::QUARTZ_STAIRS] = 'pocketmine\\block\\QuartzStairs';
				self::$list[self::DOUBLE_WOOD_SLAB] = 'pocketmine\\block\\DoubleWoodSlab';
				self::$list[self::WOOD_SLAB] = 'pocketmine\\block\\WoodSlab';
				self::$list[self::STAINED_CLAY] = 'pocketmine\\block\\StainedClay';
				self::$list[self::LEAVES2] = 'pocketmine\\block\\Leaves2';
				self::$list[self::WOOD2] = 'pocketmine\\block\\Wood2';
				self::$list[self::ACACIA_WOOD_STAIRS] = 'pocketmine\\block\\AcaciaWoodStairs';
				self::$list[self::DARK_OAK_WOOD_STAIRS] = 'pocketmine\\block\\DarkOakWoodStairs';
				self::$list[self::SLIME_BLOCK] = 'pocketmine\\block\\SlimeBlock';
				self::$list[self::HAY_BALE] = 'pocketmine\\block\\HayBale';
				self::$list[self::CARPET] = 'pocketmine\\block\\Carpet';
				self::$list[self::HARDENED_CLAY] = 'pocketmine\\block\\HardenedClay';
				self::$list[self::COAL_BLOCK] = 'pocketmine\\block\\Coal';
				self::$list[self::PACKED_ICE] = 'pocketmine\\block\\PackedIce';
				self::$list[self::DOUBLE_PLANT] = 'pocketmine\\block\\DoublePlant';
				self::$list[self::FENCE_GATE_SPRUCE] = 'pocketmine\\block\\FenceGateSpruce';
				self::$list[self::FENCE_GATE_BIRCH] = 'pocketmine\\block\\FenceGateBirch';
				self::$list[self::FENCE_GATE_JUNGLE] = 'pocketmine\\block\\FenceGateJungle';
				self::$list[self::FENCE_GATE_DARK_OAK] = 'pocketmine\\block\\FenceGateDarkOak';
				self::$list[self::FENCE_GATE_ACACIA] = 'pocketmine\\block\\FenceGateAcacia';
				self::$list[self::GRASS_PATH] = 'pocketmine\\block\\GrassPath';
				self::$list[self::PODZOL] = 'pocketmine\\block\\Podzol';
				self::$list[self::BEETROOT_BLOCK] = 'pocketmine\\block\\Beetroot';
				self::$list[self::STONECUTTER] = 'pocketmine\\block\\Stonecutter';
				self::$list[self::GLOWING_OBSIDIAN] = 'pocketmine\\block\\GlowingObsidian';
				self::$list[self::NETHER_REACTOR] = 'pocketmine\\block\\NetherReactor';
				self::$list[self::NETHER_BRICK_FENCE] = 'pocketmine\\block\\NetherBrickFence';
				self::$list[self::POWERED_RAIL] = 'pocketmine\\block\\PoweredRail';
				self::$list[self::RAIL] = 'pocketmine\\block\\Rail';
				self::$list[self::PISTON] = 'pocketmine\\block\\Piston';
				self::$list[self::STICKY_PISTON] = 'pocketmine\\block\\StickyPiston';
				self::$list[self::PISTON_HEAD] = 'pocketmine\\block\\PistonHead';
				self::$list[self::MOVING_BLOCK] = 'pocketmine\\block\\MovingBlock';
				self::$list[self::WOODEN_PRESSURE_PLATE] = 'pocketmine\\block\\WoodenPressurePlate';
				self::$list[self::STONE_PRESSURE_PLATE] = 'pocketmine\\block\\StonePressurePlate';
				self::$list[self::LIGHT_WEIGHTED_PRESSURE_PLATE] = 'pocketmine\\block\\LightWeightedPressurePlate';
				self::$list[self::HEAVY_WEIGHTED_PRESSURE_PLATE] = 'pocketmine\\block\\HeavyWeightedPressurePlate';
				self::$list[self::REDSTONE_WIRE] = 'pocketmine\\block\\RedstoneWire';
				self::$list[self::ACTIVE_REDSTONE_LAMP] = 'pocketmine\\block\\ActiveRedstoneLamp';
				self::$list[self::INACTIVE_REDSTONE_LAMP] = 'pocketmine\\block\\InactiveRedstoneLamp';
				self::$list[self::REDSTONE_TORCH] = 'pocketmine\\block\\RedstoneTorch';
				self::$list[self::UNLIT_REDSTONE_TORCH] = 'pocketmine\\block\\UnlitRedstoneTorch';
				self::$list[self::WOODEN_BUTTON] = 'pocketmine\\block\\WoodenButton';
				self::$list[self::STONE_BUTTON] = 'pocketmine\\block\\StoneButton';
				self::$list[self::LEVER] = 'pocketmine\\block\\Lever';
				self::$list[self::DAYLIGHT_SENSOR] = 'pocketmine\\block\\DaylightDetector';
				self::$list[self::DAYLIGHT_SENSOR_INVERTED] = 'pocketmine\\block\\DaylightDetectorInverted';
				self::$list[self::NOTEBLOCK] = 'pocketmine\\block\\Noteblock';
				self::$list[self::SKULL_BLOCK] = 'pocketmine\\block\\SkullBlock';
				self::$list[self::NETHER_QUARTZ_ORE] = 'pocketmine\\block\\NetherQuartzOre';
				self::$list[self::ACTIVATOR_RAIL] = 'pocketmine\\block\\ActivatorRail';
				self::$list[self::COCOA_BLOCK] = 'pocketmine\\block\\CocoaBlock';
				self::$list[self::DETECTOR_RAIL] = 'pocketmine\\block\\DetectorRail';
				self::$list[self::TRIPWIRE] = 'pocketmine\\block\\Tripwire';
				self::$list[self::TRIPWIRE_HOOK] = 'pocketmine\\block\\TripwireHook';
				self::$list[self::ITEM_FRAME_BLOCK] = 'pocketmine\\block\\ItemFrame';
				self::$list[self::DISPENSER] = 'pocketmine\\block\\Dispenser';
				self::$list[self::DROPPER] = 'pocketmine\\block\\Dropper';
				self::$list[self::POWERED_REPEATER] = 'pocketmine\\block\\PoweredRepeater';
				self::$list[self::UNPOWERED_REPEATER] = 'pocketmine\\block\\UnpoweredRepeater';
				self::$list[self::OBSERVER] = 'pocketmine\\block\\Observer';
				self::$list[self::CAULDRON_BLOCK] = 'pocketmine\\block\\Cauldron';
				self::$list[self::INVISIBLE_BEDROCK] = 'pocketmine\\block\\InvisibleBedrock';
				self::$list[self::HOPPER_BLOCK] = 'pocketmine\\block\\Hopper';
				foreach (self::$list as $id => $class) {
					if (($class !== null)) {
						new $class();
						$block = new $class();
						$data = 0;
						while (($data < 16)) {
							new $class($data);
							self::$fullList[($data | ($id << 4))] = new $class($data);
							$data++;
						}
						self::$solid[$id] = $block->isSolid();
						self::$transparent[$id] = $block->isTransparent();
						self::$hardness[$id] = $block->getHardness();
						self::$light[$id] = $block->getLightLevel();
						if ($block->isSolid()) {
							if ($block->isTransparent()) {
								if ($block instanceof \pocketmine\block\Lava) {
									self::$lightFilter[$id] = 15;
								} else {
									if (($block instanceof \pocketmine\block\Liquid || $block instanceof \pocketmine\block\Ice)) {
										self::$lightFilter[$id] = 2;
									} else {
										self::$lightFilter[$id] = 1;
									}
								}
							} else {
								if (($block->getId() == 89)) {
									self::$lightFilter[$id] = 1;
								} else {
									self::$lightFilter[$id] = 15;
								}
							}
						} else {
							self::$lightFilter[$id] = 1;
						}
					} else {
						self::$lightFilter[$id] = 1;
						$data = 0;
						while (($data < 16)) {
							new \pocketmine\block\Block($id, $data);
							self::$fullList[($data | ($id << 4))] = new \pocketmine\block\Block($id, $data);
							$data++;
						}
					}
					/* goto */
				}
			}
			return null;
		}

	public static function get($id = null, $meta = null, $pos = null) {
			/* decompiled (structured CF) */
			$block = self::$list[$id];
			if (($block !== null)) {
				new $block($meta);
				$block = new $block($meta);
			} else {
				new \pocketmine\block\Block($id, $meta);
				$block = new \pocketmine\block\Block($id, $meta);
			}
			/* jump */
			new \pocketmine\block\Block($id, $meta);
			$block = new \pocketmine\block\Block($id, $meta);
			if (($pos !== null)) {
				$block->x = $pos->x;
				$block->y = $pos->y;
				$block->z = $pos->z;
				$block->level = $pos->level;
			}
			return $block;
		}

	public function __construct($id = null, $meta = null) {
			$this->id = ($id);
			$this->meta = ($meta);
			return;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			return $this->getLevel()->setBlock($this, $this, true, true);
		}

	public function isBreakable($item = null) {
			return true;
		}

	public function tickRate() {
			return 10;
		}

	public function onBreak($item = null) {
			new \pocketmine\block\Air();
			return $this->getLevel()->setBlock($this, new \pocketmine\block\Air(), true, true);
		}

	public function onUpdate($type = null) {
			return null;
		}

	public function onActivate($item = null, $player = null) {
			return false;
		}

	public function getHardness() {
			return 10;
		}

	public function getResistance() {
			return ($this->getHardness() * 5);
		}

	public function getBurnChance() {
			return 0;
		}

	public function getBurnAbility() {
			return 0;
		}

	public function isTopFacingSurfaceSolid() {
			/* decompiled (structured CF) */
			if ($this->isSolid()) {
				return true;
			} else {
				if (($this instanceof \pocketmine\block\Stair && (($this->getDamage() & 4) == 4))) {
					return true;
				} else {
					if (($this instanceof \pocketmine\block\Slab && (($this->getDamage() & 8) == 8))) {
						return true;
					} else {
						if (($this instanceof \pocketmine\block\SnowLayer && (($this->getDamage() & 7) == 7))) {
							return true;
						}
					}
				}
			}
			return false;
		}

	public function canNeighborBurn() {
			/* decompiled (structured CF) */
			$face = 0;
			while (($face < 5)) {
				if ((0 < $this->getSide($face)->getBurnChance())) {
					return true;
				}
				$face++;
			}
			return false;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_NONE;
		}

	public function getFrictionFactor() {
			return 0.6;
		}

	public function getLightLevel() {
			return 0;
		}

	public function canBePlaced() {
			return true;
		}

	public function isPlaceable() {
			return $this->canBePlaced();
		}

	public function canBeReplaced() {
			return false;
		}

	public function isTransparent() {
			return false;
		}

	public function isSolid() {
			return true;
		}

	public function isNormalBlock() {
			return ($this->isSolid() && !($this->isTransparent()));
		}

	public function isPowerSource() {
			return false;
		}

	public function getWeakPower($side = null) {
			return 0;
		}

	public function getStrongPower($side = null) {
			return 0;
		}

	public function hasComparatorInputOverride() {
			return false;
		}

	public function getComparatorInputOverride() {
			return 0;
		}

	public function canBePushedByPiston() {
			/* decompiled (structured CF) */
			if ((isset($immovable[$this->id]) || ($this->getHardness() < 0))) {
				return false;
			}
			if (($this instanceof \pocketmine\block\PistonBase && $this->isExtended())) {
				return false;
			}
			if (!($this->isValid())) {
				return true;
			}
			$tile = $this->getLevel()->getTile($this);
			if (($tile instanceof \pocketmine\tile\MovingBlock && ($this->id !== self::MOVING_BLOCK))) {
				return true;
			}
			if ((($tile !== null) && method_exists($tile, 'isMovable'))) {
				return $tile->isMovable();
			}
			return ($tile === null);
		}

	public function canBePulledByPiston() {
			return $this->canBePushedByPiston();
		}

	public function breaksWhenMovedByPiston() {
			return isset($breakable[$this->id]);
		}

	public function sticksToPiston() {
			return !(isset($nonSticky[$this->id]));
		}

	public function canStickToPiston() {
			return $this->sticksToPiston();
		}

	public function canStickBlocks() {
			return false;
		}

	protected function calculateInventoryComparatorInput($inventory = null) {
			/* decompiled (structured CF) */
			if (($inventory === null)) {
				return 0;
			}
			$itemCount = 0;
			$averageCount = 0;
			$size = $inventory->getSize();
			if (($size <= 0)) {
				return 0;
			}
			$slot = 0;
			while (($slot < $size)) {
				$item = $inventory->getItem($slot);
				if ((($item->getId() !== \pocketmine\item\Item::AIR) && (0 < $item->getCount()))) {
					$averageCount += ($item->getCount() / min($inventory->getMaxStackSize(), $item->getMaxStackSize()));
					$itemCount++;
				}
				$slot++;
			}
			$averageCount /= $size;
			if ((0 < $itemCount)) {
			} else {
			}
			return ((floor(($averageCount * 14))) + 0);
		}

	public function canBeFlowedInto() {
			return false;
		}

	public function canBeActivated() {
			return false;
		}

	public function activate() {
			return false;
		}

	public function deactivate() {
			return false;
		}

	public function isActivated($from = null) {
			return false;
		}

	public function hasEntityCollision() {
			return false;
		}

	public function canPassThrough() {
			return false;
		}

	public function getName() {
			return 'Unknown';
		}

	public final function getId() {
			return $this->id;
		}

	public function addVelocityToEntity($entity = null, $vector = null) {
			return null;
		}

	public final function getDamage() {
			return $this->meta;
		}

	public final function setDamage($meta = null) {
			$this->meta = ($meta & 15);
		}

	public final function position($v = null) {
			/* decompiled (structured CF) */
			$this->x = ($v->x);
			$this->y = ($v->y);
			$this->z = ($v->z);
			$this->level = $v->level;
			$this->boundingBox = null;
			return null;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if (!(isset(self::$list[$this->getId()]))) {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			} else {
				return [[$this->getId(), $this->getDamage(), 1]];
			}
		}

	public function getBreakTime($item = null) {
			/* decompiled (structured CF) */
			$base = ($this->getHardness() * 1.5);
			if ($this->canBeBrokenWith($item)) {
				if ((($this->getToolType() === \pocketmine\item\Tool::TYPE_SHEARS) && $item->isShears())) {
					$base /= 15;
				} else {
					$tier = $item->isPickaxe();
					$tier = $item->isAxe();
					$tier = $item->isShovel();
					if ((((($this->getToolType() === \pocketmine\item\Tool::TYPE_PICKAXE) && ($tier !== false)) || (($this->getToolType() === \pocketmine\item\Tool::TYPE_AXE) && ($tier !== false))) || (($this->getToolType() === \pocketmine\item\Tool::TYPE_SHOVEL) && ($tier !== false)))) {
						$properTool = true;
						if (!(($tier == \pocketmine\item\Tool::TIER_WOODEN))) {
							if (!(($tier == \pocketmine\item\Tool::TIER_STONE))) {
								if (!(($tier == \pocketmine\item\Tool::TIER_IRON))) {
									if (!(($tier == \pocketmine\item\Tool::TIER_DIAMOND))) {
										if (!(($tier == \pocketmine\item\Tool::TIER_GOLD))) {
										} else {
											$base /= 2;
											/* jump */
											$base /= 4;
											/* jump */
											$base /= 6;
											/* jump */
											$base /= 8;
											/* jump */
											$base /= 12;
											/* jump */
										}
										/* jump */
										$base *= 3.33;
										$efficiency = $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_EFFICIENCY);
										if ((($t45 && $properTool) && (0 < $efficiency))) {
											$base /= (1 + ($efficiency * $efficiency));
										}
										if ($item->isSword()) {
											$base *= 0.5;
										}
										return $base;
									}
								}
							}
						}
					}
				}
			}
		}

	public function canBeBrokenWith($item = null) {
			return ($this->getHardness() !== -1);
		}

	public function getSide($side = null, $step = null) {
			/* decompiled (structured CF) */
			if ($this->isValid()) {
				return $this->getLevel()->getBlock(\pocketmine\math\Vector3::getSide($side, $step));
			}
			return \pocketmine\block\Block::get(\pocketmine\item\Item::AIR, 0, \pocketmine\level\Position::fromObject(\pocketmine\math\Vector3::getSide($side, $step)));
		}

	public function __toString() {
			return (((((('Block[' . $this->getName()) . $this) . $this->getId()) . ':') . $this->getDamage()) . ')');
		}

	public function collidesWithBB($bb = null) {
			$bb2 = $this->getBoundingBox();
			return (($bb2 !== null) && $bb->intersectsWith($bb2));
		}

	public function onEntityCollide($entity = null) {
			return null;
		}

	public function getBoundingBox() {
			/* decompiled (structured CF) */
			if (($this->boundingBox === null)) {
				$this->boundingBox = $this->recalculateBoundingBox();
			}
			return $this->boundingBox;
		}

	protected function recalculateBoundingBox() {
			new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 1), ($this->z + 1));
			return new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 1), ($this->z + 1));
		}

	public function calculateIntercept($pos1 = null, $pos2 = null) {
			/* decompiled (structured CF) */
			$bb = $this->getBoundingBox();
			if (($bb === null)) {
				return null;
			}
			$v1 = $pos1->getIntermediateWithXValue($pos2, $bb->minX);
			$v2 = $pos1->getIntermediateWithXValue($pos2, $bb->maxX);
			$v3 = $pos1->getIntermediateWithYValue($pos2, $bb->minY);
			$v4 = $pos1->getIntermediateWithYValue($pos2, $bb->maxY);
			$v5 = $pos1->getIntermediateWithZValue($pos2, $bb->minZ);
			$v6 = $pos1->getIntermediateWithZValue($pos2, $bb->maxZ);
			if ((($v1 !== null) && !($bb->isVectorInYZ($v1)))) {
				$v1 = null;
			}
			if ((($v2 !== null) && !($bb->isVectorInYZ($v2)))) {
				$v2 = null;
			}
			if ((($v3 !== null) && !($bb->isVectorInXZ($v3)))) {
				$v3 = null;
			}
			if ((($v4 !== null) && !($bb->isVectorInXZ($v4)))) {
				$v4 = null;
			}
			if ((($v5 !== null) && !($bb->isVectorInXY($v5)))) {
				$v5 = null;
			}
			if ((($v6 !== null) && !($bb->isVectorInXY($v6)))) {
				$v6 = null;
			}
			$vector = $v1;
			if ((($v2 !== null) && (($vector === null) || ($pos1->distanceSquared($v2) < $pos1->distanceSquared($vector))))) {
				$vector = $v2;
			}
			if ((($v3 !== null) && (($vector === null) || ($pos1->distanceSquared($v3) < $pos1->distanceSquared($vector))))) {
				$vector = $v3;
			}
			if ((($v4 !== null) && (($vector === null) || ($pos1->distanceSquared($v4) < $pos1->distanceSquared($vector))))) {
				$vector = $v4;
			}
			if ((($v5 !== null) && (($vector === null) || ($pos1->distanceSquared($v5) < $pos1->distanceSquared($vector))))) {
				$vector = $v5;
			}
			if ((($v6 !== null) && (($vector === null) || ($pos1->distanceSquared($v6) < $pos1->distanceSquared($vector))))) {
				$vector = $v6;
			}
			if (($vector === null)) {
			}
			$f = -1;
			if (($vector === $v1)) {
				$f = 4;
			} else {
				if (($vector === $v2)) {
					$f = 5;
				} else {
					if (($vector === $v3)) {
						$f = 0;
					} else {
						if (($vector === $v4)) {
							$f = 1;
						} else {
							if (($vector === $v5)) {
								$f = 2;
							} else {
								if (($vector === $v6)) {
									$f = 3;
								}
							}
						}
					}
				}
			}
			return \pocketmine\level\MovingObjectPosition::fromBlock($this->x, $this->y, $this->z, $f, $vector->add($this->x, $this->y, $this->z));
		}

	public function setMetadata($metadataKey = null, $metadataValue = null) {
			/* decompiled (structured CF) */
			if ($this->getLevel() instanceof \pocketmine\level\Level) {
				$this->getLevel()->getBlockMetadata()->setMetadata($this, $metadataKey, $metadataValue);
			}
			return null;
		}

	public function getMetadata($metadataKey = null) {
			if ($this->getLevel() instanceof \pocketmine\level\Level) {
				return $this->getLevel()->getBlockMetadata()->getMetadata($this, $metadataKey);
			}
		}

	public function hasMetadata($metadataKey = null) {
			/* decompiled (structured CF) */
			if ($this->getLevel() instanceof \pocketmine\level\Level) {
				$this->getLevel()->getBlockMetadata()->hasMetadata($this, $metadataKey);
			}
			return null;
		}

	public function removeMetadata($metadataKey = null, $plugin = null) {
			/* decompiled (structured CF) */
			if ($this->getLevel() instanceof \pocketmine\level\Level) {
				$this->getLevel()->getBlockMetadata()->removeMetadata($this, $metadataKey, $plugin);
			}
			return null;
		}

}
