<?php

namespace pocketmine\block;

class Sugarcane extends \pocketmine\block\Flowable {
	protected $id = 83;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return 'Sugarcane';
		}

	public function getDrops($item = null) {
			return [[\pocketmine\item\Item::SUGARCANE, 0, 1]];
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			if ((($item->getId() === \pocketmine\item\Item::DYE) && ($item->getDamage() === 15))) {
				if (($this->getSide(0)->getId() !== self::SUGARCANE_BLOCK)) {
					$y = 1;
					while (($y < 3)) {
						new \pocketmine\math\Vector3($this->x, ($this->y + $y), $this->z);
						$b = $this->getLevel()->getBlock(new \pocketmine\math\Vector3($this->x, ($this->y + $y), $this->z));
						if (($b->getId() === self::AIR)) {
							new \pocketmine\block\Sugarcane();
							new \pocketmine\event\block\BlockGrowEvent($b, new \pocketmine\block\Sugarcane());
							$ev = new \pocketmine\event\block\BlockGrowEvent($b, new \pocketmine\block\Sugarcane());
							\pocketmine\Server::getInstance()->getPluginManager()->callEvent($ev);
							if (!($ev->isCancelled())) {
								$this->getLevel()->setBlock($b, $ev->getNewState(), true);
							}
						} else {
							$y++;
						}
					}
					$this->meta = 0;
					$this->getLevel()->setBlock($this, $this, true);
				}
				if ((($player->gamemode & 1) === 0)) {
				}
				return true;
			}
			return false;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				$down = $this->getSide(0);
				if ((($down->isTransparent() === true) && ($down->getId() !== self::SUGARCANE_BLOCK))) {
					$this->getLevel()->useBreakOn($this);
					return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
				}
			} else {
				if (($type === \pocketmine\level\Level::BLOCK_UPDATE_RANDOM)) {
					if (($this->getSide(0)->getId() !== self::SUGARCANE_BLOCK)) {
						if (($this->meta === 15)) {
							$y = 1;
							while (($y < 3)) {
								new \pocketmine\math\Vector3($this->x, ($this->y + $y), $this->z);
								$b = $this->getLevel()->getBlock(new \pocketmine\math\Vector3($this->x, ($this->y + $y), $this->z));
								if (($b->getId() === self::AIR)) {
									new \pocketmine\block\Sugarcane();
									$this->getLevel()->setBlock($b, new \pocketmine\block\Sugarcane(), true);
								} else {
									$y++;
								}
							}
							$this->meta = 0;
							$this->getLevel()->setBlock($this, $this, true);
						} else {
							$this->getLevel()->setBlock($this, $this, true);
						}
						return \pocketmine\level\Level::BLOCK_UPDATE_RANDOM;
					}
				}
			}
			return false;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$down = $this->getSide(0);
			if (($down->getId() === self::SUGARCANE_BLOCK)) {
				new \pocketmine\block\Sugarcane();
				$this->getLevel()->setBlock($block, new \pocketmine\block\Sugarcane(), true);
				return true;
			} else {
				if (((($down->getId() === self::GRASS) || ($down->getId() === self::DIRT)) || ($down->getId() === self::SAND))) {
					$block0 = $down->getSide(2);
					$block1 = $down->getSide(3);
					$block2 = $down->getSide(4);
					$block3 = $down->getSide(5);
					if (((($block0 instanceof \pocketmine\block\Water || $block1 instanceof \pocketmine\block\Water) || $block2 instanceof \pocketmine\block\Water) || $block3 instanceof \pocketmine\block\Water)) {
						new \pocketmine\block\Sugarcane();
						$this->getLevel()->setBlock($block, new \pocketmine\block\Sugarcane(), true);
						return true;
					}
				}
			}
			return false;
		}

}
