<?php

namespace pocketmine\block;

class WaterLily extends \pocketmine\block\Flowable {
	protected $id = 111;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function isSolid() {
			return false;
		}

	public function getName() {
			return;
		}

	public function getHardness() {
			return 0;
		}

	public function getResistance() {
			return 0;
		}

	public function canPassThrough() {
			return true;
		}

	protected function recalculateBoundingBox() {
			new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, $this->x, ($this->y + 0.0625), $this->z);
			return new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, $this->x, ($this->y + 0.0625), $this->z);
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			if ($target instanceof \pocketmine\block\Water) {
				$up = $target->getSide(\pocketmine\math\Vector3::SIDE_UP);
				if (($up->getId() === \pocketmine\block\Block::AIR)) {
					$this->getLevel()->setBlock($up, $this, true, true);
					return true;
				}
			}
			return false;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				if (!($this->getSide(0) instanceof \pocketmine\block\Water)) {
					$this->getLevel()->useBreakOn($this);
					return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
				}
			}
			return false;
		}

	public function getDrops($item = null) {
			return [[$this->id, 0, 1]];
		}

}
