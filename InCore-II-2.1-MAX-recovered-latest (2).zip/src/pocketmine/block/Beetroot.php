<?php

namespace pocketmine\block;

class Beetroot extends \pocketmine\block\Crops {
	protected $id = 244;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			$drops = ['__array_ptr' => '2aaaac9fc9a0'];
			if ((7 <= $this->meta)) {
				$drops[] = [\pocketmine\item\Item::BEETROOT, 0, 1];
				$drops[] = [\pocketmine\item\Item::BEETROOT_SEEDS, 0, mt_rand(0, 3)];
			} else {
				$drops[] = [\pocketmine\item\Item::BEETROOT_SEEDS, 0, 1];
			}
			return $drops;
		}

}
