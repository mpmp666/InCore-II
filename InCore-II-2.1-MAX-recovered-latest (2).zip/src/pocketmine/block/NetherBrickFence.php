<?php

namespace pocketmine\block;

class NetherBrickFence extends \pocketmine\block\Transparent {
	protected $id = 113;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getBreakTime($item = null) {
			/* decompiled (structured CF) */
			if ($item instanceof \pocketmine\block\Air) {
				return 10;
			} else {
				return parent::getBreakTime($item);
			}
		}

	public function getHardness() {
			return 2;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function getName() {
			return;
		}

	public function canConnect($block = null) {
			/* decompiled (structured CF) */
			if ($block instanceof \pocketmine\block\NetherBrickFence) {
			} else {
			}
			return ($block->isSolid() && !($block->isTransparent()));
		}

	protected function recalculateBoundingBox() {
			/* decompiled (structured CF) */
			$north = $this->canConnect($this->getSide(\pocketmine\math\Vector3::SIDE_NORTH));
			$south = $this->canConnect($this->getSide(\pocketmine\math\Vector3::SIDE_SOUTH));
			$west = $this->canConnect($this->getSide(\pocketmine\math\Vector3::SIDE_WEST));
			$east = $this->canConnect($this->getSide(\pocketmine\math\Vector3::SIDE_EAST));
			if ($north) {
			} else {
			}
			$n = 0.375;
			if ($south) {
			} else {
			}
			$s = 0.625;
			if ($west) {
			} else {
			}
			$w = 0.375;
			if ($east) {
			} else {
			}
			$e = 0.625;
			new \pocketmine\math\AxisAlignedBB(($this->x + $w), $this->y, ($this->z + $n), ($this->x + $e), ($this->y + 1.5), ($this->z + $s));
			return new \pocketmine\math\AxisAlignedBB(($this->x + $w), $this->y, ($this->z + $n), ($this->x + $e), ($this->y + 1.5), ($this->z + $s));
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((\pocketmine\item\Tool::TIER_WOODEN <= $item->isPickaxe())) {
				return [[\pocketmine\item\Item::NETHER_BRICK_FENCE, $this->meta, 1]];
			} else {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
		}

}
