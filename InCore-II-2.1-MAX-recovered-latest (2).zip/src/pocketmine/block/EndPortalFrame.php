<?php

namespace pocketmine\block;

class EndPortalFrame extends \pocketmine\block\Solid {
	protected $id = 120;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getLightLevel() {
			return 1;
		}

	public function getName() {
			return;
		}

	public function getHardness() {
			return -1;
		}

	public function getResistance() {
			return 18000000;
		}

	public function isBreakable($item = null) {
			return false;
		}

	protected function recalculateBoundingBox() {
			/* decompiled (structured CF) */
			if ((0 < ($this->getDamage() & 4))) {
			} else {
			}
			new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 0.8125), ($this->z + 1));
			return new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 0.8125), ($this->z + 1));
		}

}
