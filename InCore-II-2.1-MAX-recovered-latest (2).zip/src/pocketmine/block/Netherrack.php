<?php

namespace pocketmine\block;

class Netherrack extends \pocketmine\block\Solid {
	protected $id = 87;

	public function __construct() {
			// empty
		}

	public function getName() {
			return 'Netherrack';
		}

	public function getHardness() {
			return 0.4;
		}

	public function getResistance() {
			return 2;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((1 <= $item->isPickaxe())) {
				return [[\pocketmine\item\Item::NETHERRACK, 0, 1]];
			} else {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
		}

}
