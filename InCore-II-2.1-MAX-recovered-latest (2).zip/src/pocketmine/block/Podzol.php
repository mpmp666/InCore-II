<?php

namespace pocketmine\block;

class Podzol extends \pocketmine\block\Solid {
	protected $id = 243;

	public function __construct() {
			// empty
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_SHOVEL;
		}

	public function getName() {
			return 'Podzol';
		}

	public function getHardness() {
			return 0.5;
		}

	public function getResistance() {
			return 2.5;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((0 < $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_SILK_TOUCH))) {
				return [[\pocketmine\item\Item::PODZOL, 0, 1]];
			} else {
				return [[\pocketmine\item\Item::DIRT, 0, 1]];
			}
		}

}
