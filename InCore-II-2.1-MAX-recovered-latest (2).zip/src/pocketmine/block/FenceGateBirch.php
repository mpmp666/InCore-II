<?php

namespace pocketmine\block;

class FenceGateBirch extends \pocketmine\block\FenceGate {
	protected $id = 184;

	public function getName() {
			return;
		}

}
