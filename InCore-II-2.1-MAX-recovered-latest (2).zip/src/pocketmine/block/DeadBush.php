<?php

namespace pocketmine\block;

class DeadBush extends \pocketmine\block\Flowable {
	protected $id = 32;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$down = $this->getSide(0);
			if ((((($down->getId() === \pocketmine\block\Block::SAND) || ($down->getId() === \pocketmine\block\Block::PODZOL)) || ($down->getId() === \pocketmine\block\Block::HARDENED_CLAY)) || ($down->getId() === \pocketmine\block\Block::STAINED_CLAY))) {
				$this->getLevel()->setBlock($block, $this, true);
				return true;
			}
			return false;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				if (($this->getSide(0)->isTransparent() === true)) {
					$this->getLevel()->useBreakOn($this);
					return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
				}
			}
			return false;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ($item->isShears()) {
				return [[\pocketmine\item\Item::DEAD_BUSH, 0, 1]];
			} else {
				return [[\pocketmine\item\Item::STICK, 0, mt_rand(0, 2)]];
			}
		}

}
