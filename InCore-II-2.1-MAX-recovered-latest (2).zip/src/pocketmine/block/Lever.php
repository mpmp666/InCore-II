<?php

namespace pocketmine\block;

class Lever extends \pocketmine\block\RedstoneSource {
	protected $id = 69;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function canBeActivated() {
			return true;
		}

	public function getName() {
			return 'Lever';
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				$side = $this->getDamage();
				if ($this->isActivated()) {
					$side ^= 8;
				}
				$faces = ['__array_ptr' => '2aaaadd5d498'];
				$block = $this->getSide($faces[$side]);
				if ($block->isTransparent()) {
					$this->getLevel()->useBreakOn($this);
					return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
				}
			}
			return false;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			if (($target->isTransparent() === false)) {
				$faces = ['__array_ptr' => '2aaaadd5d508'];
				if (($face === 0)) {
					if ($player instanceof \pocketmine\Player) {
					} else {
					}
					$to = 0;
					if ((($to % 2) != 1)) {
					} else {
					}
					$this->meta = 7;
				} else {
					if (($face === 1)) {
						if ($player instanceof \pocketmine\Player) {
						} else {
						}
						$to = 0;
						if ((($to % 2) != 1)) {
						} else {
						}
						$this->meta = 5;
					} else {
						$this->meta = $faces[$face];
					}
				}
				$this->getLevel()->setBlock($block, $this, true, false);
				return true;
			}
			return false;
		}

	public function activate($ignore = null) {
			/* decompiled (structured CF) */
			parent::activate($ignore);
			$side = $this->meta;
			if ($this->isActivated()) {
				$side ^= 8;
			}
			$faces = ['__array_ptr' => '2aaaadd5d540'];
			$block = $this->getSide($faces[$side])->getSide(\pocketmine\math\Vector3::SIDE_UP);
			if (!($this->equals($block))) {
				$this->activateBlock($block);
			}
			$this->checkTorchOn($this->getSide($faces[$side]), [$this->getOppositeSide($faces[$side])]);
			return null;
		}

	public function deactivate($ignore = null) {
			/* decompiled (structured CF) */
			parent::deactivate($ignore);
			$side = $this->meta;
			if ($this->isActivated()) {
				$side ^= 8;
			}
			$faces = ['__array_ptr' => '2aaaadd5d578'];
			$block = $this->getSide($faces[$side])->getSide(\pocketmine\math\Vector3::SIDE_UP);
			if (!($this->equals($block))) {
				$this->deactivateBlock($block);
			}
			$this->checkTorchOff($this->getSide($faces[$side]), [$this->getOppositeSide($faces[$side])]);
			return null;
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			$this->meta ^= 8;
			$this->getLevel()->setBlock($this, $this, true, false);
			if ($this->isActivated()) {
				$this->activate();
			} else {
				$this->deactivate();
			}
			$this->getLevel()->updateAroundRedstone($this);
			return true;
		}

	public function onBreak($item = null) {
			/* decompiled (structured CF) */
			if ($this->isActivated()) {
				$this->meta ^= 8;
				$this->getLevel()->setBlock($this, $this, true, false);
				$this->deactivate();
			}
			new \pocketmine\block\Air();
			$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), true, false);
			return null;
		}

	public function isActivated($from = null) {
			return (($this->meta & 8) === 8);
		}

	public function getStrongPower($side = null) {
			/* decompiled (structured CF) */
			$faces = ['__array_ptr' => '2aaaadd5d5b0'];
			$leverSide = $this->meta;
			if ($this->isActivated()) {
				$leverSide ^= 8;
			}
			if (($side === $faces[$leverSide])) {
			} else {
			}
			return 0;
		}

	public function getHardness() {
			return 0.5;
		}

	public function getResistance() {
			return 2.5;
		}

	public function getDrops($item = null) {
			return [[$this->id, 0, 1]];
		}

}
