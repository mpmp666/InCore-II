<?php

namespace pocketmine\block;

class EndStone extends \pocketmine\block\Solid {
	protected $id = 121;

	public function __construct() {
			// empty
		}

	public function getName() {
			return;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function getHardness() {
			return 3;
		}

}
