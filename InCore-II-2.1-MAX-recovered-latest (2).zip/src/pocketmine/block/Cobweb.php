<?php

namespace pocketmine\block;

class Cobweb extends \pocketmine\block\Flowable {
	protected $id = 30;

	public function __construct() {
			// empty
		}

	public function hasEntityCollision() {
			return true;
		}

	public function getName() {
			return 'Cobweb';
		}

	public function getHardness() {
			return 4;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_SHEARS;
		}

	public function onEntityCollide($entity = null) {
			$entity->resetFallDistance();
			return null;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ($item->isShears()) {
				return [[\pocketmine\item\Item::COBWEB, 0, 1]];
			} else {
				if ((\pocketmine\item\Tool::TIER_WOODEN <= $item->isSword())) {
					if ((0 < $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_SILK_TOUCH))) {
						return [[\pocketmine\item\Item::COBWEB, 0, 1]];
					} else {
						return [[\pocketmine\item\Item::STRING, 0, 1]];
					}
				}
			}
			return ['__array_ptr' => '2aaaac9fc9a0'];
		}

}
