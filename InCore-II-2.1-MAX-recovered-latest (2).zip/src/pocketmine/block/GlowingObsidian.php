<?php

namespace pocketmine\block;

class GlowingObsidian extends \pocketmine\block\Solid {
	protected $id = 246;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return;
		}

	public function getLightLevel() {
			return 12;
		}

}
