<?php

namespace pocketmine\block;

class Ladder extends \pocketmine\block\Transparent {
	public const NATURAL_VILLAGE_LADDER_MARKER = 19524;
	public const NATURAL_VILLAGE_LADDER_MARKER_ID = 68;
	public const NATURAL_VILLAGE_LADDER_MARKER_DATA = 76;

	protected $id = 65;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return 'Ladder';
		}

	public function hasEntityCollision() {
			return true;
		}

	public function isSolid() {
			return false;
		}

	public function getHardness() {
			return 0.4;
		}

	public function onEntityCollide($entity = null) {
			$entity->resetFallDistance();
			$entity->onGround = true;
			return null;
		}

	protected function recalculateBoundingBox() {
			/* decompiled (structured CF) */
			$f = 0.125;
			if (($this->meta === 2)) {
				new \pocketmine\math\AxisAlignedBB($this->x, $this->y, (($this->z + 1) - $f), ($this->x + 1), ($this->y + 1), ($this->z + 1));
				return new \pocketmine\math\AxisAlignedBB($this->x, $this->y, (($this->z + 1) - $f), ($this->x + 1), ($this->y + 1), ($this->z + 1));
			} else {
				if (($this->meta === 3)) {
					new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 1), ($this->z + $f));
					return new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 1), ($this->z + $f));
				} else {
					if (($this->meta === 4)) {
						new \pocketmine\math\AxisAlignedBB((($this->x + 1) - $f), $this->y, $this->z, ($this->x + 1), ($this->y + 1), ($this->z + 1));
						return new \pocketmine\math\AxisAlignedBB((($this->x + 1) - $f), $this->y, $this->z, ($this->x + 1), ($this->y + 1), ($this->z + 1));
					} else {
						if (($this->meta === 5)) {
							new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + $f), ($this->y + 1), ($this->z + 1));
							return new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + $f), ($this->y + 1), ($this->z + 1));
						}
					}
				}
			}
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			if (($target->isTransparent() === false)) {
				$faces = ['__array_ptr' => '2aaaadd5d5b0'];
				if (isset($faces[$face])) {
					$this->meta = $faces[$face];
					$this->getLevel()->setBlock($block, $this, true, true);
					return true;
				}
			}
			return false;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			$faces = ['__array_ptr' => '2aaaadd5d5e8'];
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				if (isset($faces[$this->meta])) {
					if (($this->getSide($faces[$this->meta])->getId() === self::AIR)) {
						if ($this->isNaturalVillageLadder()) {
							return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
						}
						$this->getLevel()->useBreakOn($this);
					}
					return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
				}
			}
			return false;
		}

	protected function isNaturalVillageLadder() {
			return (method_exists($this->getLevel(), 'getBlockExtraDataAt') && ($this->getLevel()->getBlockExtraDataAt($this->x, $this->y, $this->z) === self::NATURAL_VILLAGE_LADDER_MARKER));
		}

	protected function clearNaturalVillageLadderMarker() {
			/* decompiled (structured CF) */
			if ((method_exists($this->getLevel(), 'setBlockExtraDataAt') && $this->isNaturalVillageLadder())) {
				$this->getLevel()->setBlockExtraDataAt($this->x, $this->y, $this->z, 0, 0);
			}
			return null;
		}

	public function onBreak($item = null) {
			$this->clearNaturalVillageLadderMarker();
			return parent::onBreak($item);
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_AXE;
		}

	public function getDrops($item = null) {
			return [[$this->id, 0, 1]];
		}

}
