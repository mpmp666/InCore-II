<?php

namespace pocketmine\block;

class Noteblock extends \pocketmine\block\Solid implements \pocketmine\block\ElectricalAppliance {
	protected $id = 25;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getHardness() {
			return 0.8;
		}

	public function getResistance() {
			return 4;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_AXE;
		}

	public function canBeActivated() {
			return true;
		}

	public function getStrength() {
			/* decompiled (structured CF) */
			if (($this->meta < 24)) {
			} else {
				$this->meta = 0;
			}
			$this->getLevel()->setBlock($this, $this);
			return ($this->meta * 1);
		}

	public function getInstrument() {
			/* decompiled (structured CF) */
			$below = $this->getSide(\pocketmine\math\Vector3::SIDE_DOWN);
			/* jump */
			switch ($below->getId()) {
				case \pocketmine\block\Block::WOOD:
				case \pocketmine\block\Block::WOOD2:
				case \pocketmine\block\Block::WOODEN_PLANK:
				case \pocketmine\block\Block::WOODEN_SLABS:
				case \pocketmine\block\Block::DOUBLE_WOOD_SLABS:
				case \pocketmine\block\Block::OAK_WOODEN_STAIRS:
				case \pocketmine\block\Block::SPRUCE_WOODEN_STAIRS:
				case \pocketmine\block\Block::BIRCH_WOODEN_STAIRS:
				case \pocketmine\block\Block::JUNGLE_WOODEN_STAIRS:
				case \pocketmine\block\Block::ACACIA_WOODEN_STAIRS:
				case \pocketmine\block\Block::DARK_OAK_WOODEN_STAIRS:
				case \pocketmine\block\Block::FENCE:
				case \pocketmine\block\Block::FENCE_GATE:
				case \pocketmine\block\Block::FENCE_GATE_SPRUCE:
				case \pocketmine\block\Block::FENCE_GATE_BIRCH:
				case \pocketmine\block\Block::FENCE_GATE_JUNGLE:
				case \pocketmine\block\Block::FENCE_GATE_DARK_OAK:
				case \pocketmine\block\Block::FENCE_GATE_ACACIA:
				case \pocketmine\block\Block::SPRUCE_WOOD_STAIRS:
				case \pocketmine\block\Block::BOOKSHELF:
				case \pocketmine\block\Block::CHEST:
				case \pocketmine\block\Block::CRAFTING_TABLE:
				case \pocketmine\block\Block::SIGN_POST:
				case \pocketmine\block\Block::WALL_SIGN:
				case \pocketmine\block\Block::DOOR_BLOCK:
				case \pocketmine\block\Block::NOTEBLOCK:
				return \pocketmine\level\sound\NoteblockSound::INSTRUMENT_BASS;
				case \pocketmine\block\Block::SAND:
				case \pocketmine\block\Block::SOUL_SAND:
				return \pocketmine\level\sound\NoteblockSound::INSTRUMENT_TABOUR;
				case \pocketmine\block\Block::GLASS:
				case \pocketmine\block\Block::GLASS_PANE:
				return \pocketmine\level\sound\NoteblockSound::INSTRUMENT_CLICK;
				case \pocketmine\block\Block::STONE:
				case \pocketmine\block\Block::COBBLESTONE:
				case \pocketmine\block\Block::SANDSTONE:
				case \pocketmine\block\Block::MOSS_STONE:
				case \pocketmine\block\Block::BRICKS:
				case \pocketmine\block\Block::STONE_BRICK:
				case \pocketmine\block\Block::NETHER_BRICKS:
				case \pocketmine\block\Block::QUARTZ_BLOCK:
				case \pocketmine\block\Block::SLAB:
				case \pocketmine\block\Block::COBBLESTONE_STAIRS:
				case \pocketmine\block\Block::BRICK_STAIRS:
				case \pocketmine\block\Block::STONE_BRICK_STAIRS:
				case \pocketmine\block\Block::NETHER_BRICKS_STAIRS:
				case \pocketmine\block\Block::SANDSTONE_STAIRS:
				case \pocketmine\block\Block::QUARTZ_STAIRS:
				case \pocketmine\block\Block::COBBLESTONE_WALL:
				case \pocketmine\block\Block::NETHER_BRICK_FENCE:
				case \pocketmine\block\Block::BEDROCK:
				case \pocketmine\block\Block::GOLD_ORE:
				case \pocketmine\block\Block::IRON_ORE:
				case \pocketmine\block\Block::COAL_ORE:
				case \pocketmine\block\Block::LAPIS_ORE:
				case \pocketmine\block\Block::DIAMOND_ORE:
				case \pocketmine\block\Block::REDSTONE_ORE:
				case \pocketmine\block\Block::GLOWING_REDSTONE_ORE:
				case \pocketmine\block\Block::EMERALD_ORE:
				case \pocketmine\block\Block::FURNACE:
				case \pocketmine\block\Block::BURNING_FURNACE:
				case \pocketmine\block\Block::OBSIDIAN:
				case \pocketmine\block\Block::MONSTER_SPAWNER:
				case \pocketmine\block\Block::NETHERRACK:
				case \pocketmine\block\Block::ENCHANTING_TABLE:
				case \pocketmine\block\Block::END_STONE:
				case \pocketmine\block\Block::STAINED_CLAY:
				case \pocketmine\block\Block::COAL_BLOCK:
				return \pocketmine\level\sound\NoteblockSound::INSTRUMENT_BASS_DRUM;
			}
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			$up = $this->getSide(\pocketmine\math\Vector3::SIDE_UP);
			if (($up->getId() == 0)) {
				new \pocketmine\level\sound\NoteblockSound($this, $this->getInstrument(), $this->getStrength());
				$this->getLevel()->addSound(new \pocketmine\level\sound\NoteblockSound($this, $this->getInstrument(), $this->getStrength()));
				return true;
			} else {
				return false;
			}
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if ((($type === \pocketmine\level\Level::BLOCK_UPDATE_REDSTONE) || ($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL))) {
				$powered = $this->getLevel()->isBlockPowered($this);
				$wasPowered = $this->getLevel()->getBlockTempData($this);
				if (($powered && !($wasPowered))) {
					$this->getLevel()->setBlockTempData($this, true);
					$this->onActivate(\pocketmine\item\Item::get(\pocketmine\item\Item::AIR));
				} else {
					if ((!($powered) && $wasPowered)) {
						$this->getLevel()->setBlockTempData($this, null);
					}
				}
				return $type;
			}
			return false;
		}

	public function getName() {
			return 'Noteblock';
		}

}
