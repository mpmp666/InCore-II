<?php

namespace pocketmine\block;

abstract class Thin extends \pocketmine\block\Transparent {
	public function isSolid() {
			return false;
		}

	protected function recalculateBoundingBox() {
			/* decompiled (structured CF) */
			$f = 0.4375;
			$f1 = 0.5625;
			$f2 = 0.4375;
			$f3 = 0.5625;
			$flag = $this->canConnect($this->getSide(2));
			$flag1 = $this->canConnect($this->getSide(3));
			$flag2 = $this->canConnect($this->getSide(4));
			$flag3 = $this->canConnect($this->getSide(5));
			if (((!($flag2) || !($flag3)) && ((($flag2 || $flag3) || $flag) || $flag1))) {
				if (($flag2 && !($flag3))) {
					$f = 0;
				} else {
					if ((!($flag2) && $flag3)) {
						$f1 = 1;
					}
				}
			} else {
				$f = 0;
				$f1 = 1;
			}
			if (((!($flag) || !($flag1)) && ((($flag2 || $flag3) || $flag) || $flag1))) {
				if (($flag && !($flag1))) {
					$f2 = 0;
				} else {
					if ((!($flag) && $flag1)) {
						$f3 = 1;
					}
				}
			} else {
				$f2 = 0;
				$f3 = 1;
			}
			new \pocketmine\math\AxisAlignedBB(($this->x + $f), $this->y, ($this->z + $f2), ($this->x + $f1), ($this->y + 1), ($this->z + $f3));
			return new \pocketmine\math\AxisAlignedBB(($this->x + $f), $this->y, ($this->z + $f2), ($this->x + $f1), ($this->y + 1), ($this->z + $f3));
		}

	public function canConnect($block = null) {
			return ((($block->isSolid() || ($block->getId() === $this->getId())) || ($block->getId() === self::GLASS_PANE)) || ($block->getId() === self::GLASS));
		}

}
