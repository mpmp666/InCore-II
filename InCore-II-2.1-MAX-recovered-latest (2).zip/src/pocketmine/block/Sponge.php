<?php

namespace pocketmine\block;

class Sponge extends \pocketmine\block\Solid {
	protected $id = 19;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getHardness() {
			return 0.6;
		}

	public function getName() {
			return 'Sponge';
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			parent::place($item, $block, $target, $face, $fx, $fy, $fz, $player);
			$this->absorbWater();
			return null;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				$this->absorbWater();
			}
			return null;
		}

	private function absorbWater() {
			/* decompiled (structured CF) */
			$level = $this->getLevel();
			new \pocketmine\math\Vector3($this->x, $this->y, $this->z);
			$center = new \pocketmine\math\Vector3($this->x, $this->y, $this->z);
			$radius = 3;
			$absorbed = 0;
			$dx = ($radius * -1);
			while (($dx <= $radius)) {
				$dy = ($radius * -1);
				while (($dy <= $radius)) {
					$dz = ($radius * -1);
					while (($dz <= $radius)) {
						$block = $level->getBlock($center->add($dx, $dy, $dz));
						if ((((($block->getId() === \pocketmine\block\Block::WATER) || ($block->getId() === \pocketmine\block\Block::LAVA)) || ($block->getId() === \pocketmine\block\Block::STILL_WATER)) || ($block->getId() === \pocketmine\block\Block::STILL_LAVA))) {
							new \pocketmine\block\Air();
							$level->setBlock($block, new \pocketmine\block\Air(), true, false);
							$absorbed++;
						}
						$dz++;
					}
					$dy++;
				}
				$dx++;
			}
			if ((0 < $absorbed)) {
				new \pocketmine\level\sound\FizzSound($center->add(0.5, 0.5, 0.5), (2.5 + ((mt_rand(0, 1000) / 1000) * 0.8)));
				$level->addSound(new \pocketmine\level\sound\FizzSound($center->add(0.5, 0.5, 0.5), (2.5 + ((mt_rand(0, 1000) / 1000) * 0.8))));
				$i = 0;
				while (($i < 8)) {
					new \pocketmine\level\particle\SmokeParticle($center->add((mt_rand(10, 90) / 100), (mt_rand(10, 90) / 100), (mt_rand(10, 90) / 100)));
					$level->addParticle(new \pocketmine\level\particle\SmokeParticle($center->add((mt_rand(10, 90) / 100), (mt_rand(10, 90) / 100), (mt_rand(10, 90) / 100))));
					$i++;
				}
			}
			return null;
		}

}
