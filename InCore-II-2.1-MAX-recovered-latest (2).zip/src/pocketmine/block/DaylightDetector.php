<?php

namespace pocketmine\block;

class DaylightDetector extends \pocketmine\block\RedstoneSource {
	protected $id = 151;

	public function getName() {
			return;
		}

	public function getBoundingBox() {
			/* decompiled (structured CF) */
			if (($this->boundingBox === null)) {
				$this->boundingBox = $this->recalculateBoundingBox();
			}
			return $this->boundingBox;
		}

	public function canBeFlowedInto() {
			return false;
		}

	public function canBeActivated() {
			return true;
		}

	protected function getTile() {
			/* decompiled (structured CF) */
			$t = $this->getLevel()->getTile($this);
			if ($t instanceof \pocketmine\tile\DLDetector) {
				return $t;
			} else {
				new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::DAY_LIGHT_DETECTOR);
				new \pocketmine\nbt\tag\IntTag('x', $this->x);
				new \pocketmine\nbt\tag\IntTag('y', $this->y);
				new \pocketmine\nbt\tag\IntTag('z', $this->z);
				new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::DAY_LIGHT_DETECTOR), new \pocketmine\nbt\tag\IntTag('x', $this->x), new \pocketmine\nbt\tag\IntTag('y', $this->y), new \pocketmine\nbt\tag\IntTag('z', $this->z)]);
				$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::DAY_LIGHT_DETECTOR), new \pocketmine\nbt\tag\IntTag('x', $this->x), new \pocketmine\nbt\tag\IntTag('y', $this->y), new \pocketmine\nbt\tag\IntTag('z', $this->z)]);
				return \pocketmine\tile\Tile::createTile(\pocketmine\tile\Tile::DAY_LIGHT_DETECTOR, $this->getLevel()->getChunk(($this->x >> 4), ($this->z >> 4)), $nbt);
			}
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\block\DaylightDetectorInverted();
			$this->getLevel()->setBlock($this, new \pocketmine\block\DaylightDetectorInverted(), true, true);
			$this->getTile()->onUpdate();
			return true;
		}

	public function isActivated($from = null) {
			return $this->getTile()->isActivated();
		}

	public function getWeakPower($side = null) {
			return $this->getTile()->getRedstoneStrength();
		}

	public function getStrongPower($side = null) {
			return 0;
		}

	public function onBreak($item = null) {
			/* decompiled (structured CF) */
			new \pocketmine\block\Air();
			$this->getLevel()->setBlock($this, new \pocketmine\block\Air());
			if ($this->isActivated()) {
				$this->deactivate();
			}
			return null;
		}

	public function getHardness() {
			return 0.2;
		}

	public function getResistance() {
			return 1;
		}

	public function getDrops($item = null) {
			return [[self::DAYLIGHT_SENSOR, 0, 1]];
		}

}
