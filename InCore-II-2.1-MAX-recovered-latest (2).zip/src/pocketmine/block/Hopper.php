<?php

namespace pocketmine\block;

class Hopper extends \pocketmine\block\Transparent {
	protected $id = 154;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function canBeActivated() {
			return true;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function getName() {
			return 'Hopper';
		}

	public function getHardness() {
			return 3;
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			if ($player instanceof \pocketmine\Player) {
				$t = $this->getLevel()->getTile($this);
				if ($t instanceof \pocketmine\tile\Hopper) {
					if (($t->hasLock() && !($t->checkLock($item->getCustomName())))) {
						$player->getServer()->getLogger()->debug(($player->getName() . $this));
						return true;
					}
					$player->addWindow($t->getInventory());
				}
			}
			return true;
		}

	public function activate() {
			/* decompiled (structured CF) */
			$tile = $this->getLevel()->getTile($this);
			if ($tile instanceof \pocketmine\tile\Hopper) {
				$tile->activate();
			}
			return null;
		}

	public function deactivate() {
			/* decompiled (structured CF) */
			$tile = $this->getLevel()->getTile($this);
			if ($tile instanceof \pocketmine\tile\Hopper) {
				$tile->deactivate();
			}
			return null;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if ((($type === \pocketmine\level\Level::BLOCK_UPDATE_REDSTONE) || ($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL))) {
				if ($this->getLevel()->isBlockPowered($this)) {
					$this->activate();
				} else {
					$this->deactivate();
				}
				return $type;
			}
			return false;
		}

	public function getTarget() {
			return $this->target;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$faces = ['__array_ptr' => '2aaaadd5d498'];
			$this->meta = $faces[$face];
			$this->getLevel()->setBlock($block, $this, true, true);
			new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']);
			new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::HOPPER);
			new \pocketmine\nbt\tag\IntTag('x', $this->x);
			new \pocketmine\nbt\tag\IntTag('y', $this->y);
			new \pocketmine\nbt\tag\IntTag('z', $this->z);
			new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']), new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::HOPPER), new \pocketmine\nbt\tag\IntTag('x', $this->x), new \pocketmine\nbt\tag\IntTag('y', $this->y), new \pocketmine\nbt\tag\IntTag('z', $this->z)]);
			$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']), new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::HOPPER), new \pocketmine\nbt\tag\IntTag('x', $this->x), new \pocketmine\nbt\tag\IntTag('y', $this->y), new \pocketmine\nbt\tag\IntTag('z', $this->z)]);
			$nbt->Items->setTagType(\pocketmine\nbt\NBT::TAG_Compound);
			if ($item->hasCustomName()) {
				new \pocketmine\nbt\tag\StringTag('CustomName', $item->getCustomName());
				$nbt->CustomName = new \pocketmine\nbt\tag\StringTag('CustomName', $item->getCustomName());
			}
			if ($item->hasCustomBlockData()) {
				foreach ($item->getCustomBlockData() as $key => $v) {
					$nbt->prop = $v;
					/* goto */
				}
			}
			$t = \pocketmine\tile\Tile::createTile(\pocketmine\tile\Tile::HOPPER, $this->getLevel()->getChunk(($this->x >> 4), ($this->z >> 4)), $nbt);
			return true;
		}

	public function hasComparatorInputOverride() {
			return true;
		}

	public function getComparatorInputOverride() {
			/* decompiled (structured CF) */
			$tile = $this->getLevel()->getTile($this);
			if ($tile instanceof \pocketmine\tile\Hopper) {
			} else {
			}
			return 0;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((\pocketmine\item\Tool::TIER_IRON <= $item->isPickaxe())) {
				$drops = [[\pocketmine\item\Item::HOPPER, 0, 1]];
			} else {
				$drops = ['__array_ptr' => '2aaaac9fc9a0'];
			}
			$tile = $this->getLevel()->getTile($this);
			if ($tile instanceof \pocketmine\tile\Hopper) {
				foreach ($tile->getInventory()->getContents() as $content) {
					if (($content->getId() !== \pocketmine\item\Item::AIR)) {
						$this->getLevel()->dropItem($this->add(0.5, 0.5, 0.5), $content);
					}
					/* goto */
				}
				$tile->getInventory()->clearAll();
			}
			return $drops;
		}

}
