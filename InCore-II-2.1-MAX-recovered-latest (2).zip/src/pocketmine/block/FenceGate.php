<?php

namespace pocketmine\block;

class FenceGate extends \pocketmine\block\Transparent implements \pocketmine\block\ElectricalAppliance {
	protected $id = 107;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return;
		}

	public function getHardness() {
			return 2;
		}

	public function canBeActivated() {
			return true;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_AXE;
		}

	protected function recalculateBoundingBox() {
			/* decompiled (structured CF) */
			if ((0 < ($this->getDamage() & 4))) {
				return null;
			}
			$i = ($this->getDamage() & 3);
			if ((($i === 2) || ($i === 0))) {
				new \pocketmine\math\AxisAlignedBB($this->x, $this->y, ($this->z + 0.375), ($this->x + 1), ($this->y + 1.5), ($this->z + 0.625));
				return new \pocketmine\math\AxisAlignedBB($this->x, $this->y, ($this->z + 0.375), ($this->x + 1), ($this->y + 1.5), ($this->z + 0.625));
			} else {
				new \pocketmine\math\AxisAlignedBB(($this->x + 0.375), $this->y, $this->z, ($this->x + 0.625), ($this->y + 1.5), ($this->z + 1));
				return new \pocketmine\math\AxisAlignedBB(($this->x + 0.375), $this->y, $this->z, ($this->x + 0.625), ($this->y + 1.5), ($this->z + 1));
			}
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$faces = ['__array_ptr' => '2aaaadd5d6c8'];
			if ($player instanceof \pocketmine\Player) {
			} else {
			}
			$this->meta = ($faces[0] & 3);
			$this->getLevel()->setBlock($block, $this, true, true);
			return true;
		}

	public function isOpened() {
			return (0 < ($this->getDamage() & 4));
		}

	public function getDrops($item = null) {
			return [[$this->id, 0, 1]];
		}

	public function setOpen($open = null) {
			/* decompiled (structured CF) */
			if (($this->isOpened() !== $open)) {
				$this->meta ^= 4;
				$this->getLevel()->setBlock($this, $this, true);
				new \pocketmine\level\sound\DoorSound($this);
				$this->level->addSound(new \pocketmine\level\sound\DoorSound($this));
			}
			return true;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_REDSTONE)) {
				$this->setOpen($this->getLevel()->isBlockPowered($this));
				return \pocketmine\level\Level::BLOCK_UPDATE_REDSTONE;
			}
			return false;
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			$faces = ['__array_ptr' => '2aaaadd5d700'];
			if (($player !== null)) {
				if ($player instanceof \pocketmine\Player) {
				} else {
				}
				$this->meta = (($faces[0] & 3) | ($this->meta & 4));
			}
			return $this->setOpen(!($this->isOpened()));
		}

}
