<?php

namespace pocketmine\block;

class StillWater extends \pocketmine\block\Water {
	protected $id = 9;

	public function onUpdate($type = null) {
			return parent::onUpdate($type);
		}

	public function getName() {
			return;
		}

}
