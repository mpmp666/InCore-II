<?php

namespace pocketmine\block;

abstract class Flowable extends \pocketmine\block\Transparent {
	public function canBeFlowedInto() {
			return true;
		}

	public function getHardness() {
			return 0;
		}

	public function getResistance() {
			return 0;
		}

	public function isSolid() {
			return false;
		}

	public function breaksWhenMovedByPiston() {
			return true;
		}

	public function sticksToPiston() {
			return false;
		}

	public function getBoundingBox() {
			return null;
		}

	public function canPassThrough() {
			return ($this->getBoundingBox() === null);
		}

}
