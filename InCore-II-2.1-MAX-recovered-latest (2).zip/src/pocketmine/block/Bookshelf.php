<?php

namespace pocketmine\block;

class Bookshelf extends \pocketmine\block\Solid {
	protected $id = 47;

	public function __construct() {
			// empty
		}

	public function getName() {
			return 'Bookshelf';
		}

	public function getHardness() {
			return 1.5;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_AXE;
		}

	public function getBurnChance() {
			return 30;
		}

	public function getBurnAbility() {
			return 20;
		}

	public function getDrops($item = null) {
			return [[\pocketmine\item\Item::BOOK, 0, 3]];
		}

}
