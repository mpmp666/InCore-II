<?php

namespace pocketmine\block;

class Observer extends \pocketmine\block\Solid {
	public const META_FACING_MASK = 7;
	public const META_POWERED = 8;

	protected $id = 251;

	public function __construct($meta = null) {
			$this->meta = ($meta & 15);
		}

	public function getName() {
			return 'Observer';
		}

	public function getHardness() {
			return 3.5;
		}

	public function getResistance() {
			return 17.5;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function canBeBrokenWith($item = null) {
			return (\pocketmine\item\Tool::TIER_WOODEN <= $item->isPickaxe());
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((\pocketmine\item\Tool::TIER_WOODEN <= $item->isPickaxe())) {
				return [[\pocketmine\item\Item::OBSERVER, 0, 1]];
			}
			return ['__array_ptr' => '2aaaac9fc9a0'];
		}

	public function getFacing() {
			/* decompiled (structured CF) */
			$facing = ($this->meta & self::META_FACING_MASK);
			if (($facing <= \pocketmine\math\Vector3::SIDE_EAST)) {
			} else {
			}
			return \pocketmine\math\Vector3::SIDE_NORTH;
		}

	public function setFacing($facing = null) {
			$this->meta = (($this->meta & self::META_POWERED) | (($facing) & self::META_FACING_MASK));
			return null;
		}

	public function isPowered() {
			return (($this->meta & self::META_POWERED) === self::META_POWERED);
		}

	public function setPowered($powered = null) {
			/* decompiled (structured CF) */
			if ($powered) {
				$this->meta |= self::META_POWERED;
			} else {
				$this->meta &= self::META_FACING_MASK;
			}
			return null;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			if ($player instanceof \pocketmine\Player) {
				$eyeY = ($player->y + $player->getEyeHeight());
				if (((abs(($player->getFloorX() - $block->x)) <= 1) && (abs(($player->getFloorZ() - $block->z)) <= 1))) {
					if ((2 < ($eyeY - $block->y))) {
						$this->setFacing(\pocketmine\math\Vector3::SIDE_DOWN);
					} else {
						if ((0 < ($block->y - $eyeY))) {
							$this->setFacing(\pocketmine\math\Vector3::SIDE_UP);
						} else {
							$this->setFacing(self::playerDirectionToSide($player->getDirection()));
						}
					}
				} else {
					$this->setFacing(self::playerDirectionToSide($player->getDirection()));
				}
			}
			$this->getLevel()->setBlock($block, $this, true, true);
			return true;
		}

	private static function playerDirectionToSide($direction = null) {
			/* decompiled (structured CF) */
			/* jump */
			switch (($direction)) {
				case 0:
				return \pocketmine\math\Vector3::SIDE_EAST;
				case 1:
				return \pocketmine\math\Vector3::SIDE_SOUTH;
				case 2:
				return \pocketmine\math\Vector3::SIDE_WEST;
				case 3:
				return \pocketmine\math\Vector3::SIDE_NORTH;
			}
		}

	public function isPowerSource() {
			return true;
		}

	public function getWeakPower($side = null) {
			return $this->getStrongPower($side);
		}

	public function getStrongPower($side = null) {
			/* decompiled (structured CF) */
			if (($this->isPowered() && ($side === \pocketmine\math\Vector3::getOppositeSide($this->getFacing())))) {
			} else {
			}
			return 0;
		}

	public function onNeighborChange($side = null) {
			/* decompiled (structured CF) */
			if ((($side !== \pocketmine\math\Vector3::getOppositeSide($this->getFacing())) || !($this->canUseRedstone()))) {
				return null;
			}
			if (!($this->getLevel()->isBlockTickPending($this, $this))) {
				new \pocketmine\event\redstone\RedstoneUpdateEvent($this);
				$ev = new \pocketmine\event\redstone\RedstoneUpdateEvent($this);
				$this->getLevel()->getServer()->getPluginManager()->callEvent($ev);
				if ($ev->isCancelled()) {
				}
				$this->getLevel()->scheduleUpdate($this, 1);
			}
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if ((($type !== \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED) && ($type !== \pocketmine\level\Level::BLOCK_UPDATE_MOVED))) {
				return false;
			}
			new \pocketmine\event\redstone\RedstoneUpdateEvent($this);
			$ev = new \pocketmine\event\redstone\RedstoneUpdateEvent($this);
			$this->getLevel()->getServer()->getPluginManager()->callEvent($ev);
			if ($ev->isCancelled()) {
				return false;
			}
			if ($this->isPowered()) {
			} else {
			}
			$oldPower = 0;
			$this->setPowered(!($this->isPowered()));
			if ($this->isPowered()) {
			} else {
			}
			$newPower = 0;
			new \pocketmine\event\redstone\BlockRedstoneEvent($this, $oldPower, $newPower);
			$this->getLevel()->getServer()->getPluginManager()->callEvent(new \pocketmine\event\redstone\BlockRedstoneEvent($this, $oldPower, $newPower));
			$this->getLevel()->setBlock($this, $this, true, false);
			$output = $this->getSide($this->getFacing());
			$output->onUpdate(\pocketmine\level\Level::BLOCK_UPDATE_REDSTONE);
			$this->getLevel()->updateAroundRedstone($output, null);
			if ($this->isPowered()) {
				$this->getLevel()->scheduleUpdate($this, 2);
			}
			return $type;
		}

	private function canUseRedstone() {
			/* decompiled (structured CF) */
			if (!($this->isValid())) {
				return false;
			}
			$server = $this->getLevel()->getServer();
			return (!(isset($server->redstoneEnabled)) || $server->redstoneEnabled);
		}

}
