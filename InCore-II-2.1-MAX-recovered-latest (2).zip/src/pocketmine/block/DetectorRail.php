<?php

namespace pocketmine\block;

class DetectorRail extends \pocketmine\block\PoweredRail {
	public const RECHECK_DELAY = 20;

	protected $id = 28;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return;
		}

	public function isPowerSource() {
			return true;
		}

	public function getStrongPower($side = null) {
			/* decompiled (structured CF) */
			if (($this->isActive() && ($side === \pocketmine\math\Vector3::SIDE_UP))) {
			} else {
			}
			return 0;
		}

	public function getWeakPower($side = null) {
			/* decompiled (structured CF) */
			if ($this->isActive()) {
			} else {
			}
			return 0;
		}

	public function hasEntityCollision() {
			return true;
		}

	public function onEntityCollide($entity = null) {
			$this->updateState();
			return null;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED)) {
				$this->updateState();
				return $type;
			}
			return \pocketmine\block\Rail::onUpdate($type);
		}

	protected function updateState() {
			/* decompiled (structured CF) */
			$wasPowered = $this->isActive();
			$isPowered = false;
			new \pocketmine\math\AxisAlignedBB(($this->x + 0.125), $this->y, ($this->z + 0.125), ($this->x + 0.875), ($this->y + 0.75), ($this->z + 0.875));
			$bb = new \pocketmine\math\AxisAlignedBB(($this->x + 0.125), $this->y, ($this->z + 0.125), ($this->x + 0.875), ($this->y + 0.75), ($this->z + 0.875));
			foreach ($this->getLevel()->getCollidingEntities($bb) as $entity) {
				if (((($entity instanceof \pocketmine\entity\Minecart || $entity instanceof \pocketmine\entity\MinecartChest) || $entity instanceof \pocketmine\entity\MinecartHopper) || $entity instanceof \pocketmine\entity\MinecartTNT)) {
					$isPowered = true;
				} else {
					/* goto */
				}
			}
			if (($isPowered !== $wasPowered)) {
				$this->setActive($isPowered);
				$this->getLevel()->scheduleUpdate($this->getSide(\pocketmine\math\Vector3::SIDE_DOWN), 0);
				$this->getLevel()->updateAroundRedstone($this);
			}
			if ($isPowered) {
				$this->getLevel()->scheduleUpdate($this, self::RECHECK_DELAY);
			}
			return null;
		}

}
