<?php

namespace pocketmine\block;

class DoubleSlab extends \pocketmine\block\Solid {
	protected $id = 43;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getHardness() {
			return 2;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function getName() {
			return (($this . $names[($this->meta & 7)]) . $this);
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((1 <= $item->isPickaxe())) {
				return [[\pocketmine\item\Item::SLAB, ($this->meta & 7), 2]];
			} else {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
		}

}
