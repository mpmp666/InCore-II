<?php

namespace pocketmine\block;

class Pumpkin extends \pocketmine\block\Solid {
	protected $id = 86;

	public function __construct() {
			// empty
		}

	public function getHardness() {
			return 1;
		}

	public function isHelmet() {
			return true;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_AXE;
		}

	public function getName() {
			return 'Pumpkin';
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			if ($player instanceof \pocketmine\Player) {
				$this->meta = ((($player->getDirection()) + 5) % 4);
			}
			$this->getLevel()->setBlock($block, $this, true, true);
			if (($player != null)) {
				$level = $this->getLevel();
				if ($player->getServer()->allowSnowGolem) {
					$block0 = $level->getBlock($block->add(0, -1, 0));
					$block1 = $level->getBlock($block->add(0, -2, 0));
					if ((($block0->getId() == \pocketmine\item\Item::SNOW_BLOCK) && ($block1->getId() == \pocketmine\item\Item::SNOW_BLOCK))) {
						new \pocketmine\block\Air();
						$level->setBlock($block, new \pocketmine\block\Air());
						new \pocketmine\block\Air();
						$level->setBlock($block0, new \pocketmine\block\Air());
						new \pocketmine\block\Air();
						$level->setBlock($block1, new \pocketmine\block\Air());
						new \pocketmine\nbt\tag\DoubleTag('', $this->x);
						new \pocketmine\nbt\tag\DoubleTag('', $this->y);
						new \pocketmine\nbt\tag\DoubleTag('', $this->z);
						new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', $this->y), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]);
						new \pocketmine\nbt\tag\DoubleTag('', 0);
						new \pocketmine\nbt\tag\DoubleTag('', 0);
						new \pocketmine\nbt\tag\DoubleTag('', 0);
						new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]);
						new \pocketmine\nbt\tag\FloatTag('', 0);
						new \pocketmine\nbt\tag\FloatTag('', 0);
						new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', 0), new \pocketmine\nbt\tag\FloatTag('', 0)]);
						new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', $this->y), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', 0), new \pocketmine\nbt\tag\FloatTag('', 0)])]);
						new \pocketmine\entity\SnowGolem($player->getLevel()->getChunk(($this->getX() >> 4), ($this->getZ() >> 4)), new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', $this->y), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', 0), new \pocketmine\nbt\tag\FloatTag('', 0)])]));
						$golem = new \pocketmine\entity\SnowGolem($player->getLevel()->getChunk(($this->getX() >> 4), ($this->getZ() >> 4)), new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', $this->y), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', 0), new \pocketmine\nbt\tag\FloatTag('', 0)])]));
						$golem->spawnToAll();
					}
				}
				if ($player->getServer()->allowIronGolem) {
					$block0 = $level->getBlock($block->add(0, -1, 0));
					$block1 = $level->getBlock($block->add(0, -2, 0));
					$block2 = $level->getBlock($block->add(-1, -1, 0));
					$block3 = $level->getBlock($block->add(1, -1, 0));
					$block4 = $level->getBlock($block->add(0, -1, -1));
					$block5 = $level->getBlock($block->add(0, -1, 1));
					if ((($block0->getId() == \pocketmine\item\Item::IRON_BLOCK) && ($block1->getId() == \pocketmine\item\Item::IRON_BLOCK))) {
						if ((((($block2->getId() == \pocketmine\item\Item::IRON_BLOCK) && ($block3->getId() == \pocketmine\item\Item::IRON_BLOCK)) && ($block4->getId() == \pocketmine\item\Item::AIR)) && ($block5->getId() == \pocketmine\item\Item::AIR))) {
							new \pocketmine\block\Air();
							$level->setBlock($block2, new \pocketmine\block\Air());
							new \pocketmine\block\Air();
							$level->setBlock($block3, new \pocketmine\block\Air());
						} else {
							if ((((($block4->getId() == \pocketmine\item\Item::IRON_BLOCK) && ($block5->getId() == \pocketmine\item\Item::IRON_BLOCK)) && ($block2->getId() == \pocketmine\item\Item::AIR)) && ($block3->getId() == \pocketmine\item\Item::AIR))) {
								new \pocketmine\block\Air();
								$level->setBlock($block4, new \pocketmine\block\Air());
								new \pocketmine\block\Air();
								$level->setBlock($block5, new \pocketmine\block\Air());
							} else {
								return null;
							}
						}
						new \pocketmine\block\Air();
						$level->setBlock($block, new \pocketmine\block\Air());
						new \pocketmine\block\Air();
						$level->setBlock($block0, new \pocketmine\block\Air());
						new \pocketmine\block\Air();
						$level->setBlock($block1, new \pocketmine\block\Air());
						new \pocketmine\nbt\tag\DoubleTag('', $this->x);
						new \pocketmine\nbt\tag\DoubleTag('', $this->y);
						new \pocketmine\nbt\tag\DoubleTag('', $this->z);
						new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', $this->y), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]);
						new \pocketmine\nbt\tag\DoubleTag('', 0);
						new \pocketmine\nbt\tag\DoubleTag('', 0);
						new \pocketmine\nbt\tag\DoubleTag('', 0);
						new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]);
						new \pocketmine\nbt\tag\FloatTag('', 0);
						new \pocketmine\nbt\tag\FloatTag('', 0);
						new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', 0), new \pocketmine\nbt\tag\FloatTag('', 0)]);
						new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', $this->y), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', 0), new \pocketmine\nbt\tag\FloatTag('', 0)])]);
						new \pocketmine\entity\IronGolem($player->getLevel()->getChunk(($this->getX() >> 4), ($this->getZ() >> 4)), new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', $this->y), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', 0), new \pocketmine\nbt\tag\FloatTag('', 0)])]));
						$golem = new \pocketmine\entity\IronGolem($player->getLevel()->getChunk(($this->getX() >> 4), ($this->getZ() >> 4)), new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', $this->y), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', 0), new \pocketmine\nbt\tag\FloatTag('', 0)])]));
						$golem->spawnToAll();
					}
				}
			}
			return true;
		}

}
