<?php

namespace pocketmine\block;

class Leaves extends \pocketmine\block\Transparent {
	public const OAK = 0;
	public const SPRUCE = 1;
	public const BIRCH = 2;
	public const JUNGLE = 3;
	public const ACACIA = 0;
	public const DARK_OAK = 1;

	protected $id = 18;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getHardness() {
			return 0.2;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_SHEARS;
		}

	public function getBurnChance() {
			return 30;
		}

	public function getBurnAbility() {
			return 60;
		}

	public function getName() {
			return $names[($this->meta & 3)];
		}

	private function findLog($pos = null, $visited = null, $distance = null, $check = null, $fromSide = null) {
			/* decompiled (structured CF) */
			$check++;
			$index = (((($pos->x . '.') . $pos->y) . '.') . $pos->z);
			if (isset($visited[$index])) {
				return false;
			}
			if (($pos->getId() === self::WOOD)) {
				return true;
			} else {
				if ((($pos->getId() === self::LEAVES) && ($distance < 3))) {
					$visited[$index] = true;
					$down = $pos->getSide(0)->getId();
					if (($down === \pocketmine\item\Item::WOOD)) {
						return true;
					}
					if (($fromSide === null)) {
						$side = 2;
						while (($side <= 5)) {
							if (($this->findLog($pos->getSide($side), $visited, ($distance + 1), $check, $side) === true)) {
								return true;
							}
							$side++;
						}
					} else {
						if (!(($fromSide == 2))) {
							if (!(($fromSide == 3))) {
								if (!(($fromSide == 4))) {
									if (!(($fromSide == 5))) {
									} else {
										if (($this->findLog($pos->getSide(2), $visited, ($distance + 1), $check, $fromSide) === true)) {
											return true;
										} else {
											if (($this->findLog($pos->getSide(4), $visited, ($distance + 1), $check, $fromSide) === true)) {
												return true;
											} else {
												if (($this->findLog($pos->getSide(5), $visited, ($distance + 1), $check, $fromSide) === true)) {
													return true;
												}
											}
										}
										/* jump */
										if (($this->findLog($pos->getSide(3), $visited, ($distance + 1), $check, $fromSide) === true)) {
											return true;
										} else {
											if (($this->findLog($pos->getSide(4), $visited, ($distance + 1), $check, $fromSide) === true)) {
												return true;
											} else {
												if (($this->findLog($pos->getSide(5), $visited, ($distance + 1), $check, $fromSide) === true)) {
													return true;
												}
											}
										}
										/* jump */
										if (($this->findLog($pos->getSide(2), $visited, ($distance + 1), $check, $fromSide) === true)) {
											return true;
										} else {
											if (($this->findLog($pos->getSide(3), $visited, ($distance + 1), $check, $fromSide) === true)) {
												return true;
											} else {
												if (($this->findLog($pos->getSide(4), $visited, ($distance + 1), $check, $fromSide) === true)) {
													return true;
												}
											}
										}
										/* jump */
										if (($this->findLog($pos->getSide(2), $visited, ($distance + 1), $check, $fromSide) === true)) {
											return true;
										} else {
											if (($this->findLog($pos->getSide(3), $visited, ($distance + 1), $check, $fromSide) === true)) {
												return true;
											} else {
												if (($this->findLog($pos->getSide(5), $visited, ($distance + 1), $check, $fromSide) === true)) {
													return true;
												}
											}
										}
										/* jump */
									}
									return false;
								}
							}
						}
					}
				}
			}
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				if ((($this->meta & 12) === 0)) {
					$this->meta |= 8;
					$this->getLevel()->setBlock($this, $this, false, false, true);
				}
			} else {
				if (($type === \pocketmine\level\Level::BLOCK_UPDATE_RANDOM)) {
					if ((($this->meta & 12) === 8)) {
						$this->meta &= 3;
						$visited = ['__array_ptr' => '2aaaac9fc9a0'];
						$check = 0;
						new \pocketmine\event\block\LeavesDecayEvent($this);
						$ev = new \pocketmine\event\block\LeavesDecayEvent($this);
						\pocketmine\Server::getInstance()->getPluginManager()->callEvent($ev);
						if (($ev->isCancelled() || ($this->findLog($this, $visited, 0, $check) === true))) {
							$this->getLevel()->setBlock($this, $this, false, false);
						} else {
							$this->getLevel()->useBreakOn($this);
							return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
						}
					}
				}
			}
			return false;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			$this->meta |= 4;
			$this->getLevel()->setBlock($this, $this, true);
			return null;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			$drops = ['__array_ptr' => '2aaaac9fc9a0'];
			if (($item->isShears() || (0 < $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_SILK_TOUCH)))) {
				$drops[] = [\pocketmine\item\Item::LEAVES, ($this->meta & 3), 1];
			} else {
				$fortunel = $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_FORTUNE);
				if ((3 < $fortunel)) {
				} else {
				}
				$fortunel = $fortunel;
				$rates = ['__array_ptr' => '2aaaadd5d738'];
				if ((mt_rand(1, $rates[$fortunel]) === 1)) {
					$drops[] = [\pocketmine\item\Item::SAPLING, ($this->meta & 3), 1];
				}
				$rates = ['__array_ptr' => '2aaaadd5d770'];
				if (((($this->meta & 3) === self::OAK) && (mt_rand(1, $rates[$fortunel]) === 1))) {
					$drops[] = [\pocketmine\item\Item::APPLE, 0, 1];
				}
			}
			return $drops;
		}

}
