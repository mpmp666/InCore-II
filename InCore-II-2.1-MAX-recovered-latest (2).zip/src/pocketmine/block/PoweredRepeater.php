<?php

namespace pocketmine\block;

class PoweredRepeater extends \pocketmine\block\RedstoneDiode {
	protected $id = 94;
	protected $isPowered = true;

	public function getName() {
			return;
		}

	protected function getDelay() {
			return ((1 + ($this->meta >> 2)) << 1);
		}

	public function getDelayLevel() {
			return ((($this->meta >> 2) & 3) + 1);
		}

	protected function getPowered() {
			return \pocketmine\block\Block::get(self::POWERED_REPEATER, $this->meta);
		}

	protected function getUnpowered() {
			return \pocketmine\block\Block::get(self::UNPOWERED_REPEATER, $this->meta);
		}

	public function isLocked() {
			return (0 < $this->getPowerOnSides());
		}

	protected function isAlternateInput($block = null) {
			return self::isDiode($block);
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			$this->meta += 4;
			if ((15 < $this->meta)) {
				$this->meta %= 4;
			}
			$this->level->setBlock($this, $this, true, true);
			return true;
		}

	public function getDrops($item = null) {
			return [[\pocketmine\item\Item::REPEATER, 0, 1]];
		}

}
