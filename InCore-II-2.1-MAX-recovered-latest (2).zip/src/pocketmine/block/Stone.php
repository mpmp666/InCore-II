<?php

namespace pocketmine\block;

class Stone extends \pocketmine\block\Solid {
	public const NORMAL = 0;
	public const GRANITE = 1;
	public const POLISHED_GRANITE = 2;
	public const DIORITE = 3;
	public const POLISHED_DIORITE = 4;
	public const ANDESITE = 5;
	public const POLISHED_ANDESITE = 6;

	protected $id = 1;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getHardness() {
			return 1.5;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function getName() {
			return $names[(($this->meta) & 7)];
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((\pocketmine\item\Tool::TIER_WOODEN <= $item->isPickaxe())) {
				if (((0 < $item->getEnchantmentLevel(\pocketmine\item\enchantment\enchantment::TYPE_MINING_SILK_TOUCH)) && ($this->getDamage() === 0))) {
					return [[\pocketmine\item\Item::STONE, 0, 1]];
				}
				if (($this->getDamage() === 0)) {
				} else {
				}
				return [[\pocketmine\item\Item::STONE, $this->getDamage(), 1]];
			} else {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
		}

}
