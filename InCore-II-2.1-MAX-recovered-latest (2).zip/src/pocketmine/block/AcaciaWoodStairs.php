<?php

namespace pocketmine\block;

class AcaciaWoodStairs extends \pocketmine\block\Stair {
	protected $id = 163;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return;
		}

	public function getDrops($item = null) {
			return [[$this->id, 0, 1]];
		}

	public function getHardness() {
			return 2;
		}

	public function getResistance() {
			return 15;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_AXE;
		}

}
