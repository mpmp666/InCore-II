<?php

namespace pocketmine\block;

class Glass extends \pocketmine\block\Transparent {
	protected $id = 20;

	public function __construct() {
			// empty
		}

	public function getName() {
			return 'Glass';
		}

	public function getHardness() {
			return 0.3;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((0 < $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_SILK_TOUCH))) {
				return [[\pocketmine\item\Item::GLASS, 0, 1]];
			} else {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
		}

}
