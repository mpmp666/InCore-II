<?php

namespace pocketmine\block;

class FenceGateJungle extends \pocketmine\block\FenceGate {
	protected $id = 185;

	public function getName() {
			return;
		}

}
