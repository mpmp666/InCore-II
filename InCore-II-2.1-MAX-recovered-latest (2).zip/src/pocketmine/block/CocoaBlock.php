<?php

namespace pocketmine\block;

class CocoaBlock extends \pocketmine\block\Solid {
	protected $id = 127;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return;
		}

	public function getHardness() {
			return 0.2;
		}

	public function getResistance() {
			return 15;
		}

	public function canBeActivated() {
			return true;
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			if ((($item->getId() === \pocketmine\item\Item::DYE) && ($item->getDamage() === 15))) {
				$block = clone $this;
				if ((7 < $block->meta)) {
					return false;
				}
				$block->meta += 4;
				new \pocketmine\event\block\BlockGrowEvent($this, $block);
				$ev = new \pocketmine\event\block\BlockGrowEvent($this, $block);
				\pocketmine\Server::getInstance()->getPluginManager()->callEvent($ev);
				if (!($ev->isCancelled())) {
					$this->getLevel()->setBlock($this, $ev->getNewState(), true, true);
				}
				return true;
			}
			return false;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				$faces = ['__array_ptr' => '2aaaadd5d460'];
				if (($this->getSide($faces[$this->meta])->isTransparent() === true)) {
					$this->getLevel()->useBreakOn($this);
					return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
				}
			} else {
				if (($type === \pocketmine\level\Level::BLOCK_UPDATE_RANDOM)) {
					if ((mt_rand(0, 45) === 1)) {
						if (($this->meta <= 7)) {
							$block = clone $this;
							$block->meta += 4;
							new \pocketmine\event\block\BlockGrowEvent($this, $block);
							$ev = new \pocketmine\event\block\BlockGrowEvent($this, $block);
							\pocketmine\Server::getInstance()->getPluginManager()->callEvent($ev);
							if (!($ev->isCancelled())) {
								$this->getLevel()->setBlock($this, $ev->getNewState(), true, true);
							} else {
								return \pocketmine\level\Level::BLOCK_UPDATE_RANDOM;
							}
						}
					} else {
						return \pocketmine\level\Level::BLOCK_UPDATE_RANDOM;
					}
				}
			}
			return false;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			if ((($target->getId() === \pocketmine\block\Block::WOOD) && ($target->getDamage() === 3))) {
				if ((($face !== 0) && ($face !== 1))) {
					$faces = ['__array_ptr' => '2aaaadd5d508'];
					$this->meta = $faces[$face];
					$this->getLevel()->setBlock($block, \pocketmine\block\Block::get(\pocketmine\item\Item::COCOA_BLOCK, $this->meta), true);
					return true;
				}
			}
			return false;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			$drops = ['__array_ptr' => '2aaaac9fc9a0'];
			if ((8 <= $this->meta)) {
				$drops[] = [\pocketmine\item\Item::DYE, 3, 3];
			} else {
				$drops[] = [\pocketmine\item\Item::DYE, 3, 1];
			}
			return $drops;
		}

}
