<?php

namespace pocketmine\block;

class SpruceWoodStairs extends \pocketmine\block\Stair {
	protected $id = 134;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_AXE;
		}

	public function getDrops($item = null) {
			return [[$this->id, 0, 1]];
		}

}
