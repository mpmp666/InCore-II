<?php

namespace pocketmine\block;

class Bricks extends \pocketmine\block\Solid {
	protected $id = 45;

	public function __construct() {
			// empty
		}

	public function getHardness() {
			return 2;
		}

	public function getResistance() {
			return 30;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function getName() {
			return 'Bricks';
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((1 <= $item->isPickaxe())) {
				return [[\pocketmine\item\Item::BRICKS_BLOCK, 0, 1]];
			} else {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
		}

}
