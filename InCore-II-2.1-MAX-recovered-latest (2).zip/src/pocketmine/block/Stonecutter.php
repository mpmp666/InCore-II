<?php

namespace pocketmine\block;

class Stonecutter extends \pocketmine\block\Solid {
	protected $id = 245;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return 'Stonecutter';
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function canBeActivated() {
			return true;
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			if ($player instanceof \pocketmine\Player) {
				$player->craftingType = 2;
			}
			return true;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((1 <= $item->isPickaxe())) {
				return [[\pocketmine\item\Item::STONECUTTER, 0, 1]];
			} else {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
		}

}
