<?php

namespace pocketmine\block;

class Snow extends \pocketmine\block\Solid {
	protected $id = 80;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getHardness() {
			return 0.2;
		}

	public function getName() {
			return;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if (($item->isShovel() !== false)) {
				if ((0 < $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_SILK_TOUCH))) {
					return [[\pocketmine\item\Item::SNOW_BLOCK, 0, 1]];
				} else {
					return [[\pocketmine\item\Item::SNOWBALL, 0, 4]];
				}
			} else {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
		}

}
