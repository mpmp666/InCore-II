<?php

namespace pocketmine\block;

class MovingBlock extends \pocketmine\block\Transparent {
	protected $id = 36;

	public function __construct($meta = null) {
			$this->meta = ($meta & 15);
		}

	public function getName() {
			return;
		}

	public function isSolid() {
			return false;
		}

	public function canPassThrough() {
			return true;
		}

	public function canBeFlowedInto() {
			return false;
		}

	public function canBePushedByPiston() {
			return false;
		}

	public function canBePulledByPiston() {
			return false;
		}

	public function isBreakable($item = null) {
			return false;
		}

	public function getHardness() {
			return -1;
		}

	public function getResistance() {
			return -1;
		}

	public function getDrops($item = null) {
			return ['__array_ptr' => '2aaaac9fc9a0'];
		}

}
