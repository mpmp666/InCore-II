<?php

namespace pocketmine\block;

class Sand extends \pocketmine\block\Fallable {
	protected $id = 12;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getHardness() {
			return 0.5;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_SHOVEL;
		}

	public function getName() {
			/* decompiled (structured CF) */
			if (($this->meta === 1)) {
				return $this;
			}
			return 'Sand';
		}

}
