<?php

namespace pocketmine\block;

class Furnace extends \pocketmine\block\BurningFurnace {
	protected $id = 61;

	public function getName() {
			return 'Furnace';
		}

}
