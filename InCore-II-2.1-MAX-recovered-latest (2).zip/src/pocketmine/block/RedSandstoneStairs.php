<?php

namespace pocketmine\block;

class RedSandstoneStairs extends \pocketmine\block\SandstoneStairs {
	protected $id = 180;

	public function getName() {
			return;
		}

}
