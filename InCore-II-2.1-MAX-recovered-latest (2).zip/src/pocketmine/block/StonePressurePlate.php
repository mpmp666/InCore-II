<?php

namespace pocketmine\block;

class StonePressurePlate extends \pocketmine\block\PressurePlate {
	protected $id = 70;

	public function getName() {
			return;
		}

	public function onEntityCollide($entity = null) {
			/* decompiled (structured CF) */
			if ($entity instanceof \pocketmine\entity\Living) {
				parent::onEntityCollide($entity);
			}
			return null;
		}

}
