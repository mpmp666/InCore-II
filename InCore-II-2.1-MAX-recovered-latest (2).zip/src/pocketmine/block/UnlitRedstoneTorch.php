<?php

namespace pocketmine\block;

class UnlitRedstoneTorch extends \pocketmine\block\RedstoneTorch {
	protected $id = 75;

	public function getLightLevel() {
			return 0;
		}

	public function isActivated($from = null) {
			return false;
		}

}
