<?php

namespace pocketmine\block;

class NetherBrickStairs extends \pocketmine\block\Stair {
	protected $id = 114;

	public function getName() {
			return;
		}

	public function getHardness() {
			return 2;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

}
