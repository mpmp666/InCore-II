<?php

namespace pocketmine\block;

class DoubleRedSandstoneSlab extends \pocketmine\block\DoubleSlab {
	protected $id = 181;

	public function getName() {
			return;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((1 <= $item->isPickaxe())) {
				return [[\pocketmine\item\Item::RED_SANDSTONE_SLAB, $this->meta, 2]];
			} else {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
		}

}
