<?php

namespace pocketmine\block;

class Melon extends \pocketmine\block\Transparent {
	protected $id = 103;

	public function __construct() {
			// empty
		}

	public function getName() {
			return;
		}

	public function getHardness() {
			return 1;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_AXE;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((0 < $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_SILK_TOUCH))) {
				return [[\pocketmine\item\Item::MELON_BLOCK, 0, 1]];
			} else {
				$fortunel = $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_FORTUNE);
				if ((2 < $fortunel)) {
				} else {
				}
				$fortunel = $fortunel;
				return [[\pocketmine\item\Item::MELON_SLICE, 0, mt_rand(3, (7 + $fortunel))]];
			}
		}

}
