<?php

namespace pocketmine\block;

class Gravel extends \pocketmine\block\Fallable {
	protected $id = 13;

	public function __construct() {
			// empty
		}

	public function getName() {
			return 'Gravel';
		}

	public function getHardness() {
			return 0.6;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_SHOVEL;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			$drops = ['__array_ptr' => '2aaaac9fc9a0'];
			if ((0 < $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_SILK_TOUCH))) {
				$drops[] = [\pocketmine\item\Item::GRAVEL, 0, 1];
				return $drops;
			}
			$fortunel = $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_FORTUNE);
			if ((3 < $fortunel)) {
			} else {
			}
			$fortunel = $fortunel;
			$rates = ['__array_ptr' => '2aaaadd5d498'];
			if ((mt_rand(1, $rates[$fortunel]) === 1)) {
				$drops[] = [\pocketmine\item\Item::FLINT, 0, 1];
			}
			if ((mt_rand(1, 10) !== 1)) {
				$drops[] = [\pocketmine\item\Item::GRAVEL, 0, 1];
			}
			return $drops;
		}

}
