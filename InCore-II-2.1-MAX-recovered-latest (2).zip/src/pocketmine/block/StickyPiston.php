<?php

namespace pocketmine\block;

class StickyPiston extends \pocketmine\block\PistonBase {
	protected $id = 29;
	protected $sticky = true;

	public function getName() {
			return;
		}

	protected function createHead($face = null) {
			/* decompiled (structured CF) */
			new \pocketmine\block\PistonHead();
			$head = new \pocketmine\block\PistonHead();
			$head->setFacing($face);
			$head->setSticky(true);
			return $head;
		}

}
