<?php

namespace pocketmine\block;

class GoldOre extends \pocketmine\block\Solid {
	protected $id = 14;

	public function __construct() {
			// empty
		}

	public function getName() {
			return;
		}

	public function getHardness() {
			return 3;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((4 <= $item->isPickaxe())) {
				return [[\pocketmine\item\Item::GOLD_ORE, 0, 1]];
			} else {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
		}

}
