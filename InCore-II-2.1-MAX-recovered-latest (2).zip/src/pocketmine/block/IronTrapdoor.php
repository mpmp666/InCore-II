<?php

namespace pocketmine\block;

class IronTrapdoor extends \pocketmine\block\Trapdoor {
	protected $id = 167;

	public function getName() {
			return;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function getHardness() {
			return 5;
		}

	public function isSolid() {
			return false;
		}

	public function canPassThrough() {
			return true;
		}

	public function getResistance() {
			return 25;
		}

}
