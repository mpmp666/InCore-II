<?php

namespace pocketmine\block;

class ActiveRedstoneLamp extends \pocketmine\block\Solid implements \pocketmine\block\ElectricalAppliance {
	protected $id = 124;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return;
		}

	public function getHardness() {
			return 0.3;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function getLightLevel() {
			return 15;
		}

	public function getDrops($item = null) {
			return [[\pocketmine\item\Item::INACTIVE_REDSTONE_LAMP, 0, 1]];
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if ((($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL) || ($type === \pocketmine\level\Level::BLOCK_UPDATE_REDSTONE))) {
				if ($this->getLevel()->isBlockPowered($this)) {
					if (($this->getId() === self::INACTIVE_REDSTONE_LAMP)) {
						$this->turnOn();
					}
				} else {
					if ((($this->getId() === self::ACTIVE_REDSTONE_LAMP) && !($this->getLevel()->isBlockTickPending($this, $this)))) {
						$this->getLevel()->scheduleUpdate($this, 4);
					}
				}
				return $type;
			}
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED)) {
				if ((($this->getId() === self::ACTIVE_REDSTONE_LAMP) && !($this->getLevel()->isBlockPowered($this)))) {
					$this->turnOff();
				}
				return \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED;
			}
			return false;
		}

	public function isLightedByAround() {
			return ($this->meta == 1);
		}

	protected function checkPower($ignore = null) {
			/* decompiled (structured CF) */
			if ($this->isLightedByAround()) {
				$sides = [\pocketmine\math\Vector3::SIDE_EAST, \pocketmine\math\Vector3::SIDE_WEST, \pocketmine\math\Vector3::SIDE_SOUTH, \pocketmine\math\Vector3::SIDE_NORTH, \pocketmine\math\Vector3::SIDE_UP, \pocketmine\math\Vector3::SIDE_DOWN];
				foreach ($sides as $side) {
					if (!(in_array($side, $ignore))) {
						$block = $this->getSide($side);
						if (($block->getId() == $this->id)) {
							if (!($block->isLightedByAround())) {
								return true;
							}
						}
					}
					/* goto */
				}
			}
			return false;
		}

	public function lightAround() {
			/* decompiled (structured CF) */
			$sides = [\pocketmine\math\Vector3::SIDE_EAST, \pocketmine\math\Vector3::SIDE_WEST, \pocketmine\math\Vector3::SIDE_SOUTH, \pocketmine\math\Vector3::SIDE_NORTH, \pocketmine\math\Vector3::SIDE_UP, \pocketmine\math\Vector3::SIDE_DOWN];
			foreach ($sides as $side) {
				$block = $this->getSide($side);
				if (($block->getId() == self::INACTIVE_REDSTONE_LAMP)) {
					$block->turnOn();
				}
				/* goto */
			}
			return null;
		}

	protected function turnAroundOff($ignore = null) {
			/* decompiled (structured CF) */
			if (!($this->isLightedByAround())) {
				$sides = [\pocketmine\math\Vector3::SIDE_EAST, \pocketmine\math\Vector3::SIDE_WEST, \pocketmine\math\Vector3::SIDE_SOUTH, \pocketmine\math\Vector3::SIDE_NORTH, \pocketmine\math\Vector3::SIDE_UP, \pocketmine\math\Vector3::SIDE_DOWN];
				foreach ($sides as $side) {
					if (!(in_array($side, $ignore))) {
						$block = $this->getSide($side);
						if (($block->getId() == $this->id)) {
							if ($block->isLightedByAround()) {
								if (!($block->checkPower([$this->getOppositeSide($side)]))) {
									$block->turnOff();
								}
							}
						}
					}
					/* goto */
				}
			}
			return null;
		}

	public function turnOn() {
			$this->meta = 0;
			$this->getLevel()->setBlock($this, $this, true, false);
			return true;
		}

	public function turnOff() {
			new \pocketmine\block\InactiveRedstoneLamp();
			$this->getLevel()->setBlock($this, new \pocketmine\block\InactiveRedstoneLamp(), true, false);
			return true;
		}

}
