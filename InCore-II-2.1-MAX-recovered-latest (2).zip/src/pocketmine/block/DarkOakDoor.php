<?php

namespace pocketmine\block;

class DarkOakDoor extends \pocketmine\block\Door {
	protected $id = 197;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return;
		}

	public function canBeActivated() {
			return true;
		}

	public function getHardness() {
			return 3;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_AXE;
		}

	public function getDrops($item = null) {
			return [[\pocketmine\item\Item::DARK_OAK_DOOR, 0, 1]];
		}

}
