<?php

namespace pocketmine\block;

class Fire extends \pocketmine\block\Flowable {
	protected $id = 51;
	private $temporalVector = NULL;

	public function __construct($meta = null) {
			/* decompiled (structured CF) */
			$this->meta = $meta;
			if (($this->temporalVector === null)) {
				new \pocketmine\math\Vector3(0, 0, 0);
				$this->temporalVector = new \pocketmine\math\Vector3(0, 0, 0);
			}
			return;
		}

	public function hasEntityCollision() {
			return true;
		}

	public function getName() {
			return;
		}

	public function getLightLevel() {
			return 15;
		}

	public function isBreakable($item = null) {
			return true;
		}

	public function canBeReplaced() {
			return true;
		}

	public function canBeActivated() {
			return true;
		}

	public function onActivate($item = null, $player = null) {
			return $this->extinguish();
		}

	public function onBreak($item = null) {
			return $this->extinguish();
		}

	private function extinguish() {
			new \pocketmine\block\Air();
			return $this->getLevel()->setBlock($this, new \pocketmine\block\Air(), true, true);
		}

	public function onEntityCollide($entity = null) {
			/* decompiled (structured CF) */
			if (!($entity->hasEffect(\pocketmine\entity\Effect::FIRE_RESISTANCE))) {
				new \pocketmine\event\entity\EntityDamageByBlockEvent($this, $entity, \pocketmine\event\entity\EntityDamageEvent::CAUSE_FIRE, 1);
				$ev = new \pocketmine\event\entity\EntityDamageByBlockEvent($this, $entity, \pocketmine\event\entity\EntityDamageEvent::CAUSE_FIRE, 1);
				if (($entity->attack($ev->getFinalDamage(), $ev) === true)) {
					$ev->useArmors();
				}
			}
			new \pocketmine\event\entity\EntityCombustByBlockEvent($this, $entity, 8);
			$ev = new \pocketmine\event\entity\EntityCombustByBlockEvent($this, $entity, 8);
			if ($entity instanceof \pocketmine\entity\Arrow) {
				$ev->setCancelled();
			}
			\pocketmine\Server::getInstance()->getPluginManager()->callEvent($ev);
			if (!($ev->isCancelled())) {
				$entity->setOnFire($ev->getDuration());
			}
			return null;
		}

	public function getDrops($item = null) {
			return ['__array_ptr' => '2aaaac9fc9a0'];
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (((($type == \pocketmine\level\Level::BLOCK_UPDATE_NORMAL) || ($type == \pocketmine\level\Level::BLOCK_UPDATE_RANDOM)) || ($type == \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED))) {
				if ((!($this->getSide(\pocketmine\math\Vector3::SIDE_DOWN)->isTopFacingSurfaceSolid()) && !($this->canNeighborBurn()))) {
					new \pocketmine\block\Air();
					$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), true);
					return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
				} else {
					if ((($type == \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED) && $this->getLevel()->getServer()->fireSpread)) {
						$forever = ($this->getSide(\pocketmine\math\Vector3::SIDE_DOWN)->getId() == \pocketmine\block\Block::NETHERRACK);
						if ((!($this->getSide(\pocketmine\math\Vector3::SIDE_DOWN)->isTopFacingSurfaceSolid()) && !($this->canNeighborBurn()))) {
							new \pocketmine\block\Air();
							$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), true);
						}
						if (((!($forever) && $this->getLevel()->getWeather()->isRainy()) && (((($this->getLevel()->canBlockSeeSky($this) || $this->getLevel()->canBlockSeeSky($this->getSide(\pocketmine\math\Vector3::SIDE_EAST))) || $this->getLevel()->canBlockSeeSky($this->getSide(\pocketmine\math\Vector3::SIDE_WEST))) || $this->getLevel()->canBlockSeeSky($this->getSide(\pocketmine\math\Vector3::SIDE_SOUTH))) || $this->getLevel()->canBlockSeeSky($this->getSide(\pocketmine\math\Vector3::SIDE_NORTH))))) {
							new \pocketmine\block\Air();
							$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), true);
						} else {
							$meta = $this->meta;
							if (($meta < 15)) {
								$this->meta = ($meta + mt_rand(0, 3));
								$this->getLevel()->setBlock($this, $this, true);
							}
							$this->getLevel()->scheduleUpdate($this, ($this->getTickRate() + mt_rand(0, 10)));
							if ((!($forever) && !($this->canNeighborBurn()))) {
								if ((!($this->getSide(\pocketmine\math\Vector3::SIDE_DOWN)->isTopFacingSurfaceSolid()) || (3 < $meta))) {
									new \pocketmine\block\Air();
									$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), true);
								}
							} else {
								if ((((!($forever) && !((0 < $this->getSide(\pocketmine\math\Vector3::SIDE_DOWN)->getBurnAbility()))) && ($meta == 15)) && (mt_rand(0, 4) == 0))) {
									new \pocketmine\block\Air();
									$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), true);
								} else {
									$o = 0;
									$this->tryToCatchBlockOnFire($this->getSide(\pocketmine\math\Vector3::SIDE_EAST), (300 + $o), $meta);
									$this->tryToCatchBlockOnFire($this->getSide(\pocketmine\math\Vector3::SIDE_WEST), (300 + $o), $meta);
									$this->tryToCatchBlockOnFire($this->getSide(\pocketmine\math\Vector3::SIDE_DOWN), (250 + $o), $meta);
									$this->tryToCatchBlockOnFire($this->getSide(\pocketmine\math\Vector3::SIDE_UP), (250 + $o), $meta);
									$this->tryToCatchBlockOnFire($this->getSide(\pocketmine\math\Vector3::SIDE_SOUTH), (300 + $o), $meta);
									$this->tryToCatchBlockOnFire($this->getSide(\pocketmine\math\Vector3::SIDE_NORTH), (300 + $o), $meta);
									$x = ($this->x - 1);
									while (($x <= $t208)) {
										$z = ($this->z - 1);
										while (($z <= $t204)) {
											$y = ($this->y - 1);
											while (($y <= $t200)) {
												$k = 100;
												if ((($this->y + 1) < $y)) {
													$k += (($y - ($this->y + 1)) * 100);
												}
												$chance = $this->getChanceOfNeighborsEncouragingFire($this->getLevel()->getBlock($this->temporalVector->setComponents($x, $y, $z)));
												if ((0 < $chance)) {
													$t = (($chance + 40) + ($this->getLevel()->getServer()->getDifficulty() * 7));
													if (((0 < $t) && (mt_rand(0, $k) <= $t))) {
														$damage = min(15, ($meta + (mt_rand(0, 5) / 4)));
														new \pocketmine\block\Fire($damage);
														$this->getLevel()->setBlock($this->temporalVector->setComponents($x, $y, $z), new \pocketmine\block\Fire($damage), true);
														$this->getLevel()->scheduleUpdate($this->temporalVector, $this->getTickRate());
													}
												}
												$y++;
											}
											$z++;
										}
										$x++;
									}
								}
							}
						}
					}
				}
			}
			return 0;
		}

	public function getTickRate() {
			return 30;
		}

	private function tryToCatchBlockOnFire($block = null, $bound = null, $damage = null) {
			/* decompiled (structured CF) */
			if (($block instanceof \pocketmine\block\TNT && !($block->getLevel()->getServer()->tntExplosionEnabled))) {
				return null;
			}
			$burnAbility = $block->getBurnAbility();
			if ((mt_rand(0, $bound) < $burnAbility)) {
				if ((mt_rand(0, ($damage + 10)) < 5)) {
					$meta = max(15, ($damage + (mt_rand(0, 4) / 4)));
					new \pocketmine\event\block\BlockBurnEvent($block);
					$ev = new \pocketmine\event\block\BlockBurnEvent($block);
					$this->getLevel()->getServer()->getPluginManager()->callEvent($ev);
					if (!($ev->isCancelled())) {
						new \pocketmine\block\Fire($meta);
						$fire = new \pocketmine\block\Fire($meta);
						$this->getLevel()->setBlock($block, $fire, true);
						$this->getLevel()->scheduleUpdate($block, $fire->getTickRate());
					}
				} else {
					new \pocketmine\block\Air();
					$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), true);
				}
				if ($block instanceof \pocketmine\block\TNT) {
					$block->prime();
				}
			}
		}

	private function getChanceOfNeighborsEncouragingFire($block = null) {
			/* decompiled (structured CF) */
			if (($block->getId() !== self::AIR)) {
				return 0;
			} else {
				$chance = 0;
				$i = 0;
				while (($i < 5)) {
					$chance = max($chance, $block->getSide($i)->getBurnChance());
					$i++;
				}
				return $chance;
			}
		}

}
