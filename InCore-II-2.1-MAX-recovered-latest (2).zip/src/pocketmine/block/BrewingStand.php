<?php

namespace pocketmine\block;

class BrewingStand extends \pocketmine\block\Transparent {
	protected $id = 117;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			if (($block->getSide(\pocketmine\math\Vector3::SIDE_DOWN)->isTransparent() === false)) {
				$this->getLevel()->setBlock($block, $this, true, true);
				new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']);
				new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::BREWING_STAND);
				new \pocketmine\nbt\tag\IntTag('x', $this->x);
				new \pocketmine\nbt\tag\IntTag('y', $this->y);
				new \pocketmine\nbt\tag\IntTag('z', $this->z);
				new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']), new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::BREWING_STAND), new \pocketmine\nbt\tag\IntTag('x', $this->x), new \pocketmine\nbt\tag\IntTag('y', $this->y), new \pocketmine\nbt\tag\IntTag('z', $this->z)]);
				$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']), new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::BREWING_STAND), new \pocketmine\nbt\tag\IntTag('x', $this->x), new \pocketmine\nbt\tag\IntTag('y', $this->y), new \pocketmine\nbt\tag\IntTag('z', $this->z)]);
				$nbt->Items->setTagType(\pocketmine\nbt\NBT::TAG_Compound);
				if ($item->hasCustomName()) {
					new \pocketmine\nbt\tag\StringTag('CustomName', $item->getCustomName());
					$nbt->CustomName = new \pocketmine\nbt\tag\StringTag('CustomName', $item->getCustomName());
				}
				if ($item->hasCustomBlockData()) {
					foreach ($item->getCustomBlockData() as $key => $v) {
						$nbt->prop = $v;
						/* goto */
					}
				}
				\pocketmine\tile\Tile::createTile(\pocketmine\tile\Tile::BREWING_STAND, $this->getLevel()->getChunk(($this->x >> 4), ($this->z >> 4)), $nbt);
				return true;
			}
			return false;
		}

	public function canBeActivated() {
			return true;
		}

	public function getHardness() {
			return 0.5;
		}

	public function getResistance() {
			return 2.5;
		}

	public function getLightLevel() {
			return 1;
		}

	public function getName() {
			return;
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			if ($player instanceof \pocketmine\Player) {
				if (($player->isCreative() && $player->getServer()->limitedCreative)) {
					return true;
				}
				$t = $this->getLevel()->getTile($this);
				if ($t instanceof \pocketmine\tile\BrewingStand) {
					$brewingStand = $t;
				} else {
					new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']);
					new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::BREWING_STAND);
					new \pocketmine\nbt\tag\IntTag('x', $this->x);
					new \pocketmine\nbt\tag\IntTag('y', $this->y);
					new \pocketmine\nbt\tag\IntTag('z', $this->z);
					new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']), new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::BREWING_STAND), new \pocketmine\nbt\tag\IntTag('x', $this->x), new \pocketmine\nbt\tag\IntTag('y', $this->y), new \pocketmine\nbt\tag\IntTag('z', $this->z)]);
					$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']), new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::BREWING_STAND), new \pocketmine\nbt\tag\IntTag('x', $this->x), new \pocketmine\nbt\tag\IntTag('y', $this->y), new \pocketmine\nbt\tag\IntTag('z', $this->z)]);
					$nbt->Items->setTagType(\pocketmine\nbt\NBT::TAG_Compound);
					$brewingStand = \pocketmine\tile\Tile::createTile(\pocketmine\tile\Tile::BREWING_STAND, $this->getLevel()->getChunk(($this->x >> 4), ($this->z >> 4)), $nbt);
				}
				$player->addWindow($brewingStand->getInventory());
			}
			return true;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			$drops = ['__array_ptr' => '2aaaac9fc9a0'];
			if ((\pocketmine\item\Tool::TIER_WOODEN <= $item->isPickaxe())) {
				$drops[] = [\pocketmine\item\Item::BREWING_STAND, 0, 1];
			}
			return $drops;
		}

	public function hasComparatorInputOverride() {
			return true;
		}

	public function getComparatorInputOverride() {
			/* decompiled (structured CF) */
			$tile = $this->getLevel()->getTile($this);
			if ($tile instanceof \pocketmine\tile\BrewingStand) {
			} else {
			}
			return 0;
		}

}
