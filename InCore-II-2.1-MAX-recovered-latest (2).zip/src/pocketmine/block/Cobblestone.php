<?php

namespace pocketmine\block;

class Cobblestone extends \pocketmine\block\Solid {
	protected $id = 4;

	public function __construct() {
			// empty
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function getName() {
			return 'Cobblestone';
		}

	public function getHardness() {
			return 2;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((1 <= $item->isPickaxe())) {
				return [[\pocketmine\item\Item::COBBLESTONE, 0, 1]];
			} else {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
		}

}
