<?php

namespace pocketmine\block;

class BrickStairs extends \pocketmine\block\Stair {
	protected $id = 108;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getHardness() {
			return 2;
		}

	public function getResistance() {
			return 30;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function getName() {
			return;
		}

}
