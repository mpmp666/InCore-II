<?php

namespace pocketmine\block;

class SpruceDoor extends \pocketmine\block\Door {
	protected $id = 193;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return;
		}

	public function canBeActivated() {
			return true;
		}

	public function getHardness() {
			return 3;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_AXE;
		}

	public function getDrops($item = null) {
			return [[\pocketmine\item\Item::SPRUCE_DOOR, 0, 1]];
		}

}
