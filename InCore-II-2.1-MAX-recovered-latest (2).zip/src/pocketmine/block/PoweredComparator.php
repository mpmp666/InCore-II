<?php

namespace pocketmine\block;

class PoweredComparator extends \pocketmine\block\RedstoneComparator {
	protected $id = 150;
	protected $isPowered = true;

	public function getName() {
			return;
		}

	protected function getPowered() {
			return \pocketmine\block\Block::get(self::POWERED_COMPARATOR, $this->meta);
		}

}
