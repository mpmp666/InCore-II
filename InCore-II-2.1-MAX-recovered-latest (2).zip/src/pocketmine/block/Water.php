<?php

namespace pocketmine\block;

class Water extends \pocketmine\block\Liquid {
	protected $id = 8;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return 'Water';
		}

	public function onEntityCollide($entity = null) {
			/* decompiled (structured CF) */
			$entity->resetFallDistance();
			if ((0 < $entity->fireTicks)) {
				$entity->extinguish();
			}
			$entity->resetFallDistance();
			return null;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			$ret = $this->getLevel()->setBlock($this, $this, true, false);
			$this->getLevel()->scheduleUpdate($this, $this->tickRate());
			return $ret;
		}

}
