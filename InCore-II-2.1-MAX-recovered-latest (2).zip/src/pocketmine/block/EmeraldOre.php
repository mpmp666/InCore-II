<?php

namespace pocketmine\block;

class EmeraldOre extends \pocketmine\block\Solid {
	protected $id = 129;

	public function __construct() {
			// empty
		}

	public function getName() {
			return;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function getHardness() {
			return 3;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((4 <= $item->isPickaxe())) {
				if ((0 < $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_SILK_TOUCH))) {
					return [[\pocketmine\item\Item::EMERALD_ORE, 0, 1]];
				} else {
					$fortunel = $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_FORTUNE);
					if ((3 < $fortunel)) {
					} else {
					}
					$fortunel = $fortunel;
					$times = ['__array_ptr' => '2aaaadd5d460'];
					$time = $times[mt_rand(0, ($fortunel + 1))];
					return [[\pocketmine\item\Item::EMERALD, 0, $time]];
				}
			} else {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
		}

}
