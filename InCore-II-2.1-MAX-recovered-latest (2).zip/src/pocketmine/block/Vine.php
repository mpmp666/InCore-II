<?php

namespace pocketmine\block;

class Vine extends \pocketmine\block\Transparent {
	protected $id = 106;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function isSolid() {
			return false;
		}

	public function getName() {
			return 'Vines';
		}

	public function getHardness() {
			return 0.2;
		}

	public function canPassThrough() {
			return true;
		}

	public function hasEntityCollision() {
			return true;
		}

	public function onEntityCollide($entity = null) {
			$entity->resetFallDistance();
			return null;
		}

	protected function recalculateBoundingBox() {
			/* decompiled (structured CF) */
			$f1 = 1;
			$f2 = 1;
			$f3 = 1;
			$f4 = 0;
			$f5 = 0;
			$f6 = 0;
			$flag = (0 < $this->meta);
			if ((0 < ($this->meta & 2))) {
				$f4 = max($f4, 0.0625);
				$f1 = 0;
				$f2 = 0;
				$f5 = 1;
				$f3 = 0;
				$f6 = 1;
				$flag = true;
			}
			if ((0 < ($this->meta & 8))) {
				$f1 = min($f1, 0.9375);
				$f4 = 1;
				$f2 = 0;
				$f5 = 1;
				$f3 = 0;
				$f6 = 1;
				$flag = true;
			}
			if ((0 < ($this->meta & 1))) {
				$f3 = min($f3, 0.9375);
				$f6 = 1;
				$f1 = 0;
				$f4 = 1;
				$f2 = 0;
				$f5 = 1;
				$flag = true;
			}
			if ((!($flag) && $this->getSide(1)->isSolid())) {
				$f2 = min($f2, 0.9375);
				$f5 = 1;
				$f1 = 0;
				$f4 = 1;
				$f3 = 0;
				$f6 = 1;
			}
			new \pocketmine\math\AxisAlignedBB(($this->x + $f1), ($this->y + $f2), ($this->z + $f3), ($this->x + $f4), ($this->y + $f5), ($this->z + $f6));
			return new \pocketmine\math\AxisAlignedBB(($this->x + $f1), ($this->y + $f2), ($this->z + $f3), ($this->x + $f4), ($this->y + $f5), ($this->z + $f6));
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			if ((!($target->isTransparent()) && $target->isSolid())) {
				$faces = ['__array_ptr' => '2aaaadd5d5b0'];
				if (isset($faces[$face])) {
					$this->meta = $faces[$face];
					$this->getLevel()->setBlock($block, $this, true, true);
					return true;
				}
			}
			return false;
		}

	public function onUpdate($type = null) {
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) { /* unresolved jump */ }
			return false;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ($item->isShears()) {
				return [[$this->id, 0, 1]];
			} else {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_SHEARS;
		}

}
