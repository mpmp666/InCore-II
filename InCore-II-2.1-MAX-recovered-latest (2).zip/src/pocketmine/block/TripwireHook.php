<?php

namespace pocketmine\block;

class TripwireHook extends \pocketmine\block\Flowable {
	public const MAX_TRIPWIRE_CIRCUIT_LENGTH = 42;
	public const ATTACHED = 4;
	public const POWERED = 8;

	protected $id = 131;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return;
		}

	public function getHardness() {
			return 0;
		}

	public function getResistance() {
			return 0;
		}

	public function getBoundingBox() {
			/* decompiled (structured CF) */
			if (($this->boundingBox === null)) {
				new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 1), ($this->z + 1));
				$this->boundingBox = new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 1), ($this->z + 1));
			}
			return $this->boundingBox;
		}

	public function canPassThrough() {
			return false;
		}

	public function isPowerSource() {
			return true;
		}

	public function getFacing() {
			/* decompiled (structured CF) */
			/* jump */
			switch (($this->meta & 3)) {
				case 0:
				return \pocketmine\math\Vector3::SIDE_SOUTH;
				case 1:
				return \pocketmine\math\Vector3::SIDE_WEST;
				case 2:
				return \pocketmine\math\Vector3::SIDE_NORTH;
			}
		}

	public function setFacing($face = null) {
			/* decompiled (structured CF) */
			if (!(($face == \pocketmine\math\Vector3::SIDE_SOUTH))) {
				if (!(($face == \pocketmine\math\Vector3::SIDE_WEST))) {
					if (!(($face == \pocketmine\math\Vector3::SIDE_NORTH))) {
						if (!(($face == \pocketmine\math\Vector3::SIDE_EAST))) {
							/* jump */
							$direction = 0;
						} else {
							$direction = 1;
							/* jump */
							$direction = 2;
							/* jump */
							$direction = 3;
							/* jump */
							return null;
						}
						$this->meta = ($direction | ($this->meta & 12));
					}
				}
			}
		}

	public function isAttached() {
			return (($this->meta & self::ATTACHED) !== 0);
		}

	public function isPowered() {
			return (($this->meta & self::POWERED) !== 0);
		}

	public function setAttached($attached = null) {
			$this->setFlag(self::ATTACHED, $attached);
			return null;
		}

	public function setPowered($powered = null) {
			$this->setFlag(self::POWERED, $powered);
			return null;
		}

	private function setFlag($flag = null, $enabled = null) {
			/* decompiled (structured CF) */
			if ($enabled) {
				$this->meta |= $flag;
			} else {
				$this->meta &= $t4;
			}
			return null;
		}

	public function getWeakPower($side = null) {
			/* decompiled (structured CF) */
			if ($this->isPowered()) {
			} else {
			}
			return 0;
		}

	public function getStrongPower($side = null) {
			/* decompiled (structured CF) */
			if (($this->isPowered() && ($side === $this->getFacing()))) {
			} else {
			}
			return 0;
		}

	private function canAttachTo($support = null) {
			return ($support->isNormalBlock() || $support instanceof \pocketmine\block\Glass);
		}

	private function isSupported() {
			$support = $this->getSide(\pocketmine\math\Vector3::getOppositeSide($this->getFacing()));
			return $this->canAttachTo($support);
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				if (!($this->isSupported())) {
					$this->getLevel()->useBreakOn($this);
				}
				return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
			}
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED)) {
				$this->updateLine(false, true);
				return \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED;
			}
			return false;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			if ((($face === \pocketmine\math\Vector3::SIDE_UP) || ($face === \pocketmine\math\Vector3::SIDE_DOWN))) {
				return false;
			}
			$support = $this->getSide(\pocketmine\math\Vector3::getOppositeSide($face));
			if (!($this->canAttachTo($support))) {
				return false;
			}
			$this->setFacing($face);
			$this->getLevel()->setBlock($block, $this, true, true);
			$this->updateLine(false, false);
			return true;
		}

	public function onBreak($item = null) {
			/* decompiled (structured CF) */
			$attached = $this->isAttached();
			$powered = $this->isPowered();
			if (($attached || $powered)) {
				$this->updateLine(true, false);
			}
			new \pocketmine\block\Air();
			$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), true, true);
			if ($powered) {
				$this->getLevel()->updateAroundRedstone($this);
				$this->getLevel()->updateAroundRedstone($this->getSide(\pocketmine\math\Vector3::getOppositeSide($this->getFacing())));
			}
			return true;
		}

	public function updateLine($isHookBroken = null, $doUpdateAroundHook = null, $eventDistance = null, $eventBlock = null) {
			/* decompiled (structured CF) */
			if (!($this->getLevel()->getServer()->redstoneEnabled)) {
				return null;
			}
			$facing = $this->getFacing();
			$wasConnected = $this->isAttached();
			$wasPowered = $this->isPowered();
			$isConnected = !($isHookBroken);
			$isPowered = false;
			$pairedHookDistance = -1;
			$line = ['__array_ptr' => '2aaaac9fc9a0'];
			$steps = 1;
			while (($steps < $t63)) {
				$block = $this->getSide($facing, $steps);
				if ($block instanceof \pocketmine\block\TripwireHook) {
					if (($block->getFacing() === \pocketmine\math\Vector3::getOppositeSide($facing))) {
						$pairedHookDistance = $steps;
					}
				} else {
					if ((($steps === $eventDistance) && ($eventBlock !== null))) {
						$block = $eventBlock;
					}
					if (!($block instanceof \pocketmine\block\Tripwire)) {
						$isConnected = false;
						$line[$steps] = null;
					} else {
						$notDisarmed = !($block->isDisarmed());
						$isPowered = ($isPowered || ($notDisarmed && $block->isPowered()));
						if (($steps === $eventDistance)) {
							$this->getLevel()->scheduleUpdate($this, 10);
							$isConnected = ($isConnected && $notDisarmed);
						}
						$line[$steps] = $block;
					}
					$steps++;
				}
			}
			$foundPairedHook = (1 < $pairedHookDistance);
			$isConnected = ($isConnected && $foundPairedHook);
			$isPowered = ($isPowered && $isConnected);
			if ($foundPairedHook) {
				$pairedPos = $this->getSide($facing, $pairedHookDistance);
				$pairedHook = \pocketmine\block\Block::get(self::TRIPWIRE_HOOK, 0);
				$pairedHook->position($pairedPos);
				$pairedHook->setFacing(\pocketmine\math\Vector3::getOppositeSide($facing));
				$pairedHook->setAttached($isConnected);
				$pairedHook->setPowered($isPowered);
				$this->getLevel()->setBlock($pairedPos, $pairedHook, true, true);
				$this->getLevel()->updateAroundRedstone($pairedPos);
				$this->getLevel()->updateAroundRedstone($pairedPos->getSide($facing));
			}
			if (!($isHookBroken)) {
				$this->setAttached($isConnected);
				$this->setPowered($isPowered);
				$this->getLevel()->setBlock($this, $this, true, true);
				if (($doUpdateAroundHook || ($wasPowered !== $isPowered))) {
					$this->getLevel()->updateAroundRedstone($this);
					$this->getLevel()->updateAroundRedstone($this->getSide(\pocketmine\math\Vector3::getOppositeSide($facing)));
				}
			}
			if (($wasConnected === $isConnected)) {
			}
			$steps = 1;
			while (($steps < $pairedHookDistance)) {
				if ((isset($line[$steps]) && $line[$steps] instanceof \pocketmine\block\Tripwire)) {
					$wire = $line[$steps];
					$wire->setAttached($isConnected);
					$this->getLevel()->setBlock($this->getSide($facing, $steps), $wire, true, true);
				}
				$steps++;
			}
		}

	public function getDrops($item = null) {
			return [[\pocketmine\item\Item::TRIPWIRE_HOOK, 0, 1]];
		}

}
