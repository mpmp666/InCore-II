<?php

namespace pocketmine\block;

class Obsidian extends \pocketmine\block\Solid {
	protected $id = 49;
	private $temporalVector = NULL;

	public function __construct() {
			/* decompiled (structured CF) */
			if (($this->temporalVector === null)) {
				new \pocketmine\math\Vector3(0, 0, 0);
				$this->temporalVector = new \pocketmine\math\Vector3(0, 0, 0);
			}
			return;
		}

	public function getName() {
			return 'Obsidian';
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function getHardness() {
			return 50;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((5 <= $item->isPickaxe())) {
				return [[\pocketmine\item\Item::OBSIDIAN, 0, 1]];
			} else {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
		}

	public function onBreak($item = null) {
			/* decompiled (structured CF) */
			parent::onBreak($item);
			if ($this->getLevel()->getServer()->netherEnabled) {
				$i = 0;
				while (($i <= 6)) {
					if (($this->getSide($i)->getId() == self::PORTAL)) {
					} else {
						if (($i == 6)) {
							return null;
						}
						$i++;
					}
				}
				$block = $this->getSide($i);
				if ((($this->getLevel()->getBlock($this->temporalVector->setComponents(($block->x - 1), $block->y, $block->z))->getId() == \pocketmine\block\Block::PORTAL) || ($this->getLevel()->getBlock($this->temporalVector->setComponents(($block->x + 1), $block->y, $block->z))->getId() == \pocketmine\block\Block::PORTAL))) {
					$x = $block->x;
					while (($this->getLevel()->getBlock()->getId() == $t89)) {
						$y = $block->y;
						while (($this->getLevel()->getBlock()->getId() == $t60)) {
							new \pocketmine\block\Air();
							$this->getLevel()->setBlock($this->temporalVector->setComponents($x, $y, $block->z), new \pocketmine\block\Air());
							$y++;
						}
						$y = ($block->y - 1);
						while (($this->getLevel()->getBlock()->getId() == $t79)) {
							new \pocketmine\block\Air();
							$this->getLevel()->setBlock($this->temporalVector->setComponents($x, $y, $block->z), new \pocketmine\block\Air());
							$y--;
						}
						$x++;
					}
					$x = ($block->x - 1);
					while (($this->getLevel()->getBlock()->getId() == $t139)) {
						$y = $block->y;
						while (($this->getLevel()->getBlock()->getId() == $t110)) {
							new \pocketmine\block\Air();
							$this->getLevel()->setBlock($this->temporalVector->setComponents($x, $y, $block->z), new \pocketmine\block\Air());
							$y++;
						}
						$y = ($block->y - 1);
						while (($this->getLevel()->getBlock()->getId() == $t129)) {
							new \pocketmine\block\Air();
							$this->getLevel()->setBlock($this->temporalVector->setComponents($x, $y, $block->z), new \pocketmine\block\Air());
							$y--;
						}
						$x--;
					}
				} else {
					$z = $block->z;
					while (($this->getLevel()->getBlock()->getId() == $t188)) {
						$y = $block->y;
						while (($this->getLevel()->getBlock()->getId() == $t159)) {
							new \pocketmine\block\Air();
							$this->getLevel()->setBlock($this->temporalVector->setComponents($block->x, $y, $z), new \pocketmine\block\Air());
							$y++;
						}
						$y = ($block->y - 1);
						while (($this->getLevel()->getBlock()->getId() == $t178)) {
							new \pocketmine\block\Air();
							$this->getLevel()->setBlock($this->temporalVector->setComponents($block->x, $y, $z), new \pocketmine\block\Air());
							$y--;
						}
						$z++;
					}
					$z = ($block->z - 1);
					while (($this->getLevel()->getBlock()->getId() == $t238)) {
						$y = $block->y;
						while (($this->getLevel()->getBlock()->getId() == $t209)) {
							new \pocketmine\block\Air();
							$this->getLevel()->setBlock($this->temporalVector->setComponents($block->x, $y, $z), new \pocketmine\block\Air());
							$y++;
						}
						$y = ($block->y - 1);
						while (($this->getLevel()->getBlock()->getId() == $t228)) {
							new \pocketmine\block\Air();
							$this->getLevel()->setBlock($this->temporalVector->setComponents($block->x, $y, $z), new \pocketmine\block\Air());
							$y--;
						}
						$z--;
					}
				}
			}
		}

}
