<?php

namespace pocketmine\block;

class HardenedClay extends \pocketmine\block\Solid {
	protected $id = 172;

	public function __construct() {
			// empty
		}

	public function getName() {
			return;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function getHardness() {
			return 1.25;
		}

}
