<?php

namespace pocketmine\block;

abstract class Fallable extends \pocketmine\block\Solid {
	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			$ret = $this->getLevel()->setBlock($this, $this, true, true);
			return $ret;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				$down = $this->getSide(\pocketmine\math\Vector3::SIDE_DOWN);
				if ((($down->getId() === self::AIR) || $down instanceof \pocketmine\block\Liquid)) {
					new \pocketmine\nbt\tag\DoubleTag('', ($this->x + 0.5));
					new \pocketmine\nbt\tag\DoubleTag('', $this->y);
					new \pocketmine\nbt\tag\DoubleTag('', ($this->z + 0.5));
					new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', ($this->x + 0.5)), new \pocketmine\nbt\tag\DoubleTag('', $this->y), new \pocketmine\nbt\tag\DoubleTag('', ($this->z + 0.5))]);
					new \pocketmine\nbt\tag\DoubleTag('', 0);
					new \pocketmine\nbt\tag\DoubleTag('', 0);
					new \pocketmine\nbt\tag\DoubleTag('', 0);
					new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]);
					new \pocketmine\nbt\tag\FloatTag('', 0);
					new \pocketmine\nbt\tag\FloatTag('', 0);
					new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', 0), new \pocketmine\nbt\tag\FloatTag('', 0)]);
					new \pocketmine\nbt\tag\IntTag('TileID', $this->getId());
					new \pocketmine\nbt\tag\ByteTag('Data', $this->getDamage());
					new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', ($this->x + 0.5)), new \pocketmine\nbt\tag\DoubleTag('', $this->y), new \pocketmine\nbt\tag\DoubleTag('', ($this->z + 0.5))]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', 0), new \pocketmine\nbt\tag\FloatTag('', 0)]), new \pocketmine\nbt\tag\IntTag('TileID', $this->getId()), new \pocketmine\nbt\tag\ByteTag('Data', $this->getDamage())]);
					$fall = \pocketmine\entity\Entity::createEntity('FallingSand', $this->getLevel()->getChunk(($this->x >> 4), ($this->z >> 4)), new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', ($this->x + 0.5)), new \pocketmine\nbt\tag\DoubleTag('', $this->y), new \pocketmine\nbt\tag\DoubleTag('', ($this->z + 0.5))]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', 0), new \pocketmine\nbt\tag\FloatTag('', 0)]), new \pocketmine\nbt\tag\IntTag('TileID', $this->getId()), new \pocketmine\nbt\tag\ByteTag('Data', $this->getDamage())]));
					$fall->spawnToAll();
				}
			}
			return null;
		}

}
