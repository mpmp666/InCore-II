<?php

namespace pocketmine\block;

class Wood extends \pocketmine\block\Solid {
	public const OAK = 0;
	public const SPRUCE = 1;
	public const BIRCH = 2;
	public const JUNGLE = 3;
	public const ACACIA = 4;
	public const DARK_OAK = 5;

	protected $id = 17;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getHardness() {
			return 2;
		}

	public function getName() {
			return $names[($this->meta & 3)];
		}

	public function getBurnChance() {
			return 5;
		}

	public function getBurnAbility() {
			return 10;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$faces = ['__array_ptr' => '2aaaadd5d658'];
			$this->meta = (($this->meta & 3) | $faces[$face]);
			$this->getLevel()->setBlock($block, $this, true, true);
			return true;
		}

	public function getDrops($item = null) {
			return [[$this->id, ($this->meta & 3), 1]];
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_AXE;
		}

}
