<?php

namespace pocketmine\block;

class ActivatorRail extends \pocketmine\block\PoweredRail {
	protected $id = 126;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return;
		}

	public function hasEntityCollision() {
			return true;
		}

	public function onEntityCollide($entity = null) {
			/* decompiled (structured CF) */
			if ($entity instanceof \pocketmine\entity\Vehicle) {
				$entity->applyRailEffects($this);
			}
			return null;
		}

}
