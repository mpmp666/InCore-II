<?php

namespace pocketmine\block;

class PistonMoveCalculator {
	public function __construct($piston = null, $extending = null) {
		/* decompiled (structured CF) */
		$this->piston = $piston;
		$this->pistonPos = $piston->floor();
		$this->extending = $extending;
		$face = $piston->getFacing();
		if ($this->extending) {
			$this->moveDirection = $face;
			$this->blockToMove = $piston->getSide($face);
		} else {
			$this->armPos = $piston->getSide($face)->floor();
			$this->moveDirection = \pocketmine\math\Vector3::getOppositeSide($face);
			if ($piston->isSticky()) {
			} else {
			}
			$this->blockToMove = null;
		}
		return;
	}

	public function canMove() {
		/* decompiled (structured CF) */
		if ((!($this->piston->isSticky()) && !($this->extending))) {
			return true;
		}
		$this->toMove = ['__array_ptr' => '2aaaac9fc9a0'];
		$this->toDestroy = ['__array_ptr' => '2aaaac9fc9a0'];
		if (!($this->blockToMove instanceof \pocketmine\block\Block)) {
			return true;
		}
		if (!(\pocketmine\block\PistonBase::canPush($this->blockToMove, $this->moveDirection, true, $this->extending))) {
			return false;
		}
		if ($this->blockToMove->breaksWhenMovedByPiston()) {
			if (($this->extending || $this->blockToMove->canStickToPiston())) {
				$this->toDestroy[] = $this->blockToMove;
			}
			return true;
		}
		if (!($this->addBlockLine($this->blockToMove, $this->blockToMove->getSide($this->moveDirection), true))) {
			return false;
		}
		foreach ($this->toMove as $block) {
			if (($block->canStickBlocks() && !($this->addBranchingBlocks($block)))) {
				return false;
			}
			/* goto */
		}
		return true;
	}

	private function addBlockLine($origin = null, $from = null, $mainBlockLine = null) {
		/* decompiled (structured CF) */
		if (($origin->getId() === \pocketmine\block\Block::AIR)) {
			return true;
		}
		if ((((!($mainBlockLine) && $origin->canStickBlocks()) && $from->canStickBlocks()) && ($origin->getId() !== $from->getId()))) {
			return true;
		}
		if (!(\pocketmine\block\PistonBase::canPush($origin, $this->moveDirection, false, $this->extending))) {
			return true;
		}
		if (($origin->equals($this->pistonPos) || $this->contains($this->toMove, $origin))) {
			return true;
		}
		if ((\pocketmine\block\PistonBase::MOVE_LIMIT <= count($this->toMove))) {
			return false;
		}
		$this->toMove[] = $origin;
		$count = 1;
		$beStuck = ['__array_ptr' => '2aaaac9fc9a0'];
		$block = $origin;
		while ($block->canStickBlocks()) {
			$oldBlock = $block;
			$block = $origin->getSide(\pocketmine\math\Vector3::getOppositeSide($this->moveDirection), $count);
			if (((((!($this->extending) || !($mainBlockLine)) && $block->canStickBlocks()) && $oldBlock->canStickBlocks()) && ($block->getId() !== $oldBlock->getId()))) {
			} else {
				if (((($block->getId() === \pocketmine\block\Block::AIR) || !(\pocketmine\block\PistonBase::canPush($block, $this->moveDirection, false, $this->extending))) || $block->equals($this->pistonPos))) {
				} else {
					if (($block->breaksWhenMovedByPiston() && $block->canStickToPiston())) {
						$this->toDestroy[] = $block;
					} else {
						if ((\pocketmine\block\PistonBase::MOVE_LIMIT < ($count + count($this->toMove)))) {
							return false;
						}
						$count++;
						$beStuck[] = $block;
					}
				}
			}
		}
		$beStuckCount = count($beStuck);
		if ((0 < $beStuckCount)) {
			$this->toMove = array_merge($this->toMove, array_reverse($beStuck));
		}
		$step = 1;
		while (true) {
			$nextBlock = $origin->getSide($this->moveDirection, $step);
			$index = $this->indexOf($this->toMove, $nextBlock);
			if ((-1 < $index)) {
				$this->reorderListAtCollision($beStuckCount, $index);
				$i = 0;
				while (($i <= $t101)) {
					if (((isset($this->toMove[$i]) && $this->toMove[$i]->canStickBlocks()) && !($this->addBranchingBlocks($this->toMove[$i])))) {
						return false;
					}
					$i++;
				}
				return true;
			}
			if ((($nextBlock->getId() === \pocketmine\block\Block::AIR) || ($this->armPos instanceof \pocketmine\math\Vector3 && $nextBlock->equals($this->armPos)))) {
				return true;
			}
			if ((!(\pocketmine\block\PistonBase::canPush($nextBlock, $this->moveDirection, true, $this->extending)) || $nextBlock->equals($this->pistonPos))) {
				return false;
			}
			if ($nextBlock->breaksWhenMovedByPiston()) {
				$this->toDestroy[] = $nextBlock;
				return true;
			}
			if ((\pocketmine\block\PistonBase::MOVE_LIMIT <= count($this->toMove))) {
				return false;
			}
			$this->toMove[] = $nextBlock;
			$beStuckCount++;
			$step++;
		}
	}

	private function addBranchingBlocks($block = null) {
		/* decompiled (structured CF) */
		foreach (\pocketmine\block\Block::BLOCK_SIDES as $face) {
			if ((($this->getAxis($face) !== $this->getAxis($this->moveDirection)) && !($this->addBlockLine($block->getSide($face), $block, false)))) {
				return false;
			}
			/* goto */
		}
		return true;
	}

	private function getAxis($side = null) {
		/* decompiled (structured CF) */
		if ((($side === \pocketmine\math\Vector3::SIDE_DOWN) || ($side === \pocketmine\math\Vector3::SIDE_UP))) {
			return 1;
		}
		if ((($side === \pocketmine\math\Vector3::SIDE_WEST) || ($side === \pocketmine\math\Vector3::SIDE_EAST))) {
			return 2;
		}
		return 3;
	}

	private function reorderListAtCollision($count = null, $index = null) {
		/* decompiled (structured CF) */
		$list = array_slice($this->toMove, 0, $index);
		if ((0 < $count)) {
		} else {
		}
		$list1 = ['__array_ptr' => '2aaaac9fc9a0'];
		$list2 = array_slice($this->toMove, $index, ((count($this->toMove) - $index) - $count));
		$this->toMove = array_merge($list, $list1, $list2);
		return null;
	}

	private function indexOf($blocks = null, $needle = null) {
		/* decompiled (structured CF) */
		foreach ($blocks as $i => $block) {
			if ($block->equals($needle)) {
				return $i;
			}
			/* goto */
		}
		return -1;
	}

	private function contains($blocks = null, $needle = null) {
		return (-1 < $this->indexOf($blocks, $needle));
	}

	public function getBlocksToMove() {
		return $this->toMove;
	}

	public function getBlocksToDestroy() {
		return $this->toDestroy;
	}

}
