<?php

namespace pocketmine\block;

class Workbench extends \pocketmine\block\Solid {
	protected $id = 58;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function canBeActivated() {
			return true;
		}

	public function getHardness() {
			return 2.5;
		}

	public function getName() {
			return;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_AXE;
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			if ($player instanceof \pocketmine\Player) {
				if (($player->getServer()->limitedCreative && $player->isCreative())) {
					return true;
				}
				$player->craftingType = 1;
			}
			return true;
		}

	public function getDrops($item = null) {
			return [[$this->id, 0, 1]];
		}

}
