<?php

namespace pocketmine\block;

class Wheat extends \pocketmine\block\Crops {
	protected $id = 59;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			$drops = ['__array_ptr' => '2aaaac9fc9a0'];
			if ((7 <= $this->meta)) {
				$fortunel = $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_FORTUNE);
				if ((3 < $fortunel)) {
				} else {
				}
				$fortunel = $fortunel;
				$drops[] = [\pocketmine\item\Item::WHEAT, 0, 1];
				$drops[] = [\pocketmine\item\Item::WHEAT_SEEDS, 0, mt_rand(0, (3 + $fortunel))];
			} else {
				$drops[] = [\pocketmine\item\Item::WHEAT_SEEDS, 0, 1];
			}
			return $drops;
		}

}
