<?php

namespace pocketmine\block;

abstract class RedstoneDiode extends \pocketmine\block\RedstoneSource {
	protected $isPowered = false;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	protected function recalculateBoundingBox() {
			new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 0.125), ($this->z + 1));
			return new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 0.125), ($this->z + 1));
		}

	public function canBeFlowedInto() {
			return false;
		}

	public function canPassThrough() {
			return false;
		}

	public function canBeActivated() {
			return true;
		}

	public function isPowerSource() {
			return true;
		}

	public function isPowered() {
			return $this->isPowered;
		}

	public function getFacing() {
			/* decompiled (structured CF) */
			/* jump */
			switch (($this->meta & 3)) {
				case 0:
				return \pocketmine\math\Vector3::SIDE_SOUTH;
				case 1:
				return \pocketmine\math\Vector3::SIDE_WEST;
				case 2:
				return \pocketmine\math\Vector3::SIDE_NORTH;
			}
		}

	public function getDirection() {
			return $this->getFacing();
		}

	public function getOppositeDirection() {
			return \pocketmine\math\Vector3::getOppositeSide($this->getFacing());
		}

	protected static function getMetaFromYaw($yaw = null) {
			/* decompiled (structured CF) */
			$yaw = fmod($yaw, 360);
			if (($yaw < 0)) {
				$yaw += 360;
			}
			return (((floor(((($yaw * 4) / 360) + 0.5))) + 2) & 3);
		}

	protected function getLeftSide() {
			/* decompiled (structured CF) */
			/* jump */
			switch ($this->getFacing()) {
				case \pocketmine\math\Vector3::SIDE_NORTH:
				return \pocketmine\math\Vector3::SIDE_WEST;
				case \pocketmine\math\Vector3::SIDE_SOUTH:
				return \pocketmine\math\Vector3::SIDE_EAST;
				case \pocketmine\math\Vector3::SIDE_EAST:
				return \pocketmine\math\Vector3::SIDE_NORTH;
			}
		}

	protected function getRightSide() {
			return \pocketmine\math\Vector3::getOppositeSide($this->getLeftSide());
		}

	protected abstract function getDelay();

	protected abstract function getPowered();

	protected abstract function getUnpowered();

	protected function getPulseTickDelay() {
			/* decompiled (structured CF) */
			if ($this->level->getServer()->allowFrequencyPulse) {
			} else {
			}
			return $this->getDelay();
		}

	protected function getRedstoneSignal() {
			return 15;
		}

	public function isLocked() {
			return false;
		}

	protected function getInputSide() {
			return $this->getFacing();
		}

	protected function calculateInputStrength() {
			/* decompiled (structured CF) */
			$inputSide = $this->getInputSide();
			$source = $this->getSide($inputSide);
			$power = $this->level->getRedstonePower($source, $this->getFacing());
			if ((15 <= $power)) {
				return 15;
			}
			if (($source->getId() === self::REDSTONE_WIRE)) {
			} else {
			}
			return max($power, 0);
		}

	protected function getPowerOnSides() {
			return max($this->getPowerOnSide($this->getSide($this->getLeftSide()), $this->getRightSide()), $this->getPowerOnSide($this->getSide($this->getRightSide()), $this->getLeftSide()));
		}

	protected function getPowerOnSide($block = null, $sideFromSource = null) {
			/* decompiled (structured CF) */
			if (!($this->isAlternateInput($block))) {
				return 0;
			}
			if (($block->getId() === self::REDSTONE_BLOCK)) {
				return 15;
			}
			if (($block->getId() === self::REDSTONE_WIRE)) {
				return $block->getDamage();
			}
			return $this->level->getStrongPower($block, $sideFromSource);
		}

	protected function isAlternateInput($block = null) {
			return $block->isPowerSource();
		}

	public static function isDiode($block = null) {
			return $block instanceof \pocketmine\block\RedstoneDiode;
		}

	public function shouldBePowered() {
			return (0 < $this->calculateInputStrength());
		}

	public function updateState() {
			/* decompiled (structured CF) */
			if ($this->isLocked()) {
				return null;
			}
			$shouldBePowered = $this->shouldBePowered();
			if ((($this->isPowered() && !($shouldBePowered)) || (!($this->isPowered()) && $shouldBePowered))) {
				if (!($this->level->isBlockTickPending($this, $this))) {
					$this->level->scheduleUpdate($this, $this->getPulseTickDelay());
				}
			}
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED)) {
				if (!($this->isLocked())) {
					$shouldBePowered = $this->shouldBePowered();
					if (($this->isPowered() && !($shouldBePowered))) {
						if ($this->level->checkAndHandleHighFrequencyRedstoneTransition($this, 'diode:off')) {
							return \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED;
						}
						$this->level->setBlock($this, $this->getUnpowered(), true, true);
						$this->level->updateAroundRedstone($this->getSide($this->getOppositeDirection()), null);
					} else {
						if (!($this->isPowered())) {
							if ($this->level->checkAndHandleHighFrequencyRedstoneTransition($this, 'diode:on')) {
								return \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED;
							}
							$this->level->setBlock($this, $this->getPowered(), true, true);
							$this->level->updateAroundRedstone($this->getSide($this->getOppositeDirection()), null);
							if (!($shouldBePowered)) {
								$this->level->scheduleUpdate($this, $this->getPulseTickDelay());
							}
						}
					}
				}
				return \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED;
			}
			if ((($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL) || ($type === \pocketmine\level\Level::BLOCK_UPDATE_REDSTONE))) {
				$below = $this->getSide(\pocketmine\math\Vector3::SIDE_DOWN);
				if ((($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL) && $below instanceof \pocketmine\block\Transparent)) {
					$this->level->useBreakOn($this);
					return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
				}
				$this->updateState();
				return $type;
			}
			return false;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$below = $block->getSide(\pocketmine\math\Vector3::SIDE_DOWN);
			if ($below instanceof \pocketmine\block\Transparent) {
				return false;
			}
			if ($player instanceof \pocketmine\Player) {
				$this->meta = (self::getMetaFromYaw($player->yaw) | ($this->meta & 12));
			}
			$this->level->setBlock($block, $this, true, true);
			if ($this->shouldBePowered()) {
				$this->level->scheduleUpdate($this, $this->getPulseTickDelay());
			}
			return true;
		}

	public function onBreak($item = null) {
			/* decompiled (structured CF) */
			new \pocketmine\block\Air();
			$this->level->setBlock($this, new \pocketmine\block\Air(), true, true);
			$this->level->updateAroundRedstone($this, null);
			return true;
		}

	public function getWeakPower($side = null) {
			/* decompiled (structured CF) */
			if (($this->isPowered() && ($side === $this->getFacing()))) {
			} else {
			}
			return 0;
		}

	public function getStrongPower($side = null) {
			return $this->getWeakPower($side);
		}

	public function isActivated($from = null) {
			/* decompiled (structured CF) */
			if (!($this->isPowered())) {
				return false;
			}
			return (!($from instanceof \pocketmine\block\Block) || $from->equals($this->getSide($this->getOppositeDirection())));
		}

	public function activate($ignore = null) {
			$this->updateState();
			return null;
		}

	public function deactivate($ignore = null) {
			$this->updateState();
			return null;
		}

}
