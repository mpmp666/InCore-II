<?php

namespace pocketmine\block;

class StoneBricks extends \pocketmine\block\Solid {
	public const NORMAL = 0;
	public const MOSSY = 1;
	public const CRACKED = 2;
	public const CHISELED = 3;

	protected $id = 98;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getHardness() {
			return 1.5;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function getName() {
			return $names[(($this->meta) & 3)];
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((1 <= $item->isPickaxe())) {
				return [[\pocketmine\item\Item::STONE_BRICKS, ($this->meta & 3), 1]];
			} else {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
		}

}
