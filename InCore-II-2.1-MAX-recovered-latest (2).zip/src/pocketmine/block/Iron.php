<?php

namespace pocketmine\block;

class Iron extends \pocketmine\block\Solid {
	protected $id = 42;

	public function __construct() {
			// empty
		}

	public function getName() {
			return;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function getHardness() {
			return 5;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((3 <= $item->isPickaxe())) {
				return [[\pocketmine\item\Item::IRON_BLOCK, 0, 1]];
			} else {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
		}

}
