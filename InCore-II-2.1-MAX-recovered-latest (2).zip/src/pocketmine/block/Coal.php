<?php

namespace pocketmine\block;

class Coal extends \pocketmine\block\Solid {
	protected $id = 173;

	public function __construct() {
			// empty
		}

	public function getHardness() {
			return 5;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function getBurnChance() {
			return 5;
		}

	public function getBurnAbility() {
			return 5;
		}

	public function getName() {
			return;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((1 <= $item->isPickaxe())) {
				return [[\pocketmine\item\Item::COAL_BLOCK, 0, 1]];
			} else {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
		}

}
