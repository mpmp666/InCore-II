<?php

namespace pocketmine\block;

class Lava extends \pocketmine\block\Liquid {
	protected $id = 10;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getLightLevel() {
			return 15;
		}

	public function getName() {
			return 'Lava';
		}

	public function onEntityCollide($entity = null) {
			/* decompiled (structured CF) */
			$entity->fallDistance *= 0.5;
			if (!($entity->hasEffect(\pocketmine\entity\Effect::FIRE_RESISTANCE))) {
				new \pocketmine\event\entity\EntityDamageByBlockEvent($this, $entity, \pocketmine\event\entity\EntityDamageEvent::CAUSE_LAVA, 4);
				$ev = new \pocketmine\event\entity\EntityDamageByBlockEvent($this, $entity, \pocketmine\event\entity\EntityDamageEvent::CAUSE_LAVA, 4);
				if (($entity->attack($ev->getFinalDamage(), $ev) === true)) {
					$ev->useArmors();
				}
			}
			new \pocketmine\event\entity\EntityCombustByBlockEvent($this, $entity, 15);
			$ev = new \pocketmine\event\entity\EntityCombustByBlockEvent($this, $entity, 15);
			\pocketmine\Server::getInstance()->getPluginManager()->callEvent($ev);
			if (!($ev->isCancelled())) {
				$entity->setOnFire($ev->getDuration());
			}
			$entity->resetFallDistance();
			return null;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			$ret = $this->getLevel()->setBlock($this, $this, true, false);
			$this->getLevel()->scheduleUpdate($this, $this->tickRate());
			return $ret;
		}

}
