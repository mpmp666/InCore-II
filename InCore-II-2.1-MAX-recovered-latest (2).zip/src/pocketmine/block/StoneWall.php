<?php

namespace pocketmine\block;

class StoneWall extends \pocketmine\block\Transparent {
	public const NONE_MOSSY_WALL = 0;
	public const MOSSY_WALL = 1;

	protected $id = 139;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function isSolid() {
			return false;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function getHardness() {
			return 2;
		}

	public function getName() {
			/* decompiled (structured CF) */
			if (($this->meta === 1)) {
				return $this;
			}
			return $this;
		}

	protected function recalculateBoundingBox() {
			/* decompiled (structured CF) */
			$north = $this->canConnect($this->getSide(\pocketmine\math\Vector3::SIDE_NORTH));
			$south = $this->canConnect($this->getSide(\pocketmine\math\Vector3::SIDE_SOUTH));
			$west = $this->canConnect($this->getSide(\pocketmine\math\Vector3::SIDE_WEST));
			$east = $this->canConnect($this->getSide(\pocketmine\math\Vector3::SIDE_EAST));
			if ($north) {
			} else {
			}
			$n = 0.25;
			if ($south) {
			} else {
			}
			$s = 0.75;
			if ($west) {
			} else {
			}
			$w = 0.25;
			if ($east) {
			} else {
			}
			$e = 0.75;
			if (((($north && $south) && !($west)) && !($east))) {
				$w = 0.3125;
				$e = 0.6875;
			} else {
				if ((((!($north) && !($south)) && $west) && $east)) {
					$n = 0.3125;
					$s = 0.6875;
				}
			}
			new \pocketmine\math\AxisAlignedBB(($this->x + $w), $this->y, ($this->z + $n), ($this->x + $e), ($this->y + 1.5), ($this->z + $s));
			return new \pocketmine\math\AxisAlignedBB(($this->x + $w), $this->y, ($this->z + $n), ($this->x + $e), ($this->y + 1.5), ($this->z + $s));
		}

	public function canConnect($block = null) {
			/* decompiled (structured CF) */
			if ((($block->getId() !== self::COBBLE_WALL) && ($block->getId() !== self::FENCE_GATE))) {
			} else {
			}
			return true;
		}

}
