<?php

namespace pocketmine\block;

class Mycelium extends \pocketmine\block\Solid {
	protected $id = 110;

	public function __construct() {
			// empty
		}

	public function getName() {
			return 'Mycelium';
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_SHOVEL;
		}

	public function getHardness() {
			return 0.6;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((0 < $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_SILK_TOUCH))) {
				return [[\pocketmine\item\Item::MYCELIUM, 0, 1]];
			} else {
				return [[\pocketmine\item\Item::DIRT, 0, 1]];
			}
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_RANDOM)) {
				$x = mt_rand(($this->x - 1), ($this->x + 1));
				$y = mt_rand(($this->y - 2), ($this->y + 2));
				$z = mt_rand(($this->z - 1), ($this->z + 1));
				new \pocketmine\math\Vector3($x, $y, $z);
				$block = $this->getLevel()->getBlock(new \pocketmine\math\Vector3($x, $y, $z));
				if (($block->getId() === \pocketmine\block\Block::DIRT)) {
					if ($block->getSide(1) instanceof \pocketmine\block\Transparent) {
						new \pocketmine\block\Mycelium();
						new \pocketmine\event\block\BlockSpreadEvent($block, $this, new \pocketmine\block\Mycelium());
						$ev = new \pocketmine\event\block\BlockSpreadEvent($block, $this, new \pocketmine\block\Mycelium());
						\pocketmine\Server::getInstance()->getPluginManager()->callEvent($ev);
						if (!($ev->isCancelled())) {
							$this->getLevel()->setBlock($block, $ev->getNewState());
						}
					}
				}
			}
			return null;
		}

}
