<?php

namespace pocketmine\block;

class StoneBrickStairs extends \pocketmine\block\Stair {
	protected $id = 109;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function getHardness() {
			return 1.5;
		}

	public function getName() {
			return;
		}

}
