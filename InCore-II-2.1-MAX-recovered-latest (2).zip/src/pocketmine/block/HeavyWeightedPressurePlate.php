<?php

namespace pocketmine\block;

class HeavyWeightedPressurePlate extends \pocketmine\block\WeightedPressurePlate {
	protected $id = 148;
	protected $maxEntities = 150;

	public function getName() {
			return;
		}

}
