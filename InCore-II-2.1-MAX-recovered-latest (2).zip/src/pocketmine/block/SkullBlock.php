<?php

namespace pocketmine\block;

class SkullBlock extends \pocketmine\block\Transparent {
	protected $id = 144;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getHardness() {
			return 1;
		}

	public function isHelmet() {
			return true;
		}

	public function isSolid() {
			return false;
		}

	public function getBoundingBox() {
			new \pocketmine\math\AxisAlignedBB(($this->x - 0.75), ($this->y - 0.5), ($this->z - 0.75), ($this->x + 0.75), ($this->y + 0.5), ($this->z + 0.75));
			return new \pocketmine\math\AxisAlignedBB(($this->x - 0.75), ($this->y - 0.5), ($this->z - 0.75), ($this->x + 0.75), ($this->y + 0.5), ($this->z + 0.75));
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$down = $this->getSide(0);
			if ((((($face !== 0) && (0.5 < $fy)) && ($target->getId() !== self::SKULL_BLOCK)) && !($down instanceof \pocketmine\block\SkullBlock))) {
				$this->getLevel()->setBlock($block, \pocketmine\block\Block::get(\pocketmine\block\Block::SKULL_BLOCK, 0), true, true);
				if (($face === 1)) {
					new \pocketmine\nbt\tag\ByteTag('Rot', (floor(((($player->yaw * 16) / 360) + 0.5)) & 15));
					$rot = new \pocketmine\nbt\tag\ByteTag('Rot', (floor(((($player->yaw * 16) / 360) + 0.5)) & 15));
				} else {
					new \pocketmine\nbt\tag\ByteTag('Rot', 0);
					$rot = new \pocketmine\nbt\tag\ByteTag('Rot', 0);
				}
				new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::SKULL);
				new \pocketmine\nbt\tag\IntTag('x', $block->x);
				new \pocketmine\nbt\tag\IntTag('y', $block->y);
				new \pocketmine\nbt\tag\IntTag('z', $block->z);
				new \pocketmine\nbt\tag\ByteTag('SkullType', $item->getDamage());
				new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::SKULL), new \pocketmine\nbt\tag\IntTag('x', $block->x), new \pocketmine\nbt\tag\IntTag('y', $block->y), new \pocketmine\nbt\tag\IntTag('z', $block->z), new \pocketmine\nbt\tag\ByteTag('SkullType', $item->getDamage()), $rot]);
				$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::SKULL), new \pocketmine\nbt\tag\IntTag('x', $block->x), new \pocketmine\nbt\tag\IntTag('y', $block->y), new \pocketmine\nbt\tag\IntTag('z', $block->z), new \pocketmine\nbt\tag\ByteTag('SkullType', $item->getDamage()), $rot]);
				if ($item->hasCustomBlockData()) {
					foreach ($item->getCustomBlockData() as $key => $v) {
						$nbt->prop = $v;
						/* goto */
					}
				}
				$chunk = $this->getLevel()->getChunk(($this->x >> 4), ($this->z >> 4));
				$pot = \pocketmine\tile\Tile::createTile(\pocketmine\tile\Tile::SKULL, $chunk, $nbt);
				$this->getLevel()->setBlock($block, \pocketmine\block\Block::get(\pocketmine\block\Block::SKULL_BLOCK, $face), true, true);
				return true;
			}
			return false;
		}

	public function getResistance() {
			return 5;
		}

	public function getName() {
			return $names[($this->meta & 4)];
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function onBreak($item = null) {
			new \pocketmine\block\Air();
			$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), true, true);
			return true;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			$tile = $this->getLevel()->getTile($this);
			if ((($this->getLevel() != null) && $tile instanceof \pocketmine\tile\Skull)) {
				return [[\pocketmine\item\Item::SKULL, $tile->getSkullType(), 1]];
			} else {
				return [[\pocketmine\item\Item::SKULL, 0, 1]];
			}
		}

}
