<?php

namespace pocketmine\block;

class NetherWart extends \pocketmine\block\Flowable {
	protected $id = 115;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$down = $this->getSide(0);
			if (($down->getId() === self::SOUL_SAND)) {
				$this->getLevel()->setBlock($block, $this, true, true);
				return true;
			}
			return false;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				if (($this->getSide(0)->isTransparent() === true)) {
					$this->getLevel()->useBreakOn($this);
					return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
				}
			} else {
				if (($type === \pocketmine\level\Level::BLOCK_UPDATE_RANDOM)) {
					if ((mt_rand(0, 12) == 1)) {
						if (($this->meta < 3)) {
							$block = clone $this;
							new \pocketmine\event\block\BlockGrowEvent($this, $block);
							$ev = new \pocketmine\event\block\BlockGrowEvent($this, $block);
							\pocketmine\Server::getInstance()->getPluginManager()->callEvent($ev);
							if (!($ev->isCancelled())) {
								$this->getLevel()->setBlock($this, $ev->getNewState(), true, true);
							} else {
								return \pocketmine\level\Level::BLOCK_UPDATE_RANDOM;
							}
						}
					} else {
						return \pocketmine\level\Level::BLOCK_UPDATE_RANDOM;
					}
				}
			}
			return false;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			$drops = ['__array_ptr' => '2aaaac9fc9a0'];
			if ((3 <= $this->meta)) {
				$fortunel = $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_FORTUNE);
				if ((3 < $fortunel)) {
				} else {
				}
				$fortunel = $fortunel;
				$drops[] = [\pocketmine\item\Item::NETHER_WART, 0, mt_rand(2, (4 + $fortunel))];
			} else {
				$drops[] = [\pocketmine\item\Item::NETHER_WART, 0, 1];
			}
			return $drops;
		}

}
