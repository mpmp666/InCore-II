<?php

namespace pocketmine\block;

class Cake extends \pocketmine\block\Transparent implements \pocketmine\item\FoodSource {
	protected $id = 92;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function canBeActivated() {
			return true;
		}

	public function getHardness() {
			return 0.5;
		}

	public function getName() {
			return;
		}

	protected function recalculateBoundingBox() {
			$f = ((1 + ($this->getDamage() * 2)) / 16);
			new \pocketmine\math\AxisAlignedBB(($this->x + $f), $this->y, ($this->z + 0.0625), (($this->x + 1) - 0.0625), ($this->y + 0.5), (($this->z + 1) - 0.0625));
			return new \pocketmine\math\AxisAlignedBB(($this->x + $f), $this->y, ($this->z + 0.0625), (($this->x + 1) - 0.0625), ($this->y + 0.5), (($this->z + 1) - 0.0625));
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$down = $this->getSide(0);
			if (($down->getId() !== self::AIR)) {
				$this->getLevel()->setBlock($block, $this, true, true);
				return true;
			}
			return false;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				if (($this->getSide(0)->getId() === self::AIR)) {
					new \pocketmine\block\Air();
					$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), true);
					return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
				}
			}
			return false;
		}

	public function getDrops($item = null) {
			return ['__array_ptr' => '2aaaac9fc9a0'];
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			if (($player instanceof \pocketmine\Player && ($player->getHealth() < $player->getMaxHealth()))) {
				new \pocketmine\event\entity\EntityEatBlockEvent($player, $this);
				$ev = new \pocketmine\event\entity\EntityEatBlockEvent($player, $this);
				if (!($ev->isCancelled())) {
					$this->getLevel()->setBlock($this, $ev->getResidue());
					return true;
				}
			}
			return false;
		}

	public function getFoodRestore() {
			return 2;
		}

	public function getSaturationRestore() {
			return 0.4;
		}

	public function getResidue() {
			/* decompiled (structured CF) */
			$clone = clone $this;
			if ((6 <= $clone->meta)) {
				new \pocketmine\block\Air();
				$clone = new \pocketmine\block\Air();
			}
			return $clone;
		}

	public function getAdditionalEffects() {
			return ['__array_ptr' => '2aaaac9fc9a0'];
		}

}
