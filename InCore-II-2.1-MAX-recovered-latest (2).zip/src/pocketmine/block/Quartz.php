<?php

namespace pocketmine\block;

class Quartz extends \pocketmine\block\Solid {
	public const QUARTZ_NORMAL = 0;
	public const QUARTZ_CHISELED = 1;
	public const QUARTZ_PILLAR = 2;
	public const QUARTZ_PILLAR2 = 3;

	protected $id = 155;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getHardness() {
			return 0.8;
		}

	public function getName() {
			return $names[($this->meta & 3)];
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((1 <= $item->isPickaxe())) {
				return [[\pocketmine\item\Item::QUARTZ_BLOCK, ($this->meta & 3), 1]];
			} else {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
		}

}
