<?php

namespace pocketmine\block;

class Rail extends \pocketmine\block\Flowable {
	public const STRAIGHT_EAST_WEST = 0;
	public const STRAIGHT_NORTH_SOUTH = 1;
	public const SLOPED_ASCENDING_NORTH = 2;
	public const SLOPED_ASCENDING_SOUTH = 3;
	public const SLOPED_ASCENDING_EAST = 4;
	public const SLOPED_ASCENDING_WEST = 5;
	public const CURVED_NORTH_WEST = 7;
	public const CURVED_SOUTH_WEST = 6;
	public const CURVED_SOUTH_EAST = 9;
	public const CURVED_NORTH_EAST = 8;

	protected $id = 66;
	protected $connected = array (
);

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return 'Rail';
		}

	public function getRealMeta() {
			/* decompiled (structured CF) */
			if (($this->id === self::RAIL)) {
			} else {
			}
			return ($this->meta & 7);
		}

	public function isActive() {
			return (($this->meta & 8) !== 0);
		}

	public function setActive($active = null) {
			/* decompiled (structured CF) */
			if ($active) {
			} else {
			}
			$this->meta = ($this->meta & 7);
			if (($this->getLevel() !== null)) {
				$this->getLevel()->setBlock($this, $this, true, true);
			}
			return null;
		}

	protected function update() {
			return true;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				if (!($this->hasRailSupport())) {
					$this->getLevel()->useBreakOn($this);
					return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
				}
			}
			return false;
		}

	protected function hasRailSupport() {
			/* decompiled (structured CF) */
			if (!($this->getSide(\pocketmine\math\Vector3::SIDE_DOWN)->isTopFacingSurfaceSolid())) {
				return false;
			}
			switch ($this->getRealMeta()) {
				case self::SLOPED_ASCENDING_NORTH:
				return $this->getSide(\pocketmine\math\Vector3::SIDE_EAST)->isTopFacingSurfaceSolid();
				case self::SLOPED_ASCENDING_SOUTH:
				return $this->getSide(\pocketmine\math\Vector3::SIDE_WEST)->isTopFacingSurfaceSolid();
				case self::SLOPED_ASCENDING_EAST:
				return $this->getSide(\pocketmine\math\Vector3::SIDE_NORTH)->isTopFacingSurfaceSolid();
				case self::SLOPED_ASCENDING_WEST:
				return $this->getSide(\pocketmine\math\Vector3::SIDE_SOUTH)->isTopFacingSurfaceSolid();
			}
		}

	public function canConnect($block = null) {
			/* decompiled (structured CF) */
			if ((2 < $this->distanceSquared($block))) {
				return false;
			}
			$blocks = self::check($this);
			if ((count($blocks) == 2)) {
				return false;
			}
			return $blocks;
		}

	public function isBlock($block = null) {
			/* decompiled (structured CF) */
			if ($block instanceof \pocketmine\block\AIR) {
				return false;
			}
			return $block;
		}

	public function connect($rail = null, $force = null) {
			/* decompiled (structured CF) */
			if (!($force)) {
				$connected = $this->canConnect($rail);
				if (!(is_array($connected))) {
					return false;
				}
				$connected[] = $rail;
				switch (count($connected)) {
					case 1:
					$v3 = $connected[0]->subtract($this);
					if (($v3->y != 1)) {
						if (($v3->x == 0)) {
						} else {
						}
					} else {
						if (($v3->z == 0)) {
						} else {
						}
					}
					$this->meta = (($v3->z / 2) + 4.5);
					/* jump */
					case 2:
					$subtract = ['__array_ptr' => '2aaaac9fc9a0'];
					foreach ($connected as $key => $value) {
						$subtract[$key] = $value->subtract($this);
						/* goto */
					}
					if (((abs($subtract[0]->x) == abs($subtract[1]->z)) && (abs($subtract[1]->x) == abs($subtract[0]->z)))) {
						$v3 = $connected[0]->subtract($this)->add($connected[1]->subtract($this));
						if (($v3->x == 1)) {
							if (($v3->z == 1)) {
							} else {
							}
						} else {
							if (($v3->z == 1)) {
							} else {
							}
						}
						$this->meta = 8;
					} else {
						if ((($subtract[0]->y == 1) || ($subtract[1]->y == 1))) {
							if (($subtract[0]->y == 1)) {
							} else {
							}
							$v3 = $subtract[1];
							if (($v3->x == 0)) {
								if (($v3->z == -1)) {
								} else {
								}
							} else {
								if (($v3->x == 1)) {
								} else {
								}
							}
							$this->meta = 3;
						} else {
							if (($subtract[0]->x == 0)) {
							} else {
							}
							$this->meta = 1;
						}
					}
					/* jump */
					/* jump */
					$this->meta = ($this->meta);
					$this->level->setBlock($this, \pocketmine\block\Block::get($this->id, $this->meta), true, true);
					return true;
				}
			}
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$downBlock = $this->getSide(\pocketmine\math\Vector3::SIDE_DOWN);
			if (($downBlock instanceof \pocketmine\block\Rail || !($this->isBlock($downBlock)))) {
				return false;
			}
			$arrayXZ = ['__array_ptr' => '2aaaadd5dbd0'];
			$arrayY = ['__array_ptr' => '2aaaadd5dce8'];
			$connected = ['__array_ptr' => '2aaaac9fc9a0'];
			foreach ($arrayXZ as $xz) {
				$x = $xz[0];
				$z = $xz[1];
				foreach ($arrayY as $y) {
					new \pocketmine\math\Vector3($x, $y, $z);
					$v3 = (new \pocketmine\math\Vector3($x, $y, $z))->add($this);
					$block = $this->level->getBlock($v3);
					if ($block instanceof \pocketmine\block\Rail) {
						if ($block->connect($this)) {
							$connected[] = $v3;
						} else {
							/* goto */
						}
						if ((count($connected) == 2)) {
						} else {
							/* goto */
						}
						switch (count($connected)) {
							case 1:
							$v3 = $connected[0]->subtract($this);
							if (($v3->y != 1)) {
								if (($v3->x == 0)) {
								} else {
								}
							} else {
								if (($v3->z == 0)) {
								} else {
								}
							}
							$this->meta = (($v3->z / 2) + 4.5);
							/* jump */
							case 2:
							$subtract = ['__array_ptr' => '2aaaac9fc9a0'];
							foreach ($connected as $key => $value) {
								$subtract[$key] = $value->subtract($this);
								/* goto */
							}
							if (((abs($subtract[0]->x) == abs($subtract[1]->z)) && (abs($subtract[1]->x) == abs($subtract[0]->z)))) {
								$v3 = $connected[0]->subtract($this)->add($connected[1]->subtract($this));
								if (($v3->x == 1)) {
									if (($v3->z == 1)) {
									} else {
									}
								} else {
									if (($v3->z == 1)) {
									} else {
									}
								}
								$this->meta = 8;
							} else {
								if ((($subtract[0]->y == 1) || ($subtract[1]->y == 1))) {
									if (($subtract[0]->y == 1)) {
									} else {
									}
									$v3 = $subtract[1];
									if (($v3->x == 0)) {
										if (($v3->z == -1)) {
										} else {
										}
									} else {
										if (($v3->x == 1)) {
										} else {
										}
									}
									$this->meta = 3;
								} else {
									if (($subtract[0]->x == 0)) {
									} else {
									}
									$this->meta = 1;
								}
							}
							/* jump */
							/* jump */
							$this->meta = ($this->meta);
							$this->level->setBlock($this, \pocketmine\block\Block::get($this->id, $this->meta), true, true);
							return true;
						}
					}
				}
			}
		}

	public static function check($rail = null) {
			/* decompiled (structured CF) */
			$array = ['__array_ptr' => '2aaaadd5dd20'];
			$arrayY = ['__array_ptr' => '2aaaadd813f0'];
			$blocks = $array[$rail->getRealMeta()];
			$connected = ['__array_ptr' => '2aaaac9fc9a0'];
			foreach ($arrayY as $y) {
				new \pocketmine\math\Vector3(($rail->x + $blocks[0][0]), ($rail->y + $y), ($rail->z + $blocks[0][1]));
				$v3 = new \pocketmine\math\Vector3(($rail->x + $blocks[0][0]), ($rail->y + $y), ($rail->z + $blocks[0][1]));
				$id = $rail->getLevel()->getBlockIdAt($v3->x, $v3->y, $v3->z);
				$meta = $rail->getLevel()->getBlockDataAt($v3->x, $v3->y, $v3->z);
				if (($id === self::RAIL)) {
				} else {
				}
				$meta = ($meta & 7);
				if ((in_array($id, [self::RAIL, self::ACTIVATOR_RAIL, self::DETECTOR_RAIL, self::POWERED_RAIL]) && in_array([($rail->x - $v3->x), ($rail->z - $v3->z)], $array[$meta]))) {
					$connected[] = $v3;
				} else {
					/* goto */
				}
			}
			foreach ($arrayY as $y) {
				new \pocketmine\math\Vector3(($rail->x + $blocks[1][0]), ($rail->y + $y), ($rail->z + $blocks[1][1]));
				$v3 = new \pocketmine\math\Vector3(($rail->x + $blocks[1][0]), ($rail->y + $y), ($rail->z + $blocks[1][1]));
				$id = $rail->getLevel()->getBlockIdAt($v3->x, $v3->y, $v3->z);
				$meta = $rail->getLevel()->getBlockDataAt($v3->x, $v3->y, $v3->z);
				if (($id === self::RAIL)) {
				} else {
				}
				$meta = ($meta & 7);
				if ((in_array($id, [self::RAIL, self::ACTIVATOR_RAIL, self::DETECTOR_RAIL, self::POWERED_RAIL]) && in_array([($rail->x - $v3->x), ($rail->z - $v3->z)], $array[$meta]))) {
					$connected[] = $v3;
				} else {
					/* goto */
				}
			}
			return $connected;
		}

	public function getHardness() {
			return 0.7;
		}

	public function getResistance() {
			return 3.5;
		}

	public function getDrops($item = null) {
			return [[$this->id, 0, 1]];
		}

	public function canPassThrough() {
			return true;
		}

}
