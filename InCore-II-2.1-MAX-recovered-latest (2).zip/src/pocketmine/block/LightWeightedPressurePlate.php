<?php

namespace pocketmine\block;

class LightWeightedPressurePlate extends \pocketmine\block\WeightedPressurePlate {
	protected $id = 147;
	protected $maxEntities = 15;

	public function getName() {
			return;
		}

}
