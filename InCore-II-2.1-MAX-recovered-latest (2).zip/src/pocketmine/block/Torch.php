<?php

namespace pocketmine\block;

class Torch extends \pocketmine\block\Flowable {
	protected $id = 50;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getLightLevel() {
			return 15;
		}

	public function getName() {
			return 'Torch';
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				$below = $this->getSide(0);
				$side = $this->getDamage();
				$faces = ['__array_ptr' => '2aaaadd5d498'];
				if ((($this->getSide($faces[$side])->isTransparent() === true) && !((($side === 0) && (((($below->getId() === self::FENCE) || ($below->getId() === self::COBBLE_WALL)) || ($below->getId() == \pocketmine\block\Block::INACTIVE_REDSTONE_LAMP)) || ($below->getId() == \pocketmine\block\Block::ACTIVE_REDSTONE_LAMP)))))) {
					$this->getLevel()->useBreakOn($this);
					return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
				}
			}
			return false;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$below = $this->getSide(0);
			if ((($target->isTransparent() === false) && ($face !== 0))) {
				$faces = ['__array_ptr' => '2aaaadd5d508'];
				$this->meta = $faces[$face];
				$this->getLevel()->setBlock($block, $this, true, true);
				return true;
			} else {
				if (((((($below->isTransparent() === false) || ($below->getId() === self::FENCE)) || ($below->getId() === self::COBBLE_WALL)) || ($below->getId() == \pocketmine\block\Block::INACTIVE_REDSTONE_LAMP)) || ($below->getId() == \pocketmine\block\Block::ACTIVE_REDSTONE_LAMP))) {
					$this->meta = 0;
					$this->getLevel()->setBlock($block, $this, true, true);
					return true;
				}
			}
			return false;
		}

	public function getDrops($item = null) {
			return [[$this->id, 0, 1]];
		}

}
