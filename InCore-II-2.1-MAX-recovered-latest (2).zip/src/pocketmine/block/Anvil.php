<?php

namespace pocketmine\block;

class Anvil extends \pocketmine\block\Fallable {
	public const NORMAL = 0;
	public const SLIGHTLY_DAMAGED = 4;
	public const VERY_DAMAGED = 8;

	protected $id = 145;

	public function isSolid() {
			return false;
		}

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function canBeActivated() {
			return true;
		}

	public function getHardness() {
			return 5;
		}

	public function getResistance() {
			return 6000;
		}

	public function getName() {
			$names = ['Anvil', $this, $this, 'Anvil'];
			return $names[($this->meta & 12)];
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			if (!($this->getLevel()->getServer()->anvilEnabled)) {
				return true;
			}
			if ($player instanceof \pocketmine\Player) {
				if (($player->isCreative() && $player->getServer()->limitedCreative)) {
					return true;
				}
				if (!($player->usingAnvil)) {
					new \pocketmine\inventory\AnvilInventory($this);
					$player->addWindow(new \pocketmine\inventory\AnvilInventory($this));
					$player->usingAnvil = true;
				}
			}
			return true;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			if (($player !== null)) {
			} else {
			}
			$direction = (0 & 3);
			$this->meta = ($direction | ($this->meta & 12));
			$this->getLevel()->setBlock($block, $this, true, true);
			return null;
		}

	public function onBreak($item = null) {
			/* decompiled (structured CF) */
			parent::onBreak($item);
			new \pocketmine\level\sound\AnvilBreakSound($this);
			$sound = new \pocketmine\level\sound\AnvilBreakSound($this);
			$this->getLevel()->addSound($sound);
			return null;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((1 <= $item->isPickaxe())) {
				return [[$this->id, ($this->meta & 12), 1]];
			} else {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
		}

}
