<?php

namespace pocketmine\block;

class Ice extends \pocketmine\block\Transparent {
	protected $id = 79;

	public function __construct() {
			// empty
		}

	public function getName() {
			return 'Ice';
		}

	public function getHardness() {
			return 0.5;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function onBreak($item = null) {
			/* decompiled (structured CF) */
			if (($item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_SILK_TOUCH) === 0)) {
				new \pocketmine\block\Water();
				$this->getLevel()->setBlock($this, new \pocketmine\block\Water(), true);
			}
			return true;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((0 < $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_SILK_TOUCH))) {
				return [[\pocketmine\item\Item::ICE, 0, 1]];
			} else {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
		}

}
