<?php

namespace pocketmine\block;

class EnchantingTable extends \pocketmine\block\Transparent {
	protected $id = 116;

	public function __construct() {
			// empty
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$this->getLevel()->setBlock($block, $this, true, true);
			new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::ENCHANT_TABLE);
			new \pocketmine\nbt\tag\IntTag('x', $this->x);
			new \pocketmine\nbt\tag\IntTag('y', $this->y);
			new \pocketmine\nbt\tag\IntTag('z', $this->z);
			new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::ENCHANT_TABLE), new \pocketmine\nbt\tag\IntTag('x', $this->x), new \pocketmine\nbt\tag\IntTag('y', $this->y), new \pocketmine\nbt\tag\IntTag('z', $this->z)]);
			$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::ENCHANT_TABLE), new \pocketmine\nbt\tag\IntTag('x', $this->x), new \pocketmine\nbt\tag\IntTag('y', $this->y), new \pocketmine\nbt\tag\IntTag('z', $this->z)]);
			if ($item->hasCustomName()) {
				new \pocketmine\nbt\tag\StringTag('CustomName', $item->getCustomName());
				$nbt->CustomName = new \pocketmine\nbt\tag\StringTag('CustomName', $item->getCustomName());
			}
			if ($item->hasCustomBlockData()) {
				foreach ($item->getCustomBlockData() as $key => $v) {
					$nbt->prop = $v;
					/* goto */
				}
			}
			\pocketmine\tile\Tile::createTile(\pocketmine\tile\Tile::ENCHANT_TABLE, $this->getLevel()->getChunk(($this->x >> 4), ($this->z >> 4)), $nbt);
			return true;
		}

	public function canBeActivated() {
			return true;
		}

	public function getHardness() {
			return 5;
		}

	public function getResistance() {
			return 6000;
		}

	public function getName() {
			return;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			if (!($this->getLevel()->getServer()->enchantingTableEnabled)) {
				return true;
			}
			if ($player instanceof \pocketmine\Player) {
				if (($player->getProtocol() == 34)) {
					return true;
				}
				$tile = $this->getLevel()->getTile($this);
				$enchantTable = null;
				if ($tile instanceof \pocketmine\tile\EnchantTable) {
					$enchantTable = $tile;
				}
			} else {
				$this->getLevel()->setBlock($this, $this, true, true);
				new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::ENCHANT_TABLE);
				new \pocketmine\nbt\tag\IntTag('x', $this->x);
				new \pocketmine\nbt\tag\IntTag('y', $this->y);
				new \pocketmine\nbt\tag\IntTag('z', $this->z);
				new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::ENCHANT_TABLE), new \pocketmine\nbt\tag\IntTag('x', $this->x), new \pocketmine\nbt\tag\IntTag('y', $this->y), new \pocketmine\nbt\tag\IntTag('z', $this->z)]);
				$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::ENCHANT_TABLE), new \pocketmine\nbt\tag\IntTag('x', $this->x), new \pocketmine\nbt\tag\IntTag('y', $this->y), new \pocketmine\nbt\tag\IntTag('z', $this->z)]);
				if ($item->hasCustomName()) {
					new \pocketmine\nbt\tag\StringTag('CustomName', $item->getCustomName());
					$nbt->CustomName = new \pocketmine\nbt\tag\StringTag('CustomName', $item->getCustomName());
				}
				if ($item->hasCustomBlockData()) {
					foreach ($item->getCustomBlockData() as $key => $v) {
						$nbt->prop = $v;
						/* goto */
					}
				}
				$enchantTable = \pocketmine\tile\Tile::createTile(\pocketmine\tile\Tile::ENCHANT_TABLE, $this->getLevel()->getChunk(($this->x >> 4), ($this->z >> 4)), $nbt);
			}
			$player->addWindow($enchantTable->getInventory());
			return true;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((1 <= $item->isPickaxe())) {
				return [[$this->id, 0, 1]];
			} else {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
		}

}
