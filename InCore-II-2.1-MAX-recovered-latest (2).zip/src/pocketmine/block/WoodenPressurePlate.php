<?php

namespace pocketmine\block;

class WoodenPressurePlate extends \pocketmine\block\PressurePlate {
	protected $id = 72;

	public function getName() {
			return;
		}

}
