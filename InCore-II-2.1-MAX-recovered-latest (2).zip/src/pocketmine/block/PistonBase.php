<?php

namespace pocketmine\block;

abstract class PistonBase extends \pocketmine\block\Transparent {
	public const META_FACING_MASK = 7;
	public const META_EXTENDED = 8;
	public const MOVE_LIMIT = 12;
	public const MOVE_CANCELLED = -1;

	protected $sticky = false;

	public function __construct($meta = null) {
			$this->meta = ($meta & 15);
		}

	public function getHardness() {
			return 1.5;
		}

	public function getResistance() {
			return 1.5;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function isSolid() {
			return false;
		}

	public function canBePushedByPiston() {
			return !($this->isExtended());
		}

	public function canBePulledByPiston() {
			return !($this->isExtended());
		}

	public function isSticky() {
			return $this->sticky;
		}

	public function getFacing() {
			/* decompiled (structured CF) */
			$facing = ($this->meta & self::META_FACING_MASK);
			if ((($facing < \pocketmine\math\Vector3::SIDE_DOWN) || (\pocketmine\math\Vector3::SIDE_EAST < $facing))) {
				return \pocketmine\math\Vector3::SIDE_NORTH;
			}
			if (self::isHorizontalFacing($facing)) {
			} else {
			}
			return $facing;
		}

	public function setFacing($facing = null) {
			$stored = self::logicFacingToMeta($facing);
			$this->meta = (($this->meta & self::META_EXTENDED) | ($stored & self::META_FACING_MASK));
			return null;
		}

	public function isExtended() {
			/* decompiled (structured CF) */
			if ($this->isValid()) {
				$face = $this->getFacing();
				$head = $this->getSide($face);
				if ($head instanceof \pocketmine\block\PistonHead) {
					return ($face === $head->getFacing());
				}
				if (($head->getId() === self::MOVING_BLOCK)) {
					return (($this->meta & self::META_EXTENDED) === self::META_EXTENDED);
				}
				return false;
			}
			return (($this->meta & self::META_EXTENDED) === self::META_EXTENDED);
		}

	public function setExtended($extended = null) {
			/* decompiled (structured CF) */
			if ($extended) {
				$this->meta |= self::META_EXTENDED;
			} else {
				$this->meta &= self::META_FACING_MASK;
			}
			return null;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			if ($player instanceof \pocketmine\Player) {
				$eyeY = ($player->y + $player->getEyeHeight());
				if (((abs(($player->getFloorX() - $block->x)) <= 1) && (abs(($player->getFloorZ() - $block->z)) <= 1))) {
					if ((2 < ($eyeY - $block->y))) {
						$this->setFacing(\pocketmine\math\Vector3::SIDE_UP);
					} else {
						if ((0 < ($block->y - $eyeY))) {
							$this->setFacing(\pocketmine\math\Vector3::SIDE_DOWN);
						} else {
							$this->setFacing(self::playerDirectionToSide($player->getDirection()));
						}
					}
				} else {
					$this->setFacing(self::playerDirectionToSide($player->getDirection()));
				}
			}
			$this->getLevel()->setBlock($block, $this, true, true);
			$this->syncPistonArmState($this->isExtended(), ['__array_ptr' => '2aaaac9fc9a0']);
			$this->checkState($this->isGettingPower());
			return true;
		}

	private static function playerDirectionToSide($direction = null) {
			/* decompiled (structured CF) */
			/* jump */
			switch (($direction)) {
				case 0:
				return \pocketmine\math\Vector3::SIDE_WEST;
				case 1:
				return \pocketmine\math\Vector3::SIDE_NORTH;
				case 2:
				return \pocketmine\math\Vector3::SIDE_EAST;
				case 3:
				return \pocketmine\math\Vector3::SIDE_SOUTH;
			}
		}

	protected static function isHorizontalFacing($facing = null) {
			return (((($facing === \pocketmine\math\Vector3::SIDE_NORTH) || ($facing === \pocketmine\math\Vector3::SIDE_SOUTH)) || ($facing === \pocketmine\math\Vector3::SIDE_WEST)) || ($facing === \pocketmine\math\Vector3::SIDE_EAST));
		}

	protected static function logicFacingToMeta($facing = null) {
			/* decompiled (structured CF) */
			$facing = ($facing);
			if ((($facing < \pocketmine\math\Vector3::SIDE_DOWN) || (\pocketmine\math\Vector3::SIDE_EAST < $facing))) {
				return \pocketmine\math\Vector3::SIDE_NORTH;
			}
			if (self::isHorizontalFacing($facing)) {
			} else {
			}
			return $facing;
		}

	public function onBreak($item = null) {
			/* decompiled (structured CF) */
			$face = $this->getFacing();
			new \pocketmine\block\Air();
			$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), true, true);
			$head = $this->getSide($face);
			if (($head instanceof \pocketmine\block\PistonHead && ($face === $head->getFacing()))) {
				new \pocketmine\block\Air();
				$this->getLevel()->setBlock($head, new \pocketmine\block\Air(), true, true);
			}
			return true;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (((($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL) || ($type === \pocketmine\level\Level::BLOCK_UPDATE_REDSTONE)) || ($type === \pocketmine\level\Level::BLOCK_UPDATE_MOVED))) {
				if (!($this->canUseRedstone())) {
					return false;
				}
				if (!($this->getLevel()->isBlockTickPending($this, $this))) {
					$this->getLevel()->scheduleUpdate($this, 0);
				}
				return $type;
			}
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED)) {
				if (!($this->canUseRedstone())) {
					return false;
				}
				$powered = $this->isGettingPower();
				$this->updateAttachedRedstoneTorches($powered);
				$moved = $this->checkState($powered);
				if (((($powered && !($this->isExtended())) && ($moved !== true)) && ($moved !== self::MOVE_CANCELLED))) {
					$this->getLevel()->scheduleUpdate($this, 2);
				}
				return $type;
			}
			return false;
		}

	protected function canUseRedstone() {
			/* decompiled (structured CF) */
			if (!($this->isValid())) {
				return false;
			}
			$server = $this->getLevel()->getServer();
			return (!(isset($server->redstoneEnabled)) || $server->redstoneEnabled);
		}

	public function isGettingPower() {
			/* decompiled (structured CF) */
			if (!($this->isValid())) {
				return false;
			}
			$face = $this->getFacing();
			foreach (\pocketmine\block\Block::BLOCK_SIDES as $side) {
				if (($side === $face)) {
					/* goto */
				}
				$block = $this->getSide($side);
				if ((($block->getId() === self::REDSTONE_WIRE) && (0 < $block->getDamage()))) {
					return true;
				}
				if ($this->getLevel()->isSidePowered($block, $side)) {
					return true;
				}
				/* goto */
			}
			return false;
		}

	protected function checkState($powered = null) {
			/* decompiled (structured CF) */
			$face = $this->getFacing();
			$head = $this->getSide($face);
			$hasHead = (($head instanceof \pocketmine\block\PistonHead && ($face === $head->getFacing())) || (($head->getId() === self::MOVING_BLOCK) && $this->isExtended()));
			if (($powered && !($hasHead))) {
				return $this->doMove(true);
			}
			if ((!($powered) && $hasHead)) {
				return $this->doMove(false);
			}
			return false;
		}

	private function updateAttachedRedstoneTorches($powered = null) {
			/* decompiled (structured CF) */
			foreach (\pocketmine\block\Block::BLOCK_SIDES as $side) {
				$torch = $this->getSide($side);
				if (!($torch instanceof \pocketmine\block\RedstoneTorch)) {
					/* goto */
				}
				$isLit = ($torch->getId() === self::REDSTONE_TORCH);
				$isUnlit = ($torch->getId() === self::UNLIT_REDSTONE_TORCH);
				if (((!($powered) || !($isLit)) && ($powered || !($isUnlit)))) {
					/* goto */
				}
				if ($torch->getSide(self::getRedstoneTorchSupportSide($torch->getDamage()))->equals($this)) {
					$torch->onUpdate(\pocketmine\level\Level::BLOCK_UPDATE_REDSTONE);
				}
				/* goto */
			}
			return null;
		}

	private static function getRedstoneTorchSupportSide($meta = null) {
			/* decompiled (structured CF) */
			/* jump */
			switch (($meta)) {
				case 1:
				return \pocketmine\math\Vector3::SIDE_WEST;
				case 2:
				return \pocketmine\math\Vector3::SIDE_EAST;
				case 3:
				return \pocketmine\math\Vector3::SIDE_NORTH;
				case 4:
				return \pocketmine\math\Vector3::SIDE_SOUTH;
				case 5:
				case 6:
				case 0:
				return \pocketmine\math\Vector3::SIDE_DOWN;
			}
		}

	protected function doMove($extending = null) {
			/* decompiled (structured CF) */
			$face = $this->getFacing();
			new \pocketmine\block\PistonMoveCalculator($this, $extending);
			$calculator = new \pocketmine\block\PistonMoveCalculator($this, $extending);
			$canMove = $calculator->canMove();
			if ((!($canMove) && $extending)) {
				return false;
			}
			new \pocketmine\event\block\BlockPistonEvent($this, $face, $calculator->getBlocksToMove(), $calculator->getBlocksToDestroy(), $extending);
			$ev = new \pocketmine\event\block\BlockPistonEvent($this, $face, $calculator->getBlocksToMove(), $calculator->getBlocksToDestroy(), $extending);
			$this->getLevel()->getServer()->getPluginManager()->callEvent($ev);
			if ($ev->isCancelled()) {
				return self::MOVE_CANCELLED;
			}
			$touched = [$this->floor()];
			$entityPushPositions = [$this->getSide($face)->floor()];
			if (($extending || $this->sticky)) {
				foreach (array_reverse($calculator->getBlocksToDestroy()) as $block) {
					$item = \pocketmine\item\Item::get(\pocketmine\item\Item::AIR, 0, 0);
					$this->getLevel()->useBreakOn($block, $item);
					$touched[] = $block->floor();
					/* goto */
				}
			}
			if ($extending) {
			} else {
			}
			$moveDirection = \pocketmine\math\Vector3::getOppositeSide($face);
			$moved = ['__array_ptr' => '2aaaac9fc9a0'];
			$attachedBlocks = ['__array_ptr' => '2aaaac9fc9a0'];
			if (($canMove && ($extending || $this->sticky))) {
				foreach ($calculator->getBlocksToMove() as $block) {
					if (($block->getId() === self::AIR)) {
						/* goto */
					}
					$oldPos = $block->floor();
					$newPos = $block->getSide($moveDirection)->floor();
					$tile = $this->captureMovableTile($block, $newPos);
					$attachedBlocks[] = $oldPos;
					$moved[] = [$oldPos, $newPos, \pocketmine\block\Block::get($block->getId(), $block->getDamage()), $tile, $this->createMovingBlockNbt($block, $newPos, $extending, $tile)];
					/* goto */
				}
			}
			if (!($extending)) {
				$head = $this->getSide($face);
				if ((($head instanceof \pocketmine\block\PistonHead && ($face === $head->getFacing())) || ($head->getId() === self::MOVING_BLOCK))) {
					new \pocketmine\block\Air();
					$this->getLevel()->setBlock($head, new \pocketmine\block\Air(), true, false);
					$touched[] = $head->floor();
				}
			}
			foreach ($moved as $move) {
				if (((($move['tile'] !== null) && isset($move['tile']['tile'])) && method_exists($move['tile']['tile'], 'close'))) {
					$move['tile']['tile']->close();
				}
				new \pocketmine\block\Air();
				$this->getLevel()->setBlock($move['old'], new \pocketmine\block\Air(), true, false);
				$touched[] = $move['old'];
				/* goto */
			}
			$movedBlocks = ['__array_ptr' => '2aaaac9fc9a0'];
			foreach ($moved as $move) {
				$this->syncMovingBlockState($move['new'], $move['movingBlockNbt']);
				$this->getLevel()->setBlock($move['new'], $move['block'], true, false);
				$this->removeMovingBlockTile($move['new']);
				if ((($move['tile'] !== null) && isset($move['tile']['nbt']))) {
					$this->restoreMovableTile($move['new'], $move['tile']['nbt']);
				}
				$movedBlocks[] = $move['block'];
				$touched[] = $move['new'];
				$entityPushPositions[] = $move['new'];
				/* goto */
			}
			$this->setExtended($extending);
			$this->getLevel()->setBlock($this, $this, true, false);
			if ($extending) {
				$head = $this->createHead($face);
				$headPos = $this->getSide($face);
				$this->getLevel()->setBlock($headPos, $head, true, false);
				$touched[] = $headPos->floor();
			}
			foreach ($movedBlocks as $block) {
				$block->onUpdate(\pocketmine\level\Level::BLOCK_UPDATE_MOVED);
				/* goto */
			}
			$this->pushEntities($entityPushPositions, $moveDirection);
			$this->updateMovedBlocks($touched);
			$this->syncPistonArmState($extending, $attachedBlocks);
			$this->playMoveSound($extending);
			return true;
		}

	private function syncMovingBlockState($pos = null, $nbt = null) {
			/* decompiled (structured CF) */
			if (method_exists($this->getLevel(), 'createMovingBlockFromPistonMove')) {
				$this->getLevel()->createMovingBlockFromPistonMove($pos, $nbt);
			}
			return null;
		}

	private function createMovingBlockNbt($block = null, $newPos = null, $extending = null, $tileData = null) {
			/* decompiled (structured CF) */
			new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::MOVING_BLOCK);
			new \pocketmine\nbt\tag\IntTag('x', ($newPos->x));
			new \pocketmine\nbt\tag\IntTag('y', ($newPos->y));
			new \pocketmine\nbt\tag\IntTag('z', ($newPos->z));
			new \pocketmine\nbt\tag\ByteTag('isMovable', 1);
			if ($extending) {
			} else {
			}
			new \pocketmine\nbt\tag\ByteTag('expanding', 0);
			new \pocketmine\nbt\tag\IntTag('pistonPosX', ($this->x));
			new \pocketmine\nbt\tag\IntTag('pistonPosY', ($this->y));
			new \pocketmine\nbt\tag\IntTag('pistonPosZ', ($this->z));
			new \pocketmine\nbt\tag\IntTag('movingBlockId', $block->getId());
			new \pocketmine\nbt\tag\IntTag('movingBlockData', $block->getDamage());
			$tags = [new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::MOVING_BLOCK), new \pocketmine\nbt\tag\IntTag('x', ($newPos->x)), new \pocketmine\nbt\tag\IntTag('y', ($newPos->y)), new \pocketmine\nbt\tag\IntTag('z', ($newPos->z)), new \pocketmine\nbt\tag\ByteTag('isMovable', 1), new \pocketmine\nbt\tag\ByteTag('expanding', 0), new \pocketmine\nbt\tag\IntTag('pistonPosX', ($this->x)), new \pocketmine\nbt\tag\IntTag('pistonPosY', ($this->y)), new \pocketmine\nbt\tag\IntTag('pistonPosZ', ($this->z)), new \pocketmine\nbt\tag\IntTag('movingBlockId', $block->getId()), new \pocketmine\nbt\tag\IntTag('movingBlockData', $block->getDamage()), $this->createLegacyMovingBlockCompound('movingBlock', $block->getId(), $block->getDamage())];
			if (((is_array($tileData) && isset($tileData['nbt'])) && $tileData['nbt'] instanceof \pocketmine\nbt\tag\CompoundTag)) {
				$movingEntity = $this->cloneNbtTag($tileData['nbt']);
				$movingEntity->setName('movingEntity');
				$tags[] = $movingEntity;
			}
			new \pocketmine\nbt\tag\CompoundTag('', $tags);
			return new \pocketmine\nbt\tag\CompoundTag('', $tags);
		}

	private function createLegacyMovingBlockCompound($name = null, $id = null, $data = null) {
			/* decompiled (structured CF) */
			new \pocketmine\nbt\tag\IntTag('id', ($id));
			new \pocketmine\nbt\tag\IntTag('data', ($data));
			new \pocketmine\nbt\tag\CompoundTag($name, [new \pocketmine\nbt\tag\IntTag('id', ($id)), new \pocketmine\nbt\tag\IntTag('data', ($data))]);
			return new \pocketmine\nbt\tag\CompoundTag($name, [new \pocketmine\nbt\tag\IntTag('id', ($id)), new \pocketmine\nbt\tag\IntTag('data', ($data))]);
		}

	private function removeMovingBlockTile($pos = null) {
			/* decompiled (structured CF) */
			if (!(method_exists($this->getLevel(), 'getTile'))) {
				return null;
			}
			$tile = $this->getLevel()->getTile($pos);
			if (!($tile instanceof \pocketmine\tile\MovingBlock)) {
			}
			if (method_exists($tile, 'close')) {
				$tile->close();
			}
			if (method_exists($this->getLevel(), 'removeTileObject')) {
				$this->getLevel()->removeTileObject($tile);
			}
		}

	private function syncPistonArmState($extending = null, $attachedBlocks = null) {
			/* decompiled (structured CF) */
			$nbt = $this->createPistonArmNbt($extending, $attachedBlocks);
			$pos = $this->floor();
			if (method_exists($this->getLevel(), 'createPistonArmFromPistonMove')) {
				$this->getLevel()->createPistonArmFromPistonMove($pos, $nbt);
				return null;
			}
			if (!(method_exists($this->getLevel(), 'getChunk'))) {
			}
			$chunk = $this->getLevel()->getChunk(($pos->x >> 4), ($pos->z >> 4), true);
			if (($chunk !== null)) {
				\pocketmine\tile\Tile::createTile(\pocketmine\tile\Tile::PISTON_ARM, $chunk, $nbt);
			}
		}

	private function createPistonArmNbt($extending = null, $attachedBlocks = null) {
			/* decompiled (structured CF) */
			if ($extending) {
			} else {
			}
			$progress = 0;
			if ($extending) {
			} else {
			}
			$state = 0;
			new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::PISTON_ARM);
			new \pocketmine\nbt\tag\IntTag('x', ($this->x));
			new \pocketmine\nbt\tag\IntTag('y', ($this->y));
			new \pocketmine\nbt\tag\IntTag('z', ($this->z));
			new \pocketmine\nbt\tag\ByteTag('isMovable', 1);
			new \pocketmine\nbt\tag\ByteTag('State', $state);
			new \pocketmine\nbt\tag\ByteTag('NewState', $state);
			new \pocketmine\nbt\tag\FloatTag('Progress', $progress);
			new \pocketmine\nbt\tag\FloatTag('LastProgress', $progress);
			if ($this->isGettingPower()) {
			} else {
			}
			new \pocketmine\nbt\tag\ByteTag('powered', 0);
			new \pocketmine\nbt\tag\ByteTag('facing', $this->getFacing());
			if ($this->isSticky()) {
			} else {
			}
			new \pocketmine\nbt\tag\ByteTag('Sticky', 0);
			if ($extending) {
			} else {
			}
			new \pocketmine\nbt\tag\ByteTag('Extending', 0);
			new \pocketmine\nbt\tag\ListTag('BreakBlocks', ['__array_ptr' => '2aaaac9fc9a0']);
			new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::PISTON_ARM), new \pocketmine\nbt\tag\IntTag('x', ($this->x)), new \pocketmine\nbt\tag\IntTag('y', ($this->y)), new \pocketmine\nbt\tag\IntTag('z', ($this->z)), new \pocketmine\nbt\tag\ByteTag('isMovable', 1), new \pocketmine\nbt\tag\ByteTag('State', $state), new \pocketmine\nbt\tag\ByteTag('NewState', $state), new \pocketmine\nbt\tag\FloatTag('Progress', $progress), new \pocketmine\nbt\tag\FloatTag('LastProgress', $progress), new \pocketmine\nbt\tag\ByteTag('powered', 0), new \pocketmine\nbt\tag\ByteTag('facing', $this->getFacing()), new \pocketmine\nbt\tag\ByteTag('Sticky', 0), new \pocketmine\nbt\tag\ByteTag('Extending', 0), $this->createAttachedBlocksTag($attachedBlocks), new \pocketmine\nbt\tag\ListTag('BreakBlocks', ['__array_ptr' => '2aaaac9fc9a0'])]);
			return new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::PISTON_ARM), new \pocketmine\nbt\tag\IntTag('x', ($this->x)), new \pocketmine\nbt\tag\IntTag('y', ($this->y)), new \pocketmine\nbt\tag\IntTag('z', ($this->z)), new \pocketmine\nbt\tag\ByteTag('isMovable', 1), new \pocketmine\nbt\tag\ByteTag('State', $state), new \pocketmine\nbt\tag\ByteTag('NewState', $state), new \pocketmine\nbt\tag\FloatTag('Progress', $progress), new \pocketmine\nbt\tag\FloatTag('LastProgress', $progress), new \pocketmine\nbt\tag\ByteTag('powered', 0), new \pocketmine\nbt\tag\ByteTag('facing', $this->getFacing()), new \pocketmine\nbt\tag\ByteTag('Sticky', 0), new \pocketmine\nbt\tag\ByteTag('Extending', 0), $this->createAttachedBlocksTag($attachedBlocks), new \pocketmine\nbt\tag\ListTag('BreakBlocks', ['__array_ptr' => '2aaaac9fc9a0'])]);
		}

	private function createAttachedBlocksTag($blocks = null) {
			/* decompiled (structured CF) */
			$tags = ['__array_ptr' => '2aaaac9fc9a0'];
			foreach ($blocks as $block) {
				if (!($block instanceof \pocketmine\math\Vector3)) {
					/* goto */
				}
				new \pocketmine\nbt\tag\IntTag('', ($block->x));
				$tags[] = new \pocketmine\nbt\tag\IntTag('', ($block->x));
				new \pocketmine\nbt\tag\IntTag('', ($block->y));
				$tags[] = new \pocketmine\nbt\tag\IntTag('', ($block->y));
				new \pocketmine\nbt\tag\IntTag('', ($block->z));
				$tags[] = new \pocketmine\nbt\tag\IntTag('', ($block->z));
				/* goto */
			}
			new \pocketmine\nbt\tag\ListTag('AttachedBlocks', $tags);
			$list = new \pocketmine\nbt\tag\ListTag('AttachedBlocks', $tags);
			$list->setTagType(\pocketmine\nbt\NBT::TAG_Int);
			return $list;
		}

	private function playMoveSound($extending = null) {
			/* decompiled (structured CF) */
			if (!(method_exists($this->getLevel(), 'addSound'))) {
				return null;
			}
			if ($extending) {
				new \pocketmine\level\sound\PistonOutSound($this);
			} else {
				new \pocketmine\level\sound\PistonInSound($this);
			}
			$this->getLevel()->addSound(new \pocketmine\level\sound\PistonInSound($this));
		}

	private function captureMovableTile($block = null, $newPos = null) {
			/* decompiled (structured CF) */
			if ((!($block->isValid()) || !(method_exists($this->getLevel(), 'getTile')))) {
				return null;
			}
			$tile = $this->getLevel()->getTile($block);
			if (($tile === null)) {
			}
			if (($tile instanceof \pocketmine\tile\MovingBlock && ($block->getId() !== self::MOVING_BLOCK))) {
				if (method_exists($tile, 'close')) {
					$tile->close();
				}
				if (method_exists($this->getLevel(), 'removeTileObject')) {
					$this->getLevel()->removeTileObject($tile);
				}
			}
			if ((method_exists($tile, 'isMovable') && !($tile->isMovable()))) {
			}
			if (method_exists($tile, 'saveNBT')) {
				$tile->saveNBT();
			}
			if (!(isset($tile->namedtag))) {
			}
			$nbt = $this->cloneNbtTag($tile->namedtag);
			new \pocketmine\nbt\tag\IntTag('x', ($newPos->x));
			$nbt->x = new \pocketmine\nbt\tag\IntTag('x', ($newPos->x));
			new \pocketmine\nbt\tag\IntTag('y', ($newPos->y));
			$nbt->y = new \pocketmine\nbt\tag\IntTag('y', ($newPos->y));
			new \pocketmine\nbt\tag\IntTag('z', ($newPos->z));
			$nbt->z = new \pocketmine\nbt\tag\IntTag('z', ($newPos->z));
			return [$tile, $nbt];
		}

	private function cloneNbtTag($tag = null) {
			/* decompiled (structured CF) */
			if (!(is_object($tag))) {
				return $tag;
			}
			$copy = clone $tag;
			foreach ($copy as $name => $value) {
				if (is_object($value)) {
					$copy->prop = $this->cloneNbtTag($value);
				}
				/* goto */
			}
			return $copy;
		}

	private function restoreMovableTile($pos = null, $nbt = null) {
			/* decompiled (structured CF) */
			if (method_exists($this->getLevel(), 'createTileFromPistonMove')) {
				$this->getLevel()->createTileFromPistonMove($pos, $nbt);
				return null;
			}
			if ((!(isset($nbt->id)) || !(method_exists($this->getLevel(), 'getChunk')))) {
			}
			$chunk = $this->getLevel()->getChunk(($pos->x >> 4), ($pos->z >> 4), true);
			if (($chunk !== null)) {
				\pocketmine\tile\Tile::createTile($nbt['id'], $chunk, $nbt);
			}
		}

	private function pushEntities($positions = null, $moveDirection = null) {
			/* decompiled (structured CF) */
			if ((($moveDirection === \pocketmine\math\Vector3::SIDE_DOWN) || !(method_exists($this->getLevel(), 'getNearbyEntities')))) {
				return null;
			}
			$dx = 0;
			$dy = 0;
			$dz = 0;
			if (!(($moveDirection == \pocketmine\math\Vector3::SIDE_UP))) {
				if (!(($moveDirection == \pocketmine\math\Vector3::SIDE_NORTH))) {
					if (!(($moveDirection == \pocketmine\math\Vector3::SIDE_SOUTH))) {
						if (!(($moveDirection == \pocketmine\math\Vector3::SIDE_WEST))) {
							if (!(($moveDirection == \pocketmine\math\Vector3::SIDE_EAST))) {
								/* jump */
								$dy = 2;
							} else {
								$dz = -1;
								/* jump */
								$dz = 1;
								/* jump */
								$dx = -1;
								/* jump */
								$dx = 1;
								/* jump */
							}
							$moved = ['__array_ptr' => '2aaaac9fc9a0'];
							foreach ($positions as $pos) {
								new \pocketmine\math\AxisAlignedBB($pos->x, $pos->y, $pos->z, ($pos->x + 1), ($pos->y + 1), ($pos->z + 1));
								$bb = new \pocketmine\math\AxisAlignedBB($pos->x, $pos->y, $pos->z, ($pos->x + 1), ($pos->y + 1), ($pos->z + 1));
								foreach ($this->getLevel()->getNearbyEntities($bb) as $entity) {
									if ((!(is_object($entity)) || $entity instanceof \pocketmine\Player)) {
										/* goto */
									}
									$hash = spl_object_hash($entity);
									if (isset($moved[$hash])) {
										/* goto */
									}
									$moved[$hash] = true;
									if ((isset($entity->closed) && $entity->closed)) {
										/* goto */
									}
									if ((method_exists($entity, 'canBePushedByPiston') && !($entity->canBePushedByPiston()))) {
										/* goto */
									}
									if (method_exists($entity, 'onPushByPiston')) {
										$entity->onPushByPiston($this);
									}
									if (method_exists($entity, 'move')) {
										$entity->move($dx, $dy, $dz);
									}
									/* goto */
								}
								/* goto */
							}
						}
					}
				}
			}
		}

	private function updateMovedBlocks($positions = null) {
			/* decompiled (structured CF) */
			$seen = ['__array_ptr' => '2aaaac9fc9a0'];
			foreach ($positions as $pos) {
				$hash = \pocketmine\level\Level::blockHash($pos->x, $pos->y, $pos->z);
				if (isset($seen[$hash])) {
					/* goto */
				}
				$seen[$hash] = true;
				$this->getLevel()->updateAround($pos);
				$this->getLevel()->updateAroundRedstone($pos, null);
				/* goto */
			}
			return null;
		}

	protected abstract function createHead($face = null);

	public static function canPush($block = null, $face = null, $destroyBlocks = null, $extending = null) {
			/* decompiled (structured CF) */
			if (($block->getId() === self::AIR)) {
				return true;
			}
			if ((($block->y < 0) || (128 <= $block->y))) {
				return false;
			}
			if (((($face === \pocketmine\math\Vector3::SIDE_DOWN) && ($block->y === 0)) || (($face === \pocketmine\math\Vector3::SIDE_UP) && ($block->y === 127)))) {
				return false;
			}
			if ((($extending && !($block->canBePushedByPiston())) || (!($extending) && !($block->canBePulledByPiston())))) {
				return false;
			}
			if ($block->breaksWhenMovedByPiston()) {
				return ($destroyBlocks || $block->canStickToPiston());
			}
			return true;
		}

	public function getDrops($item = null) {
			return [[$this->id, 0, 1]];
		}

}
