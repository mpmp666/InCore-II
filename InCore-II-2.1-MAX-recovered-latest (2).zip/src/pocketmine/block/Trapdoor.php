<?php

namespace pocketmine\block;

class Trapdoor extends \pocketmine\block\Transparent {
	protected $id = 96;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return;
		}

	public function isSolid() {
			return false;
		}

	public function canPassThrough() {
			return true;
		}

	public function getHardness() {
			return 3;
		}

	public function canBeActivated() {
			return true;
		}

	protected function recalculateBoundingBox() {
			/* decompiled (structured CF) */
			$damage = $this->getDamage();
			$f = 0.1875;
			if ((0 < ($damage & 8))) {
				new \pocketmine\math\AxisAlignedBB($this->x, (($this->y + 1) - $f), $this->z, ($this->x + 1), ($this->y + 1), ($this->z + 1));
				$bb = new \pocketmine\math\AxisAlignedBB($this->x, (($this->y + 1) - $f), $this->z, ($this->x + 1), ($this->y + 1), ($this->z + 1));
			} else {
				new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + $f), ($this->z + 1));
				$bb = new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + $f), ($this->z + 1));
			}
			if ((0 < ($damage & 4))) {
				if ((($damage & 3) === 0)) {
					$bb->setBounds($this->x, $this->y, (($this->z + 1) - $f), ($this->x + 1), ($this->y + 1), ($this->z + 1));
				} else {
					if ((($damage & 3) === 1)) {
						$bb->setBounds($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 1), ($this->z + $f));
					}
				}
				if ((($damage & 3) === 2)) {
					$bb->setBounds((($this->x + 1) - $f), $this->y, $this->z, ($this->x + 1), ($this->y + 1), ($this->z + 1));
				}
				if ((($damage & 3) === 3)) {
					$bb->setBounds($this->x, $this->y, $this->z, ($this->x + $f), ($this->y + 1), ($this->z + 1));
				}
			}
			return $bb;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			if ((((($target->isTransparent() === false) || ($target->getId() === self::SLAB)) && ($face !== 0)) && ($face !== 1))) {
				if (!(($face == 2))) {
					if (!(($face == 3))) {
						if (!(($face == 4))) {
							if (!(($face == 5))) {
							} else {
								$this->meta |= 3;
								/* jump */
								$this->meta |= 2;
								/* jump */
								$this->meta |= 1;
								/* jump */
								/* jump */
							}
							if ((0.5 < $fy)) {
								$this->meta |= 4;
							}
							$this->getLevel()->setBlock($block, $this, true, true);
							return true;
						}
					}
				}
			}
		}

	public function getDrops($item = null) {
			return [[$this->id, 0, 1]];
		}

	public function isOpened() {
			return (($this->meta & 8) === 0);
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			$this->meta ^= 8;
			$this->getLevel()->setBlock($this, $this, true);
			new \pocketmine\level\sound\DoorSound($this);
			$this->level->addSound(new \pocketmine\level\sound\DoorSound($this));
			return true;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_AXE;
		}

}
