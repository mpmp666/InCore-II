<?php

namespace pocketmine\block;

class RedstoneOre extends \pocketmine\block\Solid {
	protected $id = 73;

	public function __construct() {
			// empty
		}

	public function getName() {
			return;
		}

	public function getHardness() {
			return 3;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if ((($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL) || ($type === \pocketmine\level\Level::BLOCK_UPDATE_TOUCH))) {
				$this->getLevel()->setBlock($this, \pocketmine\block\Block::get(\pocketmine\item\Item::GLOWING_REDSTONE_ORE, $this->meta));
				$this->getLevel()->scheduleUpdate($this, 30);
				return \pocketmine\level\Level::BLOCK_UPDATE_WEAK;
			}
			return false;
		}

	public function onEntityCollide($entity = null) {
			$this->onUpdate(\pocketmine\level\Level::BLOCK_UPDATE_TOUCH);
			return null;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((\pocketmine\item\Tool::TIER_IRON <= $item->isPickaxe())) {
				if ((0 < $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_SILK_TOUCH))) {
					return [[\pocketmine\item\Item::REDSTONE_ORE, 0, 1]];
				} else {
					$fortunel = $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_FORTUNE);
					if ((3 < $fortunel)) {
					} else {
					}
					$fortunel = $fortunel;
					return [[\pocketmine\item\Item::REDSTONE_DUST, 0, mt_rand(4, (5 + $fortunel))]];
				}
			} else {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
		}

}
