<?php

namespace pocketmine\block;

class TNT extends \pocketmine\block\Solid implements \pocketmine\block\ElectricalAppliance {
	protected $id = 46;

	public function __construct() {
			// empty
		}

	public function getName() {
			return 'TNT';
		}

	public function getHardness() {
			return 0;
		}

	public function canBeActivated() {
			return true;
		}

	public function getBurnChance() {
			return 15;
		}

	public function getBurnAbility() {
			return 100;
		}

	public function prime() {
			/* decompiled (structured CF) */
			if (!($this->getLevel()->getServer()->tntExplosionEnabled)) {
				return false;
			}
			$this->meta = 1;
			new \pocketmine\utils\Random();
			$mot = (((new \pocketmine\utils\Random())->nextSignedFloat() * \M_PI) * 2);
			new \pocketmine\nbt\tag\DoubleTag('', ($this->x + 0.5));
			new \pocketmine\nbt\tag\DoubleTag('', $this->y);
			new \pocketmine\nbt\tag\DoubleTag('', ($this->z + 0.5));
			new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', ($this->x + 0.5)), new \pocketmine\nbt\tag\DoubleTag('', $this->y), new \pocketmine\nbt\tag\DoubleTag('', ($this->z + 0.5))]);
			new \pocketmine\nbt\tag\DoubleTag('', ((sin($mot) * -1) * 0.02));
			new \pocketmine\nbt\tag\DoubleTag('', 0.2);
			new \pocketmine\nbt\tag\DoubleTag('', ((cos($mot) * -1) * 0.02));
			new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', ((sin($mot) * -1) * 0.02)), new \pocketmine\nbt\tag\DoubleTag('', 0.2), new \pocketmine\nbt\tag\DoubleTag('', ((cos($mot) * -1) * 0.02))]);
			new \pocketmine\nbt\tag\FloatTag('', 0);
			new \pocketmine\nbt\tag\FloatTag('', 0);
			new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', 0), new \pocketmine\nbt\tag\FloatTag('', 0)]);
			new \pocketmine\nbt\tag\ByteTag('Fuse', 80);
			new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', ($this->x + 0.5)), new \pocketmine\nbt\tag\DoubleTag('', $this->y), new \pocketmine\nbt\tag\DoubleTag('', ($this->z + 0.5))]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', ((sin($mot) * -1) * 0.02)), new \pocketmine\nbt\tag\DoubleTag('', 0.2), new \pocketmine\nbt\tag\DoubleTag('', ((cos($mot) * -1) * 0.02))]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', 0), new \pocketmine\nbt\tag\FloatTag('', 0)]), new \pocketmine\nbt\tag\ByteTag('Fuse', 80)]);
			$tnt = \pocketmine\entity\Entity::createEntity('PrimedTNT', $this->getLevel()->getChunk(($this->x >> 4), ($this->z >> 4)), new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', ($this->x + 0.5)), new \pocketmine\nbt\tag\DoubleTag('', $this->y), new \pocketmine\nbt\tag\DoubleTag('', ($this->z + 0.5))]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', ((sin($mot) * -1) * 0.02)), new \pocketmine\nbt\tag\DoubleTag('', 0.2), new \pocketmine\nbt\tag\DoubleTag('', ((cos($mot) * -1) * 0.02))]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', 0), new \pocketmine\nbt\tag\FloatTag('', 0)]), new \pocketmine\nbt\tag\ByteTag('Fuse', 80)]));
			$tnt->spawnToAll();
			new \pocketmine\level\sound\TNTPrimeSound($this);
			$this->level->addSound(new \pocketmine\level\sound\TNTPrimeSound($this));
			return true;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if ((($type == \pocketmine\level\Level::BLOCK_UPDATE_REDSTONE) || ($type == \pocketmine\level\Level::BLOCK_UPDATE_NORMAL))) {
				if ($this->getLevel()->isBlockPowered($this)) {
					if ($this->prime()) {
						new \pocketmine\block\Air();
						$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), true);
					}
				}
				return $type;
			}
			if (($type == \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED)) {
				$sides = ['__array_ptr' => '2aaaadd5d738'];
				foreach ($sides as $side) {
					$block = $this->getSide($side);
					if (($block instanceof \pocketmine\block\RedstoneSource && $block->isActivated($this))) {
						if ($this->prime()) {
							new \pocketmine\block\Air();
							$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), true);
						}
					} else {
						/* goto */
					}
				}
				return \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED;
			}
			return false;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			$this->getLevel()->setBlock($this, $this, true, false);
			$this->getLevel()->scheduleUpdate($this, 40);
			return null;
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			if (($item->getId() === \pocketmine\item\Item::FLINT_STEEL)) {
				if ($this->prime()) {
					new \pocketmine\block\Air();
					$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), true);
					$item->useOn($this, 2);
					return true;
				}
			}
			return false;
		}

}
