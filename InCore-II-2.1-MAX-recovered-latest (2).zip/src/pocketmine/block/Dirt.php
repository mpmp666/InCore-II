<?php

namespace pocketmine\block;

class Dirt extends \pocketmine\block\Solid {
	protected $id = 3;

	public function __construct() {
			// empty
		}

	public function canBeActivated() {
			return true;
		}

	public function getHardness() {
			return 0.5;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_SHOVEL;
		}

	public function getName() {
			return 'Dirt';
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			if ($item->isHoe()) {
				$item->useOn($this, 2);
				$this->getLevel()->setBlock($this, \pocketmine\block\Block::get(\pocketmine\item\Item::FARMLAND, 0), true);
				return true;
			}
			return false;
		}

}
