<?php

namespace pocketmine\block;

class PressurePlate extends \pocketmine\block\RedstoneSource {
	public const RECHECK_DELAY = 20;

	protected $activateTime = 0;
	protected $canActivate = true;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function hasEntityCollision() {
			return true;
		}

	public function getBoundingBox() {
			/* decompiled (structured CF) */
			if (($this->boundingBox === null)) {
				new \pocketmine\math\AxisAlignedBB(($this->x + 0.125), $this->y, ($this->z + 0.125), ($this->x + 0.875), ($this->y + 0.25), ($this->z + 0.875));
				$this->boundingBox = new \pocketmine\math\AxisAlignedBB(($this->x + 0.125), $this->y, ($this->z + 0.125), ($this->x + 0.875), ($this->y + 0.25), ($this->z + 0.875));
			}
			return $this->boundingBox;
		}

	public function canPassThrough() {
			return true;
		}

	public function onEntityCollide($entity = null) {
			/* decompiled (structured CF) */
			if (((!($this->getLevel()->getServer()->redstoneEnabled) || !($this->canActivate)) || !($entity->canTriggerWalking()))) {
				return null;
			}
			if (!($this->isActivated())) {
				$this->updateState($entity);
			}
		}

	protected function computeRedstoneStrength($collidingEntity = null) {
			/* decompiled (structured CF) */
			if ((0 < $this->countTriggeredEntities($collidingEntity))) {
			} else {
			}
			return 0;
		}

	protected function countTriggeredEntities($collidingEntity = null) {
			/* decompiled (structured CF) */
			$count = 0;
			$seen = ['__array_ptr' => '2aaaac9fc9a0'];
			if ((($collidingEntity !== null) && $collidingEntity->canTriggerWalking())) {
				$seen[spl_object_hash($collidingEntity)] = true;
				$count++;
			}
			foreach ($this->getLevel()->getCollidingEntities($this->getBoundingBox()) as $entity) {
				if ((!($entity instanceof \pocketmine\entity\Entity) || !($entity->canTriggerWalking()))) {
					/* goto */
				}
				$hash = spl_object_hash($entity);
				if (isset($seen[$hash])) {
					/* goto */
				}
				$seen[$hash] = true;
				$count++;
				/* goto */
			}
			return $count;
		}

	protected function setRedstoneStrength($strength = null) {
			/* decompiled (structured CF) */
			if ((0 < $strength)) {
			} else {
			}
			$this->meta = 0;
			return null;
		}

	protected function updateState($collidingEntity = null) {
			/* decompiled (structured CF) */
			$oldStrength = $this->getStrength();
			$newStrength = $this->computeRedstoneStrength($collidingEntity);
			$wasActivated = (0 < $oldStrength);
			$isActivated = (0 < $newStrength);
			if (($oldStrength !== $newStrength)) {
				$this->setRedstoneStrength($newStrength);
				$this->activateTime = $this->getLevel()->getServer()->getTick();
				$this->getLevel()->setBlock($this, $this, true, false);
				new \pocketmine\level\sound\GenericSound($this, 1000);
				$this->getLevel()->addSound(new \pocketmine\level\sound\GenericSound($this, 1000));
				if ($isActivated) {
					$this->activate();
				} else {
					$this->deactivate();
				}
				$this->getLevel()->updateAroundRedstone($this);
				$this->getLevel()->updateAroundRedstone($this->getSide(\pocketmine\math\Vector3::SIDE_DOWN));
			} else {
				if ($wasActivated) {
					$this->activateTime = $this->getLevel()->getServer()->getTick();
				}
			}
			if ($isActivated) {
				$this->getLevel()->scheduleUpdate($this, self::RECHECK_DELAY);
			}
			return null;
		}

	public function activate($ignore = null) {
			/* decompiled (structured CF) */
			parent::activate($ignore);
			$support = $this->getSide(\pocketmine\math\Vector3::SIDE_DOWN);
			$blockAboveSupport = $support->getSide(\pocketmine\math\Vector3::SIDE_UP);
			if (!($this->equals($blockAboveSupport))) {
				$this->activateBlock($blockAboveSupport);
			}
			$this->activateBlock($this->getSide(\pocketmine\math\Vector3::SIDE_DOWN, 2));
			$this->checkTorchOn($support, [\pocketmine\math\Vector3::SIDE_UP]);
			return null;
		}

	public function deactivate($ignore = null) {
			/* decompiled (structured CF) */
			parent::deactivate($ignore);
			$support = $this->getSide(\pocketmine\math\Vector3::SIDE_DOWN);
			$blockAboveSupport = $support->getSide(\pocketmine\math\Vector3::SIDE_UP);
			if (!($this->equals($blockAboveSupport))) {
				$this->deactivateBlock($blockAboveSupport);
			}
			$this->deactivateBlock($this->getSide(\pocketmine\math\Vector3::SIDE_DOWN, 2));
			$this->checkTorchOff($support, [\pocketmine\math\Vector3::SIDE_UP]);
			return null;
		}

	public function isActivated($from = null) {
			/* decompiled (structured CF) */
			if (($this->meta == 0)) {
			} else {
			}
			return true;
		}

	public function getStrongPower($side = null) {
			/* decompiled (structured CF) */
			if (($side === \pocketmine\math\Vector3::SIDE_UP)) {
			} else {
			}
			return 0;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				$below = $this->getSide(\pocketmine\math\Vector3::SIDE_DOWN);
				if ($below instanceof \pocketmine\block\Transparent) {
					$this->getLevel()->useBreakOn($this);
					return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
				}
			}
			if (($type == \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED)) {
				if ($this->isActivated()) {
					$this->updateState();
				}
				return \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED;
			}
			return true;
		}

	public function checkActivation() {
			/* decompiled (structured CF) */
			if ($this->isActivated()) {
				$this->updateState();
			}
			return null;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$below = $this->getSide(\pocketmine\math\Vector3::SIDE_DOWN);
			if ($below instanceof \pocketmine\block\Transparent) {
				return null;
			} else {
				$this->getLevel()->setBlock($block, $this, true, false);
			}
		}

	public function onBreak($item = null) {
			/* decompiled (structured CF) */
			if ($this->isActivated()) {
				$this->meta = 0;
				$this->deactivate();
			}
			$this->canActivate = false;
			new \pocketmine\block\Air();
			$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), true);
			return null;
		}

	public function getHardness() {
			return 0.5;
		}

	public function getResistance() {
			return 2.5;
		}

}
