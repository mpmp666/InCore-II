<?php

namespace pocketmine\block;

class SoulSand extends \pocketmine\block\Solid {
	protected $id = 88;

	public function __construct() {
			// empty
		}

	public function getName() {
			return;
		}

	public function getHardness() {
			return 0.5;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_SHOVEL;
		}

	protected function recalculateBoundingBox() {
			new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), (($this->y + 1) - 0.125), ($this->z + 1));
			return new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), (($this->y + 1) - 0.125), ($this->z + 1));
		}

}
