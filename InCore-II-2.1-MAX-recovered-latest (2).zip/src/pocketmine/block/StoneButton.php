<?php

namespace pocketmine\block;

class StoneButton extends \pocketmine\block\WoodenButton {
	protected $id = 77;

	public function getName() {
			return;
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			if (!($this->isActivated())) {
				$this->meta ^= 8;
				$this->getLevel()->setBlock($this, $this, true, false);
				new \pocketmine\level\sound\ButtonClickSound($this);
				$this->getLevel()->addSound(new \pocketmine\level\sound\ButtonClickSound($this));
				$this->activate();
				$this->getLevel()->updateAroundRedstone($this);
				$this->getLevel()->scheduleUpdate($this, 20);
			}
			return true;
		}

}
