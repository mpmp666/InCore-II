<?php

namespace pocketmine\block;

class WoodenButton extends \pocketmine\block\RedstoneSource {
	protected $id = 143;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type == \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED)) {
				if ($this->isActivated()) {
					$this->meta ^= 8;
					$this->getLevel()->setBlock($this, $this, true, false);
					new \pocketmine\level\sound\ButtonClickSound($this);
					$this->getLevel()->addSound(new \pocketmine\level\sound\ButtonClickSound($this));
					$this->deactivate();
					$this->getLevel()->updateAroundRedstone($this);
				}
				return \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED;
			}
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				$side = $this->getDamage();
				if ($this->isActivated()) {
					$side ^= 8;
				}
				$faces = ['__array_ptr' => '2aaaadd5d690'];
				if ($this->getSide($faces[$side]) instanceof \pocketmine\block\Transparent) {
					$this->getLevel()->useBreakOn($this);
					return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
				}
			}
			return false;
		}

	public function deactivate($ignore = null) {
			/* decompiled (structured CF) */
			$ignore = ['__array_ptr' => '2aaaac9fc9a0'];
			parent::deactivate($ignore);
			$faces = ['__array_ptr' => '2aaaadd5d738'];
			$side = $this->meta;
			if ($this->isActivated()) {
				$side ^= 8;
			}
			$block = $this->getSide($faces[$side])->getSide(\pocketmine\math\Vector3::SIDE_UP);
			if (!($this->equals($block))) {
				$this->deactivateBlock($block);
			}
			if (($side != 1)) {
				$this->deactivateBlock($this->getSide($faces[$side], 2));
			}
			$this->checkTorchOff($this->getSide($faces[$side]), [$this->getOppositeSide($faces[$side])]);
			return null;
		}

	public function activate($ignore = null) {
			/* decompiled (structured CF) */
			$ignore = ['__array_ptr' => '2aaaac9fc9a0'];
			parent::activate($ignore);
			$faces = ['__array_ptr' => '2aaaadd5d770'];
			$side = $this->meta;
			if ($this->isActivated()) {
				$side ^= 8;
			}
			$block = $this->getSide($faces[$side])->getSide(\pocketmine\math\Vector3::SIDE_UP);
			if (!($this->equals($block))) {
				$this->activateBlock($block);
			}
			if (($side != 1)) {
				$block = $this->getSide($faces[$side], 2);
				$this->activateBlock($block);
			}
			$this->checkTorchOn($this->getSide($faces[$side]), [$this->getOppositeSide($faces[$side])]);
			return null;
		}

	public function getName() {
			return;
		}

	public function getHardness() {
			return 0.5;
		}

	public function onBreak($item = null) {
			/* decompiled (structured CF) */
			if ($this->isActivated()) {
				$this->meta ^= 8;
				$this->getLevel()->setBlock($this, $this, true, false);
				$this->deactivate();
			}
			new \pocketmine\block\Air();
			$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), true, false);
			return null;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			if (($target->isTransparent() === false)) {
				$this->meta = $face;
				$this->getLevel()->setBlock($block, $this, true, false);
				return true;
			}
			return false;
		}

	public function canBeActivated() {
			return true;
		}

	public function isActivated($from = null) {
			return (($this->meta & 8) === 8);
		}

	public function getStrongPower($side = null) {
			/* decompiled (structured CF) */
			$buttonSide = $this->meta;
			if ($this->isActivated()) {
				$buttonSide ^= 8;
			}
			if (($side === $buttonSide)) {
			} else {
			}
			return 0;
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			if (!($this->isActivated())) {
				$this->meta ^= 8;
				$this->getLevel()->setBlock($this, $this, true, false);
				new \pocketmine\level\sound\ButtonClickSound($this);
				$this->getLevel()->addSound(new \pocketmine\level\sound\ButtonClickSound($this));
				$this->activate();
				$this->getLevel()->updateAroundRedstone($this);
				$this->getLevel()->scheduleUpdate($this, 30);
			}
			return true;
		}

}
