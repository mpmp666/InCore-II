<?php

namespace pocketmine\block;

class DaylightDetectorInverted extends \pocketmine\block\DaylightDetector {
	protected $id = 178;

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\block\DaylightDetector();
			$this->getLevel()->setBlock($this, new \pocketmine\block\DaylightDetector(), true, true);
			$this->getTile()->onUpdate();
			return true;
		}

}
