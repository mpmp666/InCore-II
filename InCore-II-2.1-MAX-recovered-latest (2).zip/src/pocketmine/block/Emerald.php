<?php

namespace pocketmine\block;

class Emerald extends \pocketmine\block\Solid {
	protected $id = 133;

	public function __construct() {
			// empty
		}

	public function getHardness() {
			return 5;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function getName() {
			return;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((4 <= $item->isPickaxe())) {
				return [[\pocketmine\item\Item::EMERALD_BLOCK, 0, 1]];
			} else {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
		}

}
