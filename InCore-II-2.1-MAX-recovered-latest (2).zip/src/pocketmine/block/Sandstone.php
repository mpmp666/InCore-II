<?php

namespace pocketmine\block;

class Sandstone extends \pocketmine\block\Solid {
	public const NORMAL = 0;
	public const CHISELED = 1;
	public const SMOOTH = 2;

	protected $id = 24;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getHardness() {
			return 0.8;
		}

	public function getName() {
			return $names[($this->meta & 3)];
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((1 <= $item->isPickaxe())) {
				return [[$this->id, ($this->meta & 3), 1]];
			} else {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
		}

}
