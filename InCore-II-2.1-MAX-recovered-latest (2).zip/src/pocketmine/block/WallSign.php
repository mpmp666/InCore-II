<?php

namespace pocketmine\block;

class WallSign extends \pocketmine\block\SignPost {
	protected $id = 68;

	public function getName() {
			return;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			$faces = ['__array_ptr' => '2aaaadd5d4d0'];
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				if (isset($faces[$this->meta])) {
					if (($this->getSide($faces[$this->meta])->getId() === self::AIR)) {
						$this->getLevel()->useBreakOn($this);
					}
					return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
				}
			}
			return false;
		}

}
