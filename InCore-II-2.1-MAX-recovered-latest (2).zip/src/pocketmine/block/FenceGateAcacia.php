<?php

namespace pocketmine\block;

class FenceGateAcacia extends \pocketmine\block\FenceGate {
	protected $id = 187;

	public function getName() {
			return;
		}

}
