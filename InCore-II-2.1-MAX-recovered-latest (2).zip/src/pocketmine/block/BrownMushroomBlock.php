<?php

namespace pocketmine\block;

class BrownMushroomBlock extends \pocketmine\block\Solid {
	public const BROWN = 14;

	protected $id = 99;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function canBeActivated() {
			return true;
		}

	public function getName() {
			return;
		}

	public function getHardness() {
			return 0.2;
		}

	public function getResistance() {
			return 1;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((0 < $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_SILK_TOUCH))) {
				return [[\pocketmine\item\Item::BROWN_MUSHROOM_BLOCK, self::BROWN, 1]];
			} else {
				return [[\pocketmine\item\Item::BROWN_MUSHROOM, 0, mt_rand(0, 2)]];
			}
		}

}
