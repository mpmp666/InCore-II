<?php

namespace pocketmine\block;

class Dandelion extends \pocketmine\block\Flowable {
	protected $id = 37;

	public function __construct() {
			// empty
		}

	public function getName() {
			return 'Dandelion';
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$down = $this->getSide(0);
			if (((($down->getId() === 2) || ($down->getId() === 3)) || ($down->getId() === 60))) {
				$this->getLevel()->setBlock($block, $this, true, true);
				return true;
			}
			return false;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				if (($this->getSide(0)->isTransparent() === true)) {
					$this->getLevel()->useBreakOn($this);
					return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
				}
			}
			return false;
		}

}
