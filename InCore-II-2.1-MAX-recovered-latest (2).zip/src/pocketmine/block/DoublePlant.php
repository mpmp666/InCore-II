<?php

namespace pocketmine\block;

class DoublePlant extends \pocketmine\block\Flowable {
	protected $id = 175;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function canBeReplaced() {
			return true;
		}

	public function getName() {
			return $names[($this->meta & 7)];
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				if ($this->shouldBreak()) {
					$this->breakHalves();
					return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
				}
			}
			return false;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$down = $this->getSide(0);
			$up = $this->getSide(1);
			if (($up->getId() != self::AIR)) {
				$this->getLevel()->setBlock($block, \pocketmine\block\Block::get(0, 0));
				return false;
			}
			if ((($down->getId() === self::GRASS) || ($down->getId() === self::DIRT))) {
				$this->getLevel()->setBlock($block, $this, false);
				$this->getLevel()->setBlock($up, \pocketmine\block\Block::get($this->id, ($this->meta ^ 8)), false);
				return true;
			}
			return false;
		}

	public function onBreak($item = null) {
			$this->breakHalves();
			return null;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((($this->meta & 8) === 8)) {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
			$type = ($this->meta & 7);
			if ((($type === 2) || ($type === 3))) {
				if ((mt_rand(0, 15) === 0)) {
					return [[\pocketmine\item\Item::WHEAT_SEEDS, 0, 1]];
				}
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
			return [[\pocketmine\item\Item::DOUBLE_PLANT, $type, 1]];
		}

	private function shouldBreak() {
			/* decompiled (structured CF) */
			if ((($this->meta & 8) === 8)) {
				$down = $this->getSide(0);
				return ((!($down instanceof \pocketmine\block\DoublePlant) || ($down->getId() !== $this->id)) || (($down->meta & 8) === 8));
			}
			return ($this->getSide(0)->isTransparent() === true);
		}

	private function breakHalves() {
			/* decompiled (structured CF) */
			$up = $this->getSide(1);
			$down = $this->getSide(0);
			new \pocketmine\block\Air();
			$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), false, false);
			if ((($this->meta & 8) === 8)) {
				if ((($down->getId() === $this->id) && (($down->meta & 8) !== 8))) {
					new \pocketmine\block\Air();
					$this->getLevel()->setBlock($down, new \pocketmine\block\Air(), false, false);
				}
			} else {
				if ((($up->getId() === $this->id) && (($up->meta & 8) === 8))) {
					new \pocketmine\block\Air();
					$this->getLevel()->setBlock($up, new \pocketmine\block\Air(), false, false);
				}
			}
			return null;
		}

}
