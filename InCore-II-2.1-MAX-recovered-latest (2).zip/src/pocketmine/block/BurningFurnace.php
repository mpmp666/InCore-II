<?php

namespace pocketmine\block;

class BurningFurnace extends \pocketmine\block\Solid {
	protected $id = 62;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return;
		}

	public function canBeActivated() {
			return true;
		}

	public function getHardness() {
			return 3.5;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function getLightLevel() {
			return 13;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$faces = ['__array_ptr' => '2aaaadd5d658'];
			if ($player instanceof \pocketmine\Player) {
			} else {
			}
			$this->meta = $faces[0];
			$this->getLevel()->setBlock($block, $this, true, true);
			new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']);
			new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::FURNACE);
			new \pocketmine\nbt\tag\IntTag('x', $this->x);
			new \pocketmine\nbt\tag\IntTag('y', $this->y);
			new \pocketmine\nbt\tag\IntTag('z', $this->z);
			new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']), new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::FURNACE), new \pocketmine\nbt\tag\IntTag('x', $this->x), new \pocketmine\nbt\tag\IntTag('y', $this->y), new \pocketmine\nbt\tag\IntTag('z', $this->z)]);
			$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']), new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::FURNACE), new \pocketmine\nbt\tag\IntTag('x', $this->x), new \pocketmine\nbt\tag\IntTag('y', $this->y), new \pocketmine\nbt\tag\IntTag('z', $this->z)]);
			$nbt->Items->setTagType(\pocketmine\nbt\NBT::TAG_Compound);
			if ($item->hasCustomName()) {
				new \pocketmine\nbt\tag\StringTag('CustomName', $item->getCustomName());
				$nbt->CustomName = new \pocketmine\nbt\tag\StringTag('CustomName', $item->getCustomName());
			}
			if ($item->hasCustomBlockData()) {
				foreach ($item->getCustomBlockData() as $key => $v) {
					$nbt->prop = $v;
					/* goto */
				}
			}
			\pocketmine\tile\Tile::createTile('Furnace', $this->getLevel()->getChunk(($this->x >> 4), ($this->z >> 4)), $nbt);
			return true;
		}

	public function onBreak($item = null) {
			new \pocketmine\block\Air();
			$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), true, true);
			return true;
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			if ($player instanceof \pocketmine\Player) {
				$t = $this->getLevel()->getTile($this);
				$furnace = false;
				if ($t instanceof \pocketmine\tile\Furnace) {
					$furnace = $t;
				} else {
					new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']);
					new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::FURNACE);
					new \pocketmine\nbt\tag\IntTag('x', $this->x);
					new \pocketmine\nbt\tag\IntTag('y', $this->y);
					new \pocketmine\nbt\tag\IntTag('z', $this->z);
					new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']), new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::FURNACE), new \pocketmine\nbt\tag\IntTag('x', $this->x), new \pocketmine\nbt\tag\IntTag('y', $this->y), new \pocketmine\nbt\tag\IntTag('z', $this->z)]);
					$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']), new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::FURNACE), new \pocketmine\nbt\tag\IntTag('x', $this->x), new \pocketmine\nbt\tag\IntTag('y', $this->y), new \pocketmine\nbt\tag\IntTag('z', $this->z)]);
					$nbt->Items->setTagType(\pocketmine\nbt\NBT::TAG_Compound);
					$furnace = \pocketmine\tile\Tile::createTile('Furnace', $this->getLevel()->getChunk(($this->x >> 4), ($this->z >> 4)), $nbt);
				}
				if ((isset($furnace->namedtag->Lock) && $furnace->namedtag->Lock instanceof \pocketmine\nbt\tag\StringTag)) {
					if (($furnace->namedtag->Lock->getValue() !== $item->getCustomName())) {
						return true;
					}
				}
				if (($player->isCreative() && $player->getServer()->limitedCreative)) {
					return true;
				}
				$player->addWindow($furnace->getInventory());
			}
			return true;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			$drops = ['__array_ptr' => '2aaaac9fc9a0'];
			if ((1 <= $item->isPickaxe())) {
				$drops[] = [\pocketmine\item\Item::FURNACE, 0, 1];
			}
			return $drops;
		}

	public function hasComparatorInputOverride() {
			return true;
		}

	public function getComparatorInputOverride() {
			/* decompiled (structured CF) */
			$tile = $this->getLevel()->getTile($this);
			if ($tile instanceof \pocketmine\tile\Furnace) {
			} else {
			}
			return 0;
		}

}
