<?php

namespace pocketmine\block;

class DoubleWoodSlab extends \pocketmine\block\Solid {
	protected $id = 157;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getHardness() {
			return 2;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_AXE;
		}

	public function getName() {
			return (($this . $names[($this->meta & 7)]) . $this);
		}

	public function getDrops($item = null) {
			return [[\pocketmine\item\Item::WOOD_SLAB, ($this->meta & 7), 2]];
		}

}
