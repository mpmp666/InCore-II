<?php

namespace pocketmine\block;

abstract class WeightedPressurePlate extends \pocketmine\block\PressurePlate {
	protected $maxStrength = 15;
	protected $maxEntities = 15;

	protected function countTriggeredEntities($collidingEntity = null) {
			/* decompiled (structured CF) */
			$count = 0;
			$seen = ['__array_ptr' => '2aaaac9fc9a0'];
			if ((($collidingEntity !== null) && $collidingEntity->canTriggerWalking())) {
				$seen[spl_object_hash($collidingEntity)] = true;
				$count += $this->getEntityTriggerWeight($collidingEntity);
			}
			foreach ($this->getLevel()->getCollidingEntities($this->getBoundingBox()) as $entity) {
				if ((!($entity instanceof \pocketmine\entity\Entity) || !($entity->canTriggerWalking()))) {
					/* goto */
				}
				$hash = spl_object_hash($entity);
				if (isset($seen[$hash])) {
					/* goto */
				}
				$seen[$hash] = true;
				$count += $this->getEntityTriggerWeight($entity);
				/* goto */
			}
			return $count;
		}

	private function getEntityTriggerWeight($entity = null) {
			/* decompiled (structured CF) */
			if ($entity instanceof \pocketmine\entity\Item) {
				return max(1, $entity->getItem()->getCount());
			}
			return 1;
		}

	protected function computeRedstoneStrength($collidingEntity = null) {
			/* decompiled (structured CF) */
			$count = $this->countTriggeredEntities($collidingEntity);
			if (($count <= 0)) {
				return 0;
			}
			$strength = (ceil((($count / $this->maxEntities) * $this->maxStrength)));
			if (($this->maxStrength < $strength)) {
				$strength = $this->maxStrength;
			}
			return $strength;
		}

	protected function setRedstoneStrength($strength = null) {
			$this->meta = max(0, min($this->maxStrength, ($strength)));
			return null;
		}

	public function getStrength() {
			return max(0, min($this->maxStrength, ($this->meta & 15)));
		}

}
