<?php

namespace pocketmine\block;

class RedstoneWire extends \pocketmine\block\RedstoneSource {
	public const ON = 1;
	public const OFF = 2;
	public const PLACE = 3;
	public const DESTROY = 4;

	protected $id = 55;
	private $canProvidePower = true;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return;
		}

	public function getStrength() {
			return $this->meta;
		}

	public function isActivated($from = null) {
			return (0 < $this->meta);
		}

	public function isPowerSource() {
			return ($this->canProvidePower && (0 < $this->meta));
		}

	private static function horizontalSides() {
			return [\pocketmine\math\Vector3::SIDE_WEST, \pocketmine\math\Vector3::SIDE_EAST, \pocketmine\math\Vector3::SIDE_NORTH, \pocketmine\math\Vector3::SIDE_SOUTH];
		}

	private static function verticalSides() {
			return [\pocketmine\math\Vector3::SIDE_DOWN, \pocketmine\math\Vector3::SIDE_UP];
		}

	private static function rotateY($side = null) {
			/* decompiled (structured CF) */
			if (!(($side == \pocketmine\math\Vector3::SIDE_NORTH))) {
				if (!(($side == \pocketmine\math\Vector3::SIDE_EAST))) {
					if (!(($side == \pocketmine\math\Vector3::SIDE_SOUTH))) {
						if (!(($side == \pocketmine\math\Vector3::SIDE_WEST))) {
							/* jump */
							return \pocketmine\math\Vector3::SIDE_EAST;
						}
					}
				}
				return \pocketmine\math\Vector3::SIDE_NORTH;
			}
		}

	private static function rotateYCCW($side = null) {
			/* decompiled (structured CF) */
			if (!(($side == \pocketmine\math\Vector3::SIDE_NORTH))) {
				if (!(($side == \pocketmine\math\Vector3::SIDE_WEST))) {
					if (!(($side == \pocketmine\math\Vector3::SIDE_SOUTH))) {
						if (!(($side == \pocketmine\math\Vector3::SIDE_EAST))) {
							/* jump */
							return \pocketmine\math\Vector3::SIDE_WEST;
						}
					}
				}
				return \pocketmine\math\Vector3::SIDE_NORTH;
			}
		}

	private static function isHorizontal($side = null) {
			return in_array($side, self::horizontalSides(), true);
		}

	protected function canBePlacedOn($block = null) {
			return ((!($block instanceof \pocketmine\block\Transparent) || ($block->getId() === self::INACTIVE_REDSTONE_LAMP)) || ($block->getId() === self::ACTIVE_REDSTONE_LAMP));
		}

	private function getIndirectPower() {
			/* decompiled (structured CF) */
			$power = 0;
			foreach (\pocketmine\block\Block::BLOCK_SIDES as $face) {
				$blockPower = $this->getIndirectPowerAt($this->getSide($face), $face);
				if ((15 <= $blockPower)) {
					return 15;
				}
				if (($power < $blockPower)) {
					$power = $blockPower;
				}
				/* goto */
			}
			return $power;
		}

	private function getIndirectPowerAt($pos = null, $face = null) {
			/* decompiled (structured CF) */
			$block = $this->level->getBlock($pos);
			if (($block->getId() === self::REDSTONE_WIRE)) {
				return 0;
			}
			if ($block->isPowerSource()) {
				return $block->getWeakPower($face);
			}
			if ($block->isNormalBlock()) {
			} else {
			}
			return $block->getWeakPower($face);
		}

	private function getStrongPowerAt($pos = null, $direction = null) {
			/* decompiled (structured CF) */
			if (($direction !== null)) {
				$block = $this->level->getBlock($pos);
				if (($block->getId() === self::REDSTONE_WIRE)) {
					return 0;
				}
				return $block->getStrongPower($direction);
			}
			$power = 0;
			foreach (\pocketmine\block\Block::BLOCK_SIDES as $side) {
				$sidePower = $this->getStrongPowerAt($pos->getSide($side), $side);
				if ((15 <= $sidePower)) {
					return 15;
				}
				if (($power < $sidePower)) {
					$power = $sidePower;
				}
				/* goto */
			}
			return $power;
		}

	private function getMaxCurrentStrength($pos = null, $maxStrength = null) {
			/* decompiled (structured CF) */
			if (($this->level->getBlockIdAt(($pos->x), ($pos->y), ($pos->z)) !== self::REDSTONE_WIRE)) {
				return $maxStrength;
			}
			return max($this->level->getBlockDataAt(($pos->x), ($pos->y), ($pos->z)), $maxStrength);
		}

	private function calculateCurrentChanges($force = null) {
			/* decompiled (structured CF) */
			$meta = $this->meta;
			$maxStrength = $meta;
			$this->canProvidePower = false;
			$power = $this->getIndirectPower();
			$this->canProvidePower = true;
			if (((0 < $power) && (($maxStrength - 1) < $power))) {
				$maxStrength = $power;
			}
			$strength = 0;
			foreach (self::horizontalSides() as $face) {
				$side = $this->getSide($face);
				$strength = $this->getMaxCurrentStrength($side, $strength);
				$sideIsNormal = $this->level->getBlock($side)->isNormalBlock();
				if (($sideIsNormal && !($this->getSide(\pocketmine\math\Vector3::SIDE_UP)->isNormalBlock()))) {
					$strength = $this->getMaxCurrentStrength($side->getSide(\pocketmine\math\Vector3::SIDE_UP), $strength);
				} else {
					if (!($sideIsNormal)) {
						$strength = $this->getMaxCurrentStrength($side->getSide(\pocketmine\math\Vector3::SIDE_DOWN), $strength);
					}
				}
				/* goto */
			}
			if (($maxStrength < $strength)) {
				$maxStrength = ($strength - 1);
			} else {
				if ((0 < $maxStrength)) {
					$maxStrength--;
				} else {
					$maxStrength = 0;
				}
			}
			if ((($maxStrength - 1) < $power)) {
				$maxStrength = $power;
			} else {
				if ((($power < $maxStrength) && ($strength <= $maxStrength))) {
					$maxStrength = max($power, ($strength - 1));
				}
			}
			$maxStrength = max(0, min(15, $maxStrength));
			if (($meta !== $maxStrength)) {
				if ($this->level->checkAndHandleHighFrequencyRedstoneTransition($this, ('wire:' . $maxStrength))) {
					return null;
				}
				$this->meta = $maxStrength;
				$this->level->setBlock($this, $this, false, false);
				$this->level->updateAroundRedstone($this, null);
				foreach (\pocketmine\block\Block::BLOCK_SIDES as $face) {
					$this->level->updateAroundRedstone($this->getSide($face), \pocketmine\math\Vector3::getOppositeSide($face));
					/* goto */
				}
			} else {
				if ($force) {
					foreach (\pocketmine\block\Block::BLOCK_SIDES as $face) {
						$this->level->updateAroundRedstone($this->getSide($face), \pocketmine\math\Vector3::getOppositeSide($face));
						/* goto */
					}
				}
			}
		}

	public static function canConnectTo($block = null, $side = null) {
			/* decompiled (structured CF) */
			if (($block->getId() === self::REDSTONE_WIRE)) {
				return true;
			}
			if (\pocketmine\block\RedstoneDiode::isDiode($block)) {
				$facing = $block->getFacing();
				return ((($side === null) || ($facing === $side)) || ($side === \pocketmine\math\Vector3::getOppositeSide($facing)));
			}
			return ($block->isPowerSource() && ($side !== null));
		}

	protected static function canConnectUpwardsTo($block = null) {
			return self::canConnectTo($block, null);
		}

	private function isPowerSourceAt($side = null) {
			$sideBlock = $this->getSide($side);
			$sideBlockIsNormal = $sideBlock->isNormalBlock();
			return (((($sideBlockIsNormal && !($this->getSide(\pocketmine\math\Vector3::SIDE_UP)->isNormalBlock())) && self::canConnectUpwardsTo($sideBlock->getSide(\pocketmine\math\Vector3::SIDE_UP))) || self::canConnectTo($sideBlock, $side)) || (!($sideBlockIsNormal) && self::canConnectUpwardsTo($sideBlock->getSide(\pocketmine\math\Vector3::SIDE_DOWN))));
		}

	public function getWeakPower($side = null) {
			/* decompiled (structured CF) */
			if (!($this->canProvidePower)) {
				return 0;
			}
			$power = $this->meta;
			if (($power <= 0)) {
				return 0;
			}
			if (($side === \pocketmine\math\Vector3::SIDE_UP)) {
				return $power;
			}
			$connected = ['__array_ptr' => '2aaaac9fc9a0'];
			foreach (self::horizontalSides() as $face) {
				if ($this->isPowerSourceAt($face)) {
					$connected[$face] = true;
				}
				/* goto */
			}
			if ((self::isHorizontal($side) && (count($connected) === 0))) {
				return $power;
			}
			if (((isset($connected[$side]) && !(isset($connected[self::rotateYCCW($side)]))) && !(isset($connected[self::rotateY($side)])))) {
				return $power;
			}
			return 0;
		}

	public function getStrongPower($side = null) {
			/* decompiled (structured CF) */
			if ($this->canProvidePower) {
			} else {
			}
			return 0;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if ((($type !== \pocketmine\level\Level::BLOCK_UPDATE_NORMAL) && ($type !== \pocketmine\level\Level::BLOCK_UPDATE_REDSTONE))) {
				return false;
			}
			if ((($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL) && !($this->canBePlacedOn($this->getSide(\pocketmine\math\Vector3::SIDE_DOWN))))) {
				$this->level->useBreakOn($this);
				return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
			}
			if (($this->level->getBlockIdAt(($this->x), ($this->y), ($this->z)) !== $this->id)) {
				return false;
			}
			$this->calculateCurrentChanges(false);
			return \pocketmine\level\Level::BLOCK_UPDATE_REDSTONE;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			if (!($this->canBePlacedOn($block->getSide(\pocketmine\math\Vector3::SIDE_DOWN)))) {
				return false;
			}
			$this->level->setBlock($block, $this, true, false);
			$this->calculateCurrentChanges(true);
			foreach (self::verticalSides() as $side) {
				$this->level->updateAroundRedstone($this->getSide($side), \pocketmine\math\Vector3::getOppositeSide($side));
				/* goto */
			}
			foreach (self::verticalSides() as $side) {
				$this->updateAround($this->getSide($side), \pocketmine\math\Vector3::getOppositeSide($side));
				/* goto */
			}
			foreach (self::horizontalSides() as $side) {
				$near = $this->getSide($side);
				if ($near->isNormalBlock()) {
					$this->updateAround($near->getSide(\pocketmine\math\Vector3::SIDE_UP), \pocketmine\math\Vector3::SIDE_DOWN);
				} else {
					$this->updateAround($near->getSide(\pocketmine\math\Vector3::SIDE_DOWN), \pocketmine\math\Vector3::SIDE_UP);
				}
				/* goto */
			}
			return true;
		}

	private function updateAround($pos = null, $face = null) {
			/* decompiled (structured CF) */
			if (($this->level->getBlockIdAt(($pos->x), ($pos->y), ($pos->z)) === self::REDSTONE_WIRE)) {
				$this->level->updateAroundRedstone($pos, $face);
				foreach (\pocketmine\block\Block::BLOCK_SIDES as $side) {
					$this->level->updateAroundRedstone($pos->getSide($side), \pocketmine\math\Vector3::getOppositeSide($side));
					/* goto */
				}
			}
			return null;
		}

	public function calcSignal($strength = null, $type = null, $hasUpdated = null) {
			/* decompiled (structured CF) */
			if (($type === self::DESTROY)) {
				new \pocketmine\block\Air();
				$this->level->setBlock($this, new \pocketmine\block\Air(), true, false);
				$this->level->updateAroundRedstone($this, null);
				return $hasUpdated;
			}
			$this->calculateCurrentChanges(true);
			return $hasUpdated;
		}

	public function onBreak($item = null) {
			/* decompiled (structured CF) */
			new \pocketmine\block\Air();
			$this->level->setBlock($this, new \pocketmine\block\Air(), true, true);
			$this->level->updateAroundRedstone($this, null);
			foreach (\pocketmine\block\Block::BLOCK_SIDES as $side) {
				$this->level->updateAroundRedstone($this->getSide($side), null);
				/* goto */
			}
			return true;
		}

	public function getDrops($item = null) {
			return [[\pocketmine\item\Item::REDSTONE, 0, 1]];
		}

}
