<?php

namespace pocketmine\block;

abstract class Door extends \pocketmine\block\Transparent implements \pocketmine\block\ElectricalAppliance {
	public function canBeActivated() {
			return true;
		}

	public function isSolid() {
			return false;
		}

	public function canPassThrough() {
			return true;
		}

	private function getFullDamage() {
			/* decompiled (structured CF) */
			$damage = $this->getDamage();
			$isUp = (0 < ($damage & 8));
			if ($isUp) {
				$down = $this->getSide(\pocketmine\math\Vector3::SIDE_DOWN)->getDamage();
				$up = $damage;
			} else {
				$down = $damage;
				$up = $this->getSide(\pocketmine\math\Vector3::SIDE_UP)->getDamage();
			}
			$isRight = (0 < ($up & 1));
			if ($isUp) {
			} else {
			}
			if ($isRight) {
			} else {
			}
			return ((($down & 7) | 0) | 0);
		}

	protected function recalculateBoundingBox() {
			/* decompiled (structured CF) */
			$f = 0.1875;
			$damage = $this->getFullDamage();
			new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 2), ($this->z + 1));
			$bb = new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 2), ($this->z + 1));
			$j = ($damage & 3);
			$isOpen = (0 < ($damage & 4));
			$isRight = (0 < ($damage & 16));
			if (($j === 0)) {
				if ($isOpen) {
					if (!($isRight)) {
						$bb->setBounds($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 1), ($this->z + $f));
					} else {
						$bb->setBounds($this->x, $this->y, (($this->z + 1) - $f), ($this->x + 1), ($this->y + 1), ($this->z + 1));
					}
				} else {
					$bb->setBounds($this->x, $this->y, $this->z, ($this->x + $f), ($this->y + 1), ($this->z + 1));
				}
			} else {
				if (($j === 1)) {
					if ($isOpen) {
						if (!($isRight)) {
							$bb->setBounds((($this->x + 1) - $f), $this->y, $this->z, ($this->x + 1), ($this->y + 1), ($this->z + 1));
						} else {
							$bb->setBounds($this->x, $this->y, $this->z, ($this->x + $f), ($this->y + 1), ($this->z + 1));
						}
					} else {
						$bb->setBounds($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 1), ($this->z + $f));
					}
				} else {
					if (($j === 2)) {
						if ($isOpen) {
							if (!($isRight)) {
								$bb->setBounds($this->x, $this->y, (($this->z + 1) - $f), ($this->x + 1), ($this->y + 1), ($this->z + 1));
							} else {
								$bb->setBounds($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 1), ($this->z + $f));
							}
						} else {
							$bb->setBounds((($this->x + 1) - $f), $this->y, $this->z, ($this->x + 1), ($this->y + 1), ($this->z + 1));
						}
					} else {
						if (($j === 3)) {
							if ($isOpen) {
								if (!($isRight)) {
									$bb->setBounds($this->x, $this->y, $this->z, ($this->x + $f), ($this->y + 1), ($this->z + 1));
								} else {
									$bb->setBounds((($this->x + 1) - $f), $this->y, $this->z, ($this->x + 1), ($this->y + 1), ($this->z + 1));
								}
							} else {
								$bb->setBounds($this->x, $this->y, (($this->z + 1) - $f), ($this->x + 1), ($this->y + 1), ($this->z + 1));
							}
						}
					}
				}
			}
			return $bb;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				if (($this->getSide(0)->getId() === self::AIR)) {
					new \pocketmine\block\Air();
					$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), false);
					if ($this->getSide(1) instanceof \pocketmine\block\Door) {
						new \pocketmine\block\Air();
						$this->getLevel()->setBlock($this->getSide(1), new \pocketmine\block\Air(), false);
					}
					return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
				}
			}
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_REDSTONE)) {
				$powered = $this->getLevel()->isBlockPowered($this);
				if ((($this->getDamage() & 8) === 8)) {
				} else {
				}
				$door = $this;
				if (($door instanceof \pocketmine\block\Door && ($powered !== $door->isOpened()))) {
					$door->setOpen($powered);
				}
				return \pocketmine\level\Level::BLOCK_UPDATE_REDSTONE;
			}
			return false;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			if (($face === 1)) {
				$blockUp = $this->getSide(1);
				$blockDown = $this->getSide(0);
				if ((($blockUp->canBeReplaced() === false) || ($blockDown->isTransparent() === true))) {
					return false;
				}
				if ($player instanceof \pocketmine\Player) {
				} else {
				}
				$direction = 0;
				$face = ['__array_ptr' => '2aaaadd5d6c8'];
				$next = $this->getSide($face[(($direction + 2) % 4)]);
				$next2 = $this->getSide($face[$direction]);
				$metaUp = 8;
				if ((($next->getId() === $this->getId()) || (($next2->isTransparent() === false) && ($next->isTransparent() === true)))) {
					$metaUp |= 1;
				}
				$this->setDamage(($player->getDirection() & 3));
				$this->getLevel()->setBlock($block, $this, true, true);
				$b = \pocketmine\block\Block::get($this->getId(), $metaUp);
				$this->getLevel()->setBlock($blockUp, $b, true);
				return true;
			}
			return false;
		}

	public function onBreak($item = null) {
			/* decompiled (structured CF) */
			if ((($this->getDamage() & 8) === 8)) {
				$down = $this->getSide(0);
				if (($down->getId() === $this->getId())) {
					new \pocketmine\block\Air();
					$this->getLevel()->setBlock($down, new \pocketmine\block\Air(), true);
				}
			} else {
				$up = $this->getSide(1);
				if (($up->getId() === $this->getId())) {
					new \pocketmine\block\Air();
					$this->getLevel()->setBlock($up, new \pocketmine\block\Air(), true);
				}
			}
			new \pocketmine\block\Air();
			$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), true);
			return true;
		}

	public function isOpened() {
			return (0 < ($this->getFullDamage() & 4));
		}

	public function setOpen($open = null) {
			/* decompiled (structured CF) */
			if ((($this->getDamage() & 8) === 8)) {
			} else {
			}
			$door = $this;
			if ((!($door instanceof \pocketmine\block\Door) || ($door->getId() !== $this->getId()))) {
				return false;
			}
			$meta = $door->getDamage();
			if (((0 < ($meta & 4)) !== $open)) {
				$meta ^= 4;
				$this->getLevel()->setBlock($door, \pocketmine\block\Block::get($this->getId(), $meta), true);
				new \pocketmine\level\sound\DoorSound($door);
				$this->level->addSound(new \pocketmine\level\sound\DoorSound($door));
			}
			return true;
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			if ((($this->getDamage() & 8) === 8)) {
				$down = $this->getSide(0);
				if (($down->getId() === $this->getId())) {
					$meta = ($down->getDamage() ^ 4);
					$this->getLevel()->setBlock($down, \pocketmine\block\Block::get($this->getId(), $meta), true);
					$players = $this->getLevel()->getChunkPlayers(($this->x >> 4), ($this->z >> 4));
					if ($player instanceof \pocketmine\Player) {
					}
					new \pocketmine\level\sound\DoorSound($this);
					$this->level->addSound(new \pocketmine\level\sound\DoorSound($this));
					return true;
				}
				return false;
			} else {
				$this->meta ^= 4;
				$this->getLevel()->setBlock($this, $this, true);
				$players = $this->getLevel()->getChunkPlayers(($this->x >> 4), ($this->z >> 4));
				if ($player instanceof \pocketmine\Player) {
				}
				new \pocketmine\level\sound\DoorSound($this);
				$this->level->addSound(new \pocketmine\level\sound\DoorSound($this));
			}
			return true;
		}

}
