<?php

namespace pocketmine\block;

class InvisibleBedrock extends \pocketmine\block\Transparent {
	protected $id = 95;

	public function __construct() {
			// empty
		}

	public function getName() {
			return;
		}

	public function getHardness() {
			return -1;
		}

	public function getResistance() {
			return 18000000;
		}

	public function isBreakable($item = null) {
			return false;
		}

}
