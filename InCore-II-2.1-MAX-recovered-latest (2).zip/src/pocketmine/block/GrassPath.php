<?php

namespace pocketmine\block;

class GrassPath extends \pocketmine\block\Transparent {
	protected $id = 198;

	public function __construct() {
			// empty
		}

	public function getName() {
			return;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_SHOVEL;
		}

	protected function recalculateBoundingBox() {
			new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 0.9375), ($this->z + 1));
			return new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 0.9375), ($this->z + 1));
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type == \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				$block = $this->getSide(self::SIDE_UP);
				if (($block->getId() != self::AIR)) {
					new \pocketmine\block\Dirt();
					$this->getLevel()->setBlock($this, new \pocketmine\block\Dirt(), true);
				}
				return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
			}
			return false;
		}

	public function getHardness() {
			return 0.6;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((0 < $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_SILK_TOUCH))) {
				return [[\pocketmine\item\Item::GRASS_PATH, 0, 1]];
			} else {
				return [[\pocketmine\item\Item::DIRT, 0, 1]];
			}
		}

}
