<?php

namespace pocketmine\block;

class Air extends \pocketmine\block\Transparent {
	protected $id = 0;
	protected $meta = 0;

	public function __construct() {
			// empty
		}

	public function getName() {
			return 'Air';
		}

	public function canPassThrough() {
			return true;
		}

	public function isBreakable($item = null) {
			return false;
		}

	public function canBeFlowedInto() {
			return true;
		}

	public function canBeReplaced() {
			return true;
		}

	public function canBePlaced() {
			return false;
		}

	public function isSolid() {
			return false;
		}

	public function getBoundingBox() {
			return null;
		}

	public function getHardness() {
			return 0;
		}

	public function getResistance() {
			return 0;
		}

}
