<?php

namespace pocketmine\block;

class Flower extends \pocketmine\block\Flowable {
	public const TYPE_POPPY = 0;
	public const TYPE_BLUE_ORCHID = 1;
	public const TYPE_ALLIUM = 2;
	public const TYPE_AZURE_BLUET = 3;
	public const TYPE_RED_TULIP = 4;
	public const TYPE_ORANGE_TULIP = 5;
	public const TYPE_WHITE_TULIP = 6;
	public const TYPE_PINK_TULIP = 7;
	public const TYPE_OXEYE_DAISY = 8;

	protected $id = 38;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return $names[$this->meta];
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$down = $this->getSide(0);
			if (((($down->getId() === \pocketmine\block\Block::GRASS) || ($down->getId() === \pocketmine\block\Block::DIRT)) || ($down->getId() === \pocketmine\block\Block::FARMLAND))) {
				$this->getLevel()->setBlock($block, $this, true);
				return true;
			}
			return false;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				if ($this->getSide(\pocketmine\math\Vector3::SIDE_DOWN)->isTransparent()) {
					$this->getLevel()->useBreakOn($this);
					return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
				}
			}
			return false;
		}

}
