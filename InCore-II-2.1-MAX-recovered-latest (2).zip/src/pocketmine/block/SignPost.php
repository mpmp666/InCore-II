<?php

namespace pocketmine\block;

class SignPost extends \pocketmine\block\Transparent {
	protected $id = 63;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getHardness() {
			return 1;
		}

	public function isSolid() {
			return false;
		}

	public function getName() {
			return;
		}

	public function getBoundingBox() {
			return null;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			if (($face !== 0)) {
				$faces = ['__array_ptr' => '2aaaadd5d700'];
				if (!(isset($faces[$face]))) {
					$this->meta = (floor((((($player->yaw + 180) * 16) / 360) + 0.5)) & 15);
					$this->getLevel()->setBlock($block, \pocketmine\block\Block::get(\pocketmine\item\Item::SIGN_POST, $this->meta), true);
					return true;
				} else {
					$this->meta = $faces[$face];
					$this->getLevel()->setBlock($block, \pocketmine\block\Block::get(\pocketmine\item\Item::WALL_SIGN, $this->meta), true);
					return true;
				}
			}
			return false;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				if (($this->getSide(\pocketmine\math\Vector3::SIDE_DOWN)->getId() === \pocketmine\block\Block::AIR)) {
					$this->getLevel()->useBreakOn($this);
					return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
				}
			}
			return false;
		}

	public function getDrops($item = null) {
			return [[\pocketmine\item\Item::SIGN, 0, 1]];
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_AXE;
		}

}
