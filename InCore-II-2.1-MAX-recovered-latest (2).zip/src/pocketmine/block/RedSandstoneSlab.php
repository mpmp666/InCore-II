<?php

namespace pocketmine\block;

class RedSandstoneSlab extends \pocketmine\block\Slab {
	protected $id = 182;

	public function getName() {
			return;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			if (($face === 0)) {
				if ((($target->getId() === self::RED_SANDSTONE_SLAB) && (($target->getDamage() & 8) === 8))) {
					$this->getLevel()->setBlock($target, \pocketmine\block\Block::get(\pocketmine\item\Item::DOUBLE_RED_SANDSTONE_SLAB, $this->meta), true);
					return true;
				} else {
					if (($block->getId() === self::RED_SANDSTONE_SLAB)) {
						$this->getLevel()->setBlock($block, \pocketmine\block\Block::get(\pocketmine\item\Item::DOUBLE_RED_SANDSTONE_SLAB, $this->meta), true);
						return true;
					} else {
						$this->meta |= 8;
					}
				}
			} else {
				if (($face === 1)) {
					if ((($target->getId() === self::RED_SANDSTONE_SLAB) && (($target->getDamage() & 8) === 0))) {
						$this->getLevel()->setBlock($target, \pocketmine\block\Block::get(\pocketmine\item\Item::DOUBLE_RED_SANDSTONE_SLAB, $this->meta), true);
						return true;
					} else {
						if (($block->getId() === self::RED_SANDSTONE_SLAB)) {
							$this->getLevel()->setBlock($block, \pocketmine\block\Block::get(\pocketmine\item\Item::DOUBLE_RED_SANDSTONE_SLAB, $this->meta), true);
							return true;
						}
					}
				} else {
					if (($block->getId() === self::RED_SANDSTONE_SLAB)) {
						$this->getLevel()->setBlock($block, \pocketmine\block\Block::get(\pocketmine\item\Item::DOUBLE_RED_SANDSTONE_SLAB, $this->meta), true);
					} else {
						if ((0.5 < $fy)) {
							$this->meta |= 8;
						}
					}
				}
			}
			if ((($block->getId() === self::RED_SANDSTONE_SLAB) && (($target->getDamage() & 7) !== ($this->meta & 7)))) {
				return false;
			}
			$this->getLevel()->setBlock($block, $this, true, true);
			return true;
		}

}
