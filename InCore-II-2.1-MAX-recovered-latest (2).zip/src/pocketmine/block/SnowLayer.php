<?php

namespace pocketmine\block;

class SnowLayer extends \pocketmine\block\Flowable {
	protected $id = 78;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return;
		}

	public function canBeReplaced() {
			return true;
		}

	public function getHardness() {
			return 0.1;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_SHOVEL;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$down = $this->getSide(0);
			if ($down->isSolid()) {
				$this->getLevel()->setBlock($block, $this, true);
				return true;
			}
			return false;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				if (($this->getSide(0)->getId() === self::AIR)) {
					new \pocketmine\block\Air();
					$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), true);
					return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
				}
			}
			return false;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if (($item->isShovel() !== false)) {
				return [[\pocketmine\item\Item::SNOWBALL, 0, 1]];
			}
			return ['__array_ptr' => '2aaaac9fc9a0'];
		}

}
