<?php

namespace pocketmine\block;

class CobblestoneStairs extends \pocketmine\block\Stair {
	protected $id = 67;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getHardness() {
			return 2;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function getName() {
			return;
		}

}
