<?php

namespace pocketmine\block;

class SlimeBlock extends \pocketmine\block\Solid {
	protected $id = 165;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function hasEntityCollision() {
			return true;
		}

	public function getHardness() {
			return 0;
		}

	public function getResistance() {
			return 0;
		}

	public function canStickBlocks() {
			return true;
		}

	public function getName() {
			return;
		}

}
