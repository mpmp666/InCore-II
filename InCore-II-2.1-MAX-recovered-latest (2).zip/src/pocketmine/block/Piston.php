<?php

namespace pocketmine\block;

class Piston extends \pocketmine\block\PistonBase {
	protected $id = 33;

	public function getName() {
			return 'Piston';
		}

	protected function createHead($face = null) {
			/* decompiled (structured CF) */
			new \pocketmine\block\PistonHead();
			$head = new \pocketmine\block\PistonHead();
			$head->setFacing($face);
			return $head;
		}

}
