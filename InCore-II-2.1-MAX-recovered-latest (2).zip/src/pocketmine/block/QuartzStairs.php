<?php

namespace pocketmine\block;

class QuartzStairs extends \pocketmine\block\Stair {
	protected $id = 156;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getHardness() {
			return 0.8;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function getName() {
			return;
		}

}
