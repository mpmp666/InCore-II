<?php

namespace pocketmine\block;

class Grass extends \pocketmine\block\Solid {
	protected $id = 2;

	public function __construct() {
			// empty
		}

	public function canBeActivated() {
			return true;
		}

	public function getName() {
			return 'Grass';
		}

	public function getHardness() {
			return 0.6;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_SHOVEL;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((0 < $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_SILK_TOUCH))) {
				return [[\pocketmine\item\Item::GRASS, 0, 1]];
			} else {
				return [[\pocketmine\item\Item::DIRT, 0, 1]];
			}
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_RANDOM)) {
				new \pocketmine\math\Vector3($this->x, $this->y, $this->z);
				$block = $this->getLevel()->getBlock(new \pocketmine\math\Vector3($this->x, $this->y, $this->z));
				if (($block->getSide(1)->getLightLevel() < 4)) {
					new \pocketmine\block\Dirt();
					new \pocketmine\event\block\BlockSpreadEvent($block, $this, new \pocketmine\block\Dirt());
					$ev = new \pocketmine\event\block\BlockSpreadEvent($block, $this, new \pocketmine\block\Dirt());
					\pocketmine\Server::getInstance()->getPluginManager()->callEvent($ev);
				} else {
					if ((9 <= $block->getSide(1)->getLightLevel())) {
						$l = 0;
						while (($l < 4)) {
							$x = mt_rand(($this->x - 1), ($this->x + 1));
							$y = mt_rand(($this->y - 2), ($this->y + 2));
							$z = mt_rand(($this->z - 1), ($this->z + 1));
							new \pocketmine\math\Vector3($x, $y, $z);
							$block = $this->getLevel()->getBlock(new \pocketmine\math\Vector3($x, $y, $z));
							if ((((($block->getId() === \pocketmine\block\Block::DIRT) && ($block->getDamage() === 15)) && (4 <= $block->getSide(1)->getLightLevel())) && ($block->z <= 2))) {
								new \pocketmine\block\Grass();
								new \pocketmine\event\block\BlockSpreadEvent($block, $this, new \pocketmine\block\Grass());
								$ev = new \pocketmine\event\block\BlockSpreadEvent($block, $this, new \pocketmine\block\Grass());
								\pocketmine\Server::getInstance()->getPluginManager()->callEvent($ev);
								if (!($ev->isCancelled())) {
									$this->getLevel()->setBlock($block, $ev->getNewState());
								}
							}
							$l++;
						}
					}
				}
			}
			return null;
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			if ((($item->getId() === \pocketmine\item\Item::DYE) && ($item->getDamage() === 15))) {
				new \pocketmine\utils\Random(mt_rand());
				\pocketmine\level\generator\object\TallGrass::growGrass($this->getLevel(), $this, new \pocketmine\utils\Random(mt_rand()), 8, 2);
				return true;
			} else {
				if ($item->isHoe()) {
					$item->useOn($this, 2);
					new \pocketmine\block\Farmland();
					$this->getLevel()->setBlock($this, new \pocketmine\block\Farmland());
					return true;
				} else {
					if (($item->isShovel() && ($this->getSide(1)->getId() === \pocketmine\block\Block::AIR))) {
						$item->useOn($this, 2);
						new \pocketmine\block\GrassPath();
						$this->getLevel()->setBlock($this, new \pocketmine\block\GrassPath());
						return true;
					}
				}
			}
			return false;
		}

}
