<?php

namespace pocketmine\block;

class ItemFrame extends \pocketmine\block\Transparent {
	protected $id = 199;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return;
		}

	public function canBeActivated() {
			return true;
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			$tile = $this->getLevel()->getTile($this);
			if (!($tile instanceof \pocketmine\tile\ItemFrame)) {
				new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::ITEM_FRAME);
				new \pocketmine\nbt\tag\IntTag('x', $this->x);
				new \pocketmine\nbt\tag\IntTag('y', $this->y);
				new \pocketmine\nbt\tag\IntTag('z', $this->z);
				new \pocketmine\nbt\tag\ByteTag('ItemRotation', 0);
				new \pocketmine\nbt\tag\FloatTag('ItemDropChance', 1);
				new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::ITEM_FRAME), new \pocketmine\nbt\tag\IntTag('x', $this->x), new \pocketmine\nbt\tag\IntTag('y', $this->y), new \pocketmine\nbt\tag\IntTag('z', $this->z), new \pocketmine\nbt\tag\ByteTag('ItemRotation', 0), new \pocketmine\nbt\tag\FloatTag('ItemDropChance', 1)]);
				$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::ITEM_FRAME), new \pocketmine\nbt\tag\IntTag('x', $this->x), new \pocketmine\nbt\tag\IntTag('y', $this->y), new \pocketmine\nbt\tag\IntTag('z', $this->z), new \pocketmine\nbt\tag\ByteTag('ItemRotation', 0), new \pocketmine\nbt\tag\FloatTag('ItemDropChance', 1)]);
				\pocketmine\tile\Tile::createTile(\pocketmine\tile\Tile::ITEM_FRAME, $this->getLevel()->getChunk(($this->x >> 4), ($this->z >> 4)), $nbt);
			}
			if (($tile->getItem()->getId() === 0)) {
				$item2 = \pocketmine\item\Item::get($item->getId(), $item->getDamage(), 1);
				if ($item->hasCompoundTag()) {
					$item2->setCompoundTag($item->getCompoundTag());
				}
				$tile->setItem($item2);
				if ($player instanceof \pocketmine\Player) {
					if ($player->isSurvival()) {
						$count = $item->getCount();
						$count--;
						if (($count <= 0)) {
							$player->getInventory()->setItemInHand(\pocketmine\item\Item::get(\pocketmine\item\Item::AIR));
							return true;
						}
						$item->setCount($count);
						$player->getInventory()->setItemInHand($item);
					}
				}
				new \pocketmine\level\sound\ItemFrameAddItemSound($this);
				$player->getLevel()->addSound(new \pocketmine\level\sound\ItemFrameAddItemSound($this), $player->getLevel()->getPlayers());
			} else {
				$itemRot = $tile->getItemRotation();
				if (($itemRot === 7)) {
					$itemRot = 0;
				} else {
					$itemRot++;
				}
				$tile->setItemRotation($itemRot);
				new \pocketmine\level\sound\ItemFrameRotateItemSound($this);
				$player->getLevel()->addSound(new \pocketmine\level\sound\ItemFrameRotateItemSound($this), $player->getLevel()->getPlayers());
			}
			return true;
		}

	public function onBreak($item = null) {
			new \pocketmine\block\Air();
			$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), true, false);
			return null;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if (($this->getLevel() == null)) {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
			$tile = $this->getLevel()->getTile($this);
			if (!($tile instanceof \pocketmine\tile\ItemFrame)) {
				return [[\pocketmine\item\Item::ITEM_FRAME, 0, 1]];
			}
			$chance = mt_rand(0, 100);
			if (($chance <= ($tile->getItemDropChance() * 100))) {
				return [[\pocketmine\item\Item::ITEM_FRAME, 0, 1], [$tile->getItem()->getId(), $tile->getItem()->getDamage(), 1]];
			}
			return [[\pocketmine\item\Item::ITEM_FRAME, 0, 1]];
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			if (((($target->isTransparent() === false) && (1 < $face)) && ($block->isSolid() === false))) {
				$faces = ['__array_ptr' => '2aaaadd5d7e0'];
				$this->meta = $faces[$face];
				$this->getLevel()->setBlock($block, $this, true, true);
				new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::ITEM_FRAME);
				new \pocketmine\nbt\tag\IntTag('x', $block->x);
				new \pocketmine\nbt\tag\IntTag('y', $block->y);
				new \pocketmine\nbt\tag\IntTag('z', $block->z);
				new \pocketmine\nbt\tag\ByteTag('ItemRotation', 0);
				new \pocketmine\nbt\tag\FloatTag('ItemDropChance', 1);
				new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::ITEM_FRAME), new \pocketmine\nbt\tag\IntTag('x', $block->x), new \pocketmine\nbt\tag\IntTag('y', $block->y), new \pocketmine\nbt\tag\IntTag('z', $block->z), new \pocketmine\nbt\tag\ByteTag('ItemRotation', 0), new \pocketmine\nbt\tag\FloatTag('ItemDropChance', 1)]);
				$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::ITEM_FRAME), new \pocketmine\nbt\tag\IntTag('x', $block->x), new \pocketmine\nbt\tag\IntTag('y', $block->y), new \pocketmine\nbt\tag\IntTag('z', $block->z), new \pocketmine\nbt\tag\ByteTag('ItemRotation', 0), new \pocketmine\nbt\tag\FloatTag('ItemDropChance', 1)]);
				if ($item->hasCustomBlockData()) {
					foreach ($item->getCustomBlockData() as $key => $v) {
						$nbt->prop = $v;
						/* goto */
					}
				}
				\pocketmine\tile\Tile::createTile(\pocketmine\tile\Tile::ITEM_FRAME, $this->getLevel()->getChunk(($this->x >> 4), ($this->z >> 4)), $nbt);
				return true;
			}
			return false;
		}

}
