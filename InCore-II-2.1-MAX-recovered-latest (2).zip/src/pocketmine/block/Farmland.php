<?php

namespace pocketmine\block;

class Farmland extends \pocketmine\block\Solid {
	protected $id = 60;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return 'Farmland';
		}

	public function getHardness() {
			return 0.6;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_SHOVEL;
		}

	protected function recalculateBoundingBox() {
			new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 0.9375), ($this->z + 1));
			return new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 0.9375), ($this->z + 1));
		}

	public function getDrops($item = null) {
			return [[\pocketmine\item\Item::DIRT, 0, 1]];
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if ((($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL) && $this->getSide(\pocketmine\math\Vector3::SIDE_UP)->isSolid())) {
				$this->turnIntoDirt();
				return $type;
			} else {
				if (($type === \pocketmine\level\Level::BLOCK_UPDATE_RANDOM)) {
					if (!($this->canHydrate())) {
						if ((0 < $this->meta)) {
							$this->level->setBlock($this, $this, false, false);
						} else {
							$this->turnIntoDirt(false, true);
						}
						return $type;
					} else {
						if (($this->meta < 7)) {
							$this->meta = 7;
							$this->level->setBlock($this, $this, false, false);
							return $type;
						}
					}
				}
			}
			return false;
		}

	public function turnIntoDirt($update = null, $notify = null) {
			/* decompiled (structured CF) */
			$up = $this->getSide(\pocketmine\math\Vector3::SIDE_UP);
			if ($up instanceof \pocketmine\block\Crops) {
				$this->level->useBreakOn($up);
			}
			$this->level->setBlock($this, \pocketmine\block\Block::get(\pocketmine\block\Block::DIRT), $update, $notify);
			return null;
		}

	protected function canHydrate() {
			/* decompiled (structured CF) */
			if (($this->level->getWeather()->getWeather() == \pocketmine\level\weather\Weather::RAINY)) {
				return true;
			}
			$start = $this->add(-4, 0, -4);
			$end = $this->add(4, 1, 4);
			$y = $start->y;
			while (($y <= $end->y)) {
				$z = $start->z;
				while (($z <= $end->z)) {
					$x = $start->x;
					while (($x <= $end->x)) {
						$id = $this->level->getBlockIdAt($x, $y, $z);
						if ((($id === \pocketmine\block\Block::STILL_WATER) || ($id === \pocketmine\block\Block::FLOWING_WATER))) {
							return true;
						}
						$x++;
					}
					$z++;
				}
				$y++;
			}
			return false;
		}

}
