<?php

namespace pocketmine\block;

class Carpet extends \pocketmine\block\Flowable {
	protected $id = 171;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getHardness() {
			return 0.1;
		}

	public function isSolid() {
			return false;
		}

	public function getName() {
			return $names[($this->meta & 15)];
		}

	public function getBoundingBox() {
			/* decompiled (structured CF) */
			if (($this->boundingBox === null)) {
				$this->boundingBox = $this->recalculateBoundingBox();
			}
			return $this->boundingBox;
		}

	protected function recalculateBoundingBox() {
			new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 0.0625), ($this->z + 1));
			return new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 0.0625), ($this->z + 1));
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$down = $this->getSide(0);
			if (($down->getId() !== self::AIR)) {
				$this->getLevel()->setBlock($block, $this, true, true);
				return true;
			}
			return false;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				if (($this->getSide(0)->getId() === self::AIR)) {
					$this->getLevel()->useBreakOn($this);
					return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
				}
			}
			return false;
		}

}
