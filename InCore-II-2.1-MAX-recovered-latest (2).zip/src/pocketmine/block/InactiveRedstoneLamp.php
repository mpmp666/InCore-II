<?php

namespace pocketmine\block;

class InactiveRedstoneLamp extends \pocketmine\block\ActiveRedstoneLamp {
	protected $id = 123;

	public function getLightLevel() {
			return 0;
		}

	public function getName() {
			return;
		}

	public function isLightedByAround() {
			return false;
		}

	public function turnOn() {
			new \pocketmine\block\ActiveRedstoneLamp();
			$this->getLevel()->setBlock($this, new \pocketmine\block\ActiveRedstoneLamp(), true, false);
			return true;
		}

	public function turnOff() {
			return true;
		}

}
