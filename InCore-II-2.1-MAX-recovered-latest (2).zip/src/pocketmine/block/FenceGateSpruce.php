<?php

namespace pocketmine\block;

class FenceGateSpruce extends \pocketmine\block\FenceGate {
	protected $id = 183;

	public function getName() {
			return;
		}

}
