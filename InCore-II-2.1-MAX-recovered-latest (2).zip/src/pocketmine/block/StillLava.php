<?php

namespace pocketmine\block;

class StillLava extends \pocketmine\block\Lava {
	protected $id = 11;

	public function onUpdate($type = null) {
			return parent::onUpdate($type);
		}

	public function getName() {
			return;
		}

}
