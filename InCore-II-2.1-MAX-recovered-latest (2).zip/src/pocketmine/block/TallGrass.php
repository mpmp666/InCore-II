<?php

namespace pocketmine\block;

class TallGrass extends \pocketmine\block\Flowable {
	protected $id = 31;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function canBeReplaced() {
			return true;
		}

	public function getName() {
			return $names[($this->meta & 3)];
		}

	public function getBurnChance() {
			return 60;
		}

	public function getBurnAbility() {
			return 100;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$down = $this->getSide(0);
			if (($down->getId() === self::GRASS)) {
				$this->getLevel()->setBlock($block, $this, true);
				return true;
			}
			return false;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				if (($this->getSide(0)->isTransparent() === true)) {
					new \pocketmine\block\Air();
					$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), false, false);
					return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
				}
			}
			return false;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_SHEARS;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((mt_rand(0, 15) === 0)) {
				return [[\pocketmine\item\Item::WHEAT_SEEDS, 0, 1]];
			}
			return ['__array_ptr' => '2aaaac9fc9a0'];
		}

}
