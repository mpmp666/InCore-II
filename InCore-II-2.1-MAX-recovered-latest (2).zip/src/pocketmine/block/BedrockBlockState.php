<?php

namespace pocketmine\block;

final class BedrockBlockState {
	public const CURRENT_VERSION = 18100737;

	private function __construct() {
			// empty
		}

	public static function createCompound($name = null, $id = null, $meta = null) {
			/* decompiled (structured CF) */
			$state = self::getState(($id), ($meta));
			new \pocketmine\nbt\tag\StringTag('name', $state['name']);
			new \pocketmine\nbt\tag\IntTag('version', self::CURRENT_VERSION);
			new \pocketmine\nbt\tag\CompoundTag($name, [new \pocketmine\nbt\tag\StringTag('name', $state['name']), self::createStatesCompound($state['states']), new \pocketmine\nbt\tag\IntTag('version', self::CURRENT_VERSION)]);
			return new \pocketmine\nbt\tag\CompoundTag($name, [new \pocketmine\nbt\tag\StringTag('name', $state['name']), self::createStatesCompound($state['states']), new \pocketmine\nbt\tag\IntTag('version', self::CURRENT_VERSION)]);
		}

	private static function createStatesCompound($states = null) {
			/* decompiled (structured CF) */
			$tags = ['__array_ptr' => '2aaaac9fc9a0'];
			foreach ($states as $name => $value) {
				if (is_bool($value)) {
					if ($value) {
					} else {
					}
					new \pocketmine\nbt\tag\ByteTag($name, 0);
					$tags[] = new \pocketmine\nbt\tag\ByteTag($name, 0);
				} else {
					if (is_int($value)) {
						new \pocketmine\nbt\tag\IntTag($name, $value);
						$tags[] = new \pocketmine\nbt\tag\IntTag($name, $value);
					} else {
						new \pocketmine\nbt\tag\StringTag($name, ($value));
						$tags[] = new \pocketmine\nbt\tag\StringTag($name, ($value));
					}
				}
				/* goto */
			}
			new \pocketmine\nbt\tag\CompoundTag('states', $tags);
			return new \pocketmine\nbt\tag\CompoundTag('states', $tags);
		}

	private static function getState($id = null, $meta = null) {
			/* decompiled (structured CF) */
			$meta &= 15;
			if (!(($id == \pocketmine\block\Block::WATER))) {
				if (!(($id == \pocketmine\block\Block::STILL_WATER))) {
					if (!(($id == \pocketmine\block\Block::LAVA))) {
						if (!(($id == \pocketmine\block\Block::STILL_LAVA))) {
							if (!(($id == \pocketmine\block\Block::STICKY_PISTON))) {
								if (!(($id == \pocketmine\block\Block::PISTON))) {
									if (!(($id == \pocketmine\block\Block::PISTON_HEAD))) {
										if (!(($id == \pocketmine\block\Block::WOOL))) {
											if (!(($id == \pocketmine\block\Block::CHEST))) {
												if (!(($id == \pocketmine\block\Block::FURNACE))) {
													if (!(($id == \pocketmine\block\Block::BURNING_FURNACE))) {
														if (!(($id == \pocketmine\block\Block::STAINED_CLAY))) {
															if (!(($id == \pocketmine\block\Block::HAY_BALE))) {
																if (!(($id == \pocketmine\block\Block::OBSERVER))) {
																	/* jump */
																	return ['minecraft:flowing_water', [min($meta, 7)]];
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
				return ['minecraft:observer', [self::blockFaceFromFacing(($meta & 7)), (($meta & 8) !== 0)]];
				if (isset($states[$id])) {
					$state = $states[$id];
					if (is_string($state)) {
						return [$state, ['__array_ptr' => '2aaaac9fc9a0']];
					}
					if ((isset($state[0]) && is_string($state[0]))) {
						if (isset($state[1])) {
						} else {
						}
						return [$state[0], ['__array_ptr' => '2aaaac9fc9a0']];
					}
					if (isset($state[$meta])) {
					} else {
					}
					$metaState = $state[0];
					if (is_string($metaState)) {
						return [$metaState, ['__array_ptr' => '2aaaac9fc9a0']];
					}
					if (isset($metaState[1])) {
					} else {
					}
					return [$metaState[0], ['__array_ptr' => '2aaaac9fc9a0']];
				}
				return ['__array_ptr' => '2aaaadd5d738'];
			}
		}

	private static function cardinalFromFacing($facing = null) {
			/* decompiled (structured CF) */
			switch (($facing)) {
				case 2:
				return 'north';
				case 3:
				return 'south';
				case 4:
				return 'west';
				case 5:
				return 'east';
			}
		}

	private static function blockFaceFromFacing($facing = null) {
			/* decompiled (structured CF) */
			if (isset($faces[$facing])) {
			} else {
			}
			return 'north';
		}

	private static function axisFromDirection($direction = null) {
			/* decompiled (structured CF) */
			if (isset($axes[$direction])) {
			} else {
			}
			return 'y';
		}

	private static function colorName($meta = null) {
			return $colors[($meta & 15)];
		}

}
