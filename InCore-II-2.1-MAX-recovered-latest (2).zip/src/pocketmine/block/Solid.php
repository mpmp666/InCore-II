<?php

namespace pocketmine\block;

abstract class Solid extends \pocketmine\block\Block {
	public function isSolid() {
			return true;
		}

}
