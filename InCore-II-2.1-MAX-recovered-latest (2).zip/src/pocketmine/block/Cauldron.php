<?php

namespace pocketmine\block;

class Cauldron extends \pocketmine\block\Solid {
	protected $id = 118;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getHardness() {
			return 2;
		}

	public function getName() {
			return 'Cauldron';
		}

	public function canBeActivated() {
			return true;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::CAULDRON);
			new \pocketmine\nbt\tag\IntTag('x', $block->x);
			new \pocketmine\nbt\tag\IntTag('y', $block->y);
			new \pocketmine\nbt\tag\IntTag('z', $block->z);
			new \pocketmine\nbt\tag\ShortTag('PotionId', 65535);
			new \pocketmine\nbt\tag\ByteTag('SplashPotion', 0);
			new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']);
			new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::CAULDRON), new \pocketmine\nbt\tag\IntTag('x', $block->x), new \pocketmine\nbt\tag\IntTag('y', $block->y), new \pocketmine\nbt\tag\IntTag('z', $block->z), new \pocketmine\nbt\tag\ShortTag('PotionId', 65535), new \pocketmine\nbt\tag\ByteTag('SplashPotion', 0), new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0'])]);
			$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::CAULDRON), new \pocketmine\nbt\tag\IntTag('x', $block->x), new \pocketmine\nbt\tag\IntTag('y', $block->y), new \pocketmine\nbt\tag\IntTag('z', $block->z), new \pocketmine\nbt\tag\ShortTag('PotionId', 65535), new \pocketmine\nbt\tag\ByteTag('SplashPotion', 0), new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0'])]);
			if ($item->hasCustomBlockData()) {
				foreach ($item->getCustomBlockData() as $key => $v) {
					$nbt->prop = $v;
					/* goto */
				}
			}
			$chunk = $this->getLevel()->getChunk(($this->x >> 4), ($this->z >> 4));
			$tile = \pocketmine\tile\Tile::createTile('Cauldron', $chunk, $nbt);
			$this->getLevel()->setBlock($block, $this, true, true);
			return true;
		}

	public function onBreak($item = null) {
			new \pocketmine\block\Air();
			$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), true);
			return true;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((1 <= $item->isPickaxe())) {
				return [[\pocketmine\item\Item::CAULDRON, 0, 1]];
			}
			return ['__array_ptr' => '2aaaac9fc9a0'];
		}

	public function update() {
			$this->getLevel()->setBlock($this, \pocketmine\block\Block::get($this->id, ($this->meta + 1)), true);
			$this->getLevel()->setBlock($this, $this, true);
			return null;
		}

	public function isEmpty() {
			return ($this->meta === 0);
		}

	public function isFull() {
			return ($this->meta === 6);
		}

	protected function sendCauldronEvent($eventId = null, $data = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\LevelEventPacket();
			$pk = new \pocketmine\network\protocol\LevelEventPacket();
			$pk->evid = $eventId;
			$pk->x = ($this->x + 0.5);
			$pk->y = ($this->y + 0.5);
			$pk->z = ($this->z + 0.5);
			$pk->data = ($data);
			$this->getLevel()->addChunkPacket(($this->x >> 4), ($this->z >> 4), $pk);
			return null;
		}

	protected function refreshCauldronBlock() {
			$level = $this->getLevel();
			$level->sendBlocks($level->getChunkPlayers(($this->x >> 4), ($this->z >> 4)), [$this], \pocketmine\network\protocol\UpdateBlockPacket::FLAG_ALL_PRIORITY);
			return null;
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			$tile = $this->getLevel()->getTile($this);
			if (!($tile instanceof \pocketmine\tile\Cauldron)) {
				return false;
			}
			switch ($item->getId()) {
				case \pocketmine\item\Item::BUCKET:
				if (($item->getDamage() === 0)) {
					if (((!($this->isFull()) || $tile->isCustomColor()) || $tile->hasPotion())) {
					} else {
						$bucket = clone $item;
						$bucket->setDamage(8);
						new \pocketmine\event\player\PlayerBucketFillEvent($player, $this, 0, $item, $bucket);
						$ev = new \pocketmine\event\player\PlayerBucketFillEvent($player, $this, 0, $item, $bucket);
						\pocketmine\Server::getInstance()->getPluginManager()->callEvent($ev);
						if (!($ev->isCancelled())) {
							if ($player->isSurvival()) {
								$player->getInventory()->setItemInHand($ev->getItem());
							}
							$this->meta = 0;
							$this->getLevel()->setBlock($this, $this, true);
							$tile->clearCustomColor();
							new \pocketmine\level\sound\SplashSound($this->add(0.5, 1, 0.5));
							$this->getLevel()->addSound(new \pocketmine\level\sound\SplashSound($this->add(0.5, 1, 0.5)));
						}
						/* jump */
						if (($item->getDamage() === 8)) {
							if ((($this->isFull() && !($tile->isCustomColor())) && !($tile->hasPotion()))) {
							} else {
								$bucket = clone $item;
								$bucket->setDamage(0);
								new \pocketmine\event\player\PlayerBucketEmptyEvent($player, $this, 0, $item, $bucket);
								$ev = new \pocketmine\event\player\PlayerBucketEmptyEvent($player, $this, 0, $item, $bucket);
								\pocketmine\Server::getInstance()->getPluginManager()->callEvent($ev);
								if (!($ev->isCancelled())) {
									if ($player->isSurvival()) {
										$player->getInventory()->setItemInHand($ev->getItem());
									}
									if ($tile->hasPotion()) {
										$this->meta = 0;
										$tile->setPotionId(65535);
										$tile->setSplashPotion(false);
										$tile->clearCustomColor();
										$this->getLevel()->setBlock($this, $this, true);
										new \pocketmine\level\sound\ExplodeSound($this->add(0.5, 0, 0.5));
										$this->getLevel()->addSound(new \pocketmine\level\sound\ExplodeSound($this->add(0.5, 0, 0.5)));
									} else {
										$this->meta = 6;
										$tile->clearCustomColor();
										$this->getLevel()->setBlock($this, $this, true);
										new \pocketmine\level\sound\SplashSound($this->add(0.5, 1, 0.5));
										$this->getLevel()->addSound(new \pocketmine\level\sound\SplashSound($this->add(0.5, 1, 0.5)));
									}
									$this->update();
								}
							}
						}
					}
				}
				break;
				case \pocketmine\item\Item::DYE:
				if (($this->isEmpty() || $tile->hasPotion())) {
				} else {
					$color = \pocketmine\utils\Color::getDyeColor($item->getDamage());
					if ($tile->isCustomColor()) {
						$color = \pocketmine\utils\Color::mixCauldronDye($color, $tile->getCustomColor());
					}
					if ((($player !== null) && $player->isSurvival())) {
						$item->setCount(($item->getCount() - 1));
						if ((0 < $item->getCount())) {
						} else {
						}
						$player->getInventory()->setItemInHand(\pocketmine\item\Item::get(\pocketmine\item\Item::AIR));
					}
					$tile->setCustomColor($color);
					$this->sendCauldronEvent(\pocketmine\network\protocol\LevelEventPacket::EVENT_CAULDRON_ADD_DYE, $color->getABGRCode());
					$this->refreshCauldronBlock();
				}
				break;
				case \pocketmine\item\Item::LEATHER_CAP:
				case \pocketmine\item\Item::LEATHER_TUNIC:
				case \pocketmine\item\Item::LEATHER_PANTS:
				case \pocketmine\item\Item::LEATHER_BOOTS:
				if ((($this->isEmpty() || $tile->hasPotion()) || !($item instanceof \pocketmine\item\Armor))) {
				} else {
					if ($tile->isCustomColor()) {
						$newItem = clone $item;
						$newItem->setCustomColor($tile->getCustomColor());
						if (($player !== null)) {
							$player->getInventory()->setItemInHand($newItem);
						}
						$this->meta = max(0, ($this->meta - 2));
						$this->getLevel()->setBlock($this, $this, true);
						$this->sendCauldronEvent(\pocketmine\network\protocol\LevelEventPacket::EVENT_CAULDRON_DYE_ARMOR);
						$this->refreshCauldronBlock();
						if ($this->isEmpty()) {
							$tile->clearCustomColor();
						}
					} else {
						if (($item->getCustomColor() === null)) {
						} else {
							$newItem = clone $item;
							$newItem->clearCustomColor();
							if (($player !== null)) {
								$player->getInventory()->setItemInHand($newItem);
							}
							$this->meta = max(0, ($this->meta - 2));
							$this->getLevel()->setBlock($this, $this, true);
							$this->sendCauldronEvent(\pocketmine\network\protocol\LevelEventPacket::EVENT_CAULDRON_CLEAN_ARMOR);
							$this->refreshCauldronBlock();
						}
					}
				}
				break;
				case \pocketmine\item\Item::POTION:
				case \pocketmine\item\Item::SPLASH_POTION:
				if ((!($this->isEmpty()) && ((((($tile->getPotionId() !== $item->getDamage()) && ($item->getDamage() !== \pocketmine\item\Potion::WATER_BOTTLE)) || (($item->getId() === \pocketmine\item\Item::POTION) && $tile->getSplashPotion())) || ((($item->getId() === \pocketmine\item\Item::SPLASH_POTION) && !($tile->getSplashPotion())) && ($item->getDamage() !== 0))) || (($item->getDamage() === \pocketmine\item\Potion::WATER_BOTTLE) && $tile->hasPotion())))) {
					$this->meta = 0;
					$this->getLevel()->setBlock($this, $this, true);
					$tile->setPotionId(65535);
					$tile->setSplashPotion(false);
					$tile->clearCustomColor();
					if ($player->isSurvival()) {
						$player->getInventory()->setItemInHand(\pocketmine\item\Item::get(\pocketmine\item\Item::GLASS_BOTTLE));
					}
					new \pocketmine\level\sound\ExplodeSound($this->add(0.5, 0, 0.5));
					$this->getLevel()->addSound(new \pocketmine\level\sound\ExplodeSound($this->add(0.5, 0, 0.5)));
				} else {
					if (($item->getDamage() === \pocketmine\item\Potion::WATER_BOTTLE)) {
						$this->meta += 2;
						if ((6 < $this->meta)) {
							$this->meta = 6;
						}
						$this->getLevel()->setBlock($this, $this, true);
						if ($player->isSurvival()) {
							$player->getInventory()->setItemInHand(\pocketmine\item\Item::get(\pocketmine\item\Item::GLASS_BOTTLE));
						}
						$tile->setPotionId(65535);
						$tile->setSplashPotion(false);
						$tile->clearCustomColor();
						new \pocketmine\level\sound\SplashSound($this->add(0.5, 1, 0.5));
						$this->getLevel()->addSound(new \pocketmine\level\sound\SplashSound($this->add(0.5, 1, 0.5)));
					} else {
						if (!($this->isFull())) {
							$this->meta += 2;
							if ((6 < $this->meta)) {
								$this->meta = 6;
							}
							$tile->setPotionId($item->getDamage());
							$tile->setSplashPotion(($item->getId() === \pocketmine\item\Item::SPLASH_POTION));
							$tile->clearCustomColor();
							$this->getLevel()->setBlock($this, $this, true);
							if ($player->isSurvival()) {
								$player->getInventory()->setItemInHand(\pocketmine\item\Item::get(\pocketmine\item\Item::GLASS_BOTTLE));
							}
							$color = \pocketmine\item\Potion::getColor($item->getDamage());
							new \pocketmine\level\sound\SpellSound($this->add(0.5, 1, 0.5), $color[0], $color[1], $color[2]);
							$this->getLevel()->addSound(new \pocketmine\level\sound\SpellSound($this->add(0.5, 1, 0.5), $color[0], $color[1], $color[2]));
						}
					}
				}
				break;
				case \pocketmine\item\Item::GLASS_BOTTLE:
				new \pocketmine\event\player\PlayerGlassBottleEvent($player, $this, $item);
				$ev = new \pocketmine\event\player\PlayerGlassBottleEvent($player, $this, $item);
				$player->getServer()->getPluginManager()->callEvent($ev);
				if ($ev->isCancelled()) {
					return false;
				}
				if (($this->meta < 2)) {
				} else {
					if ($tile->hasPotion()) {
						$this->meta -= 2;
						if (($tile->getSplashPotion() === true)) {
							$result = \pocketmine\item\Item::get(\pocketmine\item\Item::SPLASH_POTION, $tile->getPotionId());
						} else {
							$result = \pocketmine\item\Item::get(\pocketmine\item\Item::POTION, $tile->getPotionId());
						}
						if ($this->isEmpty()) {
							$tile->setPotionId(65535);
							$tile->setSplashPotion(false);
							$tile->clearCustomColor();
						}
						$this->getLevel()->setBlock($this, $this, true);
						$this->addItem($item, $player, $result);
						$color = \pocketmine\item\Potion::getColor($result->getDamage());
						new \pocketmine\level\sound\SpellSound($this->add(0.5, 1, 0.5), $color[0], $color[1], $color[2]);
						$this->getLevel()->addSound(new \pocketmine\level\sound\SpellSound($this->add(0.5, 1, 0.5), $color[0], $color[1], $color[2]));
					} else {
						$this->meta -= 2;
						$this->getLevel()->setBlock($this, $this, true);
						if ($player->isSurvival()) {
							$result = \pocketmine\item\Item::get(\pocketmine\item\Item::POTION, \pocketmine\item\Potion::WATER_BOTTLE);
							$this->addItem($item, $player, $result);
						}
						new \pocketmine\level\sound\GraySplashSound($this->add(0.5, 1, 0.5));
						$this->getLevel()->addSound(new \pocketmine\level\sound\GraySplashSound($this->add(0.5, 1, 0.5)));
					}
				}
				break;
			}
			return true;
		}

	public function addItem($item = null, $player = null, $result = null) {
			/* decompiled (structured CF) */
			if (($item->getCount() <= 1)) {
				$player->getInventory()->setItemInHand($result);
			} else {
				$item->setCount(($item->getCount() - 1));
				if (($player->getInventory()->canAddItem($result) === true)) {
					$player->getInventory()->addItem($result);
				} else {
					$motion = $player->getDirectionVector()->multiply(0.4);
					$position = clone $player->getPosition();
					$player->getLevel()->dropItem($position->add(0, 0.5, 0), $result, $motion, 40);
				}
			}
			return null;
		}

}
