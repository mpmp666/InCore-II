<?php

namespace pocketmine\block;

class WoodSlab extends \pocketmine\block\Transparent {
	protected $id = 158;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getHardness() {
			return 2;
		}

	public function getName() {
			/* decompiled (structured CF) */
			if ((($this->meta & 8) === 8)) {
			} else {
			}
			return (('' . $names[($this->meta & 7)]) . $this);
		}

	protected function recalculateBoundingBox() {
			/* decompiled (structured CF) */
			if ((0 < ($this->meta & 8))) {
				new \pocketmine\math\AxisAlignedBB($this->x, ($this->y + 0.5), $this->z, ($this->x + 1), ($this->y + 1), ($this->z + 1));
				return new \pocketmine\math\AxisAlignedBB($this->x, ($this->y + 0.5), $this->z, ($this->x + 1), ($this->y + 1), ($this->z + 1));
			} else {
				new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 0.5), ($this->z + 1));
				return new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 0.5), ($this->z + 1));
			}
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$this->meta &= 7;
			if (($face === 0)) {
				if (((($target->getId() === self::WOOD_SLAB) && (($target->getDamage() & 8) === 8)) && (($target->getDamage() & 7) === ($this->meta & 7)))) {
					$this->getLevel()->setBlock($target, \pocketmine\block\Block::get(\pocketmine\item\Item::DOUBLE_WOOD_SLAB, $this->meta), true);
					return true;
				} else {
					if ((($block->getId() === self::WOOD_SLAB) && (($block->getDamage() & 7) === ($this->meta & 7)))) {
						$this->getLevel()->setBlock($block, \pocketmine\block\Block::get(\pocketmine\item\Item::DOUBLE_WOOD_SLAB, $this->meta), true);
						return true;
					} else {
						$this->meta |= 8;
					}
				}
			} else {
				if (($face === 1)) {
					if (((($target->getId() === self::WOOD_SLAB) && (($target->getDamage() & 8) === 0)) && (($target->getDamage() & 7) === ($this->meta & 7)))) {
						$this->getLevel()->setBlock($target, \pocketmine\block\Block::get(\pocketmine\item\Item::DOUBLE_WOOD_SLAB, $this->meta), true);
						return true;
					} else {
						if ((($block->getId() === self::WOOD_SLAB) && (($block->getDamage() & 7) === ($this->meta & 7)))) {
							$this->getLevel()->setBlock($block, \pocketmine\block\Block::get(\pocketmine\item\Item::DOUBLE_WOOD_SLAB, $this->meta), true);
							return true;
						}
					}
				} else {
					if (($block->getId() === self::WOOD_SLAB)) {
						if ((($block->getDamage() & 7) === ($this->meta & 7))) {
							$this->getLevel()->setBlock($block, \pocketmine\block\Block::get(\pocketmine\item\Item::DOUBLE_WOOD_SLAB, $this->meta), true);
							return true;
						}
						return false;
					} else {
						if ((0.5 < $fy)) {
							$this->meta |= 8;
						}
					}
				}
			}
			if ((($block->getId() === self::WOOD_SLAB) && (($target->getDamage() & 7) !== ($this->meta & 7)))) {
				return false;
			}
			$this->getLevel()->setBlock($block, $this, true, true);
			return true;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_AXE;
		}

	public function getDrops($item = null) {
			return [[$this->id, ($this->meta & 7), 1]];
		}

}
