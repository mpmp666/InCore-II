<?php

namespace pocketmine\block;

class FenceGateDarkOak extends \pocketmine\block\FenceGate {
	protected $id = 186;

	public function getName() {
			return;
		}

}
