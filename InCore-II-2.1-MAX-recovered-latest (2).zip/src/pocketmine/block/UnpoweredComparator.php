<?php

namespace pocketmine\block;

class UnpoweredComparator extends \pocketmine\block\RedstoneComparator {
	protected $id = 149;
	protected $isPowered = false;

	public function getName() {
			return;
		}

	protected function getUnpowered() {
			return \pocketmine\block\Block::get(self::UNPOWERED_COMPARATOR, $this->meta);
		}

}
