<?php

namespace pocketmine\block;

class Tripwire extends \pocketmine\block\Flowable {
	public const POWERED = 1;
	public const SUSPENDED = 2;
	public const ATTACHED = 4;
	public const DISARMED = 8;

	protected $id = 132;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return 'Tripwire';
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_SHEARS;
		}

	public function getHardness() {
			return 0;
		}

	public function getResistance() {
			return 0;
		}

	public function hasEntityCollision() {
			return true;
		}

	public function getBoundingBox() {
			/* decompiled (structured CF) */
			if (($this->boundingBox === null)) {
				new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 0.5), ($this->z + 1));
				$this->boundingBox = new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 0.5), ($this->z + 1));
			}
			return $this->boundingBox;
		}

	public function canPassThrough() {
			return true;
		}

	public function isPowered() {
			return (($this->meta & self::POWERED) !== 0);
		}

	public function isSuspended() {
			return (($this->meta & self::SUSPENDED) !== 0);
		}

	public function isAttached() {
			return (($this->meta & self::ATTACHED) !== 0);
		}

	public function isDisarmed() {
			return (($this->meta & self::DISARMED) !== 0);
		}

	public function setPowered($powered = null) {
			$this->setFlag(self::POWERED, $powered);
			return null;
		}

	public function setSuspended($suspended = null) {
			$this->setFlag(self::SUSPENDED, $suspended);
			return null;
		}

	public function setAttached($attached = null) {
			$this->setFlag(self::ATTACHED, $attached);
			return null;
		}

	public function setDisarmed($disarmed = null) {
			$this->setFlag(self::DISARMED, $disarmed);
			return null;
		}

	private function setFlag($flag = null, $enabled = null) {
			/* decompiled (structured CF) */
			if ($enabled) {
				$this->meta |= $flag;
			} else {
				$this->meta &= $t4;
			}
			return null;
		}

	public function onEntityCollide($entity = null) {
			/* decompiled (structured CF) */
			if (((!($this->getLevel()->getServer()->redstoneEnabled) || !($entity->canTriggerWalking())) || $this->isPowered())) {
				return null;
			}
			$this->setPowered(true);
			$this->getLevel()->setBlock($this, $this, true, false);
			$this->updateHook(false);
			$this->getLevel()->scheduleUpdate($this, 10);
		}

	private function updateHook($scheduleUpdate = null) {
			/* decompiled (structured CF) */
			if (!($this->getLevel()->getServer()->redstoneEnabled)) {
				return null;
			}
			foreach ([\pocketmine\math\Vector3::SIDE_EAST, \pocketmine\math\Vector3::SIDE_WEST, \pocketmine\math\Vector3::SIDE_SOUTH, \pocketmine\math\Vector3::SIDE_NORTH] as $side) {
				$distance = 1;
				while (($distance < $t28)) {
					$block = $this->getSide($side, $distance);
					if ($block instanceof \pocketmine\block\TripwireHook) {
						if (($block->getFacing() === \pocketmine\math\Vector3::getOppositeSide($side))) {
							$block->updateLine(false, true, $distance, $this);
							if ($scheduleUpdate) {
								$this->getLevel()->scheduleUpdate($block, 10);
							}
						}
					} else {
						if (!($block instanceof \pocketmine\block\Tripwire)) {
						} else {
							$distance++;
						}
					}
				}
				/* goto */
			}
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (!($this->getLevel()->getServer()->redstoneEnabled)) {
				return false;
			}
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED)) {
				if (!($this->isPowered())) {
					return \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED;
				}
				foreach ($this->getLevel()->getCollidingEntities($this->getBoundingBox()) as $entity) {
					if (($entity instanceof \pocketmine\entity\Entity && $entity->canTriggerWalking())) {
						$this->getLevel()->scheduleUpdate($this, 10);
						return \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED;
					}
					/* goto */
				}
				$this->setPowered(false);
				$this->getLevel()->setBlock($this, $this, true, false);
				$this->updateHook(false);
				return \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED;
			}
			return false;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			$this->getLevel()->setBlock($block, $this, true, true);
			$this->updateHook(false);
			return true;
		}

	public function onBreak($item = null) {
			/* decompiled (structured CF) */
			if (($item instanceof \pocketmine\item\Tool && $item->isShears())) {
				$this->setDisarmed(true);
				$this->getLevel()->setBlock($this, $this, true, false);
				$this->updateHook(false);
			} else {
				$this->setPowered(true);
				$this->updateHook(true);
			}
			new \pocketmine\block\Air();
			$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), true, true);
			return true;
		}

	public function getDrops($item = null) {
			return [[\pocketmine\item\Item::STRING, 0, 1]];
		}

}
