<?php

namespace pocketmine\block;

abstract class Transparent extends \pocketmine\block\Block {
	public function isTransparent() {
			return true;
		}

}
