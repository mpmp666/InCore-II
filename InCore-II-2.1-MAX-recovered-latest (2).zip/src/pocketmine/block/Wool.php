<?php

namespace pocketmine\block;

class Wool extends \pocketmine\block\Solid {
	public const WHITE = 0;
	public const ORANGE = 1;
	public const MAGENTA = 2;
	public const LIGHT_BLUE = 3;
	public const YELLOW = 4;
	public const LIME = 5;
	public const PINK = 6;
	public const GRAY = 7;
	public const LIGHT_GRAY = 8;
	public const CYAN = 9;
	public const PURPLE = 10;
	public const BLUE = 11;
	public const BROWN = 12;
	public const GREEN = 13;
	public const RED = 14;
	public const BLACK = 15;

	protected $id = 35;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getHardness() {
			return 0.8;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_SHEARS;
		}

	public function getName() {
			return $names[($this->meta & 15)];
		}

	public function getBurnChance() {
			return 30;
		}

	public function getBurnAbility() {
			return 60;
		}

}
