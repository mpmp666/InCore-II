<?php

namespace pocketmine\block;

class Bedrock extends \pocketmine\block\Solid {
	protected $id = 7;

	public function __construct() {
			// empty
		}

	public function getName() {
			return 'Bedrock';
		}

	public function getHardness() {
			return -1;
		}

	public function getResistance() {
			return 18000000;
		}

	public function isBreakable($item = null) {
			return false;
		}

}
