<?php

namespace pocketmine\block;

class Camera extends \pocketmine\block\Flowable {
	protected $id = 439;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function canBeReplaced() {
			return true;
		}

	public function getName() {
			return $names[($this->meta & 7)];
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				if ((($this->getSide(0)->isTransparent() === true) && !($this->getSide(0) instanceof \pocketmine\block\Camera))) {
					new \pocketmine\block\Air();
					$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), false, false, true);
					return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
				}
			}
			return false;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$down = $this->getSide(0);
			$up = $this->getSide(1);
			if ((($down->getId() === self::GRASS) || ($down->getId() === self::DIRT))) {
				$this->getLevel()->setBlock($block, $this, true);
				$this->getLevel()->setBlock($up, \pocketmine\block\Block::get($this->id, ($this->meta ^ 8)), true);
				return true;
			}
			return false;
		}

	public function onBreak($item = null) {
			/* decompiled (structured CF) */
			$up = $this->getSide(1);
			$down = $this->getSide(0);
			if ((($this->meta & 8) === 8)) {
				if ((($up->getId() === $this->id) && ($up->meta !== 8))) {
					new \pocketmine\block\Air();
					$this->getLevel()->setBlock($up, new \pocketmine\block\Air(), true, true);
				} else {
					if ((($down->getId() === $this->id) && ($down->meta !== 8))) {
						new \pocketmine\block\Air();
						$this->getLevel()->setBlock($down, new \pocketmine\block\Air(), true, true);
					}
				}
			} else {
				if ((($up->getId() === $this->id) && (($up->meta & 8) === 8))) {
					new \pocketmine\block\Air();
					$this->getLevel()->setBlock($up, new \pocketmine\block\Air(), true, true);
				} else {
					if ((($down->getId() === $this->id) && (($down->meta & 8) === 8))) {
						new \pocketmine\block\Air();
						$this->getLevel()->setBlock($down, new \pocketmine\block\Air(), true, true);
					}
				}
			}
			return null;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((($this->meta & 8) !== 8)) {
				return [[\pocketmine\item\Item::CAMERA, $this->meta, 1]];
			} else {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
		}

}
