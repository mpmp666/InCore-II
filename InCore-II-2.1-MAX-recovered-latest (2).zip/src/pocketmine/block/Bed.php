<?php

namespace pocketmine\block;

class Bed extends \pocketmine\block\Transparent {
	protected $id = 26;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function canBeActivated() {
			return true;
		}

	public function getHardness() {
			return 0.2;
		}

	public function getName() {
			return;
		}

	protected function recalculateBoundingBox() {
			new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 0.5625), ($this->z + 1));
			return new \pocketmine\math\AxisAlignedBB($this->x, $this->y, $this->z, ($this->x + 1), ($this->y + 0.5625), ($this->z + 1));
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			if (($this->getLevel()->getDimension() == \pocketmine\level\Level::DIMENSION_NETHER)) {
				new \pocketmine\level\Explosion($this, 6, $this);
				$explosion = new \pocketmine\level\Explosion($this, 6, $this);
				$explosion->explodeB();
				return true;
			}
			$time = ($this->getLevel()->getTime() % \pocketmine\level\Level::TIME_FULL);
			$isNight = ((\pocketmine\level\Level::TIME_NIGHT <= $time) && ($time < \pocketmine\level\Level::TIME_SUNRISE));
			if (($player instanceof \pocketmine\Player && !($isNight))) {
				$player->sendMessage((\pocketmine\utils\TextFormat::GRAY . "\xe4\xbd\xa0\xe5\x8f\xaa\xe8\x83\xbd\xe5\x9c\xa8\xe6\x99\x9a\xe4\xb8\x8a\xe7\x9d\xa1\xe8\xa7\x89"));
				return true;
			}
			$blockNorth = $this->getSide(2);
			$blockSouth = $this->getSide(3);
			$blockEast = $this->getSide(5);
			$blockWest = $this->getSide(4);
			if ((($this->meta & 8) === 8)) {
				$b = $this;
			} else {
				if ((($blockNorth->getId() === $this->id) && (($blockNorth->meta & 8) === 8))) {
					$b = $blockNorth;
				} else {
					if ((($blockSouth->getId() === $this->id) && (($blockSouth->meta & 8) === 8))) {
						$b = $blockSouth;
					} else {
						if ((($blockEast->getId() === $this->id) && (($blockEast->meta & 8) === 8))) {
							$b = $blockEast;
						} else {
							if ((($blockWest->getId() === $this->id) && (($blockWest->meta & 8) === 8))) {
								$b = $blockWest;
							} else {
								if ($player instanceof \pocketmine\Player) {
									$player->sendMessage((\pocketmine\utils\TextFormat::GRAY . $this));
								}
								return true;
							}
						}
					}
				}
			}
			if (($player instanceof \pocketmine\Player && ($player->sleepOn($b) === false))) {
				$player->sendMessage((\pocketmine\utils\TextFormat::GRAY . $this));
			}
			return true;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$down = $this->getSide(0);
			if (($down->isTransparent() === false)) {
				$faces = ['__array_ptr' => '2aaaadd5d658'];
				if ($player instanceof \pocketmine\Player) {
				} else {
				}
				$d = 0;
				$next = $this->getSide($faces[(($d + 3) % 4)]);
				$downNext = $this->getSide(0);
				if ((($next->canBeReplaced() === true) && ($downNext->isTransparent() === false))) {
					$meta = ((($d + 3) % 4) & 3);
					$this->getLevel()->setBlock($block, \pocketmine\block\Block::get($this->id, $meta), true, true);
					$this->getLevel()->setBlock($next, \pocketmine\block\Block::get($this->id, ($meta | 8)), true, true);
					return true;
				}
			}
			return false;
		}

	public function onBreak($item = null) {
			/* decompiled (structured CF) */
			$sides = ['__array_ptr' => '2aaaadd5d690'];
			if ((($this->meta & 8) === 8)) {
				$next = $this->getSide($sides[$this->meta]);
				if ((($next->getId() === $this->id) && (($next->meta | 8) === $this->meta))) {
					new \pocketmine\block\Air();
					$this->getLevel()->setBlock($next, new \pocketmine\block\Air(), true, true);
				}
			} else {
				$next = $this->getSide($sides[$this->meta]);
				if ((($next->getId() === $this->id) && ($next->meta === ($this->meta | 8)))) {
					new \pocketmine\block\Air();
					$this->getLevel()->setBlock($next, new \pocketmine\block\Air(), true, true);
				}
			}
			new \pocketmine\block\Air();
			$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), true, true);
			return true;
		}

	public function getDrops($item = null) {
			return [[\pocketmine\item\Item::BED, 0, 1]];
		}

}
