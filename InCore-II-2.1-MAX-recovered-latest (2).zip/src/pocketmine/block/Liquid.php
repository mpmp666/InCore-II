<?php

namespace pocketmine\block;

abstract class Liquid extends \pocketmine\block\Transparent {
	private $temporalVector = NULL;
	public $adjacentSources = 0;
	public $isOptimalFlowDirection = array (
  0 => 0,
  1 => 0,
  2 => 0,
  3 => 0,
);
	public $flowCost = array (
  0 => 0,
  1 => 0,
  2 => 0,
  3 => 0,
);

	public function hasEntityCollision() {
			return true;
		}

	public function isBreakable($item = null) {
			return false;
		}

	public function canBeReplaced() {
			return true;
		}

	public function canBeFlowedInto() {
			return true;
		}

	public function canPassThrough() {
			return true;
		}

	public function isSolid() {
			return false;
		}

	public function breaksWhenMovedByPiston() {
			return true;
		}

	public function sticksToPiston() {
			return false;
		}

	public function getFluidHeightPercent() {
			/* decompiled (structured CF) */
			$d = $this->meta;
			if ((8 <= $d)) {
				$d = 0;
			}
			return (($d + 1) / 9);
		}

	protected function getFlowDecay($pos = null) {
			/* decompiled (structured CF) */
			if (!($pos instanceof \pocketmine\block\Block)) {
				$pos = $this->getLevel()->getBlock($pos);
			}
			if (($pos->getId() !== $this->getId())) {
				return -1;
			} else {
				return $pos->getDamage();
			}
		}

	protected function getEffectiveFlowDecay($pos = null) {
			/* decompiled (structured CF) */
			if (!($pos instanceof \pocketmine\block\Block)) {
				$pos = $this->getLevel()->getBlock($pos);
			}
			if (($pos->getId() !== $this->getId())) {
				return -1;
			}
			$decay = $pos->getDamage();
			if ((8 <= $decay)) {
				$decay = 0;
			}
			return $decay;
		}

	public function getFlowVector() {
			/* decompiled (structured CF) */
			new \pocketmine\math\Vector3(0, 0, 0);
			$vector = new \pocketmine\math\Vector3(0, 0, 0);
			if (($this->temporalVector === null)) {
				new \pocketmine\math\Vector3(0, 0, 0);
				$this->temporalVector = new \pocketmine\math\Vector3(0, 0, 0);
			}
			$decay = $this->getEffectiveFlowDecay($this);
			$j = 0;
			while (($j < 4)) {
				$x = $this->x;
				$y = $this->y;
				$z = $this->z;
				if (($j === 0)) {
					$x--;
				} else {
					if (($j === 1)) {
						$x++;
					} else {
						if (($j === 2)) {
							$z--;
						} else {
							if (($j === 3)) {
								$z++;
							}
						}
					}
				}
				$sideBlock = $this->getLevel()->getBlock($this->temporalVector->setComponents($x, $y, $z));
				$blockDecay = $this->getEffectiveFlowDecay($sideBlock);
				if (($blockDecay < 0)) {
					if (!($this->canFlowInto($sideBlock))) {
					} else {
						$blockDecay = $this->getEffectiveFlowDecay($this->getLevel()->getBlock($this->temporalVector->setComponents($x, ($y - 1), $z)));
						if ((0 <= $blockDecay)) {
							$realDecay = ($blockDecay - ($decay - 8));
							$vector->x += ($realDecay * ($sideBlock->x - $this->x));
							$vector->y += ($realDecay * ($sideBlock->y - $this->y));
							$vector->z += ($realDecay * ($sideBlock->z - $this->z));
						}
						/* jump */
						/* jump */
						$realDecay = ($blockDecay - $decay);
						$vector->x += ($realDecay * ($sideBlock->x - $this->x));
						$vector->y += ($realDecay * ($sideBlock->y - $this->y));
						$vector->z += ($realDecay * ($sideBlock->z - $this->z));
					}
					$j++;
					if ((8 <= $this->getDamage())) {
						$falling = false;
						if (!($this->canFlowInto($this->getLevel()->getBlock($this->temporalVector->setComponents($this->x, $this->y, ($this->z - 1)))))) {
							$falling = true;
						} else {
							if (!($this->canFlowInto($this->getLevel()->getBlock($this->temporalVector->setComponents($this->x, $this->y, ($this->z + 1)))))) {
								$falling = true;
							} else {
								if (!($this->canFlowInto($this->getLevel()->getBlock($this->temporalVector->setComponents(($this->x - 1), $this->y, $this->z))))) {
									$falling = true;
								} else {
									if (!($this->canFlowInto($this->getLevel()->getBlock($this->temporalVector->setComponents(($this->x + 1), $this->y, $this->z))))) {
										$falling = true;
									} else {
										if (!($this->canFlowInto($this->getLevel()->getBlock($this->temporalVector->setComponents($this->x, ($this->y + 1), ($this->z - 1)))))) {
											$falling = true;
										} else {
											if (!($this->canFlowInto($this->getLevel()->getBlock($this->temporalVector->setComponents($this->x, ($this->y + 1), ($this->z + 1)))))) {
												$falling = true;
											} else {
												if (!($this->canFlowInto($this->getLevel()->getBlock($this->temporalVector->setComponents(($this->x - 1), ($this->y + 1), $this->z))))) {
													$falling = true;
												} else {
													if (!($this->canFlowInto($this->getLevel()->getBlock($this->temporalVector->setComponents(($this->x + 1), ($this->y + 1), $this->z))))) {
														$falling = true;
													}
												}
											}
										}
									}
								}
							}
						}
						if ($falling) {
							$vector = $vector->normalize()->add(0, -6, 0);
						}
					}
					return $vector->normalize();
				}
			}
		}

	public function addVelocityToEntity($entity = null, $vector = null) {
			/* decompiled (structured CF) */
			$flow = $this->getFlowVector();
			$vector->x += $flow->x;
			$vector->y += $flow->y;
			$vector->z += $flow->z;
			return null;
		}

	public function tickRate() {
			/* decompiled (structured CF) */
			if ($this instanceof \pocketmine\block\Water) {
				return 5;
			} else {
				if ($this instanceof \pocketmine\block\Lava) {
					if ($this->isInNether()) {
					} else {
					}
					return 30;
				}
			}
			return 0;
		}

	protected function getFlowDecayPerBlock() {
			/* decompiled (structured CF) */
			if (($this instanceof \pocketmine\block\Lava && !($this->isInNether()))) {
			} else {
			}
			return 1;
		}

	protected function canFlowInto($block = null) {
			return ($block->canBeFlowedInto() && !(($block instanceof \pocketmine\block\Liquid && ($block->getDamage() === 0))));
		}

	private function isInNether() {
			return ((($this->level !== null) && method_exists($this->level, 'getDimension')) && ($this->level->getDimension() === \pocketmine\level\Level::DIMENSION_NETHER));
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				$this->checkForHarden();
				$this->getLevel()->scheduleUpdate($this, $this->tickRate());
			} else {
				if (($type === \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED)) {
					if (($this->temporalVector === null)) {
						new \pocketmine\math\Vector3(0, 0, 0);
						$this->temporalVector = new \pocketmine\math\Vector3(0, 0, 0);
					}
					$decay = $this->getFlowDecay($this);
					$multiplier = $this->getFlowDecayPerBlock();
					if ((0 < $decay)) {
						$smallestFlowDecay = -100;
						$this->adjacentSources = 0;
						$smallestFlowDecay = $this->getSmallestFlowDecay($this->level->getBlock($this->temporalVector->setComponents($this->x, $this->y, ($this->z - 1))), $smallestFlowDecay);
						$smallestFlowDecay = $this->getSmallestFlowDecay($this->level->getBlock($this->temporalVector->setComponents($this->x, $this->y, ($this->z + 1))), $smallestFlowDecay);
						$smallestFlowDecay = $this->getSmallestFlowDecay($this->level->getBlock($this->temporalVector->setComponents(($this->x - 1), $this->y, $this->z)), $smallestFlowDecay);
						$smallestFlowDecay = $this->getSmallestFlowDecay($this->level->getBlock($this->temporalVector->setComponents(($this->x + 1), $this->y, $this->z)), $smallestFlowDecay);
						$k = ($smallestFlowDecay + $multiplier);
						if (((8 <= $k) || ($smallestFlowDecay < 0))) {
							$k = -1;
						}
						$topFlowDecay = $this->getFlowDecay($this->level->getBlock($this->level->getBlock($this->temporalVector->setComponents($this->x, ($this->y + 1), $this->z))));
						if ((0 <= $topFlowDecay)) {
							if ((8 <= $topFlowDecay)) {
								$k = $topFlowDecay;
							} else {
								$k = ($topFlowDecay | 8);
							}
						}
						if (((2 <= $this->adjacentSources) && $this instanceof \pocketmine\block\Water)) {
							$bottomBlock = $this->level->getBlock($this->level->getBlock($this->temporalVector->setComponents($this->x, ($this->y - 1), $this->z)));
							if ($bottomBlock->isSolid()) {
								$k = 0;
							} else {
								if (($bottomBlock instanceof \pocketmine\block\Water && ($bottomBlock->getDamage() === 0))) {
									$k = 0;
								}
							}
						}
						if (($k !== $decay)) {
							$decay = $k;
							if (($decay < 0)) {
								new \pocketmine\block\Air();
								$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), true);
							} else {
								$this->getLevel()->setBlock($this, \pocketmine\block\Block::get($this->id, $decay), true);
								$this->getLevel()->scheduleUpdate($this, $this->tickRate());
							}
						}
					}
					$bottomBlock = $this->level->getBlock($this->temporalVector->setComponents($this->x, ($this->y - 1), $this->z));
					if ((0 <= $decay)) {
						$this->flowIntoBlock($bottomBlock, ($decay | 8));
					}
					if (((0 <= $decay) && (($decay === 0) || !($bottomBlock->canBeFlowedInto())))) {
						$flags = $this->getOptimalFlowDirections();
						$l = ($decay + $multiplier);
						if ((8 <= $decay)) {
							$l = 1;
						}
						if ((8 <= $l)) {
							$this->checkForHarden();
							return null;
						}
						if ($flags[0]) {
							$this->flowIntoBlock($this->level->getBlock($this->temporalVector->setComponents(($this->x - 1), $this->y, $this->z)), $l);
						}
						if ($flags[1]) {
							$this->flowIntoBlock($this->level->getBlock($this->temporalVector->setComponents(($this->x + 1), $this->y, $this->z)), $l);
						}
						if ($flags[2]) {
							$this->flowIntoBlock($this->level->getBlock($this->temporalVector->setComponents($this->x, $this->y, ($this->z - 1))), $l);
						}
						if ($flags[3]) {
							$this->flowIntoBlock($this->level->getBlock($this->temporalVector->setComponents($this->x, $this->y, ($this->z + 1))), $l);
						}
					}
					$this->checkForHarden();
				}
			}
		}

	private function flowIntoBlock($block = null, $newFlowDecay = null) {
			/* decompiled (structured CF) */
			if (($this instanceof \pocketmine\block\Lava && $block instanceof \pocketmine\block\Water)) {
				$this->getLevel()->setBlock($block, \pocketmine\block\Block::get(\pocketmine\item\Item::STONE), true);
				$this->triggerLavaMixEffects($block);
				return null;
			}
			if (($this->canFlowInto($block) && !($block instanceof \pocketmine\block\Liquid))) {
				if ((0 < $block->getId())) {
					$this->getLevel()->useBreakOn($block);
				}
				$this->getLevel()->setBlock($block, \pocketmine\block\Block::get($this->getId(), $newFlowDecay), true);
				$this->getLevel()->scheduleUpdate($block, $this->tickRate());
			}
		}

	private function calculateFlowCost($block = null, $accumulatedCost = null, $previousDirection = null) {
			/* decompiled (structured CF) */
			$cost = 1000;
			$j = 0;
			while (($j < 4)) {
				if (((((($j === 0) && ($previousDirection === 1)) || (($j === 1) && ($previousDirection === 0))) || (($j === 2) && ($previousDirection === 3))) || (($j === 3) && ($previousDirection === 2)))) {
				} else {
					$x = $block->x;
					$y = $block->y;
					$z = $block->z;
					if (($j === 0)) {
						$x--;
					} else {
						if (($j === 1)) {
							$x++;
						} else {
							if (($j === 2)) {
								$z--;
							} else {
								if (($j === 3)) {
									$z++;
								}
							}
						}
					}
					$blockSide = $this->getLevel()->getBlock($this->temporalVector->setComponents($x, $y, $z));
					if (!($this->canFlowInto($blockSide))) {
						/* jump */
					} else {
						if ($this->getLevel()->getBlock($this->temporalVector->setComponents($x, ($y - 1), $z))->canBeFlowedInto()) {
							return $accumulatedCost;
						}
					}
					if ((4 <= $accumulatedCost)) {
					} else {
						$realCost = $this->calculateFlowCost($blockSide, ($accumulatedCost + 1), $j);
						if (($realCost < $cost)) {
							$cost = $realCost;
						}
					}
				}
				$j++;
			}
			return $cost;
		}

	private function getOptimalFlowDirections() {
			/* decompiled (structured CF) */
			if (($this->temporalVector === null)) {
				new \pocketmine\math\Vector3(0, 0, 0);
				$this->temporalVector = new \pocketmine\math\Vector3(0, 0, 0);
			}
			$j = 0;
			while (($j < 4)) {
				$this->flowCost[$j] = 1000;
				$x = $this->x;
				$y = $this->y;
				$z = $this->z;
				if (($j === 0)) {
					$x--;
				} else {
					if (($j === 1)) {
						$x++;
					} else {
						if (($j === 2)) {
							$z--;
						} else {
							if (($j === 3)) {
								$z++;
							}
						}
					}
				}
				$block = $this->getLevel()->getBlock($this->temporalVector->setComponents($x, $y, $z));
				if (!($this->canFlowInto($block))) {
				} else {
					/* jump */
					if ($this->getLevel()->getBlock($this->temporalVector->setComponents($x, ($y - 1), $z))->canBeFlowedInto()) {
						$this->flowCost[$j] = 0;
					} else {
						$this->flowCost[$j] = $this->calculateFlowCost($block, 1, $j);
					}
				}
				$j++;
			}
			$minCost = $this->flowCost[0];
			$i = 1;
			while (($i < 4)) {
				if (($this->flowCost[$i] < $minCost)) {
					$minCost = $this->flowCost[$i];
				}
				$i++;
			}
			$i = 0;
			while (($i < 4)) {
				$this->isOptimalFlowDirection[$i] = ($minCost === $this->flowCost[$i]);
				$i++;
			}
			return $this->isOptimalFlowDirection;
		}

	private function getSmallestFlowDecay($pos = null, $decay = null) {
			/* decompiled (structured CF) */
			$blockDecay = $this->getFlowDecay($pos);
			if (($blockDecay < 0)) {
				return $decay;
			} else {
				if (($blockDecay === 0)) {
				} else {
					if ((8 <= $blockDecay)) {
						$blockDecay = 0;
					}
				}
			}
			if (((0 <= $decay) && ($decay <= $blockDecay))) {
			} else {
			}
			return $blockDecay;
		}

	private function checkForHarden() {
			/* decompiled (structured CF) */
			if ($this instanceof \pocketmine\block\Lava) {
				$colliding = false;
				$side = 0;
				while (!($colliding)) {
					$colliding = $this->getSide($side) instanceof \pocketmine\block\Water;
					$side++;
				}
				if ($colliding) {
					if (($this->getDamage() === 0)) {
						$this->getLevel()->setBlock($this, \pocketmine\block\Block::get(\pocketmine\item\Item::OBSIDIAN), true);
					} else {
						if (($this->getDamage() <= 4)) {
							$this->getLevel()->setBlock($this, \pocketmine\block\Block::get(\pocketmine\item\Item::COBBLESTONE), true);
						}
					}
					$this->triggerLavaMixEffects($this);
				}
			}
			return null;
		}

	public function getBoundingBox() {
			return null;
		}

	public function getDrops($item = null) {
			return ['__array_ptr' => '2aaaac9fc9a0'];
		}

	protected function triggerLavaMixEffects($pos = null) {
			/* decompiled (structured CF) */
			new \pocketmine\level\sound\FizzSound($pos->add(0.5, 0.5, 0.5), (2.5 + ((mt_rand(0, 1000) / 1000) * 0.8)));
			$this->getLevel()->addSound(new \pocketmine\level\sound\FizzSound($pos->add(0.5, 0.5, 0.5), (2.5 + ((mt_rand(0, 1000) / 1000) * 0.8))));
			$i = 0;
			while (($i < 8)) {
				new \pocketmine\level\particle\SmokeParticle($pos->add((mt_rand(0, 80) / 100), 0.5, (mt_rand(0, 80) / 100)));
				$this->getLevel()->addParticle(new \pocketmine\level\particle\SmokeParticle($pos->add((mt_rand(0, 80) / 100), 0.5, (mt_rand(0, 80) / 100))));
				$i++;
			}
			return null;
		}

}
