<?php

namespace pocketmine\block;

class Portal extends \pocketmine\block\Transparent {
	protected $id = 90;
	private $temporalVector = NULL;

	public function __construct() {
			/* decompiled (structured CF) */
			if (($this->temporalVector === null)) {
				new \pocketmine\math\Vector3(0, 0, 0);
				$this->temporalVector = new \pocketmine\math\Vector3(0, 0, 0);
			}
			return;
		}

	public function getName() {
			return 'Portal';
		}

	public function getHardness() {
			return -1;
		}

	public function getResistance() {
			return 0;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function canPassThrough() {
			return true;
		}

	public function canBeActivated() {
			return true;
		}

	public function hasEntityCollision() {
			return true;
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			if ($player instanceof \pocketmine\Player) {
				$n = 0;
				while (($n <= 2)) {
					new \pocketmine\level\sound\EndermanTeleportSound($this);
					$sound = new \pocketmine\level\sound\EndermanTeleportSound($this);
					$this->getLevel()->addSound($sound);
					$n++;
				}
				$num = 0;
				while (($num <= 10)) {
					new \pocketmine\level\particle\PortalParticle($this);
					$particle = new \pocketmine\level\particle\PortalParticle($this);
					$this->getLevel()->addParticle($particle);
					$num++;
				}
			}
			return true;
		}

	public function onBreak($item = null) {
			/* decompiled (structured CF) */
			new \pocketmine\level\sound\EndermanTeleportSound($this);
			$sound = new \pocketmine\level\sound\EndermanTeleportSound($this);
			$this->getLevel()->addSound($sound);
			new \pocketmine\level\particle\PortalParticle($this);
			$particle = new \pocketmine\level\particle\PortalParticle($this);
			$this->getLevel()->addParticle($particle);
			$block = $this;
			if ((($this->getLevel()->getBlock($this->temporalVector->setComponents(($block->x - 1), $block->y, $block->z))->getId() == \pocketmine\block\Block::PORTAL) || ($this->getLevel()->getBlock($this->temporalVector->setComponents(($block->x + 1), $block->y, $block->z))->getId() == \pocketmine\block\Block::PORTAL))) {
				$x = $block->x;
				while (($this->getLevel()->getBlock()->getId() == $t90)) {
					$y = $block->y;
					while (($this->getLevel()->getBlock()->getId() == $t61)) {
						new \pocketmine\block\Air();
						$this->getLevel()->setBlock($this->temporalVector->setComponents($x, $y, $block->z), new \pocketmine\block\Air());
						$y++;
					}
					$y = ($block->y - 1);
					while (($this->getLevel()->getBlock()->getId() == $t80)) {
						new \pocketmine\block\Air();
						$this->getLevel()->setBlock($this->temporalVector->setComponents($x, $y, $block->z), new \pocketmine\block\Air());
						$y--;
					}
					$x++;
				}
				$x = ($block->x - 1);
				while (($this->getLevel()->getBlock()->getId() == $t140)) {
					$y = $block->y;
					while (($this->getLevel()->getBlock()->getId() == $t111)) {
						new \pocketmine\block\Air();
						$this->getLevel()->setBlock($this->temporalVector->setComponents($x, $y, $block->z), new \pocketmine\block\Air());
						$y++;
					}
					$y = ($block->y - 1);
					while (($this->getLevel()->getBlock()->getId() == $t130)) {
						new \pocketmine\block\Air();
						$this->getLevel()->setBlock($this->temporalVector->setComponents($x, $y, $block->z), new \pocketmine\block\Air());
						$y--;
					}
					$x--;
				}
			} else {
				$z = $block->z;
				while (($this->getLevel()->getBlock()->getId() == $t189)) {
					$y = $block->y;
					while (($this->getLevel()->getBlock()->getId() == $t160)) {
						new \pocketmine\block\Air();
						$this->getLevel()->setBlock($this->temporalVector->setComponents($block->x, $y, $z), new \pocketmine\block\Air());
						$y++;
					}
					$y = ($block->y - 1);
					while (($this->getLevel()->getBlock()->getId() == $t179)) {
						new \pocketmine\block\Air();
						$this->getLevel()->setBlock($this->temporalVector->setComponents($block->x, $y, $z), new \pocketmine\block\Air());
						$y--;
					}
					$z++;
				}
				$z = ($block->z - 1);
				while (($this->getLevel()->getBlock()->getId() == $t239)) {
					$y = $block->y;
					while (($this->getLevel()->getBlock()->getId() == $t210)) {
						new \pocketmine\block\Air();
						$this->getLevel()->setBlock($this->temporalVector->setComponents($block->x, $y, $z), new \pocketmine\block\Air());
						$y++;
					}
					$y = ($block->y - 1);
					while (($this->getLevel()->getBlock()->getId() == $t229)) {
						new \pocketmine\block\Air();
						$this->getLevel()->setBlock($this->temporalVector->setComponents($block->x, $y, $z), new \pocketmine\block\Air());
						$y--;
					}
					$z--;
				}
			}
			parent::onBreak($item);
			return null;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			if ($player instanceof \pocketmine\Player) {
				$this->meta = ((($player->getDirection()) + 5) % 2);
			}
			$this->getLevel()->setBlock($block, $this, true, true);
			return true;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((1 <= $item->isPickaxe())) {
				return [[\pocketmine\item\Item::PORTAL, 0, 1]];
			} else {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
		}

}
