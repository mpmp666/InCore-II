<?php

namespace pocketmine\block;

class GlowingRedstoneOre extends \pocketmine\block\RedstoneOre {
	protected $id = 74;

	public function getName() {
			return;
		}

	public function getLightLevel() {
			return 9;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if ((($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL) || ($type === \pocketmine\level\Level::BLOCK_UPDATE_TOUCH))) {
				$this->getLevel()->scheduleUpdate($this, 30);
				return \pocketmine\level\Level::BLOCK_UPDATE_WEAK;
			}
			if ((($type === \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED) || ($type === \pocketmine\level\Level::BLOCK_UPDATE_RANDOM))) {
				$this->getLevel()->setBlock($this, \pocketmine\block\Block::get(\pocketmine\item\Item::REDSTONE_ORE, $this->meta), false, false);
				return \pocketmine\level\Level::BLOCK_UPDATE_WEAK;
			}
			return false;
		}

}
