<?php

namespace pocketmine\block;

class Glowstone extends \pocketmine\block\Transparent {
	protected $id = 89;

	public function __construct() {
			// empty
		}

	public function getName() {
			return 'Glowstone';
		}

	public function getHardness() {
			return 0.3;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function getLightLevel() {
			return 15;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((0 < $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_SILK_TOUCH))) {
				return [[\pocketmine\item\Item::GLOWSTONE_BLOCK, 0, 1]];
			} else {
				$fortunel = $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_FORTUNE);
				if ((3 < $fortunel)) {
				} else {
				}
				$fortunel = $fortunel;
				$times = ['__array_ptr' => '2aaaadd5d4d0'];
				$time = $times[mt_rand(0, ($fortunel + 1))];
				$num = ($time * mt_rand(2, 4));
				if ((4 < $num)) {
				} else {
				}
				$num = $num;
				return [[\pocketmine\item\Item::GLOWSTONE_DUST, 0, $num]];
			}
		}

}
