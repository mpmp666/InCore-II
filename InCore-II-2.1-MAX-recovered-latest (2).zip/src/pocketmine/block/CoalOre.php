<?php

namespace pocketmine\block;

class CoalOre extends \pocketmine\block\Solid {
	protected $id = 16;

	public function __construct() {
			// empty
		}

	public function getHardness() {
			return 3;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_PICKAXE;
		}

	public function getName() {
			return;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((1 <= $item->isPickaxe())) {
				if ((0 < $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_SILK_TOUCH))) {
					return [[\pocketmine\item\Item::COAL_ORE, 0, 1]];
				} else {
					$fortunel = $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_FORTUNE);
					if ((3 < $fortunel)) {
					} else {
					}
					$fortunel = $fortunel;
					$times = ['__array_ptr' => '2aaaadd5d460'];
					$time = $times[mt_rand(0, ($fortunel + 1))];
					return [[\pocketmine\item\Item::COAL, 0, $time]];
				}
			} else {
				return ['__array_ptr' => '2aaaac9fc9a0'];
			}
		}

}
