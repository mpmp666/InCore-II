<?php

namespace pocketmine\block;

class Clay extends \pocketmine\block\Solid {
	protected $id = 82;

	public function __construct() {
			// empty
		}

	public function getHardness() {
			return 0.6;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_SHOVEL;
		}

	public function getName() {
			return;
		}

	public function getDrops($item = null) {
			return [[\pocketmine\item\Item::CLAY, 0, 4]];
		}

}
