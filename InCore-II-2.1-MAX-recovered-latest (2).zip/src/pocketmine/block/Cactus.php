<?php

namespace pocketmine\block;

class Cactus extends \pocketmine\block\Transparent {
	protected $id = 81;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getHardness() {
			return 0.4;
		}

	public function hasEntityCollision() {
			return true;
		}

	public function getName() {
			return 'Cactus';
		}

	protected function recalculateBoundingBox() {
			new \pocketmine\math\AxisAlignedBB(($this->x + 0.0625), ($this->y + 0.0625), ($this->z + 0.0625), ($this->x + 0.9375), ($this->y + 0.9375), ($this->z + 0.9375));
			return new \pocketmine\math\AxisAlignedBB(($this->x + 0.0625), ($this->y + 0.0625), ($this->z + 0.0625), ($this->x + 0.9375), ($this->y + 0.9375), ($this->z + 0.9375));
		}

	public function onEntityCollide($entity = null) {
			/* decompiled (structured CF) */
			new \pocketmine\event\entity\EntityDamageByBlockEvent($this, $entity, \pocketmine\event\entity\EntityDamageEvent::CAUSE_CONTACT, 1);
			$ev = new \pocketmine\event\entity\EntityDamageByBlockEvent($this, $entity, \pocketmine\event\entity\EntityDamageEvent::CAUSE_CONTACT, 1);
			if (($entity->attack($ev->getFinalDamage(), $ev) === true)) {
				$ev->useArmors();
			}
			return null;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				$down = $this->getSide(0);
				if ((($down->getId() !== self::SAND) && ($down->getId() !== self::CACTUS))) {
					$this->getLevel()->useBreakOn($this);
				} else {
					$side = 2;
					while (($side <= 5)) {
						$b = $this->getSide($side);
						if (!($b->canBeFlowedInto())) {
							$this->getLevel()->useBreakOn($this);
						}
						$side++;
					}
				}
			} else {
				if (($type === \pocketmine\level\Level::BLOCK_UPDATE_RANDOM)) {
					if (($this->getSide(0)->getId() !== self::CACTUS)) {
						if (($this->meta == 15)) {
							$y = 1;
							while (($y < 3)) {
								new \pocketmine\math\Vector3($this->x, ($this->y + $y), $this->z);
								$b = $this->getLevel()->getBlock(new \pocketmine\math\Vector3($this->x, ($this->y + $y), $this->z));
								if (($b->getId() === self::AIR)) {
									new \pocketmine\block\Cactus();
									new \pocketmine\event\block\BlockGrowEvent($b, new \pocketmine\block\Cactus());
									$ev = new \pocketmine\event\block\BlockGrowEvent($b, new \pocketmine\block\Cactus());
									\pocketmine\Server::getInstance()->getPluginManager()->callEvent($ev);
									if (!($ev->isCancelled())) {
										$this->getLevel()->setBlock($b, $ev->getNewState(), true);
									}
								}
								$y++;
							}
							$this->meta = 0;
							$this->getLevel()->setBlock($this, $this);
						} else {
							$this->getLevel()->setBlock($this, $this);
						}
					}
				}
			}
			return false;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$down = $this->getSide(0);
			if ((($down->getId() === self::SAND) || ($down->getId() === self::CACTUS))) {
				$block0 = $this->getSide(2);
				$block1 = $this->getSide(3);
				$block2 = $this->getSide(4);
				$block3 = $this->getSide(5);
				if ((((($block0->isTransparent() === true) && ($block1->isTransparent() === true)) && ($block2->isTransparent() === true)) && ($block3->isTransparent() === true))) {
					$this->getLevel()->setBlock($this, $this, true);
					return true;
				}
			}
			return false;
		}

	public function getDrops($item = null) {
			return [[$this->id, 0, 1]];
		}

}
