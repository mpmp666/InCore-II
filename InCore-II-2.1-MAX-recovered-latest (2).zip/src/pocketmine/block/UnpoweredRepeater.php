<?php

namespace pocketmine\block;

class UnpoweredRepeater extends \pocketmine\block\PoweredRepeater {
	protected $id = 93;
	protected $isPowered = false;

	public function getName() {
			return;
		}

	protected function getPowered() {
			return \pocketmine\block\Block::get(self::POWERED_REPEATER, $this->meta);
		}

	protected function getUnpowered() {
			return \pocketmine\block\Block::get(self::UNPOWERED_REPEATER, $this->meta);
		}

}
