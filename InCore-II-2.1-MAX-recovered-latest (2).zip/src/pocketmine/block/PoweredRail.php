<?php

namespace pocketmine\block;

class PoweredRail extends \pocketmine\block\Rail {
	protected $id = 27;
	protected $connected = array (
);

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getName() {
			return 'PoweredRail';
		}

	protected function update() {
			return true;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (((($type === \pocketmine\level\Level::BLOCK_UPDATE_REDSTONE) || ($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) || ($type === \pocketmine\level\Level::BLOCK_UPDATE_SCHEDULED))) {
				if ((parent::onUpdate($type) === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
					return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
				}
				$powered = $this->isRailPowered();
				if (($powered !== $this->isActive())) {
					$this->setActive($powered);
					$this->getLevel()->updateAround($this->getSide(\pocketmine\math\Vector3::SIDE_DOWN));
					if (in_array($this->getRealMeta(), [self::SLOPED_ASCENDING_NORTH, self::SLOPED_ASCENDING_SOUTH, self::SLOPED_ASCENDING_EAST, self::SLOPED_ASCENDING_WEST], true)) {
						$this->getLevel()->updateAround($this->getSide(\pocketmine\math\Vector3::SIDE_UP));
					}
				}
				return $type;
			}
			return false;
		}

	protected function isRailPowered() {
			return (($this->getLevel()->isBlockPowered($this) || $this->checkSurrounding($this, true, 0)) || $this->checkSurrounding($this, false, 0));
		}

	protected function canPowerRailAt($x = null, $y = null, $z = null, $orientation = null, $power = null, $relative = null) {
			/* decompiled (structured CF) */
			new \pocketmine\math\Vector3($x, $y, $z);
			$block = $this->getLevel()->getBlock(new \pocketmine\math\Vector3($x, $y, $z));
			if (!($block instanceof \pocketmine\math\Vector3)) {
				return false;
			}
			$base = $block->getRealMeta();
			if (((($orientation === self::STRAIGHT_EAST_WEST) && in_array($base, [self::STRAIGHT_NORTH_SOUTH, self::SLOPED_ASCENDING_NORTH, self::SLOPED_ASCENDING_SOUTH], true)) || (($orientation === self::STRAIGHT_NORTH_SOUTH) && in_array($base, [self::STRAIGHT_EAST_WEST, self::SLOPED_ASCENDING_EAST, self::SLOPED_ASCENDING_WEST], true)))) {
				return false;
			}
			return ($this->getLevel()->isBlockPowered($block) || $this->checkSurrounding($block, $relative, ($power + 1)));
		}

	protected function checkSurrounding($pos = null, $relative = null, $power = null) {
			/* decompiled (structured CF) */
			if ((8 <= $power)) {
				return false;
			}
			$dx = (floor($pos->x));
			$dy = (floor($pos->y));
			$dz = (floor($pos->z));
			new \pocketmine\math\Vector3($dx, $dy, $dz);
			$block = $this->getLevel()->getBlock(new \pocketmine\math\Vector3($dx, $dy, $dz));
			if (!($block instanceof \pocketmine\block\Rail)) {
				return false;
			}
			$base = null;
			$onStraight = true;
			switch ($block->getRealMeta()) {
				case self::STRAIGHT_EAST_WEST:
				if ($relative) {
					$dz++;
				} else {
					$dz--;
				}
				$base = self::STRAIGHT_EAST_WEST;
				break;
				case self::STRAIGHT_NORTH_SOUTH:
				if ($relative) {
					$dx--;
				} else {
					$dx++;
				}
				$base = self::STRAIGHT_NORTH_SOUTH;
				break;
				case self::SLOPED_ASCENDING_NORTH:
				if ($relative) {
					$dx--;
				} else {
					$dx++;
					$dy++;
					$onStraight = false;
				}
				$base = self::STRAIGHT_NORTH_SOUTH;
				break;
				case self::SLOPED_ASCENDING_SOUTH:
				if ($relative) {
					$dx--;
					$dy++;
					$onStraight = false;
				} else {
					$dx++;
				}
				$base = self::STRAIGHT_NORTH_SOUTH;
				break;
				case self::SLOPED_ASCENDING_EAST:
				if ($relative) {
					$dz++;
				} else {
					$dz--;
					$dy++;
					$onStraight = false;
				}
				$base = self::STRAIGHT_EAST_WEST;
				break;
				case self::SLOPED_ASCENDING_WEST:
				if ($relative) {
					$dz++;
					$dy++;
					$onStraight = false;
				} else {
					$dz--;
				}
				$base = self::STRAIGHT_EAST_WEST;
				break;
				return false;
			}
			return ($this->canPowerRailAt($dx, $dy, $dz, $base, $power, $relative) || ($onStraight && $this->canPowerRailAt($dx, ($dy - 1), $dz, $base, $power, $relative)));
		}

	public function canConnect($block = null) {
			/* decompiled (structured CF) */
			if ((2 < $this->distanceSquared($block))) {
				return false;
			}
			$blocks = self::check($this);
			if ((count($blocks) == 2)) {
				return false;
			}
			if (isset($blocks[0])) {
				$v3 = $blocks[0]->subtract($this);
				$v33 = $block->subtract($this);
				if (((abs($v3->x) == abs($v33->z)) && (abs($v3->z) == abs($v33->x)))) {
					return false;
				}
			}
			return $blocks;
		}

	public function isBlock($block = null) {
			/* decompiled (structured CF) */
			if ($block instanceof \pocketmine\block\AIR) {
				return false;
			}
			return $block;
		}

	public function connect($rail = null, $force = null) {
			/* decompiled (structured CF) */
			if (!($force)) {
				$connected = $this->canConnect($rail);
				if (!(is_array($connected))) {
					return false;
				}
				$connected[] = $rail;
				switch (count($connected)) {
					case 1:
					$v3 = $connected[0]->subtract($this);
					if (($v3->y != 1)) {
						if (($v3->x == 0)) {
						} else {
						}
					} else {
						if (($v3->z == 0)) {
						} else {
						}
					}
					$this->meta = (($v3->z / 2) + 4.5);
					/* jump */
					case 2:
					$subtract = ['__array_ptr' => '2aaaac9fc9a0'];
					foreach ($connected as $key => $value) {
						$subtract[$key] = $value->subtract($this);
						/* goto */
					}
					if (((abs($subtract[0]->x) == abs($subtract[1]->z)) && (abs($subtract[1]->x) == abs($subtract[0]->z)))) {
						$v3 = $connected[0]->subtract($this)->add($connected[1]->subtract($this));
						if (($v3->x == 1)) {
							if (($v3->z == 1)) {
							} else {
							}
						} else {
							if (($v3->z == 1)) {
							} else {
							}
						}
						$this->meta = 8;
					} else {
						if ((($subtract[0]->y == 1) || ($subtract[1]->y == 1))) {
							if (($subtract[0]->y == 1)) {
							} else {
							}
							$v3 = $subtract[1];
							if (($v3->x == 0)) {
								if (($v3->x == -1)) {
								} else {
								}
							} else {
								if (($v3->x == 1)) {
								} else {
								}
							}
							$this->meta = 3;
						} else {
							if (($subtract[0]->x == 0)) {
							} else {
							}
							$this->meta = 1;
						}
					}
					/* jump */
					/* jump */
					$this->meta = ($this->meta);
					$this->level->setBlock($this, \pocketmine\block\Block::get($this->id, $this->meta), true, true);
					return true;
				}
			}
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$downBlock = $this->getSide(\pocketmine\math\Vector3::SIDE_DOWN);
			if (($downBlock instanceof \pocketmine\block\Rail || !($this->isBlock($downBlock)))) {
				return false;
			}
			$arrayXZ = ['__array_ptr' => '2aaaadd5d8f8'];
			$arrayY = ['__array_ptr' => '2aaaadd5da10'];
			$connected = ['__array_ptr' => '2aaaac9fc9a0'];
			foreach ($arrayXZ as $key => $xz) {
				foreach ($arrayY as $y) {
					new \pocketmine\math\Vector3($xz[0], $y, $xz[1]);
					$v3 = (new \pocketmine\math\Vector3($xz[0], $y, $xz[1]))->add($this);
					$block = $this->level->getBlock($v3);
					if ($block instanceof \pocketmine\block\Rail) {
						if ($block->connect($this)) {
							$connected[] = $v3;
							if (($key <= 1)) {
								$xz = $arrayXZ[($key + 1)];
								foreach ($arrayY as $yy) {
									new \pocketmine\math\Vector3($xz[0], $yy, $xz[1]);
									$v3 = (new \pocketmine\math\Vector3($xz[0], $yy, $xz[1]))->add($this);
									$block = $this->level->getBlock($v3);
									if ($block instanceof \pocketmine\block\Rail) {
										if ($block->connect($this)) {
											$connected[] = $v3;
										}
									}
									/* goto */
								}
							}
						} else {
							/* goto */
						}
						if ((1 <= count($connected))) {
						} else {
							/* goto */
						}
						switch (count($connected)) {
							case 1:
							$v3 = $connected[0]->subtract($this);
							if (($v3->y != 1)) {
								if (($v3->x == 0)) {
								} else {
								}
							} else {
								if (($v3->z == 0)) {
								} else {
								}
							}
							$this->meta = (($v3->z / 2) + 4.5);
							/* jump */
							case 2:
							$subtract = ['__array_ptr' => '2aaaac9fc9a0'];
							foreach ($connected as $key => $value) {
								$subtract[$key] = $value->subtract($this);
								/* goto */
							}
							if (((abs($subtract[0]->x) == abs($subtract[1]->z)) && (abs($subtract[1]->x) == abs($subtract[0]->z)))) {
								$v3 = $connected[0]->subtract($this)->add($connected[1]->subtract($this));
								if (($v3->x == 1)) {
									if (($v3->z == 1)) {
									} else {
									}
								} else {
									if (($v3->z == 1)) {
									} else {
									}
								}
								$this->meta = 8;
							} else {
								if ((($subtract[0]->y == 1) || ($subtract[1]->y == 1))) {
									if (($subtract[0]->y == 1)) {
									} else {
									}
									$v3 = $subtract[1];
									if (($v3->x == 0)) {
										if (($v3->x == -1)) {
										} else {
										}
									} else {
										if (($v3->x == 1)) {
										} else {
										}
									}
									$this->meta = 3;
								} else {
									if (($subtract[0]->x == 0)) {
									} else {
									}
									$this->meta = 1;
								}
							}
							/* jump */
							/* jump */
							$this->meta = ($this->meta);
							$this->level->setBlock($this, \pocketmine\block\Block::get($this->id, $this->meta), true, true);
							return true;
						}
					}
				}
			}
		}

	public function getHardness() {
			return 0.7;
		}

	public function canPassThrough() {
			return true;
		}

}
