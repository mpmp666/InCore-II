<?php

namespace pocketmine\block;

class RedSandstone extends \pocketmine\block\Sandstone {
	protected $id = 179;

	public function getName() {
			return $names[($this->meta & 3)];
		}

}
