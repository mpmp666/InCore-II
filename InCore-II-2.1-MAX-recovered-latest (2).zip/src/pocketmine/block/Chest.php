<?php

namespace pocketmine\block;

class Chest extends \pocketmine\block\Transparent {
	protected $id = 54;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function canBeActivated() {
			return true;
		}

	public function getHardness() {
			return 2.5;
		}

	public function getName() {
			return 'Chest';
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_AXE;
		}

	protected function recalculateBoundingBox() {
			new \pocketmine\math\AxisAlignedBB(($this->x + 0.0625), $this->y, ($this->z + 0.0625), ($this->x + 0.9375), ($this->y + 0.9475), ($this->z + 0.9375));
			return new \pocketmine\math\AxisAlignedBB(($this->x + 0.0625), $this->y, ($this->z + 0.0625), ($this->x + 0.9375), ($this->y + 0.9475), ($this->z + 0.9375));
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$faces = ['__array_ptr' => '2aaaadd5d540'];
			$chest = null;
			if ($player instanceof \pocketmine\Player) {
			} else {
			}
			$this->meta = $faces[0];
			$side = 2;
			while (($side <= 5)) {
				if (((($this->meta === 4) || ($this->meta === 5)) && (($side === 4) || ($side === 5)))) {
					/* jump */
				} else {
					if (((($this->meta === 3) || ($this->meta === 2)) && (($side === 2) || ($side === 3)))) {
					} else {
						$c = $this->getSide($side);
						if (($c instanceof \pocketmine\block\Chest && ($c->getDamage() === $this->meta))) {
							$tile = $this->getLevel()->getTile($c);
							if (($tile instanceof \pocketmine\tile\Chest && !($tile->isPaired()))) {
								$chest = $tile;
							} else {
								$side++;
							}
							$this->getLevel()->setBlock($block, $this, true, true);
							new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']);
							new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::CHEST);
							new \pocketmine\nbt\tag\IntTag('x', $this->x);
							new \pocketmine\nbt\tag\IntTag('y', $this->y);
							new \pocketmine\nbt\tag\IntTag('z', $this->z);
							new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']), new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::CHEST), new \pocketmine\nbt\tag\IntTag('x', $this->x), new \pocketmine\nbt\tag\IntTag('y', $this->y), new \pocketmine\nbt\tag\IntTag('z', $this->z)]);
							$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']), new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::CHEST), new \pocketmine\nbt\tag\IntTag('x', $this->x), new \pocketmine\nbt\tag\IntTag('y', $this->y), new \pocketmine\nbt\tag\IntTag('z', $this->z)]);
							$nbt->Items->setTagType(\pocketmine\nbt\NBT::TAG_Compound);
							if ($item->hasCustomName()) {
								new \pocketmine\nbt\tag\StringTag('CustomName', $item->getCustomName());
								$nbt->CustomName = new \pocketmine\nbt\tag\StringTag('CustomName', $item->getCustomName());
							}
							if ($item->hasCustomBlockData()) {
								foreach ($item->getCustomBlockData() as $key => $v) {
									$nbt->prop = $v;
									/* goto */
								}
							}
							$tile = \pocketmine\tile\Tile::createTile('Chest', $this->getLevel()->getChunk(($this->x >> 4), ($this->z >> 4)), $nbt);
							if (($chest instanceof \pocketmine\tile\Chest && $tile instanceof \pocketmine\tile\Chest)) {
								$chest->pairWith($tile);
								$tile->pairWith($chest);
							}
							return true;
						}
					}
				}
			}
		}

	public function onBreak($item = null) {
			/* decompiled (structured CF) */
			$t = $this->getLevel()->getTile($this);
			if ($t instanceof \pocketmine\tile\Chest) {
				$t->unpair();
			}
			new \pocketmine\block\Air();
			$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), true, true);
			return true;
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			if ($player instanceof \pocketmine\Player) {
				$top = $this->getSide(1);
				if (($top->isTransparent() !== true)) {
					return true;
				}
				$t = $this->getLevel()->getTile($this);
				$chest = null;
				if ($t instanceof \pocketmine\tile\Chest) {
					$chest = $t;
				} else {
					new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']);
					new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::CHEST);
					new \pocketmine\nbt\tag\IntTag('x', $this->x);
					new \pocketmine\nbt\tag\IntTag('y', $this->y);
					new \pocketmine\nbt\tag\IntTag('z', $this->z);
					new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']), new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::CHEST), new \pocketmine\nbt\tag\IntTag('x', $this->x), new \pocketmine\nbt\tag\IntTag('y', $this->y), new \pocketmine\nbt\tag\IntTag('z', $this->z)]);
					$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Items', ['__array_ptr' => '2aaaac9fc9a0']), new \pocketmine\nbt\tag\StringTag('id', \pocketmine\tile\Tile::CHEST), new \pocketmine\nbt\tag\IntTag('x', $this->x), new \pocketmine\nbt\tag\IntTag('y', $this->y), new \pocketmine\nbt\tag\IntTag('z', $this->z)]);
					$nbt->Items->setTagType(\pocketmine\nbt\NBT::TAG_Compound);
					$chest = \pocketmine\tile\Tile::createTile('Chest', $this->getLevel()->getChunk(($this->x >> 4), ($this->z >> 4)), $nbt);
				}
				if ((isset($chest->namedtag->Lock) && $chest->namedtag->Lock instanceof \pocketmine\nbt\tag\StringTag)) {
					if (($chest->namedtag->Lock->getValue() !== $item->getCustomName())) {
						return true;
					}
				}
				if (($player->isCreative() && $player->getServer()->limitedCreative)) {
					return true;
				}
				$player->addWindow($chest->getInventory());
			}
			return true;
		}

	public function getDrops($item = null) {
			return [[$this->id, 0, 1]];
		}

	public function hasComparatorInputOverride() {
			return true;
		}

	public function getComparatorInputOverride() {
			/* decompiled (structured CF) */
			$tile = $this->getLevel()->getTile($this);
			if ($tile instanceof \pocketmine\tile\Chest) {
			} else {
			}
			return 0;
		}

}
