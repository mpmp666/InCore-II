<?php

namespace pocketmine\block;

class RedMushroomBlock extends \pocketmine\block\Solid {
	public const RED = 14;
	public const STEM = 10;

	protected $id = 100;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function canBeActivated() {
			return true;
		}

	public function getName() {
			return;
		}

	public function getHardness() {
			return 0.2;
		}

	public function getResistance() {
			return 1;
		}

	public function getDrops($item = null) {
			/* decompiled (structured CF) */
			if ((0 < $item->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_SILK_TOUCH))) {
				return [[\pocketmine\item\Item::RED_MUSHROOM_BLOCK, self::RED, 1]];
			} else {
				return [[\pocketmine\item\Item::RED_MUSHROOM, 0, mt_rand(0, 2)]];
			}
		}

}
