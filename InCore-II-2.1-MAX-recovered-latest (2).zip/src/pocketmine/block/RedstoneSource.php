<?php

namespace pocketmine\block;

class RedstoneSource extends \pocketmine\block\Flowable {
	protected $maxStrength = 15;
	protected $activated = false;

	public function __construct() {
			// empty
		}

	public function getMaxStrength() {
			return $this->maxStrength;
		}

	public function isPowerSource() {
			return true;
		}

	public function getWeakPower($side = null) {
			return $this->getStrength();
		}

	public function getStrongPower($side = null) {
			return $this->getWeakPower($side);
		}

	public function isActivated($from = null) {
			return $this->activated;
		}

	public function canCalc() {
			return $this->getLevel()->getServer()->redstoneEnabled;
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$this->getLevel()->setBlock($this, $this, true);
			if ($this->isActivated()) {
				$this->activate();
			}
			return null;
		}

	public function onBreak($item = null) {
			/* decompiled (structured CF) */
			new \pocketmine\block\Air();
			$this->getLevel()->setBlock($this, new \pocketmine\block\Air(), true);
			if ($this->isActivated()) {
				$this->deactivate();
			}
			return null;
		}

	public function activateBlockWithoutWire($block = null) {
			/* decompiled (structured CF) */
			if ((($block instanceof \pocketmine\block\Door || $block instanceof \pocketmine\block\Trapdoor) || $block instanceof \pocketmine\block\FenceGate)) {
				if (!($block->isOpened())) {
					new \pocketmine\item\Item(0);
					$block->onActivate(new \pocketmine\item\Item(0));
				}
			}
			if (($block->getId() == \pocketmine\block\Block::TNT)) {
				new \pocketmine\item\Item(\pocketmine\item\Item::FLINT_AND_STEEL);
				$block->onActivate(new \pocketmine\item\Item(\pocketmine\item\Item::FLINT_AND_STEEL));
			}
			if (($block->getId() == \pocketmine\block\Block::INACTIVE_REDSTONE_LAMP)) {
				$block->turnOn();
			}
			if ((($block->getId() == \pocketmine\block\Block::DROPPER) || ($block->getId() == \pocketmine\block\Block::DISPENSER))) {
				$block->activate();
			}
			if (($block->getId() == \pocketmine\block\Block::UNPOWERED_REPEATER)) {
				if ($this->equals($block->getSide($block->getDirection()))) {
					$block->activate();
				}
			}
			return null;
		}

	public function activateBlock($block = null) {
			/* decompiled (structured CF) */
			$this->activateBlockWithoutWire($block);
			if (($block->getId() == \pocketmine\block\Block::REDSTONE_WIRE)) {
				$wire = $block;
				$wire->calcSignal($this->maxStrength, \pocketmine\block\RedstoneWire::ON);
			}
			return null;
		}

	public function deactivateBlock($block = null) {
			/* decompiled (structured CF) */
			$this->deactivateBlockWithoutWire($block);
			if (($block->getId() == \pocketmine\block\Block::REDSTONE_WIRE)) {
				$wire = $block;
				$wire->calcSignal(0, \pocketmine\block\RedstoneWire::OFF);
			}
			return null;
		}

	public function deactivateBlockWithoutWire($block = null) {
			/* decompiled (structured CF) */
			if (!($this->checkPower($block))) {
				if ((($block instanceof \pocketmine\block\Door || $block instanceof \pocketmine\block\Trapdoor) || $block instanceof \pocketmine\block\FenceGate)) {
					if ($block->isOpened()) {
						new \pocketmine\item\Item(0);
						$block->onActivate(new \pocketmine\item\Item(0));
					}
				}
				if (($block->getId() == \pocketmine\block\Block::ACTIVE_REDSTONE_LAMP)) {
					$block->turnOff();
				}
			}
			if (($block->getId() == \pocketmine\block\Block::POWERED_REPEATER)) {
				if ($this->equals($block->getSide($block->getDirection()))) {
					$block->deactivate();
				}
			}
			return null;
		}

	public function activate($ignore = null) {
			/* decompiled (structured CF) */
			if ($this->canCalc()) {
				$this->activated = true;
				$sides = [\pocketmine\math\Vector3::SIDE_EAST, \pocketmine\math\Vector3::SIDE_WEST, \pocketmine\math\Vector3::SIDE_SOUTH, \pocketmine\math\Vector3::SIDE_NORTH, \pocketmine\math\Vector3::SIDE_DOWN];
				foreach ($sides as $side) {
					if (!(in_array($side, $ignore))) {
						$block = $this->getSide($side);
						$this->activateBlock($block);
					}
					/* goto */
				}
			}
			return null;
		}

	public function deactivate($ignore = null) {
			/* decompiled (structured CF) */
			if ($this->canCalc()) {
				$this->activated = false;
				$sides = [\pocketmine\math\Vector3::SIDE_EAST, \pocketmine\math\Vector3::SIDE_WEST, \pocketmine\math\Vector3::SIDE_SOUTH, \pocketmine\math\Vector3::SIDE_NORTH];
				foreach ($sides as $side) {
					if (!(in_array($side, $ignore))) {
						$block = $this->getSide($side);
						$this->deactivateBlock($block);
					}
					/* goto */
				}
				if (!(in_array(\pocketmine\math\Vector3::SIDE_DOWN, $ignore))) {
					$block = $this->getSide(\pocketmine\math\Vector3::SIDE_DOWN);
					if (!($this->checkPower($block))) {
						if (($block->getId() == \pocketmine\block\Block::ACTIVE_REDSTONE_LAMP)) {
							$block->turnOff();
						}
					}
					$block = $this->getSide(\pocketmine\math\Vector3::SIDE_DOWN, 2);
					$this->deactivateBlock($block);
				}
			}
			return null;
		}

	public function checkPower($block = null, $ignore = null, $ignoreWire = null) {
			/* decompiled (structured CF) */
			if ($block instanceof \pocketmine\block\PoweredRepeater) {
				if ($block->getSide($block->getDirection())->isActivated($block)) {
					return true;
				}
				return false;
			}
			$sides = [\pocketmine\math\Vector3::SIDE_EAST, \pocketmine\math\Vector3::SIDE_WEST, \pocketmine\math\Vector3::SIDE_SOUTH, \pocketmine\math\Vector3::SIDE_NORTH];
			foreach ($sides as $side) {
				if (!(in_array($side, $ignore))) {
					$pos = $block->getSide($side);
					if ($pos instanceof \pocketmine\block\RedstoneSource) {
						if ($pos->isActivated($this)) {
							if ((($ignoreWire && ($pos->getId() != self::REDSTONE_WIRE)) || (!($ignoreWire) && ($pos->getId() != self::REDSTONE_WIRE)))) {
								return true;
							}
							if ((!($ignoreWire) && ($pos->getId() == self::REDSTONE_WIRE))) {
								if ((0 < $pos->getWeakPower($side))) {
									return true;
								}
							}
						}
					}
				}
				/* goto */
			}
			if ((($block->getId() == \pocketmine\block\Block::ACTIVE_REDSTONE_LAMP) && !(in_array(\pocketmine\math\Vector3::SIDE_UP, $ignore)))) {
				$pos = $block->getSide(\pocketmine\math\Vector3::SIDE_UP);
				if (($pos instanceof \pocketmine\block\RedstoneSource && ($pos->getId() != self::REDSTONE_TORCH))) {
					if ($pos->isActivated($this)) {
						return true;
					}
				}
			}
			return false;
		}

	public function checkTorchOn($pos = null, $ignore = null) {
			/* decompiled (structured CF) */
			$sides = [\pocketmine\math\Vector3::SIDE_EAST, \pocketmine\math\Vector3::SIDE_WEST, \pocketmine\math\Vector3::SIDE_SOUTH, \pocketmine\math\Vector3::SIDE_NORTH, \pocketmine\math\Vector3::SIDE_UP];
			foreach ($sides as $side) {
				if (!(in_array($side, $ignore))) {
					$block = $pos->getSide($side);
					if (($block->getId() == self::REDSTONE_TORCH)) {
						$faces = ['__array_ptr' => '2aaaadd5dd58'];
						if ($block->getSide($faces[$block->meta])->equals($pos)) {
							$ignoreBlock = $this->getSide($this->getOppositeSide($faces[$block->meta]));
							$block->turnOff(\pocketmine\level\Level::blockHash($ignoreBlock->x, $ignoreBlock->y, $ignoreBlock->z));
						}
					}
				}
				/* goto */
			}
			return null;
		}

	public function checkTorchOff($pos = null, $ignore = null) {
			/* decompiled (structured CF) */
			$sides = [\pocketmine\math\Vector3::SIDE_EAST, \pocketmine\math\Vector3::SIDE_WEST, \pocketmine\math\Vector3::SIDE_SOUTH, \pocketmine\math\Vector3::SIDE_NORTH, \pocketmine\math\Vector3::SIDE_UP];
			foreach ($sides as $side) {
				if (!(in_array($side, $ignore))) {
					$block = $pos->getSide($side);
					if (($block->getId() == self::UNLIT_REDSTONE_TORCH)) {
						$faces = ['__array_ptr' => '2aaaadd5ddc8'];
						if ($block->getSide($faces[$block->meta])->equals($pos)) {
							$ignoreBlock = $this->getSide($this->getOppositeSide($faces[$block->meta]));
							$block->turnOn(\pocketmine\level\Level::blockHash($ignoreBlock->x, $ignoreBlock->y, $ignoreBlock->z));
						}
					}
				}
				/* goto */
			}
			return null;
		}

	public function getStrength() {
			/* decompiled (structured CF) */
			if ($this->isActivated()) {
				return $this->maxStrength;
			}
			return 0;
		}

}
