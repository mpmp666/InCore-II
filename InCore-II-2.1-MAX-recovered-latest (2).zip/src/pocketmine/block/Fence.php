<?php

namespace pocketmine\block;

class Fence extends \pocketmine\block\Transparent {
	public const FENCE_OAK = 0;
	public const FENCE_SPRUCE = 1;
	public const FENCE_BIRCH = 2;
	public const FENCE_JUNGLE = 3;
	public const FENCE_ACACIA = 4;
	public const FENCE_DARKOAK = 5;

	protected $id = 85;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function getHardness() {
			return 2;
		}

	public function getToolType() {
			return \pocketmine\item\Tool::TYPE_AXE;
		}

	public function getBurnChance() {
			return 5;
		}

	public function getBurnAbility() {
			return 20;
		}

	public function getName() {
			return $names[($this->meta & 7)];
		}

	protected function recalculateBoundingBox() {
			/* decompiled (structured CF) */
			$north = $this->canConnect($this->getSide(\pocketmine\math\Vector3::SIDE_NORTH));
			$south = $this->canConnect($this->getSide(\pocketmine\math\Vector3::SIDE_SOUTH));
			$west = $this->canConnect($this->getSide(\pocketmine\math\Vector3::SIDE_WEST));
			$east = $this->canConnect($this->getSide(\pocketmine\math\Vector3::SIDE_EAST));
			if ($north) {
			} else {
			}
			$n = 0.375;
			if ($south) {
			} else {
			}
			$s = 0.625;
			if ($west) {
			} else {
			}
			$w = 0.375;
			if ($east) {
			} else {
			}
			$e = 0.625;
			new \pocketmine\math\AxisAlignedBB(($this->x + $w), $this->y, ($this->z + $n), ($this->x + $e), ($this->y + 1.5), ($this->z + $s));
			return new \pocketmine\math\AxisAlignedBB(($this->x + $w), $this->y, ($this->z + $n), ($this->x + $e), ($this->y + 1.5), ($this->z + $s));
		}

	public function canConnect($block = null) {
			/* decompiled (structured CF) */
			if (($block instanceof \pocketmine\block\Fence || $block instanceof \pocketmine\block\FenceGate)) {
			} else {
			}
			return ($block->isSolid() && !($block->isTransparent()));
		}

}
