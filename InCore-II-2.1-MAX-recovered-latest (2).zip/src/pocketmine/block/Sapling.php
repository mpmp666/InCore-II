<?php

namespace pocketmine\block;

class Sapling extends \pocketmine\block\Flowable {
	public const OAK = 0;
	public const SPRUCE = 1;
	public const BIRCH = 2;
	public const JUNGLE = 3;
	public const ACACIA = 4;
	public const DARK_OAK = 5;
	public const GOLDEN = 6;
	public const PINK = 7;

	protected $id = 6;

	public function __construct($meta = null) {
			$this->meta = $meta;
		}

	public function canBeActivated() {
			return true;
		}

	public function getName() {
			return $names[($this->meta & 7)];
		}

	public function place($item = null, $block = null, $target = null, $face = null, $fx = null, $fy = null, $fz = null, $player = null) {
			/* decompiled (structured CF) */
			$down = $this->getSide(0);
			if ((((($down->getId() === self::GRASS) || ($down->getId() === self::DIRT)) || ($down->getId() === self::FARMLAND)) || ($down->getId() === self::PODZOL))) {
				$this->getLevel()->setBlock($block, $this, true, true);
				return true;
			}
			return false;
		}

	public function onActivate($item = null, $player = null) {
			/* decompiled (structured CF) */
			if ((($item->getId() === \pocketmine\item\Item::DYE) && ($item->getDamage() === 15))) {
				new \pocketmine\utils\Random(mt_rand());
				\pocketmine\level\generator\object\Tree::growTree($this->getLevel(), $this->x, $this->y, $this->z, new \pocketmine\utils\Random(mt_rand()), ($this->meta & 7));
				if ((($player->gamemode & 1) === 0)) {
				}
				return true;
			}
			return false;
		}

	public function onUpdate($type = null) {
			/* decompiled (structured CF) */
			if (($type === \pocketmine\level\Level::BLOCK_UPDATE_NORMAL)) {
				if (($this->getSide(0)->isTransparent() === true)) {
					$this->getLevel()->useBreakOn($this);
					return \pocketmine\level\Level::BLOCK_UPDATE_NORMAL;
				}
			} else {
				if (($type === \pocketmine\level\Level::BLOCK_UPDATE_RANDOM)) {
					if ((mt_rand(1, 7) === 1)) {
						if ((($this->meta & 8) === 8)) {
							new \pocketmine\utils\Random(mt_rand());
							\pocketmine\level\generator\object\Tree::growTree($this->getLevel(), $this->x, $this->y, $this->z, new \pocketmine\utils\Random(mt_rand()), ($this->meta & 7));
						} else {
							$this->meta |= 8;
							$this->getLevel()->setBlock($this, $this, true);
							return \pocketmine\level\Level::BLOCK_UPDATE_RANDOM;
						}
					} else {
						return \pocketmine\level\Level::BLOCK_UPDATE_RANDOM;
					}
				}
			}
			return false;
		}

	public function getDrops($item = null) {
			return [[$this->id, ($this->meta & 7), 1]];
		}

}
