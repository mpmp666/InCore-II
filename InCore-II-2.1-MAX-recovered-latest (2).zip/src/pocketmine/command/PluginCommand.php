<?php

namespace pocketmine\command;

class PluginCommand extends \pocketmine\command\Command implements \pocketmine\command\PluginIdentifiableCommand {
	private $owningPlugin = NULL;
	private $executor = NULL;

	public function __construct($name = null, $owner = null) {
			/* decompiled (structured CF) */
			parent::__construct($name);
			$this->owningPlugin = $owner;
			$this->executor = $owner;
			$this->usageMessage = '';
			return;
		}

	public function execute($sender = null, $commandLabel = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->owningPlugin->isEnabled())) {
				return false;
			}
			if (!($this->testPermission($sender))) {
				return false;
			}
			$success = $this->executor->onCommand($sender, $this, $commandLabel, $args);
			if ((!($success) && ($this->usageMessage !== ''))) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
			}
			return $success;
		}

	public function getExecutor() {
			return $this->executor;
		}

	public function setExecutor($executor = null) {
			/* decompiled (structured CF) */
			if (($executor != null)) {
			} else {
			}
			$this->executor = $this->owningPlugin;
			return null;
		}

	public function getPlugin() {
			return $this->owningPlugin;
		}

}
