<?php

namespace pocketmine\command;

class CommandReader extends \pocketmine\Thread {
	private $readline = NULL;
	protected $buffer = NULL;
	private $shutdown = false;
	private $stdin = NULL;
	private $logger = NULL;

	public function __construct($logger = null) {
			/* decompiled (structured CF) */
			$this->stdin = fopen('php://stdin', 'r');
			$opts = getopt('', ['__array_ptr' => '2aaaadd5d4d0']);
			if (((extension_loaded('readline') && !(isset($opts['disable-readline']))) && (!(function_exists('posix_isatty')) || posix_isatty($this->stdin)))) {
				$this->readline = true;
			} else {
				$this->readline = false;
			}
			$this->logger = $logger;
			new \Threaded();
			$this->buffer = new \Threaded();
			$this->start();
			return;
		}

	public function shutdown() {
			$this->shutdown = true;
		}

	private function readline_callback($line = null) {
			/* decompiled (structured CF) */
			if (($line !== '')) {
				$this->buffer[] = $line;
				readline_add_history($line);
			}
			return null;
		}

	private function readLine() {
			/* decompiled (structured CF) */
			if (!($this->readline)) {
				$line = trim(fgets($this->stdin));
				if (($line !== '')) {
					$this->buffer[] = $line;
				}
			} else {
				readline_callback_read_char();
			}
			return null;
		}

	public function getLine() {
			if (($this->buffer->count() !== 0)) {
				return $this->buffer->shift();
			}
		}

	public function quit() {
			/* decompiled (structured CF) */
			$this->shutdown();
			if ((\pocketmine\utils\Utils::getOS() != 'win')) {
				parent::quit();
			}
			return null;
		}

	public function run() : void {
			/* decompiled (structured CF) */
			if ($this->readline) {
				readline_callback_handler_install($this, [$this, 'readline_callback']);
				$this->logger->setConsoleCallback('readline_redisplay');
			}
			while (!($this->shutdown)) {
				$r = [$this->stdin];
				$w = null;
				$e = null;
				if ((0 < stream_select($r, $w, $e, 0, 200000))) {
					if (feof($this->stdin)) {
						if ((\pocketmine\utils\Utils::getOS() == 'win')) {
							$this->stdin = fopen('php://stdin', 'r');
							if (!(is_resource($this->stdin))) {
							} else {
								/* jump */
								/* jump */
								$this->readLine();
							}
							if ($this->readline) {
								$this->logger->setConsoleCallback(null);
								readline_callback_handler_remove();
							}
							return;
						}
					}
				}
			}
		}

	public function getThreadName() {
			return 'Console';
		}

}
