<?php

namespace pocketmine\command;

class FormattedCommandAlias extends \pocketmine\command\Command {
	private $formatStrings = array (
);

	public function __construct($alias = null, $formatStrings = null) {
			parent::__construct($alias);
			$this->formatStrings = $formatStrings;
			return;
		}

	public function execute($sender = null, $commandLabel = null, $args = null) {
			/* decompiled (structured CF) */
			$commands = ['__array_ptr' => '2aaaac9fc9a0'];
			$result = false;
			foreach ($this->formatStrings as $formatString) {
				$commands[] = $this->buildCommand($formatString, $args);
				/* jump */
				if ($e instanceof \InvalidArgumentException) {
					$sender->sendMessage((\pocketmine\utils\TextFormat::RED . $e->getMessage()));
				} else {
					new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.exception'));
					$sender->sendMessage(new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.exception')));
					$logger = $sender->getServer()->getLogger();
					if ($logger instanceof \pocketmine\utils\MainLogger) {
						$logger->logException($e);
					}
				}
			}
			return false;
			/* goto */
			foreach ($commands as $command) {
				$result |= \pocketmine\Server::getInstance()->dispatchCommand($sender, $command);
				/* goto */
			}
			return $result;
		}

	private function buildCommand($formatString = null, $args = null) {
			/* decompiled (structured CF) */
			$index = strpos($formatString, '$');
			while (($index !== false)) {
				$start = $index;
				if (((0 < $index) && ($formatString[($start - 1)] === '\\'))) {
					$formatString = (substr($formatString, 0, ($start - 1)) . substr($formatString, $start));
					$index = strpos($formatString, '$', $index);
				} else {
					$required = false;
					if (($formatString[($index + 1)] == '$')) {
						$required = true;
						$index++;
					}
					$index++;
					$argStart = $index;
					while (self::inRange($t38, 0, 9)) {
						$index++;
					}
					if (($argStart === $index)) {
						new \InvalidArgumentException($this);
						throw new \InvalidArgumentException($this);
					}
					$position = intval(substr($formatString, $argStart, $index));
					if (($position === 0)) {
						new \InvalidArgumentException($this);
						throw new \InvalidArgumentException($this);
					}
					$position--;
					$rest = false;
					if ((($index < strlen($formatString)) && ($formatString[$index] === '-'))) {
						$rest = true;
						$index++;
					}
					$end = $index;
					if (($required && (count($args) <= $position))) {
						new \InvalidArgumentException(($this . ($position + 1)));
						throw new \InvalidArgumentException(($this . ($position + 1)));
					}
					$replacement = '';
					if (($rest && ($position < count($args)))) {
						$i = $position;
						while (($i < count($args))) {
							if (($i !== $position)) {
								$replacement .= $this;
							}
							$replacement .= $args[$i];
							$i++;
						}
					} else {
						if (($position < count($args))) {
							$replacement .= $args[$position];
						}
					}
					$formatString = ((substr($formatString, 0, $start) . $replacement) . substr($formatString, $end));
					$index = ($start + strlen($replacement));
					$index = strpos($formatString, '$', $index);
				}
			}
			return $formatString;
		}

	private static function inRange($i = null, $j = null, $k = null) {
			return (($j <= $i) && ($i <= $k));
		}

}
