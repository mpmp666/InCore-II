<?php

namespace pocketmine\command;

interface CommandSender extends \pocketmine\permission\Permissible {
	public function sendMessage($message);

	public function getServer();

	public function getName();

}
