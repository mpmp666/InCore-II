<?php

namespace pocketmine\command\defaults;

class XpCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.xp.description', '%commands.xp.usage');
			$this->setPermission('pocketmine.command.xp');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if ((count($args) != 2)) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return false;
			} else {
				$name = $args[1];
				$player = $sender->getServer()->getPlayerExact($name);
				if ($player instanceof \pocketmine\Player) {
					if ((strcasecmp(substr($args[0], -1), 'L') == 0)) {
						$level = rtrim($args[0], 'Ll');
						if (is_numeric($level)) {
							$player->addExpLevel($level);
							$sender->sendMessage(($this . $name));
						}
					} else {
						if (is_numeric($args[0])) {
							$player->addExperience($args[0]);
							$sender->sendMessage(($this . $name));
						} else {
							$sender->sendMessage($this);
							return false;
						}
					}
				} else {
					new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.player.notFound'));
					$sender->sendMessage(new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.player.notFound')));
					return false;
				}
			}
			return false;
		}

}
