<?php

namespace pocketmine\command\defaults;

class LoadPluginCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, "\xe5\x8a\xa0\xe8\xbd\xbd\xe6\x8f\x92\xe4\xbb\xb6", $this);
			$this->setPermission('pocketmine.command.loadplugin');
			return;
		}

	public function execute($sender = null, $commandLabel = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return false;
			}
			if ((count($args) === 0)) {
				$sender->sendMessage(((\pocketmine\utils\TextFormat::RED . $this) . $this->usageMessage));
				return true;
			}
			if (!(isset($args[0]))) {
				return false;
			}
			$plugin = $sender->getServer()->getPluginManager()->loadPlugin((($sender->getServer()->getPluginPath() . \DIRECTORY_SEPARATOR) . $args[0]));
			if (($plugin != null)) {
				$sender->getServer()->getPluginManager()->enablePlugin($plugin);
				return true;
			}
			return false;
		}

}
