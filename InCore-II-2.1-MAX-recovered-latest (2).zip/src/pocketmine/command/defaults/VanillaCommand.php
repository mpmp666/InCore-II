<?php

namespace pocketmine\command\defaults;

abstract class VanillaCommand extends \pocketmine\command\Command {
	public const MAX_COORD = 30000000;
	public const MIN_COORD = -30000000;

	public function __construct($name = null, $description = null, $usageMessage = null, $aliases = null) {
			parent::__construct($name, $description, $usageMessage, $aliases);
			return;
		}

	protected function getInteger($sender = null, $value = null, $min = null, $max = null) {
			/* decompiled (structured CF) */
			$i = ($value);
			if (($i < $min)) {
				$i = $min;
			} else {
				if (($max < $i)) {
					$i = $max;
				}
			}
			return $i;
		}

	protected function getRelativeDouble($original = null, $sender = null, $input = null, $min = null, $max = null) {
			/* decompiled (structured CF) */
			if (($input[0] === '~')) {
				$value = $this->getDouble($sender, substr($input, 1));
				return ($original + $value);
			}
			return $this->getDouble($sender, $input, $min, $max);
		}

	protected function getDouble($sender = null, $value = null, $min = null, $max = null) {
			/* decompiled (structured CF) */
			$i = ($value);
			if (($i < $min)) {
				$i = $min;
			} else {
				if (($max < $i)) {
					$i = $max;
				}
			}
			return $i;
		}

}
