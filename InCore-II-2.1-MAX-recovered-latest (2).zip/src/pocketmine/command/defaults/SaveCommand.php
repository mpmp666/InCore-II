<?php

namespace pocketmine\command\defaults;

class SaveCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.save.description', '%commands.save.usage');
			$this->setPermission('pocketmine.command.save.perform');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			new \pocketmine\event\TranslationContainer('commands.save.start');
			\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('commands.save.start'));
			foreach ($sender->getServer()->getOnlinePlayers() as $player) {
				$player->save();
				/* goto */
			}
			foreach ($sender->getServer()->getLevels() as $level) {
				$level->save(true);
				/* goto */
			}
			new \pocketmine\event\TranslationContainer('commands.save.success');
			\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('commands.save.success'));
			return true;
		}

}
