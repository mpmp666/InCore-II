<?php

namespace pocketmine\command\defaults;

class GameruleCommand extends \pocketmine\command\defaults\VanillaCommand {
	private static $knownVanillaRules = array (
  0 => 'doMobSpawning',
  1 => 'doMobLoot',
  2 => 'mobGriefing',
  3 => 'tnTExplodes',
  4 => 'naturalRegeneration',
  5 => 'randomTickSpeed',
  6 => 'doEntityDrops',
  7 => 'keepInventory',
  8 => 'doDaylightCycle',
);

	public function __construct($name = null) {
			parent::__construct($name, $this, $this);
			$this->setPermission('pocketmine.command.gamerule');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			$level = $this->getLevelForSender($sender);
			if (!($level instanceof \pocketmine\level\Level)) {
				$sender->sendMessage((\pocketmine\utils\TextFormat::RED . $this));
				return true;
			}
			$server = $sender->getServer();
			$rules = $server->getSupportedGamerules();
			if ((count($args) === 0)) {
				$values = ['__array_ptr' => '2aaaac9fc9a0'];
				foreach (self::$knownVanillaRules as $rule) {
					if (isset($rules[$rule])) {
						$values[] = (($rule . $this) . $this->formatValue($server->getWorldGamerule($level, $rule)));
					}
					/* goto */
				}
				$sender->sendMessage(((($this . $level->getFolderName()) . $this) . implode($this, $values)));
				return true;
			}
			$rule = $this->matchRuleName($args[0], $rules);
			if (($rule === null)) {
				$sender->sendMessage((((\pocketmine\utils\TextFormat::RED . $this) . $args[0]) . '\'.'));
				return true;
			}
			if ((count($args) === 1)) {
				$sender->sendMessage((($rule . $this) . $this->formatValue($server->getWorldGamerule($level, $rule))));
				return true;
			}
			$value = $this->parseValue($sender, $rules[$rule], $args[1]);
			if (($value === null)) {
				return true;
			}
			if (!($server->setWorldGamerule($level, $rule, $value))) {
				$sender->sendMessage((((\pocketmine\utils\TextFormat::RED . $this) . $rule) . '\'.'));
				return true;
			}
			\pocketmine\command\Command::broadcastCommandMessage($sender, ((((($this . $rule) . $this) . $this->formatValue($server->getWorldGamerule($level, $rule))) . $this) . $level->getFolderName()));
			return true;
		}

	private function getLevelForSender($sender = null) {
			/* decompiled (structured CF) */
			if ($sender instanceof \pocketmine\Player) {
				return $sender->getLevel();
			}
			return $sender->getServer()->getDefaultLevel();
		}

	private function matchRuleName($input = null, $rules = null) {
			/* decompiled (structured CF) */
			foreach (array_keys($rules) as $rule) {
				if ((strcasecmp($rule, $input) === 0)) {
					return $rule;
				}
				/* goto */
			}
		}

	private function parseValue($sender = null, $definition = null, $value = null) {
			/* decompiled (structured CF) */
			if (($definition['type'] === 'int')) {
				if (!(preg_match('/^\\d+$/', $value))) {
					new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
					$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
					return null;
				}
				return ($value);
			}
			if ((strcasecmp($value, 'true') === 0)) {
				return true;
			}
			if ((strcasecmp($value, 'false') === 0)) {
				return false;
			}
			new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
			$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
		}

	private function formatValue($value = null) {
			/* decompiled (structured CF) */
			if (is_bool($value)) {
				if ($value) {
				} else {
				}
				return 'false';
			}
			return ($value);
		}

}
