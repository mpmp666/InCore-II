<?php

namespace pocketmine\command\defaults;

class DifficultyCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.difficulty.description', '%commands.difficulty.usage');
			$this->setPermission('pocketmine.command.difficulty');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if ((count($args) !== 1)) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return false;
			}
			$difficulty = \pocketmine\Server::getDifficultyFromString($args[0]);
			if ($sender->getServer()->isHardcore()) {
				$difficulty = 3;
			}
			if (($difficulty !== -1)) {
				$sender->getServer()->setConfigInt('difficulty', $difficulty);
				if (($sender->getServer()->getAIHolder() !== null)) {
					$sender->getServer()->getAIHolder()->RestartSpawnTimer();
				}
				new \pocketmine\network\protocol\SetDifficultyPacket();
				$pk = new \pocketmine\network\protocol\SetDifficultyPacket();
				$pk->difficulty = $sender->getServer()->getDifficulty();
				\pocketmine\Server::broadcastPacket($sender->getServer()->getOnlinePlayers(), $pk);
				new \pocketmine\event\TranslationContainer('commands.difficulty.success', [$difficulty]);
				\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('commands.difficulty.success', [$difficulty]));
			} else {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return false;
			}
			return true;
		}

}
