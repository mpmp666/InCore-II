<?php

namespace pocketmine\command\defaults;

class BanIpCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.ban.ip.description', '%commands.banip.usage');
			$this->setPermission('pocketmine.command.ban.ip');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if ((count($args) === 0)) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return false;
			}
			$value = array_shift($args);
			$reason = implode($this, $args);
			if (preg_match('/^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])$/', $value)) {
				$this->processIPBan($value, $sender, $reason);
				new \pocketmine\event\TranslationContainer('commands.banip.success', [$value]);
				\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('commands.banip.success', [$value]));
			} else {
				$player = $sender->getServer()->getPlayer($value);
				if ($player instanceof \pocketmine\Player) {
					$this->processIPBan($player->getAddress(), $sender, $reason);
					new \pocketmine\event\TranslationContainer('commands.banip.success.players', [$player->getAddress(), $player->getName()]);
					\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('commands.banip.success.players', [$player->getAddress(), $player->getName()]));
				} else {
					new \pocketmine\event\TranslationContainer('commands.banip.invalid');
					$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.banip.invalid'));
					return false;
				}
			}
			return true;
		}

	private function processIPBan($ip = null, $sender = null, $reason = null) {
			/* decompiled (structured CF) */
			$sender->getServer()->getIPBans()->addBan($ip, $reason, null, $sender->getName());
			foreach ($sender->getServer()->getOnlinePlayers() as $player) {
				if (($ip === $player->getAddress())) {
					if (($reason !== '')) {
					} else {
					}
					$player->kick($this);
				}
				/* goto */
			}
			$sender->getServer()->getNetwork()->blockAddress($ip, -1);
			return null;
		}

}
