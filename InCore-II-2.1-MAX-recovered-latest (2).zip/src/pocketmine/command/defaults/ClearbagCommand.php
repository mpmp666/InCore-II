<?php

namespace pocketmine\command\defaults;

class ClearbagCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, "\xe6\xb8\x85\xe7\xa9\xba\xe6\x8c\x87\xe5\xae\x9a\xe7\x8e\xa9\xe5\xae\xb6\xe7\x9a\x84\xe8\x83\x8c\xe5\x8c\x85", $this, ['__array_ptr' => '2aaaac9fc9a0']);
			$this->setPermission('command.kill');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if ($t7) {
				$sender->sendMessage((\pocketmine\utils\TextFormat::RED . $this));
				return false;
			}
			$targetName = array_shift($args);
			$targetPlayer = $sender->getServer()->getPlayer($targetName);
			if ((($targetPlayer === null) || !($targetPlayer->isOnline()))) {
				$sender->sendMessage((\pocketmine\utils\TextFormat::RED . ("\xe9\x94\x99\xe8\xaf\xaf\xef\xbc\x9a\xe7\x8e\xa9\xe5\xae\xb6\xe3\x80\x8c" . "\xe3\x80\x8d\xe4\xb8\x8d\xe5\xad\x98\xe5\x9c\xa8\xe6\x88\x96\xe6\x9c\xaa\xe5\x9c\xa8\xe7\xba\xbf\xef\xbc\x81")));
				return false;
			}
			$targetPlayer->getInventory()->setContents(['__array_ptr' => '2aaaac9fc9a0']);
			$targetPlayer->sendMessage((\pocketmine\utils\TextFormat::GRAY . "\xe4\xbd\xa0\xe7\x9a\x84\xe8\x83\x8c\xe5\x8c\x85\xe5\xb7\xb2\xe8\xa2\xab\xe7\xae\xa1\xe7\x90\x86\xe5\x91\x98\xe6\xb8\x85\xe7\xa9\xba\xef\xbc\x81"));
			$sender->sendMessage((\pocketmine\utils\TextFormat::GREEN . ("\xe6\x88\x90\xe5\x8a\x9f\xe6\xb8\x85\xe7\xa9\xba\xe7\x8e\xa9\xe5\xae\xb6\xe3\x80\x8c" . "\xe3\x80\x8d\xe7\x9a\x84\xe8\x83\x8c\xe5\x8c\x85\xef\xbc\x81")));
			return true;
		}

}
