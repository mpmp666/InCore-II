<?php

namespace pocketmine\command\defaults;

class PingCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, "PING\xe7\x8e\xa9\xe5\xae\xb6", $this);
			return;
		}

	public function execute($sender = null, $commandLabel = null, $args = null) {
			/* decompiled (structured CF) */
			if (!(isset($args[0]))) {
				if (!($sender instanceof \pocketmine\Player)) {
					$sender->sendMessage("\xe5\x8f\xaa\xe8\x83\xbd\xe5\x9c\xa8\xe6\xb8\xb8\xe6\x88\x8f\xe4\xb8\xad\xe4\xbd\xbf\xe7\x94\xa8!");
					return true;
				}
				$ping = $sender->getPing();
				if (($ping <= 60)) {
					$sender->sendMessage((($this . $ping) . $this));
				} else {
					if (($ping <= 90)) {
						$sender->sendMessage((($this . $ping) . $this));
					} else {
						if (($ping <= 150)) {
							$sender->sendMessage((($this . $ping) . $this));
						} else {
							if (($ping <= 190)) {
								$sender->sendMessage((($this . $ping) . $this));
							} else {
								if (($ping <= 210)) {
									$sender->sendMessage((($this . $ping) . $this));
								} else {
									$sender->sendMessage((($this . $ping) . $this));
								}
							}
						}
					}
				}
				return true;
			} else {
				$target = \pocketmine\Server::getInstance()->getPlayer($args[0]);
				if (($target == null)) {
					return $sender->sendMessage((\pocketmine\utils\TextFormat::RED . "\xe6\x89\xbe\xe4\xb8\x8d\xe5\x88\xb0\xe8\xaf\xa5\xe7\x8e\xa9\xe5\xae\xb6"));
				}
				$ping = $target->getPing();
				if (($ping <= 60)) {
					$sender->sendMessage((((("\xc2\xa7a" . $target->getName()) . $this) . $ping) . $this));
				} else {
					if (($ping <= 90)) {
						$sender->sendMessage((((("\xc2\xa72" . $target->getName()) . $this) . $ping) . $this));
					} else {
						if (($ping <= 150)) {
							$sender->sendMessage((((("\xc2\xa7e" . $target->getName()) . $this) . $ping) . $this));
						} else {
							if (($ping <= 190)) {
								$sender->sendMessage((((("\xc2\xa76" . $target->getName()) . $this) . $ping) . $this));
							} else {
								if (($ping <= 210)) {
									$sender->sendMessage((((("\xc2\xa7c" . $target->getName()) . $this) . $ping) . $this));
								} else {
									$sender->sendMessage((((("\xc2\xa74" . $target->getName()) . $this) . $ping) . $this));
								}
							}
						}
					}
				}
			}
			return false;
		}

}
