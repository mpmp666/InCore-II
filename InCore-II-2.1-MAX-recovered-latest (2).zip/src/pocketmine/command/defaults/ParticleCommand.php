<?php

namespace pocketmine\command\defaults;

class ParticleCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.particle.description', '%pocketmine.command.particle.usage');
			$this->setPermission('pocketmine.command.particle');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if ((count($args) < 7)) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return true;
			}
			if ($sender instanceof \pocketmine\Player) {
				$level = $sender->getLevel();
			} else {
				$level = $sender->getServer()->getDefaultLevel();
			}
			$name = strtolower($args[0]);
			new \pocketmine\math\Vector3(($args[1]), ($args[2]), ($args[3]));
			$pos = new \pocketmine\math\Vector3(($args[1]), ($args[2]), ($args[3]));
			$xd = ($args[4]);
			$yd = ($args[5]);
			$zd = ($args[6]);
			if (isset($args[7])) {
			} else {
			}
			$count = 1;
			if (isset($args[8])) {
			} else {
			}
			$data = null;
			$particle = $this->getParticle($name, $pos, $xd, $yd, $zd, $data);
			if (($particle === null)) {
				new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.particle.notFound'), [$name]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.particle.notFound'), [$name]));
				return true;
			}
			new \pocketmine\event\TranslationContainer('commands.particle.success', [$name, $count]);
			$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.particle.success', [$name, $count]));
			new \pocketmine\utils\Random((((microtime(true) * 1000)) + mt_rand()));
			$random = new \pocketmine\utils\Random((((microtime(true) * 1000)) + mt_rand()));
			$i = 0;
			while (($i < $count)) {
				$particle->setComponents(($pos->x + ($xd * $random->nextSignedFloat())), ($pos->y + ($yd * $random->nextSignedFloat())), ($pos->z + ($zd * $random->nextSignedFloat())));
				$level->addParticle($particle);
				$i++;
			}
			return true;
		}

	private function getParticle($name = null, $pos = null, $xd = null, $yd = null, $zd = null, $data = null) {
			/* decompiled (structured CF) */
			if (!(($name == 'explode'))) {
				if (!(($name == 'largeexplode'))) {
					if (!(($name == 'hugeexplosion'))) {
						if (!(($name == 'bubble'))) {
							if (!(($name == 'splash'))) {
								if (!(($name == 'wake'))) {
									if (!(($name == 'water'))) {
										if (!(($name == 'crit'))) {
											if (!(($name == 'smoke'))) {
												if (!(($name == 'spell'))) {
													if (!(($name == 'instantspell'))) {
														if (!(($name == 'dripwater'))) {
															if (!(($name == 'driplava'))) {
																if (!(($name == 'townaura'))) {
																	if (!(($name == 'spore'))) {
																		if (!(($name == 'portal'))) {
																			if (!(($name == 'flame'))) {
																				if (!(($name == 'lava'))) {
																					if (!(($name == 'reddust'))) {
																						if (!(($name == 'snowballpoof'))) {
																							if (!(($name == 'slime'))) {
																								if (!(($name == 'itembreak'))) {
																									if (!(($name == 'terrain'))) {
																										if (!(($name == 'heart'))) {
																											if (!(($name == 'ink'))) {
																												if (!(($name == 'droplet'))) {
																													if (!(($name == 'enchantmenttable'))) {
																														if (!(($name == 'happyvillager'))) {
																															if (!(($name == 'angryvillager'))) {
																																/* jump */
																																new \pocketmine\level\particle\ExplodeParticle($pos);
																																return new \pocketmine\level\particle\ExplodeParticle($pos);
																																new \pocketmine\level\particle\LargeExplodeParticle($pos);
																																return new \pocketmine\level\particle\LargeExplodeParticle($pos);
																																new \pocketmine\level\particle\HugeExplodeParticle($pos);
																																return new \pocketmine\level\particle\HugeExplodeParticle($pos);
																																new \pocketmine\level\particle\BubbleParticle($pos);
																																return new \pocketmine\level\particle\BubbleParticle($pos);
																																new \pocketmine\level\particle\SplashParticle($pos);
																																return new \pocketmine\level\particle\SplashParticle($pos);
																																new \pocketmine\level\particle\WaterParticle($pos);
																																return new \pocketmine\level\particle\WaterParticle($pos);
																																new \pocketmine\level\particle\CriticalParticle($pos);
																																return new \pocketmine\level\particle\CriticalParticle($pos);
																																if (($data !== null)) {
																																} else {
																																}
																																new \pocketmine\level\particle\SmokeParticle($pos, 0);
																																return new \pocketmine\level\particle\SmokeParticle($pos, 0);
																																new \pocketmine\level\particle\EnchantParticle($pos);
																																return new \pocketmine\level\particle\EnchantParticle($pos);
																																new \pocketmine\level\particle\InstantEnchantParticle($pos);
																																return new \pocketmine\level\particle\InstantEnchantParticle($pos);
																																new \pocketmine\level\particle\WaterDripParticle($pos);
																																return new \pocketmine\level\particle\WaterDripParticle($pos);
																																new \pocketmine\level\particle\LavaDripParticle($pos);
																																return new \pocketmine\level\particle\LavaDripParticle($pos);
																																new \pocketmine\level\particle\SporeParticle($pos);
																																return new \pocketmine\level\particle\SporeParticle($pos);
																																new \pocketmine\level\particle\PortalParticle($pos);
																																return new \pocketmine\level\particle\PortalParticle($pos);
																																new \pocketmine\level\particle\FlameParticle($pos);
																																return new \pocketmine\level\particle\FlameParticle($pos);
																																new \pocketmine\level\particle\LavaParticle($pos);
																																return new \pocketmine\level\particle\LavaParticle($pos);
																																if (($data !== null)) {
																																} else {
																																}
																																new \pocketmine\level\particle\RedstoneParticle($pos, 1);
																																return new \pocketmine\level\particle\RedstoneParticle($pos, 1);
																																new \pocketmine\level\particle\ItemBreakParticle($pos, \pocketmine\item\Item::get(\pocketmine\item\Item::SNOWBALL));
																																return new \pocketmine\level\particle\ItemBreakParticle($pos, \pocketmine\item\Item::get(\pocketmine\item\Item::SNOWBALL));
																																new \pocketmine\level\particle\ItemBreakParticle($pos, \pocketmine\item\Item::get(\pocketmine\item\Item::SLIMEBALL));
																																return new \pocketmine\level\particle\ItemBreakParticle($pos, \pocketmine\item\Item::get(\pocketmine\item\Item::SLIMEBALL));
																																if ((($data !== null) && ($data !== 0))) {
																																	new \pocketmine\level\particle\ItemBreakParticle($pos, $data);
																																	return new \pocketmine\level\particle\ItemBreakParticle($pos, $data);
																																}
																																/* jump */
																																if ((($data !== null) && ($data !== 0))) {
																																	new \pocketmine\level\particle\TerrainParticle($pos, $data);
																																	return new \pocketmine\level\particle\TerrainParticle($pos, $data);
																																}
																																/* jump */
																																if (($data !== null)) {
																																} else {
																																}
																																new \pocketmine\level\particle\HeartParticle($pos, 0);
																																return new \pocketmine\level\particle\HeartParticle($pos, 0);
																																if (($data !== null)) {
																																} else {
																																}
																																new \pocketmine\level\particle\InkParticle($pos, 0);
																																return new \pocketmine\level\particle\InkParticle($pos, 0);
																																new \pocketmine\level\particle\RainSplashParticle($pos);
																																return new \pocketmine\level\particle\RainSplashParticle($pos);
																																new \pocketmine\level\particle\EnchantmentTableParticle($pos);
																																return new \pocketmine\level\particle\EnchantmentTableParticle($pos);
																																new \pocketmine\level\particle\HappyVillagerParticle($pos);
																																return new \pocketmine\level\particle\HappyVillagerParticle($pos);
																															}
																														}
																													}
																												}
																											}
																											new \pocketmine\level\particle\AngryVillagerParticle($pos);
																											return new \pocketmine\level\particle\AngryVillagerParticle($pos);
																											if ((substr($name, 0, 10) === 'iconcrack_')) {
																												$d = explode('_', $name);
																												if ((count($d) === 3)) {
																													new \pocketmine\level\particle\ItemBreakParticle($pos, \pocketmine\item\Item::get(($d[1]), ($d[2])));
																													return new \pocketmine\level\particle\ItemBreakParticle($pos, \pocketmine\item\Item::get(($d[1]), ($d[2])));
																												}
																											} else {
																												if ((substr($name, 0, 11) === 'blockcrack_')) {
																													$d = explode('_', $name);
																													if ((count($d) === 2)) {
																														new \pocketmine\level\particle\TerrainParticle($pos, \pocketmine\block\Block::get(($d[1] & 255), ($d[1] >> 12)));
																														return new \pocketmine\level\particle\TerrainParticle($pos, \pocketmine\block\Block::get(($d[1] & 255), ($d[1] >> 12)));
																													}
																												} else {
																													if ((substr($name, 0, 10) === 'blockdust_')) {
																														$d = explode('_', $name);
																														if ((4 <= count($d))) {
																															if (isset($d[4])) {
																															} else {
																															}
																															new \pocketmine\level\particle\DustParticle($pos, ($d[1] & 255), ($d[2] & 255), ($d[3] & 255), 255);
																															return new \pocketmine\level\particle\DustParticle($pos, ($d[1] & 255), ($d[2] & 255), ($d[3] & 255), 255);
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

}
