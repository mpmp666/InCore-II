<?php

namespace pocketmine\command\defaults;

class PluginsCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.plugins.description', '%pocketmine.command.plugins.usage', ['__array_ptr' => '2aaaadd5d428']);
			$this->setPermission('pocketmine.command.plugins');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if ((!($sender->getServer()->getConfigString('player-view-plugins')) && !($this->testPermission($sender)))) {
				return true;
			}
			$this->sendPluginList($sender);
			return true;
		}

	private function sendPluginList($sender = null) {
			/* decompiled (structured CF) */
			$list = '';
			$plugins = $sender->getServer()->getPluginManager()->getPlugins();
			foreach ($plugins as $plugin) {
				if ((0 < strlen($list))) {
					$list .= (\pocketmine\utils\TextFormat::WHITE . $this);
				}
				if ($plugin->isEnabled()) {
				} else {
				}
				$list .= \pocketmine\utils\TextFormat::RED;
				$list .= $plugin->getDescription()->getFullName();
				/* goto */
			}
			new \pocketmine\event\TranslationContainer('pocketmine.command.plugins.success', [count($plugins), $list]);
			$sender->sendMessage(new \pocketmine\event\TranslationContainer('pocketmine.command.plugins.success', [count($plugins), $list]));
			return null;
		}

}
