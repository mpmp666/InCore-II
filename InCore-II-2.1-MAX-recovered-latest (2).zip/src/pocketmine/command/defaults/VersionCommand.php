<?php

namespace pocketmine\command\defaults;

class VersionCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.version.description', '%pocketmine.command.version.usage', ['__array_ptr' => '2aaaadd5d428']);
			$this->setPermission('pocketmine.command.version');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if (($t9 === 0)) {
				$sender->sendMessage("-----\xe6\x9c\x8d\xe5\x8a\xa1\xe7\xab\xaf\xe4\xbf\xa1\xe6\x81\xaf-----");
				$sender->sendMessage(("\xe6\x9c\x8d\xe5\x8a\xa1\xe5\x99\xa8\xe5\x90\x8d\xe7\xa7\xb0\xef\xbc\x9a" . $sender->getServer()->getConfigString('motd')));
				$sender->sendMessage($this);
				$sender->sendMessage((($this . $sender->getServer()->InCoreVersion) . ')'));
				$sender->sendMessage("\xe6\x89\xa7\xe8\xa1\x8cAPI\xe7\x89\x88\xe6\x9c\xac\xef\xbc\x9a2.0.0");
				$sender->sendMessage("InCore-II\xe7\x89\x88\xe6\x9c\xac\xef\xbc\x9a2.1MAX");
				$sender->sendMessage($this);
				$sender->sendMessage((((($this . \PHP_VERSION) . $this) . (\PHP_INT_SIZE * 8)) . 'bit'));
				$sender->sendMessage(($this . \PHP_OS));
			} else {
				$pluginName = implode($this, $args);
				$exactPlugin = $sender->getServer()->getPluginManager()->getPlugin($pluginName);
				if ($exactPlugin instanceof \pocketmine\plugin\Plugin) {
					$this->describeToSender($exactPlugin, $sender);
					return true;
				}
				$found = false;
				$pluginName = strtolower($pluginName);
				foreach ($sender->getServer()->getPluginManager()->getPlugins() as $plugin) {
					if ((stripos($plugin->getName(), $pluginName) !== false)) {
						$this->describeToSender($plugin, $sender);
						$found = true;
					}
					/* goto */
				}
				if (!($found)) {
					new \pocketmine\event\TranslationContainer('pocketmine.command.version.noSuchPlugin');
					$sender->sendMessage(new \pocketmine\event\TranslationContainer('pocketmine.command.version.noSuchPlugin'));
				}
			}
			return true;
		}

	private function describeToSender($plugin = null, $sender = null) {
			/* decompiled (structured CF) */
			$desc = $plugin->getDescription();
			$sender->sendMessage((((((\pocketmine\utils\TextFormat::DARK_GREEN . $desc->getName()) . \pocketmine\utils\TextFormat::WHITE) . $this) . \pocketmine\utils\TextFormat::DARK_GREEN) . $desc->getVersion()));
			if (($desc->getDescription() != null)) {
				$sender->sendMessage($desc->getDescription());
			}
			if (($desc->getWebsite() != null)) {
				$sender->sendMessage(($this . $desc->getWebsite()));
			}
			$authors = $desc->getAuthors();
			if ((0 < $t28)) {
				if (($t30 === 1)) {
					$sender->sendMessage(($this . implode($this, $authors)));
				} else {
					$sender->sendMessage(($this . implode($this, $authors)));
				}
			}
			return null;
		}

}
