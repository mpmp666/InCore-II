<?php

namespace pocketmine\command\defaults;

class KillCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.kill.description', '%pocketmine.command.kill.usage', ['__array_ptr' => '2aaaadd5d460']);
			$this->setPermission('pocketmine.command.kill.self;pocketmine.command.kill.other');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if ((2 <= count($args))) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return false;
			}
			if ((count($args) === 1)) {
				if (!($sender->hasPermission('pocketmine.command.kill.other'))) {
					new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.permission'));
					$sender->sendMessage(new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.permission')));
					return true;
				}
				$player = $sender->getServer()->getPlayer($args[0]);
				if ($player instanceof \pocketmine\Player) {
					new \pocketmine\event\entity\EntityDamageEvent($player, \pocketmine\event\entity\EntityDamageEvent::CAUSE_SUICIDE, 1000);
					$ev = new \pocketmine\event\entity\EntityDamageEvent($player, \pocketmine\event\entity\EntityDamageEvent::CAUSE_SUICIDE, 1000);
					$sender->getServer()->getPluginManager()->callEvent($ev);
					if ($ev->isCancelled()) {
						return true;
					}
					$player->setLastDamageCause($ev);
					$player->setHealth(0);
					new \pocketmine\event\TranslationContainer('commands.kill.successful', [$player->getName()]);
					\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('commands.kill.successful', [$player->getName()]));
				} else {
					new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.player.notFound'));
					$sender->sendMessage(new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.player.notFound')));
				}
				return true;
			}
			if ($sender instanceof \pocketmine\Player) {
				if (!($sender->hasPermission('pocketmine.command.kill.self'))) {
					new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.permission'));
					$sender->sendMessage(new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.permission')));
					return true;
				}
				new \pocketmine\event\entity\EntityDamageEvent($sender, \pocketmine\event\entity\EntityDamageEvent::CAUSE_SUICIDE, 1000);
				$ev = new \pocketmine\event\entity\EntityDamageEvent($sender, \pocketmine\event\entity\EntityDamageEvent::CAUSE_SUICIDE, 1000);
				$sender->getServer()->getPluginManager()->callEvent($ev);
				if ($ev->isCancelled()) {
					return true;
				}
				$sender->setLastDamageCause($ev);
				$sender->setHealth(0);
				new \pocketmine\event\TranslationContainer('commands.kill.successful', [$sender->getName()]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.kill.successful', [$sender->getName()]));
			} else {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return false;
			}
			return true;
		}

}
