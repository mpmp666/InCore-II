<?php

namespace pocketmine\command\defaults;

class GamemodeCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.gamemode.description', '%commands.gamemode.usage', ['__array_ptr' => '2aaaadd5d460']);
			$this->setPermission('pocketmine.command.gamemode');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if ((!($sender->getServer()->getConfigString('player-change-gamemode')) && !($this->testPermission($sender)))) {
				return true;
			}
			if ((count($args) === 0)) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return false;
			}
			$gameMode = (\pocketmine\Server::getGamemodeFromString($args[0]));
			if (($gameMode === -1)) {
				$sender->sendMessage($this);
				return true;
			}
			$target = $sender;
			if (isset($args[1])) {
				$target = $sender->getServer()->getPlayer($args[1]);
				if (($target === null)) {
					new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.player.notFound'));
					$sender->sendMessage(new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.player.notFound')));
					return true;
				}
			} else {
				if (!($sender instanceof \pocketmine\Player)) {
					new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
					$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
					return true;
				}
			}
			if (!($target->setGamemode($gameMode))) {
				$sender->sendMessage((((\pocketmine\utils\TextFormat::RED . $this) . $target->getName()) . $this));
			} else {
				if (($target === $sender)) {
					new \pocketmine\event\TranslationContainer('commands.gamemode.success.self', [\pocketmine\Server::getGamemodeString($gameMode)]);
					\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('commands.gamemode.success.self', [\pocketmine\Server::getGamemodeString($gameMode)]));
				} else {
					new \pocketmine\event\TranslationContainer('gameMode.changed');
					$target->sendMessage(new \pocketmine\event\TranslationContainer('gameMode.changed'));
					new \pocketmine\event\TranslationContainer('commands.gamemode.success.other', [$target->getName(), \pocketmine\Server::getGamemodeString($gameMode)]);
					\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('commands.gamemode.success.other', [$target->getName(), \pocketmine\Server::getGamemodeString($gameMode)]));
				}
			}
			return true;
		}

}
