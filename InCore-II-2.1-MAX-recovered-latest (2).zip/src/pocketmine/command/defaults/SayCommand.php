<?php

namespace pocketmine\command\defaults;

class SayCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.say.description', '%commands.say.usage', ['__array_ptr' => '2aaaadd5d428']);
			$this->setPermission('pocketmine.command.say');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if ((count($args) === 0)) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return false;
			}
			if ($sender instanceof \pocketmine\Player) {
			} else {
				if ($sender instanceof \pocketmine\command\ConsoleCommandSender) {
				} else {
				}
			}
			new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::LIGHT_PURPLE . '%chat.type.announcement'), [$sender->getName(), (\pocketmine\utils\TextFormat::LIGHT_PURPLE . implode($this, $args))]);
			$sender->getServer()->broadcastMessage(new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::LIGHT_PURPLE . '%chat.type.announcement'), [$sender->getName(), (\pocketmine\utils\TextFormat::LIGHT_PURPLE . implode($this, $args))]));
			return true;
		}

}
