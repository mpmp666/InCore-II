<?php

namespace pocketmine\command\defaults;

class TeleportCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.tp.description', '%commands.tp.usage');
			$this->setPermission('pocketmine.command.teleport');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if ((!($sender->getServer()->getConfigString('player-tp')) && !($this->testPermission($sender)))) {
				return true;
			}
			if (((count($args) < 1) || (6 < count($args)))) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return true;
			}
			$target = null;
			$origin = $sender;
			if (((count($args) === 1) || (count($args) === 3))) {
				if ($sender instanceof \pocketmine\Player) {
					$target = $sender;
				} else {
					$sender->sendMessage((\pocketmine\utils\TextFormat::RED . $this));
					return true;
				}
				if ((count($args) === 1)) {
					$target = $sender->getServer()->getPlayer($args[0]);
					if (($target === null)) {
						$sender->sendMessage(((\pocketmine\utils\TextFormat::RED . $this) . $args[0]));
						return true;
					}
				}
			} else {
				$target = $sender->getServer()->getPlayer($args[0]);
				if (($target === null)) {
					$sender->sendMessage(((\pocketmine\utils\TextFormat::RED . $this) . $args[0]));
					return true;
				}
				if ((count($args) === 2)) {
					$origin = $target;
					$target = $sender->getServer()->getPlayer($args[1]);
					if (($target === null)) {
						$sender->sendMessage(((\pocketmine\utils\TextFormat::RED . $this) . $args[1]));
						return true;
					}
				}
			}
			if ((count($args) < 3)) {
				$origin->teleport($target);
				new \pocketmine\event\TranslationContainer('commands.tp.success', [$origin->getName(), $target->getName()]);
				\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('commands.tp.success', [$origin->getName(), $target->getName()]));
				return true;
			} else {
				if (($target->getLevel() !== null)) {
					if (((count($args) === 4) || (count($args) === 6))) {
						$pos = 1;
					} else {
						$pos = 0;
					}
					$pos++;
					$x = $this->getRelativeDouble($target->x, $sender, $args[$pos]);
					$pos++;
					$y = $this->getRelativeDouble($target->y, $sender, $args[$pos], 0, 128);
					$pos++;
					$z = $this->getRelativeDouble($target->z, $sender, $args[$pos]);
					$yaw = $target->getYaw();
					$pitch = $target->getPitch();
					if (((count($args) === 6) || ((count($args) === 5) && ($pos === 3)))) {
						$pos++;
						$yaw = $args[$pos];
						$pos++;
						$pitch = $args[$pos];
					}
					new \pocketmine\math\Vector3($x, $y, $z);
					$target->teleport(new \pocketmine\math\Vector3($x, $y, $z), $yaw, $pitch);
					new \pocketmine\event\TranslationContainer('commands.tp.success.coordinates', [$target->getName(), round($x, 2), round($y, 2), round($z, 2)]);
					\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('commands.tp.success.coordinates', [$target->getName(), round($x, 2), round($y, 2), round($z, 2)]));
					return true;
				}
			}
			new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
			$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
			return true;
		}

}
