<?php

namespace pocketmine\command\defaults;

class SummonCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.summon.description', '%commands.summon.usage');
			$this->setPermission('pocketmine.command.summon');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if ((((count($args) != 1) && (count($args) != 4)) && (count($args) != 5))) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return true;
			}
			if (($args[0] == 'Human')) {
				$sender->sendMessage((\pocketmine\utils\TextFormat::RED . "\xe7\xa6\x81\xe6\xad\xa2\xe7\x94\x9f\xe6\x88\x90\xe6\xad\xa4\xe7\x94\x9f\xe7\x89\xa9\xef\xbc\x81"));
				return false;
			}
			$x = 0;
			$y = 0;
			$z = 0;
			if (((count($args) == 4) || (count($args) == 5))) {
				if (is_numeric($args[1])) {
					$x = $args[1];
				} else {
					if ((0 <= strcmp($args[1], '~'))) {
						$offset_x = trim($args[1], '~');
						if ($sender instanceof \pocketmine\Player) {
							if (is_numeric($offset_x)) {
							} else {
							}
							$x = $sender->x;
						} else {
							$sender->sendMessage((\pocketmine\utils\TextFormat::RED . $this));
							return false;
						}
					} else {
						$sender->sendMessage((\pocketmine\utils\TextFormat::RED . $this));
						return false;
					}
				}
				if (is_numeric($args[2])) {
					$y = $args[2];
				} else {
					if ((0 <= strcmp($args[2], '~'))) {
						$offset_y = trim($args[2], '~');
						if ($sender instanceof \pocketmine\Player) {
							if (is_numeric($offset_y)) {
							} else {
							}
							$y = $sender->y;
							if (($y < 0)) {
								$y = 0;
							}
							if ((128 < $y)) {
								$y = 128;
							}
						} else {
							$sender->sendMessage((\pocketmine\utils\TextFormat::RED . $this));
							return false;
						}
					} else {
						$sender->sendMessage((\pocketmine\utils\TextFormat::RED . $this));
						return false;
					}
				}
				if (is_numeric($args[3])) {
					$z = $args[3];
				} else {
					if ((0 <= strcmp($args[3], '~'))) {
						$offset_z = trim($args[3], '~');
						if ($sender instanceof \pocketmine\Player) {
							if (is_numeric($offset_z)) {
							} else {
							}
							$z = $sender->z;
						} else {
							$sender->sendMessage((\pocketmine\utils\TextFormat::RED . $this));
							return false;
						}
					} else {
						$sender->sendMessage((\pocketmine\utils\TextFormat::RED . $this));
						return false;
					}
				}
			}
			if ((count($args) == 1)) {
				if ($sender instanceof \pocketmine\Player) {
					$x = $sender->x;
					$y = $sender->y;
					$z = $sender->z;
				} else {
					$sender->sendMessage((\pocketmine\utils\TextFormat::RED . $this));
					return false;
				}
			}
			$entity = null;
			$type = $args[0];
			if ($sender instanceof \pocketmine\Player) {
			} else {
			}
			$level = $sender->getServer()->getDefaultLevel();
			$chunk = $level->getChunk((round($x) >> 4), (round($z) >> 4));
			new \pocketmine\nbt\tag\DoubleTag('', $x);
			new \pocketmine\nbt\tag\DoubleTag('', $y);
			new \pocketmine\nbt\tag\DoubleTag('', $z);
			new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $x), new \pocketmine\nbt\tag\DoubleTag('', $y), new \pocketmine\nbt\tag\DoubleTag('', $z)]);
			new \pocketmine\nbt\tag\DoubleTag('', 0);
			new \pocketmine\nbt\tag\DoubleTag('', 0);
			new \pocketmine\nbt\tag\DoubleTag('', 0);
			new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]);
			new \pocketmine\nbt\tag\FloatTag('', (lcg_value() * 360));
			new \pocketmine\nbt\tag\FloatTag('', 0);
			new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', (lcg_value() * 360)), new \pocketmine\nbt\tag\FloatTag('', 0)]);
			new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $x), new \pocketmine\nbt\tag\DoubleTag('', $y), new \pocketmine\nbt\tag\DoubleTag('', $z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', (lcg_value() * 360)), new \pocketmine\nbt\tag\FloatTag('', 0)])]);
			$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $x), new \pocketmine\nbt\tag\DoubleTag('', $y), new \pocketmine\nbt\tag\DoubleTag('', $z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0), new \pocketmine\nbt\tag\DoubleTag('', 0)]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', (lcg_value() * 360)), new \pocketmine\nbt\tag\FloatTag('', 0)])]);
			$entity = \pocketmine\entity\Entity::createEntity($type, $chunk, $nbt);
			if ($entity instanceof \pocketmine\entity\Entity) {
				$entity->spawnToAll();
				$sender->sendMessage(($this . ')'));
				return true;
			} else {
				$sender->sendMessage((\pocketmine\utils\TextFormat::RED . $t180));
				return false;
			}
		}

}
