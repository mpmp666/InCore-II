<?php

namespace pocketmine\command\defaults;

class TimeCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.time.description', '%pocketmine.command.time.usage');
			$this->setPermission('pocketmine.command.time.add;pocketmine.command.time.set;pocketmine.command.time.start;pocketmine.command.time.stop');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if ((count($args) < 1)) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return false;
			}
			if (($args[0] === 'start')) {
				if (!($sender->hasPermission('pocketmine.command.time.start'))) {
					new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.permission'));
					$sender->sendMessage(new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.permission')));
					return true;
				}
				foreach ($sender->getServer()->getLevels() as $level) {
					$level->checkTime();
					$level->startTime();
					$level->checkTime();
					/* goto */
				}
				\pocketmine\command\Command::broadcastCommandMessage($sender, "\xe9\x87\x8d\xe6\x96\xb0\xe5\xbc\x80\xe5\xa7\x8b\xe8\xae\xa1\xe6\x97\xb6");
				return true;
			} else {
				if (($args[0] === 'stop')) {
					if (!($sender->hasPermission('pocketmine.command.time.stop'))) {
						new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.permission'));
						$sender->sendMessage(new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.permission')));
						return true;
					}
					foreach ($sender->getServer()->getLevels() as $level) {
						$level->checkTime();
						$level->stopTime();
						$level->checkTime();
						/* goto */
					}
					\pocketmine\command\Command::broadcastCommandMessage($sender, "\xe5\xb7\xb2\xe5\x81\x9c\xe6\xad\xa2\xe6\x97\xb6\xe9\x97\xb4");
					return true;
				} else {
					if (($args[0] === 'query')) {
						if (!($sender->hasPermission('pocketmine.command.time.query'))) {
							new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.permission'));
							$sender->sendMessage(new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.permission')));
							return true;
						}
						if ($sender instanceof \pocketmine\Player) {
							$level = $sender->getLevel();
						} else {
							$level = $sender->getServer()->getDefaultLevel();
						}
						new \pocketmine\event\TranslationContainer('commands.time.query', [$level->getTime()]);
						$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.time.query', [$level->getTime()]));
						return true;
					}
				}
			}
			if ((count($args) < 2)) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return false;
			}
			if (($args[0] === 'set')) {
				if (!($sender->hasPermission('pocketmine.command.time.set'))) {
					new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.permission'));
					$sender->sendMessage(new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.permission')));
					return true;
				}
				if (($args[1] === 'day')) {
					$value = 0;
				} else {
					if (($args[1] === 'night')) {
						$value = \pocketmine\level\Level::TIME_NIGHT;
					} else {
						$value = $this->getInteger($sender, $args[1], 0);
					}
				}
				foreach ($sender->getServer()->getLevels() as $level) {
					$level->checkTime();
					$level->setTime($value);
					$level->checkTime();
					/* goto */
				}
				new \pocketmine\event\TranslationContainer('commands.time.set', [$value]);
				\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('commands.time.set', [$value]));
			} else {
				if (($args[0] === 'add')) {
					if (!($sender->hasPermission('pocketmine.command.time.add'))) {
						new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.permission'));
						$sender->sendMessage(new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.permission')));
						return true;
					}
					$value = $this->getInteger($sender, $args[1], 0);
					foreach ($sender->getServer()->getLevels() as $level) {
						$level->checkTime();
						$level->setTime(($level->getTime() + $value));
						$level->checkTime();
						/* goto */
					}
					new \pocketmine\event\TranslationContainer('commands.time.added', [$value]);
					\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('commands.time.added', [$value]));
				} else {
					new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
					$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				}
			}
			return true;
		}

}
