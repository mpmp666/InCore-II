<?php

namespace pocketmine\command\defaults;

class ReloadCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.reload.description', '%pocketmine.command.reload.usage');
			$this->setPermission('pocketmine.command.reload');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::YELLOW . '%pocketmine.command.reload.reloading'));
			\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::YELLOW . '%pocketmine.command.reload.reloading')));
			$sender->getServer()->reload();
			new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::YELLOW . '%pocketmine.command.reload.reloaded'));
			\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::YELLOW . '%pocketmine.command.reload.reloaded')));
			return true;
		}

}
