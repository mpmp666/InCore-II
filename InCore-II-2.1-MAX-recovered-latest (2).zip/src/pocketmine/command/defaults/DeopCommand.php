<?php

namespace pocketmine\command\defaults;

class DeopCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.deop.description', '%commands.deop.usage');
			$this->setPermission('pocketmine.command.op.take');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if ((count($args) === 0)) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return false;
			}
			$name = array_shift($args);
			$player = $sender->getServer()->getOfflinePlayer($name);
			$player->setOp(false);
			if ($player instanceof \pocketmine\Player) {
				$player->sendMessage((\pocketmine\utils\TextFormat::GRAY . "\xe4\xbd\xa0\xe8\xa2\xab\xe7\xa7\xbb\xe9\x99\xa4\xe4\xba\x86\xe7\xae\xa1\xe7\x90\x86\xe5\x91\x98\xe6\x9d\x83\xe9\x99\x90!"));
			}
			new \pocketmine\event\TranslationContainer('commands.deop.success', [$player->getName()]);
			\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('commands.deop.success', [$player->getName()]));
			return true;
		}

}
