<?php

namespace pocketmine\command\defaults;

class DumpMemoryCommand extends \pocketmine\command\defaults\VanillaCommand {
	private static $executions = 0;

	public function __construct($name = null) {
			parent::__construct($name, "\xe8\xbd\xac\xe5\x82\xa8\xe5\x86\x85\xe5\xad\x98", ('/' . $this));
			$this->setPermission('pocketmine.command.dumpmemory');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			$token = strtoupper(substr(sha1(((((pocketmine\command\defaults\BOOTUP_RANDOM . ':') . $sender->getServer()->getServerUniqueId()) . ':') . self::$executions)), 6, 6));
			if (((count($args) < 1) || ($token !== strtoupper($args[0])))) {
				$sender->sendMessage(((($this . $this->getName()) . $this) . $token));
				return true;
			}
			if (isset($args[1])) {
			} else {
			}
			$sender->getServer()->getMemoryManager()->dumpServerMemory(($sender->getServer()->getDataPath() . $t36), 48, 80);
			return true;
		}

}
