<?php

namespace pocketmine\command\defaults;

class StopCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.stop.description', '%commands.stop.usage');
			$this->setPermission('pocketmine.command.stop');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			$msg = '';
			if (isset($args[0])) {
				$msg = $args[0];
			}
			$restart = false;
			if (isset($args[1])) {
				if (($args[0] == 'force')) {
					$restart = true;
				} else {
					$restart = false;
				}
			}
			new \pocketmine\event\TranslationContainer('commands.stop.start');
			\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('commands.stop.start'));
			$sender->getServer()->shutdown($restart, $msg);
			return true;
		}

}
