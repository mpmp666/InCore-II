<?php

namespace pocketmine\command\defaults;

class ExtractPluginCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, $this, $this);
			$this->setPermission('pocketmine.command.extractplugin');
			return;
		}

	public function execute($sender = null, $commandLabel = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return false;
			}
			if ((count($args) === 0)) {
				$sender->sendMessage(((\pocketmine\utils\TextFormat::RED . $this) . $this->usageMessage));
				return true;
			}
			$pluginName = trim(implode($this, $args));
			$plugin = \pocketmine\Server::getInstance()->getPluginManager()->getPlugin($pluginName);
			if ((($pluginName === '') || !($plugin instanceof \pocketmine\plugin\Plugin))) {
				$sender->sendMessage((\pocketmine\utils\TextFormat::RED . $this));
				return true;
			}
			$description = $plugin->getDescription();
			if (!($plugin->getPluginLoader() instanceof \pocketmine\plugin\PharPluginLoader)) {
				$sender->sendMessage((((\pocketmine\utils\TextFormat::RED . $this) . $description->getName()) . $this));
				return true;
			}
			$folderPath = (((((((\pocketmine\Server::getInstance()->getPluginPath() . \DIRECTORY_SEPARATOR) . 'InCore-II') . \DIRECTORY_SEPARATOR) . $description->getName()) . '_v') . $description->getVersion()) . '/');
			if (file_exists($folderPath)) {
				$sender->sendMessage($this);
			} else {
				mkdir($folderPath);
			}
			new \ReflectionClass('pocketmine\\plugin\\PluginBase');
			$reflection = new \ReflectionClass('pocketmine\\plugin\\PluginBase');
			$file = $reflection->getProperty('file');
			$file->setAccessible(true);
			$pharPath = str_replace('\\', '/', rtrim($file->getValue($plugin), '\\/'));
			new \RecursiveDirectoryIterator($pharPath);
			new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($pharPath));
			foreach (new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($pharPath)) as $fInfo) {
				$path = $fInfo->getPathname();
				mkdir(dirname(($folderPath . str_replace($pharPath, '', $path))), 493, true);
				file_put_contents(($folderPath . str_replace($pharPath, '', $path)), file_get_contents($path));
				/* goto */
			}
			$sender->sendMessage(((((($this . $description->getName()) . $this) . $description->getVersion()) . $this) . $folderPath));
			return true;
		}

}
