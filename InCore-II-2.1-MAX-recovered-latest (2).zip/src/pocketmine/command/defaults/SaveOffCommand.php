<?php

namespace pocketmine\command\defaults;

class SaveOffCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.saveoff.description', '%commands.save-off.usage');
			$this->setPermission('pocketmine.command.save.disable');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			$sender->getServer()->setAutoSave(false);
			new \pocketmine\event\TranslationContainer('commands.save.disabled');
			\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('commands.save.disabled'));
			return true;
		}

}
