<?php

namespace pocketmine\command\defaults;

class SetBlockCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.setblock.description', '%commands.setblock.usage');
			$this->setPermission('pocketmine.command.setblock');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if (((count($args) < 4) || (5 < count($args)))) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return false;
			}
			$itemblock = \pocketmine\item\Item::fromString($args[3]);
			if ($itemblock instanceof \pocketmine\item\ItemBlock) {
				$block = $itemblock->getBlock();
				if ((isset($args[4]) && is_numeric($args[4]))) {
					$block->setDamage(($args[4]));
				}
				$x = $args[0];
				$y = $args[1];
				$z = $args[2];
				if (($x[0] === '~')) {
					if (((is_numeric(trim($x, '~')) || (trim($x, '~') === '')) && $sender instanceof \pocketmine\Player)) {
						$x = (round((trim($x, '~') + $sender->x)));
					}
				} else {
					if (is_numeric($x)) {
						$x = (round($x));
					} else {
						new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
						$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
						return false;
					}
				}
				if (($y[0] === '~')) {
					if (((is_numeric(trim($y, '~')) || (trim($y, '~') === '')) && $sender instanceof \pocketmine\Player)) {
						$y = (round((trim($y, '~') + $sender->y)));
					}
					if ((($y < 0) || (128 < $y))) {
						return false;
					}
				} else {
					if (is_numeric($y)) {
						$y = (round($y));
					} else {
						new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
						$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
						return false;
					}
				}
				if (($z[0] === '~')) {
					if (((is_numeric(trim($z, '~')) || (trim($z, '~') === '')) && $sender instanceof \pocketmine\Player)) {
						$z = (round((trim($z, '~') + $sender->z)));
					}
				} else {
					if (is_numeric($z)) {
						$z = (round($z));
					} else {
						new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
						$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
						return false;
					}
				}
				if (!(((is_integer($x) && is_integer($y)) && is_integer($z)))) {
					new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
					$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
					return false;
				}
				new \pocketmine\math\Vector3($x, $y, $z);
				$pos = new \pocketmine\math\Vector3($x, $y, $z);
				if ($pos instanceof \pocketmine\math\Vector3) {
					if ($sender instanceof \pocketmine\Player) {
					} else {
					}
					$level = $sender->getServer()->getDefaultLevel();
					if ($level->setBlock($pos, $block)) {
						$sender->sendMessage(($this . $args[3]));
						return true;
					} else {
						new \pocketmine\event\TranslationContainer('commands.generic.exception', ['__array_ptr' => '2aaaac9fc9a0']);
						$sender->sendMessage((\pocketmine\utils\TextFormat::RED . new \pocketmine\event\TranslationContainer('commands.generic.exception', ['__array_ptr' => '2aaaac9fc9a0'])));
						return false;
					}
				}
			} else {
				new \pocketmine\event\TranslationContainer('command.setblock.invalidBlock', ['__array_ptr' => '2aaaac9fc9a0']);
				$sender->sendMessage((\pocketmine\utils\TextFormat::RED . new \pocketmine\event\TranslationContainer('command.setblock.invalidBlock', ['__array_ptr' => '2aaaac9fc9a0'])));
				return false;
			}
			return true;
		}

}
