<?php

namespace pocketmine\command\defaults;

class BanListCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.banlist.description', '%commands.banlist.usage');
			$this->setPermission('pocketmine.command.ban.list');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			$list = $sender->getServer()->getNameBans();
			if (isset($args[0])) {
				$args[0] = strtolower($args[0]);
				if (($args[0] === 'ips')) {
					$list = $sender->getServer()->getIPBans();
				} else {
					if (($args[0] === 'players')) {
						$list = $sender->getServer()->getNameBans();
					} else {
						if (($args[0] === 'cids')) {
							$list = $sender->getServer()->getCIDBans();
						} else {
							new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
							$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
							return false;
						}
					}
				}
			}
			$message = '';
			$list = $list->getEntries();
			foreach ($list as $entry) {
				$message .= ($entry->getName() . $this);
				/* goto */
			}
			if (!(isset($args[0]))) {
				return false;
			}
			if (($args[0] === 'ips')) {
				$sender->sendMessage(\pocketmine\Server::getInstance()->getLanguage()->translateString('commands.banlist.ips', [$t48]));
			} else {
				if (($args[0] === 'players')) {
					$sender->sendMessage(\pocketmine\Server::getInstance()->getLanguage()->translateString('commands.banlist.players', [$t56]));
				} else {
					$sender->sendMessage((($this . $t60) . "\xe8\xa2\xabban"));
				}
			}
			$sender->sendMessage(substr($message, 0, -2));
			return true;
		}

}
