<?php

namespace pocketmine\command\defaults;

class FindBiomeCommand extends \pocketmine\command\defaults\VanillaCommand {
	public const DEFAULT_REGION_RADIUS = 24;
	public const DEFAULT_BIOME_RADIUS = 4096;
	public const VILLAGE_GENERATION_RETRY_INTERVAL = 20;
	public const VILLAGE_GENERATION_RETRY_LIMIT = 30;

	public function __construct($name = null) {
			/* decompiled (structured CF) */
			parent::__construct($name, $this, $this);
			$this->setPermission('pocketmine.command.findbiome');
			$this->setAliases(['__array_ptr' => '2aaaadd5d6c8']);
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if (!($sender instanceof \pocketmine\Player)) {
				$sender->sendMessage((\pocketmine\utils\TextFormat::RED . '%commands.generic.runingame'));
				return false;
			}
			if (((2 < count($args)) || ((count($args) < 1) && ($currentAlias !== 'findvillage')))) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return true;
			}
			if (isset($args[0])) {
			} else {
			}
			$type = 'village';
			if ((($currentAlias === 'findvillage') && ($type !== 'hell'))) {
				$type = 'village';
			}
			if (($type === 'village')) {
				if (((($currentAlias === 'findvillage') && isset($args[0])) && is_numeric($args[0]))) {
				} else {
				}
				$radiusArg = null;
				if (($radiusArg !== null)) {
				} else {
				}
				$maxRadius = self::DEFAULT_REGION_RADIUS;
				return $this->locateVillage($sender, $maxRadius, false);
			}
			if (((($type === 'desertvillage') || ($type === 'desert_village')) || ($type === 'sandvillage'))) {
				if (isset($args[1])) {
				} else {
				}
				$maxRadius = self::DEFAULT_REGION_RADIUS;
				return $this->locateVillage($sender, $maxRadius, true);
			}
			if (($type === 'hell')) {
				if (isset($args[1])) {
				} else {
				}
				$maxRadius = self::DEFAULT_REGION_RADIUS;
				return $this->locateFortress($sender, $maxRadius);
			}
			if ((($type === 'jungletemple') || ($type === 'jungle_temple'))) {
				if (isset($args[1])) {
				} else {
				}
				$maxRadius = self::DEFAULT_REGION_RADIUS;
				return $this->locateJungleTemple($sender, $maxRadius);
			}
			if ((((($type === 'deserttemple') || ($type === 'desert_temple')) || ($type === 'desertpyramid')) || ($type === 'desert_pyramid'))) {
				if (isset($args[1])) {
				} else {
				}
				$maxRadius = self::DEFAULT_REGION_RADIUS;
				return $this->locateDesertTemple($sender, $maxRadius);
			}
			if (((((($type === 'outpost') || ($type === 'pillageroutpost')) || ($type === 'pillager_outpost')) || ($type === 'desertoutpost')) || ($type === 'desert_outpost'))) {
				if (isset($args[1])) {
				} else {
				}
				$maxRadius = self::DEFAULT_REGION_RADIUS;
				return $this->locatePillagerOutpost($sender, $maxRadius, (($type === 'desertoutpost') || ($type === 'desert_outpost')));
			}
			if (((($type === 'portal') || ($type === 'ruinedportal')) || ($type === 'ruined_portal'))) {
				if (isset($args[1])) {
				} else {
				}
				$maxRadius = self::DEFAULT_REGION_RADIUS;
				return $this->locateRuinedPortal($sender, $maxRadius);
			}
			if (isset($args[1])) {
			} else {
			}
			$radius = self::DEFAULT_BIOME_RADIUS;
			new \pocketmine\level\generator\biome\BiomeLocator(($sender->getLevel()->getSeed()));
			$locator = new \pocketmine\level\generator\biome\BiomeLocator(($sender->getLevel()->getSeed()));
			$result = $locator->findNearestByName($args[0], (floor($sender->getX())), (floor($sender->getZ())), $radius, 16);
			if (($result === null)) {
				$sender->sendMessage((\pocketmine\utils\TextFormat::RED . ($this . $this)));
				return true;
			}
			$x = ($result['x']);
			$z = ($result['z']);
			$y = 96;
			new \pocketmine\math\Vector3(($x + 0.5), $y, ($z + 0.5));
			$sender->teleport(new \pocketmine\math\Vector3(($x + 0.5), $y, ($z + 0.5)));
			\pocketmine\command\Command::broadcastCommandMessage($sender, (($this . $result['biome']) . ($this . $z)));
			return true;
		}

	private function locateVillage($sender = null, $maxRadius = null, $desertOnly = null) {
			/* decompiled (structured CF) */
			$level = $sender->getLevel();
			if ((\pocketmine\level\generator\Generator::getGenerator($level->getProvider()->getGenerator()) !== 'pocketmine\\level\\generator\\normal\\Normal')) {
				$sender->sendMessage((\pocketmine\utils\TextFormat::RED . $this));
				return true;
			}
			$playerChunkX = (($sender->x) >> 4);
			$playerChunkZ = (($sender->z) >> 4);
			$originRegionX = \pocketmine\level\generator\normal\populator\VillagePopulator::regionCoord($playerChunkX, \pocketmine\level\generator\normal\populator\VillagePopulator::REGION_SIZE);
			$originRegionZ = \pocketmine\level\generator\normal\populator\VillagePopulator::regionCoord($playerChunkZ, \pocketmine\level\generator\normal\populator\VillagePopulator::REGION_SIZE);
			$found = null;
			$radius = 0;
			while (($found === null)) {
				$regionX = ($originRegionX - $radius);
				while (($found === null)) {
					$regionZ = ($originRegionZ - $radius);
					while (($regionZ <= $t66)) {
						if (((($radius !== 0) && ($radius !== abs(($regionX - $originRegionX)))) && ($radius !== abs(($regionZ - $originRegionZ))))) {
						} else {
							$candidate = \pocketmine\level\generator\normal\populator\VillagePopulator::findRegionVillageCandidate($level->getSeed(), $regionX, $regionZ);
							if (($candidate !== null)) {
								if (($desertOnly && (!(isset($candidate['biomeId'])) || (($candidate['biomeId']) !== \pocketmine\level\generator\biome\Biome::DESERT)))) {
								} else {
									$found = $candidate;
									/* jump */
								}
								$regionZ++;
								$regionX++;
								$radius++;
								if (($found === null)) {
									if ($desertOnly) {
									} else {
									}
									$sender->sendMessage((((\pocketmine\utils\TextFormat::RED . $this) . '') . ($this . $this)));
									return true;
								}
								$placement = $this->prepareLocatedVillage($level, ($found['chunkX']), ($found['chunkZ']));
								if (($placement === null)) {
									$sender->sendMessage((\pocketmine\utils\TextFormat::YELLOW . $this));
									$this->scheduleVillageTeleportRetry($sender, $level, ($found['chunkX']), ($found['chunkZ']), $desertOnly);
									return true;
								}
								$targetX = ($placement['targetX']);
								$targetY = ($placement['targetY']);
								$targetZ = ($placement['targetZ']);
								new \pocketmine\math\Vector3(($targetX + 0.5), $targetY, ($targetZ + 0.5));
								$sender->teleport(new \pocketmine\math\Vector3(($targetX + 0.5), $targetY, ($targetZ + 0.5)));
								\pocketmine\command\Command::broadcastCommandMessage($sender, ($this . $targetZ));
								return true;
							}
						}
					}
				}
			}
		}

	private function scheduleVillageTeleportRetry($sender = null, $level = null, $chunkX = null, $chunkZ = null, $desertOnly = null, $attempt = null) {
			new \pocketmine\scheduler\CallbackTask(function () { /* unrecovered lambda E:/Desktop/src/src/pocketmine/command/defaults/FindBiomeComm */ return null; });
			$sender->getServer()->getScheduler()->scheduleDelayedTask(new \pocketmine\scheduler\CallbackTask(function () { /* unrecovered lambda E:/Desktop/src/src/pocketmine/command/defaults/FindBiomeComm */ return null; }), self::VILLAGE_GENERATION_RETRY_INTERVAL);
			return null;
		}

	private function locateFortress($sender = null, $maxRadius = null) {
			/* decompiled (structured CF) */
			$level = $sender->getLevel();
			if ((\pocketmine\level\generator\Generator::getGenerator($level->getProvider()->getGenerator()) !== 'pocketmine\\level\\generator\\hell\\Nether')) {
				$sender->sendMessage((\pocketmine\utils\TextFormat::RED . $this));
				return true;
			}
			$playerChunkX = (($sender->x) >> 4);
			$playerChunkZ = (($sender->z) >> 4);
			$originRegionX = \pocketmine\level\generator\hell\populator\NetherFortressPopulator::floorDiv($playerChunkX, \pocketmine\level\generator\hell\populator\NetherFortressPopulator::REGION_SIZE);
			$originRegionZ = \pocketmine\level\generator\hell\populator\NetherFortressPopulator::floorDiv($playerChunkZ, \pocketmine\level\generator\hell\populator\NetherFortressPopulator::REGION_SIZE);
			$found = null;
			$radius = 0;
			while (($found === null)) {
				$regionX = ($originRegionX - $radius);
				while (($found === null)) {
					$regionZ = ($originRegionZ - $radius);
					while (($regionZ <= $t56)) {
						if (((($radius !== 0) && ($radius !== abs(($regionX - $originRegionX)))) && ($radius !== abs(($regionZ - $originRegionZ))))) {
						} else {
							$candidate = \pocketmine\level\generator\hell\populator\NetherFortressPopulator::getFortressCandidate($level->getSeed(), $regionX, $regionZ);
							if (($candidate !== null)) {
								$found = $candidate;
							} else {
								$regionZ++;
								$regionX++;
							}
						}
					}
				}
				$radius++;
			}
			if (($found === null)) {
				$sender->sendMessage((\pocketmine\utils\TextFormat::RED . ($this . $this)));
				return true;
			}
			$targetX = ($found['centerX']);
			$targetZ = ($found['centerZ']);
			new \pocketmine\math\Vector3(($targetX + 0.5), 64, ($targetZ + 0.5));
			$sender->teleport(new \pocketmine\math\Vector3(($targetX + 0.5), 64, ($targetZ + 0.5)));
			\pocketmine\command\Command::broadcastCommandMessage($sender, ($this . $targetZ));
			return true;
		}

	private function locateJungleTemple($sender = null, $maxRadius = null) {
			/* decompiled (structured CF) */
			$level = $sender->getLevel();
			if ((\pocketmine\level\generator\Generator::getGenerator($level->getProvider()->getGenerator()) !== 'pocketmine\\level\\generator\\normal\\Normal')) {
				$sender->sendMessage((\pocketmine\utils\TextFormat::RED . $this));
				return true;
			}
			new \pocketmine\level\generator\biome\BiomeLocator(($level->getSeed()));
			$locator = new \pocketmine\level\generator\biome\BiomeLocator(($level->getSeed()));
			$playerChunkX = (($sender->x) >> 4);
			$playerChunkZ = (($sender->z) >> 4);
			$originRegionX = \pocketmine\level\generator\normal\populator\JungleTemple::floorDiv($playerChunkX, \pocketmine\level\generator\normal\populator\JungleTemple::REGION_SIZE);
			$originRegionZ = \pocketmine\level\generator\normal\populator\JungleTemple::floorDiv($playerChunkZ, \pocketmine\level\generator\normal\populator\JungleTemple::REGION_SIZE);
			$found = null;
			$radius = 0;
			while (($found === null)) {
				$regionX = ($originRegionX - $radius);
				while (($found === null)) {
					$regionZ = ($originRegionZ - $radius);
					while (($regionZ <= $t75)) {
						if (((($radius !== 0) && ($radius !== abs(($regionX - $originRegionX)))) && ($radius !== abs(($regionZ - $originRegionZ))))) {
						} else {
							$candidate = \pocketmine\level\generator\normal\populator\JungleTemple::findRegionJungleTempleCandidate($level->getSeed(), $regionX, $regionZ);
							$sampleX = (($candidate['chunkX'] << 4) + 7);
							$sampleZ = (($candidate['chunkZ'] << 4) + 7);
							if (\pocketmine\level\generator\normal\populator\JungleTemple::isJungleTempleBiome($locator->getBiomeIdAt($sampleX, $sampleZ))) {
								$found = $candidate;
							} else {
								$regionZ++;
								$regionX++;
							}
						}
					}
				}
				$radius++;
			}
			if (($found === null)) {
				$sender->sendMessage((\pocketmine\utils\TextFormat::RED . ($this . $this)));
				return true;
			}
			$placement = $this->prepareLocatedJungleTemple($level, ($found['chunkX']), ($found['chunkZ']));
			if (($placement === null)) {
				$sender->sendMessage((\pocketmine\utils\TextFormat::YELLOW . $this));
				return true;
			}
			$targetX = ($placement['targetX']);
			$targetY = ($placement['targetY']);
			$targetZ = ($placement['targetZ']);
			new \pocketmine\math\Vector3(($targetX + 0.5), $targetY, ($targetZ + 0.5));
			$sender->teleport(new \pocketmine\math\Vector3(($targetX + 0.5), $targetY, ($targetZ + 0.5)));
			\pocketmine\command\Command::broadcastCommandMessage($sender, ($this . $targetZ));
			return true;
		}

	private function locateDesertTemple($sender = null, $maxRadius = null) {
			/* decompiled (structured CF) */
			$level = $sender->getLevel();
			if ((\pocketmine\level\generator\Generator::getGenerator($level->getProvider()->getGenerator()) !== 'pocketmine\\level\\generator\\normal\\Normal')) {
				$sender->sendMessage((\pocketmine\utils\TextFormat::RED . $this));
				return true;
			}
			new \pocketmine\level\generator\biome\BiomeLocator(($level->getSeed()));
			$locator = new \pocketmine\level\generator\biome\BiomeLocator(($level->getSeed()));
			$playerChunkX = (($sender->x) >> 4);
			$playerChunkZ = (($sender->z) >> 4);
			$originRegionX = \pocketmine\level\generator\normal\populator\Temple::floorDiv($playerChunkX, \pocketmine\level\generator\normal\populator\Temple::REGION_SIZE);
			$originRegionZ = \pocketmine\level\generator\normal\populator\Temple::floorDiv($playerChunkZ, \pocketmine\level\generator\normal\populator\Temple::REGION_SIZE);
			$found = null;
			$radius = 0;
			while (($found === null)) {
				$regionX = ($originRegionX - $radius);
				while (($found === null)) {
					$regionZ = ($originRegionZ - $radius);
					while (($regionZ <= $t78)) {
						if (((($radius !== 0) && ($radius !== abs(($regionX - $originRegionX)))) && ($radius !== abs(($regionZ - $originRegionZ))))) {
						} else {
							$candidate = \pocketmine\level\generator\normal\populator\Temple::findRegionTempleCandidate($level->getSeed(), $regionX, $regionZ);
							$origin = \pocketmine\level\generator\normal\populator\Temple::getTempleOrigin(($level->getSeed()), ($candidate['chunkX']), ($candidate['chunkZ']));
							if (\pocketmine\level\generator\normal\populator\Temple::isDesertTempleBiome($locator->getBiomeIdAt(($origin['x']), ($origin['z'])))) {
								$found = $candidate;
							} else {
								$regionZ++;
								$regionX++;
							}
						}
					}
				}
				$radius++;
			}
			if (($found === null)) {
				$sender->sendMessage((\pocketmine\utils\TextFormat::RED . ($this . $this)));
				return true;
			}
			$placement = $this->prepareLocatedDesertTemple($level, ($found['chunkX']), ($found['chunkZ']));
			if (($placement === null)) {
				$sender->sendMessage((\pocketmine\utils\TextFormat::YELLOW . $this));
				return true;
			}
			$targetX = ($placement['targetX']);
			$targetY = ($placement['targetY']);
			$targetZ = ($placement['targetZ']);
			new \pocketmine\math\Vector3(($targetX + 0.5), $targetY, ($targetZ + 0.5));
			$sender->teleport(new \pocketmine\math\Vector3(($targetX + 0.5), $targetY, ($targetZ + 0.5)));
			\pocketmine\command\Command::broadcastCommandMessage($sender, ($this . $targetZ));
			return true;
		}

	private function locatePillagerOutpost($sender = null, $maxRadius = null, $desertOnly = null) {
			/* decompiled (structured CF) */
			$level = $sender->getLevel();
			if ((\pocketmine\level\generator\Generator::getGenerator($level->getProvider()->getGenerator()) !== 'pocketmine\\level\\generator\\normal\\Normal')) {
				$sender->sendMessage((\pocketmine\utils\TextFormat::RED . $this));
				return true;
			}
			new \pocketmine\level\generator\biome\BiomeLocator(($level->getSeed()));
			$locator = new \pocketmine\level\generator\biome\BiomeLocator(($level->getSeed()));
			$playerChunkX = (($sender->x) >> 4);
			$playerChunkZ = (($sender->z) >> 4);
			$originRegionX = \pocketmine\level\generator\normal\populator\PillagerOutpost::regionCoord($playerChunkX, \pocketmine\level\generator\normal\populator\PillagerOutpost::REGION_SIZE);
			$originRegionZ = \pocketmine\level\generator\normal\populator\PillagerOutpost::regionCoord($playerChunkZ, \pocketmine\level\generator\normal\populator\PillagerOutpost::REGION_SIZE);
			$found = null;
			$radius = 0;
			while (($found === null)) {
				$regionX = ($originRegionX - $radius);
				while (($found === null)) {
					$regionZ = ($originRegionZ - $radius);
					while (($regionZ <= $t82)) {
						if (((($radius !== 0) && ($radius !== abs(($regionX - $originRegionX)))) && ($radius !== abs(($regionZ - $originRegionZ))))) {
						} else {
							$candidate = \pocketmine\level\generator\normal\populator\PillagerOutpost::findRegionOutpostCandidate($level->getSeed(), $regionX, $regionZ);
							$sampleX = (($candidate['chunkX'] << 4) + 7);
							$sampleZ = (($candidate['chunkZ'] << 4) + 7);
							$biomeId = $locator->getBiomeIdAt($sampleX, $sampleZ);
							if (($desertOnly && (($biomeId) !== \pocketmine\level\generator\biome\Biome::DESERT))) {
							} else {
								if (\pocketmine\level\generator\normal\populator\PillagerOutpost::isValidOutpostBiome($biomeId)) {
									$found = $candidate;
								} else {
									$regionZ++;
									$regionX++;
								}
							}
						}
					}
				}
				$radius++;
			}
			if (($found === null)) {
				if ($desertOnly) {
				} else {
				}
				$sender->sendMessage((((\pocketmine\utils\TextFormat::RED . $this) . '') . ($this . $this)));
				return true;
			}
			$placement = $this->prepareLocatedPillagerOutpost($level, ($found['chunkX']), ($found['chunkZ']));
			if (($placement === null)) {
				if ($desertOnly) {
				} else {
				}
				$sender->sendMessage((((\pocketmine\utils\TextFormat::YELLOW . $this) . 'pillageroutpost') . $this));
				return true;
			}
			$targetX = ($placement['targetX']);
			$targetY = ($placement['targetY']);
			$targetZ = ($placement['targetZ']);
			new \pocketmine\math\Vector3(($targetX + 0.5), $targetY, ($targetZ + 0.5));
			$sender->teleport(new \pocketmine\math\Vector3(($targetX + 0.5), $targetY, ($targetZ + 0.5)));
			\pocketmine\command\Command::broadcastCommandMessage($sender, ($this . $targetZ));
			return true;
		}

	private function locateRuinedPortal($sender = null, $maxRadius = null) {
			/* decompiled (structured CF) */
			$level = $sender->getLevel();
			if ((\pocketmine\level\generator\Generator::getGenerator($level->getProvider()->getGenerator()) !== 'pocketmine\\level\\generator\\normal\\Normal')) {
				$sender->sendMessage((\pocketmine\utils\TextFormat::RED . $this));
				return true;
			}
			new \pocketmine\level\generator\biome\BiomeLocator(($level->getSeed()));
			$locator = new \pocketmine\level\generator\biome\BiomeLocator(($level->getSeed()));
			$playerChunkX = (($sender->x) >> 4);
			$playerChunkZ = (($sender->z) >> 4);
			$originRegionX = \pocketmine\level\generator\normal\populator\RuinedPortal::regionCoord($playerChunkX, \pocketmine\level\generator\normal\populator\RuinedPortal::REGION_SIZE);
			$originRegionZ = \pocketmine\level\generator\normal\populator\RuinedPortal::regionCoord($playerChunkZ, \pocketmine\level\generator\normal\populator\RuinedPortal::REGION_SIZE);
			$found = null;
			$radius = 0;
			while (($found === null)) {
				$regionX = ($originRegionX - $radius);
				while (($found === null)) {
					$regionZ = ($originRegionZ - $radius);
					while (($regionZ <= $t75)) {
						if (((($radius !== 0) && ($radius !== abs(($regionX - $originRegionX)))) && ($radius !== abs(($regionZ - $originRegionZ))))) {
						} else {
							$candidate = \pocketmine\level\generator\normal\populator\RuinedPortal::findRegionRuinedPortalCandidate($level->getSeed(), $regionX, $regionZ);
							$sampleX = (($candidate['chunkX'] << 4) + 7);
							$sampleZ = (($candidate['chunkZ'] << 4) + 7);
							if (\pocketmine\level\generator\normal\populator\RuinedPortal::isValidRuinedPortalBiome($locator->getBiomeIdAt($sampleX, $sampleZ))) {
								$found = $candidate;
							} else {
								$regionZ++;
								$regionX++;
							}
						}
					}
				}
				$radius++;
			}
			if (($found === null)) {
				$sender->sendMessage((\pocketmine\utils\TextFormat::RED . ($this . $this)));
				return true;
			}
			$placement = $this->prepareLocatedRuinedPortal($level, ($found['chunkX']), ($found['chunkZ']));
			if (($placement === null)) {
				$sender->sendMessage((\pocketmine\utils\TextFormat::YELLOW . $this));
				return true;
			}
			$targetX = ($placement['targetX']);
			$targetY = ($placement['targetY']);
			$targetZ = ($placement['targetZ']);
			new \pocketmine\math\Vector3(($targetX + 0.5), $targetY, ($targetZ + 0.5));
			$sender->teleport(new \pocketmine\math\Vector3(($targetX + 0.5), $targetY, ($targetZ + 0.5)));
			\pocketmine\command\Command::broadcastCommandMessage($sender, ($this . $targetZ));
			return true;
		}

	private function prepareLocatedJungleTemple($level = null, $chunkX = null, $chunkZ = null) {
			/* decompiled (structured CF) */
			$footprintChunks = \pocketmine\level\generator\normal\populator\JungleTemple::getJungleTempleFootprintChunks(($level->getSeed()), $chunkX, $chunkZ);
			$allGenerated = true;
			foreach ($footprintChunks as $chunkPos) {
				$fx = ($chunkPos['chunkX']);
				$fz = ($chunkPos['chunkZ']);
				$level->loadChunk($fx, $fz, true);
				if (!($level->isChunkGenerated($fx, $fz))) {
					$allGenerated = false;
				}
				/* goto */
			}
			if ((!($level->isChunkPopulated($chunkX, $chunkZ)) || !($allGenerated))) {
				foreach ($footprintChunks as $chunkPos) {
					$level->populateChunk(($chunkPos['chunkX']), ($chunkPos['chunkZ']), true);
					/* goto */
				}
				return null;
			}
			new \pocketmine\level\generator\normal\populator\JungleTemple();
			$populator = new \pocketmine\level\generator\normal\populator\JungleTemple();
			new \pocketmine\utils\Random(0);
			$random = new \pocketmine\utils\Random(0);
			$random->setSeed((\pocketmine\level\Level::chunkHash($chunkX, $chunkZ) ^ ($level->getSeed())));
			return $populator->placeJungleTempleAtCandidate($level, $chunkX, $chunkZ, $random);
		}

	private function prepareLocatedVillage($level = null, $chunkX = null, $chunkZ = null) {
			/* decompiled (structured CF) */
			$footprintChunks = \pocketmine\level\generator\normal\populator\VillagePopulator::getVillageFootprintChunks(($level->getSeed()), $chunkX, $chunkZ);
			$allGenerated = true;
			foreach ($footprintChunks as $chunkPos) {
				$fx = ($chunkPos['chunkX']);
				$fz = ($chunkPos['chunkZ']);
				$level->loadChunk($fx, $fz, true);
				if (!($level->isChunkGenerated($fx, $fz))) {
					$allGenerated = false;
				}
				/* goto */
			}
			if ((!($level->isChunkPopulated($chunkX, $chunkZ)) || !($allGenerated))) {
				foreach ($footprintChunks as $chunkPos) {
					$level->populateChunk(($chunkPos['chunkX']), ($chunkPos['chunkZ']), true);
					/* goto */
				}
				return null;
			}
			new \pocketmine\level\generator\normal\populator\VillagePopulator();
			$populator = new \pocketmine\level\generator\normal\populator\VillagePopulator();
			new \pocketmine\utils\Random(0);
			$random = new \pocketmine\utils\Random(0);
			$random->setSeed((\pocketmine\level\Level::chunkHash($chunkX, $chunkZ) ^ ($level->getSeed())));
			return $populator->placeVillageAtCandidate($level, $chunkX, $chunkZ, $random);
		}

	private function prepareLocatedDesertTemple($level = null, $chunkX = null, $chunkZ = null) {
			/* decompiled (structured CF) */
			$footprintChunks = \pocketmine\level\generator\normal\populator\Temple::getTempleFootprintChunks(($level->getSeed()), $chunkX, $chunkZ);
			$allGenerated = true;
			foreach ($footprintChunks as $chunkPos) {
				$fx = ($chunkPos['chunkX']);
				$fz = ($chunkPos['chunkZ']);
				$level->loadChunk($fx, $fz, true);
				if (!($level->isChunkGenerated($fx, $fz))) {
					$allGenerated = false;
				}
				/* goto */
			}
			if ((!($level->isChunkPopulated($chunkX, $chunkZ)) || !($allGenerated))) {
				foreach ($footprintChunks as $chunkPos) {
					$level->populateChunk(($chunkPos['chunkX']), ($chunkPos['chunkZ']), true);
					/* goto */
				}
				return null;
			}
			new \pocketmine\level\generator\normal\populator\Temple();
			$populator = new \pocketmine\level\generator\normal\populator\Temple();
			new \pocketmine\utils\Random(0);
			$random = new \pocketmine\utils\Random(0);
			$random->setSeed((\pocketmine\level\Level::chunkHash($chunkX, $chunkZ) ^ ($level->getSeed())));
			return $populator->placeTempleAtCandidate($level, $chunkX, $chunkZ, $random);
		}

	private function prepareLocatedPillagerOutpost($level = null, $chunkX = null, $chunkZ = null) {
			/* decompiled (structured CF) */
			$footprintChunks = \pocketmine\level\generator\normal\populator\PillagerOutpost::getOutpostFootprintChunks(($level->getSeed()), $chunkX, $chunkZ);
			$allGenerated = true;
			foreach ($footprintChunks as $chunkPos) {
				$fx = ($chunkPos['chunkX']);
				$fz = ($chunkPos['chunkZ']);
				$level->loadChunk($fx, $fz, true);
				if (!($level->isChunkGenerated($fx, $fz))) {
					$allGenerated = false;
				}
				/* goto */
			}
			if ((!($level->isChunkPopulated($chunkX, $chunkZ)) || !($allGenerated))) {
				foreach ($footprintChunks as $chunkPos) {
					$level->populateChunk(($chunkPos['chunkX']), ($chunkPos['chunkZ']), true);
					/* goto */
				}
				return null;
			}
			new \pocketmine\level\generator\normal\populator\PillagerOutpost();
			$populator = new \pocketmine\level\generator\normal\populator\PillagerOutpost();
			new \pocketmine\utils\Random(0);
			$random = new \pocketmine\utils\Random(0);
			$random->setSeed((\pocketmine\level\Level::chunkHash($chunkX, $chunkZ) ^ ($level->getSeed())));
			return $populator->placeOutpostAtCandidate($level, $chunkX, $chunkZ, $random);
		}

	private function prepareLocatedRuinedPortal($level = null, $chunkX = null, $chunkZ = null) {
			/* decompiled (structured CF) */
			$footprintChunks = \pocketmine\level\generator\normal\populator\RuinedPortal::getRuinedPortalFootprintChunks(($level->getSeed()), $chunkX, $chunkZ);
			$allGenerated = true;
			foreach ($footprintChunks as $chunkPos) {
				$fx = ($chunkPos['chunkX']);
				$fz = ($chunkPos['chunkZ']);
				$level->loadChunk($fx, $fz, true);
				if (!($level->isChunkGenerated($fx, $fz))) {
					$allGenerated = false;
				}
				/* goto */
			}
			if ((!($level->isChunkPopulated($chunkX, $chunkZ)) || !($allGenerated))) {
				foreach ($footprintChunks as $chunkPos) {
					$level->populateChunk(($chunkPos['chunkX']), ($chunkPos['chunkZ']), true);
					/* goto */
				}
				return null;
			}
			new \pocketmine\level\generator\normal\populator\RuinedPortal();
			$populator = new \pocketmine\level\generator\normal\populator\RuinedPortal();
			new \pocketmine\utils\Random(0);
			$random = new \pocketmine\utils\Random(0);
			$random->setSeed((\pocketmine\level\Level::chunkHash($chunkX, $chunkZ) ^ ($level->getSeed())));
			return $populator->placeRuinedPortalAtCandidate($level, $chunkX, $chunkZ, $random);
		}

	private function floorDiv($value = null, $divisor = null) {
			/* decompiled (structured CF) */
			$result = intdiv($value, $divisor);
			if ((($value < 0) && (($value % $divisor) !== 0))) {
				$result--;
			}
			return $result;
		}

}
