<?php

namespace pocketmine\command\defaults;

class BanipbynameCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.banipbyname.description', '%commands.banipbyname.usage');
			$this->setPermission('pocketmine.command.banipbyname');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if (($t9 === 0)) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return false;
			}
			$name = array_shift($args);
			$reason = implode($this, $args);
			if ($sender->getServer()->getPlayer($name) instanceof \pocketmine\Player) {
				$target = $sender->getServer()->getPlayer($name);
			} else {
				return false;
			}
			$sender->getServer()->getIPBans()->addBan($target->getAddress(), $reason, null, $sender->getName());
			$player = $sender->getServer()->getPlayerExact($name);
			if ($player instanceof \pocketmine\Player) {
				if (($reason !== '')) {
				} else {
				}
				$player->kick("\xe8\xa2\xab\xe5\xb0\x81\xe7\xa6\x81\xe8\xb8\xa2\xe5\x87\xba\xe6\xb8\xb8\xe6\x88\x8f");
			}
			if (($player !== null)) {
			} else {
			}
			new \pocketmine\event\TranslationContainer('%commands.banipbyname.success', [$name]);
			\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('%commands.banipbyname.success', [$name]));
			return true;
		}

}
