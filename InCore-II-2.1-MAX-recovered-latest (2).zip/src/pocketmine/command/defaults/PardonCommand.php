<?php

namespace pocketmine\command\defaults;

class PardonCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.unban.player.description', '%commands.unban.usage');
			$this->setPermission('pocketmine.command.unban.player');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if ((count($args) !== 1)) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return false;
			}
			$sender->getServer()->getNameBans()->remove($args[0]);
			new \pocketmine\event\TranslationContainer('commands.unban.success', [$args[0]]);
			\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('commands.unban.success', [$args[0]]));
			return true;
		}

}
