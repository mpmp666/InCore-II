<?php

namespace pocketmine\command\defaults;

class BiomeCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.biome.description', $this);
			$this->setPermission('pocketmine.command.biome');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if ((count($args) === 0)) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return false;
			}
			if ($sender instanceof \pocketmine\Player) {
				if (($args[0] == 'set')) {
					if (isset($args[1])) {
					} else {
					}
					$biome = 1;
					if ((isset($sender->selectedPos[0]) && isset($sender->selectedPos[1]))) {
						if ((is_numeric($biome) === false)) {
							$sender->sendMessage((\pocketmine\utils\TextFormat::RED . '%pocketmine.command.biome.wrongBio'));
							return false;
						}
						$biome = ($biome);
						if (($sender->selectedLev[0] !== $sender->selectedLev[1])) {
							$sender->sendMessage((\pocketmine\utils\TextFormat::RED . '%pocketmine.command.biome.wrongLev'));
							return false;
						}
						$x1 = min($sender->selectedPos[0][0], $sender->selectedPos[1][0]);
						$z1 = min($sender->selectedPos[0][1], $sender->selectedPos[1][1]);
						$x2 = max($sender->selectedPos[0][0], $sender->selectedPos[1][0]);
						$z2 = max($sender->selectedPos[0][1], $sender->selectedPos[1][1]);
						$level = $sender->selectedLev[0];
						$x = $x1;
						while (($x <= $x2)) {
							$z = $z1;
							while (($z <= $z2)) {
								$level->setBiomeId($x, $z, $biome);
								$z++;
							}
							$x++;
						}
						new \pocketmine\event\TranslationContainer('pocketmine.command.biome.set', [$biome]);
						$sender->sendMessage(new \pocketmine\event\TranslationContainer('pocketmine.command.biome.set', [$biome]));
					} else {
						$sender->sendMessage('%pocketmine.command.biome.noPos');
					}
				} else {
					if (($args[0] == 'color')) {
						if (isset($args[1])) {
						} else {
						}
						$color = '146,188,89';
						$a = explode(',', $color);
						if ((count($a) != 3)) {
							$sender->sendMessage((\pocketmine\utils\TextFormat::RED . '%pocketmine.command.biome.wrongCol'));
							return false;
						}
						if ((isset($sender->selectedPos[0]) && isset($sender->selectedPos[1]))) {
							if (($sender->selectedLev[0] !== $sender->selectedLev[1])) {
								$sender->sendMessage((\pocketmine\utils\TextFormat::RED . '%pocketmine.command.biome.wrongLev'));
								return false;
							}
							$x1 = min($sender->selectedPos[0][0], $sender->selectedPos[1][0]);
							$z1 = min($sender->selectedPos[0][1], $sender->selectedPos[1][1]);
							$x2 = max($sender->selectedPos[0][0], $sender->selectedPos[1][0]);
							$z2 = max($sender->selectedPos[0][1], $sender->selectedPos[1][1]);
							$x = $x1;
							while (($x <= $x2)) {
								$z = $z1;
								while (($z <= $z2)) {
									$level = $sender->getLevel();
									$level->setBiomeColor($x, $z, $a[0], $a[1], $a[2]);
									$z++;
								}
								$x++;
							}
							new \pocketmine\event\TranslationContainer('pocketmine.command.biome.color', [$a[0], $a[1], $a[2]]);
							$sender->sendMessage(new \pocketmine\event\TranslationContainer('pocketmine.command.biome.color', [$a[0], $a[1], $a[2]]));
						} else {
							$sender->sendMessage('%pocketmine.command.biome.noPos');
						}
					} else {
						if (($args[0] == 'pos1')) {
							$x = floor($sender->getX());
							$z = floor($sender->getZ());
							$sender->selectedLev[0] = $sender->getlevel();
							$sender->selectedPos[0][0] = $x;
							$sender->selectedPos[0][1] = $z;
							new \pocketmine\event\TranslationContainer('pocketmine.command.biome.posset', [$sender->selectedLev[0]->getName(), $x, $z, '1']);
							$sender->sendMessage(new \pocketmine\event\TranslationContainer('pocketmine.command.biome.posset', [$sender->selectedLev[0]->getName(), $x, $z, '1']));
						} else {
							if (($args[0] == 'pos2')) {
								$x = floor($sender->getX());
								$z = floor($sender->getZ());
								$sender->selectedLev[1] = $sender->getlevel();
								$sender->selectedPos[1][0] = $x;
								$sender->selectedPos[1][1] = $z;
								new \pocketmine\event\TranslationContainer('pocketmine.command.biome.posset', [$sender->selectedLev[1]->getname(), $x, $z, '2']);
								$sender->sendMessage(new \pocketmine\event\TranslationContainer('pocketmine.command.biome.posset', [$sender->selectedLev[1]->getname(), $x, $z, '2']));
							} else {
								if (($args[0] == 'get')) {
									$x = floor($sender->getX());
									$z = floor($sender->getZ());
									$biome = $sender->getLevel()->getBiomeId($x, $z);
									$color = $sender->getLevel()->getBiomeColor($x, $z);
									new \pocketmine\event\TranslationContainer('pocketmine.command.biome.get', [$biome, $color[0], $color[1], $color[2]]);
									$sender->sendMessage(new \pocketmine\event\TranslationContainer('pocketmine.command.biome.get', [$biome, $color[0], $color[1], $color[2]]));
								} else {
									new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
									$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
									return true;
								}
							}
						}
					}
				}
			} else {
				$sender->sendMessage('%commands.generic.runingame');
				return false;
			}
		}

}
