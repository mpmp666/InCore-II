<?php

namespace pocketmine\command\defaults;

class MakePluginCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, $this, $this);
			$this->setPermission('pocketmine.command.makeplugin');
			return;
		}

	public function execute($sender = null, $commandLabel = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return false;
			}
			if ((count($args) === 0)) {
				$sender->sendMessage(((\pocketmine\utils\TextFormat::RED . $this) . $this->usageMessage));
				return true;
			}
			$pluginName = trim(implode($this, $args));
			$plugin = \pocketmine\Server::getInstance()->getPluginManager()->getPlugin($pluginName);
			if ((($pluginName === '') || !($plugin instanceof \pocketmine\plugin\Plugin))) {
				$sender->sendMessage((\pocketmine\utils\TextFormat::RED . $this));
				return true;
			}
			$description = $plugin->getDescription();
			if (!($plugin->getPluginLoader() instanceof \pocketmine\plugin\FolderPluginLoader)) {
				$sender->sendMessage((((\pocketmine\utils\TextFormat::RED . $this) . $description->getName()) . $this));
				return true;
			}
			$pharPath = (((((((\pocketmine\Server::getInstance()->getPluginPath() . \DIRECTORY_SEPARATOR) . 'InCore-II') . \DIRECTORY_SEPARATOR) . $description->getName()) . '_v') . $description->getVersion()) . '.phar');
			if (file_exists($pharPath)) {
				$sender->sendMessage($this);
				unlink($pharPath);
			}
			new \Phar($pharPath);
			$phar = new \Phar($pharPath);
			$phar->setMetadata([$description->getName(), $description->getVersion(), $description->getMain(), $description->getCompatibleApis(), $description->getCompatibleGeniApis(), $description->getDepend(), $description->getDescription(), $description->getAuthors(), $description->getWebsite(), $this, time()]);
			if (($description->getName() === 'DevTools')) {
				$phar->setStub($this);
			} else {
				$phar->setStub((((((($this . $description->getName()) . $this) . $description->getVersion()) . $this) . date('r')) . $this));
			}
			$phar->setSignatureAlgorithm(\Phar::SHA1);
			new \ReflectionClass('pocketmine\\plugin\\PluginBase');
			$reflection = new \ReflectionClass('pocketmine\\plugin\\PluginBase');
			$file = $reflection->getProperty('file');
			$file->setAccessible(true);
			$filePath = (rtrim(str_replace('\\', '/', $file->getValue($plugin)), '/') . '/');
			$phar->startBuffering();
			new \RecursiveDirectoryIterator($filePath);
			new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($filePath));
			foreach (new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($filePath)) as $file) {
				$path = ltrim(str_replace(['\\', $filePath], ['__array_ptr' => '2aaaadd5d658'], $file), '/');
				if ((($path[0] === '.') || (strpos($path, '/.') !== false))) {
					/* goto */
				}
				$phar->addFile($file, $path);
				$sender->sendMessage($t120);
				/* goto */
			}
			foreach ($phar as $file => $finfo) {
				if ((524288 < $finfo->getSize())) {
					$finfo->compress(\Phar::GZ);
				}
				/* goto */
			}
			if ((!(isset($args[1])) || (isset($args[1]) && ($args[1] != 'nogz')))) {
				$phar->compressFiles(\Phar::GZ);
			}
			$phar->stopBuffering();
			$sender->sendMessage(((((($this . $description->getName()) . $this) . $description->getVersion()) . $this) . $pharPath));
			return true;
		}

}
