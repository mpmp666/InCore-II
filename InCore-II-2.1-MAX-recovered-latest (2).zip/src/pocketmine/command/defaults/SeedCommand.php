<?php

namespace pocketmine\command\defaults;

class SeedCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.seed.description', '%commands.seed.usage');
			$this->setPermission('pocketmine.command.seed');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if ($sender instanceof \pocketmine\Player) {
				$seed = $sender->getLevel()->getSeed();
			} else {
				$seed = $sender->getServer()->getDefaultLevel()->getSeed();
			}
			new \pocketmine\event\TranslationContainer('commands.seed.success', [$seed]);
			$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.seed.success', [$seed]));
			return true;
		}

}
