<?php

namespace pocketmine\command\defaults;

class TellCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.tell.description', '%commands.message.usage', ['__array_ptr' => '2aaaadd5d428']);
			$this->setPermission('pocketmine.command.tell');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if ((count($args) < 2)) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return false;
			}
			$name = strtolower(array_shift($args));
			$player = $sender->getServer()->getPlayer($name);
			if (($player === $sender)) {
				new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.message.sameTarget'));
				$sender->sendMessage(new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.message.sameTarget')));
				return true;
			}
			if ($player instanceof \pocketmine\Player) {
				$sender->sendMessage(((((('[' . $sender->getName()) . $this) . $player->getDisplayName()) . $this) . implode($this, $args)));
				if ($sender instanceof \pocketmine\Player) {
				} else {
				}
				$player->sendMessage(((((('[' . $sender->getName()) . $this) . $player->getName()) . $this) . implode($this, $args)));
			} else {
				new \pocketmine\event\TranslationContainer('commands.generic.player.notFound');
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.player.notFound'));
			}
			return true;
		}

}
