<?php

namespace pocketmine\command\defaults;

class StatusCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.status.description', '%pocketmine.command.status.usage');
			$this->setPermission('pocketmine.command.status');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			$mUsage = \pocketmine\utils\Utils::getMemoryUsage(true);
			$rUsage = \pocketmine\utils\Utils::getRealMemoryUsage();
			$server = $sender->getServer();
			$onlineCount = 0;
			foreach ($sender->getServer()->getOnlinePlayers() as $player) {
				if (($player->isOnline() && (!($sender instanceof \pocketmine\Player) || $sender->canSee($player)))) {
					$onlineCount++;
				}
				/* goto */
			}
			$sender->sendMessage((((((\pocketmine\utils\TextFormat::GREEN . $this) . \pocketmine\utils\TextFormat::WHITE) . '%pocketmine.command.status.title') . \pocketmine\utils\TextFormat::GREEN) . $this));
			$sender->sendMessage(((((((\pocketmine\utils\TextFormat::GOLD . '%pocketmine.command.status.player') . \pocketmine\utils\TextFormat::GREEN) . $this) . $onlineCount) . '/') . $sender->getServer()->getMaxPlayers()));
			$time = (microtime(true) - \pocketmine\START_TIME);
			$seconds = floor(($time % 60));
			$minutes = null;
			$hours = null;
			$days = null;
			if ((60 <= $time)) {
				$minutes = floor((($time % 3600) / 60));
				if ((3600 <= $time)) {
					$hours = floor((($time % 86400) / 3600));
					if ((86400 <= $time)) {
						$days = floor(($time / 86400));
					}
				}
			}
			if (($minutes !== null)) {
				if (($hours !== null)) {
					if (($days !== null)) {
					} else {
					}
				} else {
				}
			} else {
			}
			$uptime = ('' . $t90);
			$sender->sendMessage((((\pocketmine\utils\TextFormat::GOLD . $this) . \pocketmine\utils\TextFormat::RED) . $uptime));
			$tpsColor = \pocketmine\utils\TextFormat::GREEN;
			if (($server->getTicksPerSecondAverage() < 10)) {
				$tpsColor = \pocketmine\utils\TextFormat::GOLD;
			} else {
				if (($server->getTicksPerSecondAverage() < 1)) {
					$tpsColor = \pocketmine\utils\TextFormat::RED;
				}
			}
			$tpsColour = \pocketmine\utils\TextFormat::GREEN;
			if (($server->getTicksPerSecond() < 10)) {
				$tpsColour = \pocketmine\utils\TextFormat::GOLD;
			} else {
				if (($server->getTicksPerSecond() < 1)) {
					$tpsColour = \pocketmine\utils\TextFormat::RED;
				}
			}
			$sender->sendMessage(((((((\pocketmine\utils\TextFormat::GOLD . $this) . $tpsColor) . $server->getTicksPerSecondAverage()) . $this) . $server->getTickUsageAverage()) . '%)'));
			$sender->sendMessage(((((((\pocketmine\utils\TextFormat::GOLD . $this) . $tpsColour) . $server->getTicksPerSecond()) . $this) . $server->getTickUsage()) . '%)'));
			$sender->sendMessage(((((\pocketmine\utils\TextFormat::GOLD . $this) . \pocketmine\utils\TextFormat::RED) . round(($server->getNetwork()->getUpload() / 1024), 2)) . $this));
			$sender->sendMessage(((((\pocketmine\utils\TextFormat::GOLD . $this) . \pocketmine\utils\TextFormat::RED) . round(($server->getNetwork()->getDownload() / 1024), 2)) . $this));
			$sender->sendMessage((((\pocketmine\utils\TextFormat::GOLD . $this) . \pocketmine\utils\TextFormat::RED) . \pocketmine\utils\Utils::getThreadCount()));
			$sender->sendMessage(((((\pocketmine\utils\TextFormat::GOLD . $this) . \pocketmine\utils\TextFormat::RED) . number_format(round((($mUsage[0] / 1024) / 1024), 2))) . $this));
			$sender->sendMessage(((((\pocketmine\utils\TextFormat::GOLD . $this) . \pocketmine\utils\TextFormat::RED) . number_format(round((($mUsage[1] / 1024) / 1024), 2))) . $this));
			$sender->sendMessage(((((\pocketmine\utils\TextFormat::GOLD . $this) . \pocketmine\utils\TextFormat::RED) . number_format(round((($mUsage[2] / 1024) / 1024), 2))) . $this));
			$sender->sendMessage(((((\pocketmine\utils\TextFormat::GOLD . $this) . \pocketmine\utils\TextFormat::RED) . number_format(round((($rUsage[0] / 1024) / 1024), 2))) . $this));
			$sender->sendMessage(((((\pocketmine\utils\TextFormat::GOLD . $this) . \pocketmine\utils\TextFormat::RED) . number_format(round((($mUsage[2] / 1024) / 1024), 2))) . $this));
			if ((0 < $server->getProperty('memory.global-limit'))) {
				$sender->sendMessage(((((\pocketmine\utils\TextFormat::GOLD . $this) . \pocketmine\utils\TextFormat::RED) . number_format(round($server->getProperty('memory.global-limit'), 2))) . $this));
			}
			foreach ($server->getLevels() as $level) {
				if (($level->getFolderName() !== $level->getName())) {
				} else {
				}
				if (((1 < $level->getTickRate()) || (40 < $level->getTickRateTime()))) {
				} else {
				}
				if ((1 < $level->getTickRate())) {
				} else {
				}
				$sender->sendMessage(((((((((((((((((((((((\pocketmine\utils\TextFormat::GOLD . $this) . $level->getFolderName()) . '"') . '') . $this) . \pocketmine\utils\TextFormat::RED) . number_format(count($level->getChunks()))) . \pocketmine\utils\TextFormat::GREEN) . $this) . \pocketmine\utils\TextFormat::RED) . number_format(count($level->getEntities()))) . \pocketmine\utils\TextFormat::GREEN) . $this) . \pocketmine\utils\TextFormat::RED) . number_format(count($level->getTiles()))) . \pocketmine\utils\TextFormat::GREEN) . $this) . $this) . \pocketmine\utils\TextFormat::YELLOW) . round($level->getTickRateTime(), 2)) . '%pocketmine.command.status.ms') . ''));
				/* goto */
			}
			return true;
		}

}
