<?php

namespace pocketmine\command\defaults;

class CaveCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, "\xe7\x94\x9f\xe6\x88\x90\xe4\xb8\x80\xe4\xb8\xaa\xe6\xb4\x9e\xe7\xa9\xb4", '%commands.cave.usage');
			$this->setPermission('pocketmine.command.cave');
			return;
		}

	public function execute($sender = null, $commandLabel = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if (($sender instanceof \pocketmine\Player && ($args[0] == 'getmypos'))) {
				$sender->sendMessage(($this . ')'));
				return true;
			}
			if ((count($args) != 8)) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return false;
			}
			$level = $sender->getServer()->getLevelByName($args[7]);
			if (!($level instanceof \pocketmine\level\Level)) {
				$sender->sendMessage((\pocketmine\utils\TextFormat::RED . $this));
				return false;
			}
			new \pocketmine\level\Position($args[4], $args[5], $args[6], $level);
			$pos = new \pocketmine\level\Position($args[4], $args[5], $args[6], $level);
			if (isset($args[0])) {
			} else {
			}
			$caves[0] = mt_rand(1, 360);
			if (isset($args[1])) {
			} else {
			}
			$caves[1] = mt_rand(10, 300);
			if (isset($args[2])) {
			} else {
			}
			$caves[2] = mt_rand(1, 6);
			if (isset($args[3])) {
			} else {
			}
			$caves[4] = mt_rand(1, 10);
			$caves[3] = ['__array_ptr' => '2aaaadd5d540'];
			new \pocketmine\event\TranslationContainer('commands.cave.info', [$caves[0], $caves[1], $caves[2], $caves[3]]);
			$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.cave.info', [$caves[0], $caves[1], $caves[2], $caves[3]]));
			$sender->sendMessage((($this . \pocketmine\utils\TextFormat::YELLOW) . '%commands.cave.start'));
			$sender->sendMessage((((($pos->x . $this) . $pos->y) . $this) . $pos->z));
			$this->caves($pos, $caves);
			$sender->sendMessage((($this . \pocketmine\utils\TextFormat::GREEN) . '%commands.cave.success'));
			return true;
		}

	public function chu($v1 = null, $v2 = null) {
			/* decompiled (structured CF) */
			if (($v2 == 0)) {
				return 0;
			}
			return ($v1 / $v2);
		}

	public function getDirectionVector($yaw = null, $pitch = null) {
			/* decompiled (structured CF) */
			$y = (sin(deg2rad($pitch)) * -1);
			$xz = cos(deg2rad($pitch));
			$x = (sin(deg2rad($yaw)) * ($xz * -1));
			$z = ($xz * cos(deg2rad($yaw)));
			new \pocketmine\math\Vector3($x, $y, $z);
			$temporalVector = new \pocketmine\math\Vector3($x, $y, $z);
			return $temporalVector->normalize();
		}

	public function caves($pos = null, $cave = null, $tt = null) {
			/* decompiled (structured CF) */
			$x = $pos->x;
			$y = $pos->y;
			$z = $pos->z;
			$level = $pos->getLevel();
			$ls = $cave[1];
			$cv = $cave[2];
			$lofs = ($ls / $cave[2]);
			$ls2 = $lofs;
			$yaw = $cave[0];
			if (((0 <= $cave[0]) || ($cave[0] < 0))) {
			} else {
				$yaw = (mt_rand(0, 100) * 72);
			}
			$pitch = -45;
			$s1 = [$x, $y, $z];
			$s2 = [$x, $y, $z];
			$i = 1;
			$u = 0;
			while (($u <= $ls)) {
				if ((12 < $pitch)) {
					$pitch = -45;
				}
				$pitch += (5 + mt_rand(0, 5));
				$pos->getLevel()->getServer()->getLogger()->debug((($this . \pocketmine\utils\TextFormat::YELLOW) . ($this . $pitch)));
				if ($tt) {
					$pitch = (mt_rand(0, 100) * 0.05);
				}
				$see = $this->getDirectionVector($yaw, $pitch);
				$s2[0] = ($s1[0] + ($i * $see->x));
				$s2[1] = ($s1[1] - ($i * $see->y));
				$s2[2] = ($s1[2] + ($i * $see->z));
				if (($s2[1] < 10)) {
					$s2[1] = (10 + mt_rand(0, 10));
				}
				if (($lofs < $u)) {
					$cv--;
					if (($cave[3][1] === false)) {
						$cv = 0;
					}
					$lofs += $ls2;
					new \pocketmine\level\Position($s2[0], $s2[1], $s2[2], $level);
					$newPos = new \pocketmine\level\Position($s2[0], $s2[1], $s2[2], $level);
					$this->caves($newPos, [($yaw + (((round((mt_rand(0, 100) / 100)) * 2) - 1) * 90)), ($ls - $u), $cv, [false, $cave[3][1], $cave[3][2]], 0], $tt);
				}
				if ((80 < mt_rand(0, 100))) {
					$add = mt_rand(-10, 10);
				} else {
					$add = mt_rand(-45, 45);
				}
				$yaw = ($yaw + $add);
				$yaw = ($yaw % 360);
				if ((0 <= $yaw)) {
				} else {
				}
				$yaw = (360 + $yaw);
				$x = $s1[0];
				$y = $s1[1];
				$z = $s1[2];
				$x2 = $s2[0];
				$y2 = $s2[1];
				$z2 = $s2[2];
				$l = max(abs(($x - $x2)), abs(($y - $y2)), abs(($z - $z2)));
				$m = 0;
				while (($m <= $l)) {
					$liu = (mt_rand(0, 200) == 100);
					$this->fdx(round(($x + $this->chu($m, ($l * ($x2 - $x))))), round(($y + $this->chu($m, ($l * ($y2 - $y))))), round(($z + $this->chu($m, ($l * ($z2 - $z))))), $level, $liu);
					$m++;
				}
				$s1 = [$s2[0], $s2[1], $s2[2]];
				$u += $i;
			}
			if (((5 <= mt_rand(0, 10)) && ($s2[1] <= 40))) {
				$this->lavaSpawn($level, $s2[0], $s2[1], $s2[2]);
			}
			return null;
		}

	public function lavaSpawn($level = null, $x = null, $y = null, $z = null) {
			/* decompiled (structured CF) */
			$level->getServer()->getLogger()->info(((((($this . ('floor(' . ')')) . $this) . ('floor(' . ')')) . $this) . floor($z)));
			$xx = ($x - 20);
			while (($xx <= $t38)) {
				$zz = ($z - 20);
				while (($zz <= $t35)) {
					$yy = $y;
					while (($t32 < $yy)) {
						$id = $level->getBlockIdAt($xx, $yy, $zz);
						if (($id == 0)) {
							$level->setBlockIdAt($xx, $yy, $zz, 10);
							$level->setBlockDataAt($xx, $yy, $zz, 0);
						}
						$yy--;
					}
					$zz++;
				}
				$xx++;
			}
			new \pocketmine\math\Vector3($x, $y, $z);
			new \pocketmine\block\Lava();
			$level->setBlock(new \pocketmine\math\Vector3($x, $y, $z), new \pocketmine\block\Lava());
			return null;
		}

	public function explodeBlocks($source = null, $rays = null, $size = null) {
			/* decompiled (structured CF) */
			new \pocketmine\math\Vector3(0, 0, 0);
			$vector = new \pocketmine\math\Vector3(0, 0, 0);
			new \pocketmine\math\Vector3(0, 0, 0);
			$vBlock = new \pocketmine\math\Vector3(0, 0, 0);
			$stepLen = 0.3;
			$mRays = (($rays - 1));
			$affectedBlocks = ['__array_ptr' => '2aaaac9fc9a0'];
			$i = 0;
			while (($i < $rays)) {
				$j = 0;
				while (($j < $rays)) {
					$k = 0;
					while (($k < $rays)) {
						if ((((((($i === 0) || ($i === $mRays)) || ($j === 0)) || ($j === $mRays)) || ($k === 0)) || ($k === $mRays))) {
							$vector->setComponents(((($i / $mRays) * 2) - 1), ((($j / $mRays) * 2) - 1), ((($k / $mRays) * 2) - 1));
							$len = $vector->length();
							$vector->setComponents(($stepLen * ($vector->x / $len)), ($stepLen * ($vector->y / $len)), ($stepLen * ($vector->z / $len)));
							$pointerX = $source->x;
							$pointerY = $source->y;
							$pointerZ = $source->z;
							$blastForce = ($size * (mt_rand(700, 1300) / 1000));
							while ((0 < $blastForce)) {
								$x = ($pointerX);
								$y = ($pointerY);
								$z = ($pointerZ);
								if (($x <= $pointerX)) {
								} else {
								}
								$vBlock->x = ($x - 1);
								if (($y <= $pointerY)) {
								} else {
								}
								$vBlock->y = ($y - 1);
								if (($z <= $pointerZ)) {
								} else {
								}
								$vBlock->z = ($z - 1);
								if ((($vBlock->y < 0) || (127 < $vBlock->y))) {
								} else {
									$block = $source->getLevel()->getBlock($vBlock);
									if (($block->getId() !== 0)) {
										$blastForce -= ($stepLen * ((mt_rand(1, 3) / 5) + 0.3));
										if ((0 < $blastForce)) {
											if ((PHP_INT_SIZE === 8)) {
											} else {
											}
											$index = (((($block->x . ':') . $block->y) . ':') . $block->z);
											if (!(isset($affectedBlocks[$index]))) {
												$affectedBlocks[$index] = $block;
											}
										}
									}
									$pointerX += $vector->x;
									$pointerY += $vector->y;
									$pointerZ += $vector->z;
									$blastForce -= ($stepLen * 0.75);
								}
							}
						}
						$k++;
					}
					$j++;
				}
				$i++;
			}
			foreach ($affectedBlocks as $block) {
				if ($block instanceof \pocketmine\block\Block) {
					new \pocketmine\block\Air();
					$block->getLevel()->setBlock($block, new \pocketmine\block\Air(), false, false);
				}
				/* goto */
			}
			return null;
		}

	public function fdx($x = null, $y = null, $z = null, $level = null, $liu = null) {
			/* decompiled (structured CF) */
			$i = 1;
			while (($i < mt_rand(2, 4))) {
				$level->setBlockIdAt((($x + $i) - 2), ($y - 1), ($z + 1), 0);
				$level->setBlockIdAt((($x + $i) - 2), ($y - 1), $z, 0);
				$level->setBlockIdAt((($x + $i) - 2), ($y - 1), ($z - 1), 0);
				$level->setBlockIdAt((($x + $i) - 2), ($y - 1), ($z - 1), 0);
				$level->setBlockIdAt((($x + $i) - 2), ($y - 1), ($z + 1), 0);
				$level->setBlockIdAt((($x + $i) - 2), ($y + 2), ($z + 1), 0);
				$level->setBlockIdAt((($x + $i) - 2), ($y + 2), $z, 0);
				$level->setBlockIdAt((($x + $i) - 2), ($y + 2), ($z - 1), 0);
				$i++;
			}
			$i = 1;
			while (($i < mt_rand(3, 6))) {
				$level->setBlockIdAt((($x + $i) - 3), ($y + 1), ($z + 2), 0);
				$level->setBlockIdAt((($x + $i) - 3), ($y + 1), ($z + 1), 0);
				$level->setBlockIdAt((($x + $i) - 3), ($y + 1), $z, 0);
				$level->setBlockIdAt((($x + $i) - 3), ($y + 1), ($z - 1), 0);
				$level->setBlockIdAt((($x + $i) - 3), ($y + 1), ($z - 2), 0);
				$level->setBlockIdAt((($x + $i) - 3), $y, ($z + 2), 0);
				$level->setBlockIdAt((($x + $i) - 3), $y, ($z + 1), 0);
				$level->setBlockIdAt((($x + $i) - 3), $y, $z, 0);
				$level->setBlockIdAt((($x + $i) - 3), $y, ($z - 1), 0);
				$level->setBlockIdAt((($x + $i) - 3), $y, ($z - 2), 0);
				$i++;
			}
			if ($liu) {
				if ((mt_rand(0, 1) == 0)) {
					new \pocketmine\block\Water();
				} else {
					new \pocketmine\block\Lava();
				}
				$l = new \pocketmine\block\Lava();
				$i = mt_rand(3, 6);
				new \pocketmine\math\Vector3((($x + $i) - 3), ($y + 1), ($z + 3));
				$level->setBlock(new \pocketmine\math\Vector3((($x + $i) - 3), ($y + 1), ($z + 3)), $l);
			}
			return null;
		}

	public function ranz($a = null) {
			/* decompiled (structured CF) */
			$n = ['__array_ptr' => '2aaaac9fc9a0'];
			$j = 0;
			$m = 0;
			while (($m < $a)) {
				$n[] = ((mt_rand(0, 999) / 1000) - 1);
				$m++;
			}
			$m = 0;
			while (($m < $a)) {
				foreach ($n as $q) {
					$min = min($n);
					if (($min == $n[$q])) {
						$n[$q] = $j;
						$j++;
					} else {
						/* goto */
					}
				}
				$m++;
			}
			return $n;
		}

	public function tiankengy($level = null, $x = null, $y = null, $z = null, $l = null, $id = null, $bd = null) {
			/* decompiled (structured CF) */
			new \pocketmine\math\Vector3($x, $y, $z);
			if (($level->getBlock(new \pocketmine\math\Vector3($x, $y, $z))->getId() == 0)) {
				new \pocketmine\math\Vector3($x, $y, $z);
				$level->setBlock(new \pocketmine\math\Vector3($x, $y, $z), \pocketmine\item\Item::get($id, $bd)->getBlock());
			}
			if ((0 <= $l)) {
				$random = (mt_rand(0, 99999) / 100000);
				$mz = $this->ranz(4);
				foreach ($mz as $sss) {
					switch ($mz[$sss]) {
						case 0:
						new \pocketmine\math\Vector3($x, $y, ($z - 1));
						if (($level->getBlock(new \pocketmine\math\Vector3($x, $y, ($z - 1)))->getId() == 0)) {
							$this->tiankengy($level, $x, $y, ($z - 1), ($l - $random), $id, $bd);
						}
						break;
						case 1:
						new \pocketmine\math\Vector3($x, $y, ($z + 1));
						if (($level->getBlock(new \pocketmine\math\Vector3($x, $y, ($z + 1)))->getId() == 0)) {
							$this->tiankengy($level, $x, $y, ($z + 1), ($l - $random), $id, $bd);
						}
						break;
						case 2:
						new \pocketmine\math\Vector3(($x + 1), $y, $z);
						if (($level->getBlock(new \pocketmine\math\Vector3(($x + 1), $y, $z))->getId() == 0)) {
							$this->tiankengy($level, ($x + 1), $y, $z, ($l - $random), $id, $bd);
						}
						break;
						case 3:
						new \pocketmine\math\Vector3(($x - 1), $y, $z);
						if (($level->getBlock(new \pocketmine\math\Vector3(($x - 1), $y, $z))->getId() == 0)) {
							$this->tiankengy($level, ($x - 1), $y, $z, ($l - $random), $id, $bd);
						}
						break;
					}
					/* goto */
				}
			}
			return null;
		}

}
