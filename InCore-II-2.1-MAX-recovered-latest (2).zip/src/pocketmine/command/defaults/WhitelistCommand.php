<?php

namespace pocketmine\command\defaults;

class WhitelistCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.whitelist.description', '%commands.whitelist.usage', ['__array_ptr' => '2aaaadd5d460']);
			$this->setPermission('pocketmine.command.whitelist.reload;pocketmine.command.whitelist.enable;pocketmine.command.whitelist.disable;pocketmine.command.whitelist.list;pocketmine.command.whitelist.add;pocketmine.command.whitelist.remove');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if (((count($args) === 0) || (2 < count($args)))) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return true;
			}
			if ((count($args) === 1)) {
				if ($this->badPerm($sender, strtolower($args[0]))) {
					return false;
				}
				switch (strtolower($args[0])) {
					case 'reload':
					$sender->getServer()->reloadWhitelist();
					new \pocketmine\event\TranslationContainer('commands.whitelist.reloaded');
					\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('commands.whitelist.reloaded'));
					return true;
					case 'on':
					$sender->getServer()->setConfigBool('white-list', true);
					new \pocketmine\event\TranslationContainer('commands.whitelist.enabled');
					\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('commands.whitelist.enabled'));
					return true;
					case 'off':
					$sender->getServer()->setConfigBool('white-list', false);
					new \pocketmine\event\TranslationContainer('commands.whitelist.disabled');
					\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('commands.whitelist.disabled'));
					return true;
					case 'list':
					$result = '';
					$count = 0;
					foreach ($sender->getServer()->getWhitelisted()->getAll(true) as $player) {
						$result .= ($player . $this);
						$count++;
						/* goto */
					}
					new \pocketmine\event\TranslationContainer('commands.whitelist.list', [$count, $count]);
					$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.whitelist.list', [$count, $count]));
					$sender->sendMessage(substr($result, 0, -2));
					return true;
					case 'add':
					new \pocketmine\event\TranslationContainer('commands.generic.usage', ['__array_ptr' => '2aaaadd5d620']);
					$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', ['__array_ptr' => '2aaaadd5d620']));
					return true;
					case 'remove':
					new \pocketmine\event\TranslationContainer('commands.generic.usage', ['__array_ptr' => '2aaaadd5d690']);
					$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', ['__array_ptr' => '2aaaadd5d690']));
					return true;
					/* jump */
					if ((count($args) === 2)) {
						if ($this->badPerm($sender, strtolower($args[0]))) {
							return false;
						}
					}
					case 'add':
					$sender->getServer()->getOfflinePlayer($args[1])->setWhitelisted(true);
					new \pocketmine\event\TranslationContainer('commands.whitelist.add.success', [$args[1]]);
					\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('commands.whitelist.add.success', [$args[1]]));
					return true;
					case 'remove':
					$sender->getServer()->getOfflinePlayer($args[1])->setWhitelisted(false);
					new \pocketmine\event\TranslationContainer('commands.whitelist.remove.success', [$args[1]]);
					\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('commands.whitelist.remove.success', [$args[1]]));
					return true;
				}
			}
		}

	private function badPerm($sender = null, $perm = null) {
			/* decompiled (structured CF) */
			if (!($sender->hasPermission($t2))) {
				new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.permission'));
				$sender->sendMessage(new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.permission')));
				return true;
			}
			return false;
		}

}
