<?php

namespace pocketmine\command\defaults;

class LvdatCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.lvdat.description', $this);
			$this->setPermission('pocketmine.command.lvdat');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return false;
			}
			$levname = array_shift($args);
			if (($levname == '')) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return false;
			}
			if (!($this->autoLoad($sender, $levname))) {
				new \pocketmine\event\TranslationContainer('pocketmine.command.lvdat.nofound', [$levname]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('pocketmine.command.lvdat.nofound', [$levname]));
				return false;
			}
			$level = $sender->getServer()->getLevelByName($levname);
			if (!($level)) {
				new \pocketmine\event\TranslationContainer('pocketmine.command.lvdat.nofound', [$levname]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('pocketmine.command.lvdat.nofound', [$levname]));
				return false;
			}
			$provider = $level->getProvider();
			$o = array_shift($args);
			$p = array_shift($args);
			if (!(($o == 'fixname'))) {
				if (!(($o == 'help'))) {
					if (!(($o == 'seed'))) {
						if (!(($o == 'name'))) {
							if (!(($o == 'generator'))) {
								if (!(($o == 'preset'))) {
									/* jump */
									new \pocketmine\nbt\tag\StringTag('LevelName', $level->getFolderName());
									$provider->getLevelData()->LevelName = new \pocketmine\nbt\tag\StringTag('LevelName', $level->getFolderName());
									new \pocketmine\event\TranslationContainer('pocketmine.command.lvdat.fixname', [$level->getFolderName()]);
									$sender->sendMessage(new \pocketmine\event\TranslationContainer('pocketmine.command.lvdat.fixname', [$level->getFolderName()]));
								} else {
									new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
									$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
									$sender->sendMessage($this);
									$sender->sendMessage($this);
									$sender->sendMessage($this);
									$sender->sendMessage($this);
									$sender->sendMessage($this);
									/* jump */
									if (($p == '')) {
										$sender->sendMessage('%commands.generic.opt.missing');
										return false;
									}
									$provider->setSeed($p);
									new \pocketmine\event\TranslationContainer('pocketmine.command.lvdat.changed', [$level->getFolderName(), $o]);
									$sender->sendMessage(new \pocketmine\event\TranslationContainer('pocketmine.command.lvdat.changed', [$level->getFolderName(), $o]));
									/* jump */
									if (($p == '')) {
										$sender->sendMessage('%commands.generic.opt.missing');
										return false;
									}
									new \pocketmine\nbt\tag\StringTag('LevelName', $p);
									$provider->getLevelData()->LevelName = new \pocketmine\nbt\tag\StringTag('LevelName', $p);
									new \pocketmine\event\TranslationContainer('pocketmine.command.lvdat.changed', [$level->getFolderName(), $o]);
									$sender->sendMessage(new \pocketmine\event\TranslationContainer('pocketmine.command.lvdat.changed', [$level->getFolderName(), $o]));
									/* jump */
									if (($p == '')) {
										$sender->sendMessage('%commands.generic.opt.missing');
										return false;
									}
									new \pocketmine\nbt\tag\StringTag('generatorName', $p);
									$provider->getLevelData()->generatorName = new \pocketmine\nbt\tag\StringTag('generatorName', $p);
									new \pocketmine\event\TranslationContainer('pocketmine.command.lvdat.changed', [$level->getFolderName(), $o]);
									$sender->sendMessage(new \pocketmine\event\TranslationContainer('pocketmine.command.lvdat.changed', [$level->getFolderName(), $o]));
									/* jump */
									if (($p == '')) {
										$sender->sendMessage('%commands.generic.opt.missing');
										return false;
									}
									new \pocketmine\nbt\tag\StringTag('generatorOptions', $p);
									$provider->getLevelData()->generatorOptions = new \pocketmine\nbt\tag\StringTag('generatorOptions', $p);
									new \pocketmine\event\TranslationContainer('pocketmine.command.lvdat.changed', [$level->getFolderName(), $o]);
									$sender->sendMessage(new \pocketmine\event\TranslationContainer('pocketmine.command.lvdat.changed', [$level->getFolderName(), $o]));
									/* jump */
									new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
									$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
									return false;
								}
								$provider->saveLevelData();
								return true;
							}
						}
					}
				}
			}
		}

	public function autoLoad($c = null, $world = null) {
			/* decompiled (structured CF) */
			if ($c->getServer()->isLevelLoaded($world)) {
				return true;
			}
			if (!($c->getServer()->isLevelGenerated($world))) {
				return false;
			}
			$c->getServer()->loadLevel($world);
			return $c->getServer()->isLevelLoaded($world);
		}

}
