<?php

namespace pocketmine\command\defaults;

class OpCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.op.description', '%commands.op.usage');
			$this->setPermission('pocketmine.command.op.give');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if ((count($args) === 0)) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return false;
			}
			$name = array_shift($args);
			$player = $sender->getServer()->getOfflinePlayer($name);
			new \pocketmine\event\TranslationContainer('commands.op.success', [$player->getName()]);
			\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('commands.op.success', [$player->getName()]));
			if ($player instanceof \pocketmine\Player) {
				$player->sendMessage((\pocketmine\utils\TextFormat::GRAY . "\xe4\xbd\xa0\xe6\x88\x90\xe4\xb8\xba\xe4\xba\x86\xe7\xae\xa1\xe7\x90\x86\xe5\x91\x98!"));
			}
			$player->setOp(true);
			return true;
		}

}
