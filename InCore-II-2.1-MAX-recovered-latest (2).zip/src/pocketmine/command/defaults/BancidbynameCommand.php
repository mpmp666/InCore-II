<?php

namespace pocketmine\command\defaults;

class BancidbynameCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.bancidbyname.description', '%commands.bancidbyname.usage');
			$this->setPermission('pocketmine.command.bancidbyname');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if ((count($args) === 0)) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return false;
			}
			$name = array_shift($args);
			$reason = implode($this, $args);
			if ($sender->getServer()->getPlayer($name) instanceof \pocketmine\Player) {
				$target = $sender->getServer()->getPlayer($name);
			} else {
				return false;
			}
			$sender->getServer()->getCIDBans()->addBan($target->getClientId(), $reason, null, $sender->getName());
			if (($reason !== '')) {
			} else {
			}
			$target->kick("\xe8\xa2\xab\xe5\xb0\x81\xe7\xa6\x81\xe8\xb8\xa2\xe5\x87\xba\xe6\xb8\xb8\xe6\x88\x8f");
			if (($target !== null)) {
			} else {
			}
			new \pocketmine\event\TranslationContainer('%commands.bancidbyname.success', [$name]);
			\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('%commands.bancidbyname.success', [$name]));
			return true;
		}

}
