<?php

namespace pocketmine\command\defaults;

class MeCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.me.description', '%commands.me.usage');
			$this->setPermission('pocketmine.command.me');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if ((count($args) === 0)) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return false;
			}
			if ($sender instanceof \pocketmine\Player) {
			} else {
			}
			new \pocketmine\event\TranslationContainer('chat.type.emote', [$sender->getName(), (\pocketmine\utils\TextFormat::WHITE . implode($this, $args))]);
			$sender->getServer()->broadcastMessage(new \pocketmine\event\TranslationContainer('chat.type.emote', [$sender->getName(), (\pocketmine\utils\TextFormat::WHITE . implode($this, $args))]));
			return true;
		}

}
