<?php

namespace pocketmine\command\defaults;

class ChunkInfoCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, "\xe8\x8e\xb7\xe5\x8f\x96\xe5\x8c\xba\xe5\x9d\x97\xe7\x9a\x84\xe4\xbf\xa1\xe6\x81\xaf\xe6\x88\x96\xe9\x87\x8d\xe6\x96\xb0\xe7\x94\x9f\xe6\x88\x90\xe5\x8c\xba\xe5\x9d\x97", $this);
			$this->setPermission('pocketmine.command.chunkinfo');
			return;
		}

	public function execute($sender = null, $commandLabel = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if ((!($sender instanceof \pocketmine\Player) && (count($args) < 4))) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return false;
			}
			if (($sender instanceof \pocketmine\Player && (count($args) < 4))) {
				$pos = $sender->getPosition();
			} else {
				$level = $sender->getServer()->getLevelByName($args[3]);
				if (!($level instanceof \pocketmine\level\Level)) {
					$sender->sendMessage((\pocketmine\utils\TextFormat::RED . $this));
					return false;
				}
				new \pocketmine\level\Position(($args[0]), ($args[1]), ($args[2]), $level);
				$pos = new \pocketmine\level\Position(($args[0]), ($args[1]), ($args[2]), $level);
			}
			if ((!(isset($args[4])) || ($args[0] != 'regenerate'))) {
				$chunk = $pos->getLevel()->getChunk(($pos->x >> 4), ($pos->z >> 4));
				\pocketmine\level\format\mcregion\McRegion::getRegionIndex($chunk->getX(), $chunk->getZ(), $x, $z);
				$sender->sendMessage(($this . $z));
			} else {
				if (($args[4] == 'regenerate')) {
					foreach ($sender->getServer()->getOnlinePlayers() as $p) {
						if (($p->getLevel() == $pos->getLevel())) {
							$p->kick((\pocketmine\utils\TextFormat::AQUA . $this), false);
						}
						/* goto */
					}
					$pos->getLevel()->regenerateChunk(($pos->x >> 4), ($pos->z >> 4));
				}
			}
			return true;
		}

}
