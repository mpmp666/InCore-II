<?php

namespace pocketmine\command\defaults;

class KickCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.kick.description', '%commands.kick.usage');
			$this->setPermission('pocketmine.command.kick');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if ((count($args) === 0)) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return false;
			}
			$name = array_shift($args);
			$reason = trim(implode($this, $args));
			$player = $sender->getServer()->getPlayer($name);
			if ($player instanceof \pocketmine\Player) {
				$player->kick($reason);
				if ((1 <= strlen($reason))) {
					new \pocketmine\event\TranslationContainer('commands.kick.success.reason', [$player->getName(), $reason]);
					\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('commands.kick.success.reason', [$player->getName(), $reason]));
				} else {
					new \pocketmine\event\TranslationContainer('commands.kick.success', [$player->getName()]);
					\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('commands.kick.success', [$player->getName()]));
				}
			} else {
				new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.player.notFound'));
				$sender->sendMessage(new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.player.notFound')));
			}
			return true;
		}

}
