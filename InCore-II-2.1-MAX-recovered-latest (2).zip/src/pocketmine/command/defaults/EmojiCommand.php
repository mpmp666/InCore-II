<?php

namespace pocketmine\command\defaults;

class EmojiCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, "\xe5\x88\x97\xe5\x87\xba\xe9\xa2\x9c\xe6\x96\x87\xe5\xad\x97\xe5\x88\x97\xe8\xa1\xa8", '/emoji');
			$this->setPermission('');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			$sender->sendMessage("\xc2\xa7e****Emoji\xe9\xa2\x9c\xe6\x96\x87\xe5\xad\x97\xe5\x88\x97\xe8\xa1\xa8****");
			$sender->sendMessage('string(40)"\\xc2\\xa7e\\xe6\\xa0\\xbc\\xe5\\xbc\\x8f(\\xe5\\x9c\\xa8\\xe5\\x89\\x8d\\xe9\\x9d\\xa2\\xe5\\x8a\\xa0/');
			$sender->sendMessage($this);
			$sender->sendMessage($this);
			$sender->sendMessage($this);
			$sender->sendMessage($this);
			$sender->sendMessage($this);
			$sender->sendMessage($this);
			$sender->sendMessage($this);
			$sender->sendMessage($this);
			return true;
		}

}
