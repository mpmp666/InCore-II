<?php

namespace pocketmine\command\defaults;

class WeatherCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.weather.description', '%pocketmine.command.weather.usage');
			$this->setPermission('pocketmine.command.weather');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if ((count($args) < 1)) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return false;
			}
			if ($sender instanceof \pocketmine\Player) {
				$wea = \pocketmine\level\weather\Weather::getWeatherFromString($args[0]);
				if (!(isset($args[1]))) {
					$duration = mt_rand(min($sender->getServer()->weatherRandomDurationMin, $sender->getServer()->weatherRandomDurationMax), max($sender->getServer()->weatherRandomDurationMin, $sender->getServer()->weatherRandomDurationMax));
				} else {
					$duration = ($args[1]);
				}
				if (((0 <= $wea) && ($wea <= 3))) {
					$sender->getLevel()->getWeather()->setWeather($wea, $duration);
					new \pocketmine\event\TranslationContainer('pocketmine.command.weather.changed', [$sender->getLevel()->getFolderName()]);
					$sender->sendMessage(new \pocketmine\event\TranslationContainer('pocketmine.command.weather.changed', [$sender->getLevel()->getFolderName()]));
					return true;
				} else {
					$sender->sendMessage((\pocketmine\utils\TextFormat::RED . '%pocketmine.command.weather.invalid'));
					return false;
				}
			}
			if ((count($args) < 2)) {
				$sender->sendMessage((\pocketmine\utils\TextFormat::RED . '%pocketmine.command.weather.wrong'));
				return false;
			}
			$level = $sender->getServer()->getLevelByName($args[0]);
			if (!($level instanceof \pocketmine\level\Level)) {
				$sender->sendMessage((\pocketmine\utils\TextFormat::RED . '%pocketmine.command.weather.invalid.level'));
				return false;
			}
			$wea = \pocketmine\level\weather\Weather::getWeatherFromString($args[1]);
			if (!(isset($args[1]))) {
				$duration = mt_rand(min($sender->getServer()->weatherRandomDurationMin, $sender->getServer()->weatherRandomDurationMax), max($sender->getServer()->weatherRandomDurationMin, $sender->getServer()->weatherRandomDurationMax));
			} else {
				$duration = ($args[1]);
			}
			if (((0 <= $wea) && ($wea <= 3))) {
				$level->getWeather()->setWeather($wea, $duration);
				new \pocketmine\event\TranslationContainer('pocketmine.command.weather.changed', [$level->getFolderName()]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('pocketmine.command.weather.changed', [$level->getFolderName()]));
				return true;
			} else {
				$sender->sendMessage((\pocketmine\utils\TextFormat::RED . '%pocketmine.command.weather.invalid'));
				return false;
			}
		}

}
