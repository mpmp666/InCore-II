<?php

namespace pocketmine\command\defaults;

class HelpCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.help.description', '%commands.help.usage', ['__array_ptr' => '2aaaadd5d428']);
			$this->setPermission('pocketmine.command.help');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if ((count($args) === 0)) {
				$command = '';
				$pageNumber = 1;
			} else {
				if (is_numeric($args[(count($args) - 1)])) {
					$pageNumber = (array_pop($args));
					if (($pageNumber <= 0)) {
						$pageNumber = 1;
					}
					$command = implode($this, $args);
				} else {
					$command = implode($this, $args);
					$pageNumber = 1;
				}
			}
			if ($sender instanceof \pocketmine\command\ConsoleCommandSender) {
				$pageHeight = \PHP_INT_MAX;
			} else {
				$pageHeight = 5;
			}
			if (($command === '')) {
				$commands = ['__array_ptr' => '2aaaac9fc9a0'];
				foreach ($sender->getServer()->getCommandMap()->getCommands() as $command) {
					if ($command->testPermissionSilent($sender)) {
						$commands[$command->getName()] = $command;
					}
					/* goto */
				}
				ksort($commands, (\SORT_NATURAL | \SORT_FLAG_CASE));
				$commands = array_chunk($commands, $pageHeight);
				$pageNumber = (min(count($commands), $pageNumber));
				if (($pageNumber < 1)) {
					$pageNumber = 1;
				}
				new \pocketmine\event\TranslationContainer('commands.help.header', [$pageNumber, count($commands)]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.help.header', [$pageNumber, count($commands)]));
				if (isset($commands[($pageNumber - 1)])) {
					foreach ($commands[($pageNumber - 1)] as $command) {
						$sender->sendMessage((((((\pocketmine\utils\TextFormat::DARK_GREEN . '/') . $command->getName()) . $this) . \pocketmine\utils\TextFormat::WHITE) . $command->getDescription()));
						/* goto */
					}
				}
				return true;
			} else {
				$cmd = $sender->getServer()->getCommandMap()->getCommand(strtolower($command));
				if ($cmd instanceof \pocketmine\command\Command) {
					if ($cmd->testPermissionSilent($sender)) {
						$message = ((((((\pocketmine\utils\TextFormat::YELLOW . $this) . \pocketmine\utils\TextFormat::WHITE) . $this) . $cmd->getName()) . \pocketmine\utils\TextFormat::YELLOW) . $this);
						$message .= ((((\pocketmine\utils\TextFormat::GOLD . $this) . \pocketmine\utils\TextFormat::WHITE) . $cmd->getDescription()) . "\x0a");
						$message .= ((((\pocketmine\utils\TextFormat::GOLD . $this) . \pocketmine\utils\TextFormat::WHITE) . implode(("\x0a" . \pocketmine\utils\TextFormat::WHITE), explode("\x0a", $cmd->getUsage()))) . "\x0a");
						$sender->sendMessage($message);
						return true;
					}
				}
				$sender->sendMessage(((\pocketmine\utils\TextFormat::RED . $this) . strtolower($command)));
				return true;
			}
		}

}
