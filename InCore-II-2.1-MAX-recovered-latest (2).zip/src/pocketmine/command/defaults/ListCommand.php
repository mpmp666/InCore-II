<?php

namespace pocketmine\command\defaults;

class ListCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.list.description', '%command.players.usage');
			$this->setPermission('pocketmine.command.list');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if ((!($sender->getServer()->getConfigString('player-view-list')) && !($this->testPermission($sender)))) {
				return true;
			}
			$online = '';
			$onlineCount = 0;
			foreach ($sender->getServer()->getOnlinePlayers() as $player) {
				if (($player->isOnline() && (!($sender instanceof \pocketmine\Player) || $sender->canSee($player)))) {
					$online .= ($player->getDisplayName() . $this);
					$onlineCount++;
				}
				/* goto */
			}
			new \pocketmine\event\TranslationContainer('commands.players.list', [$onlineCount, $sender->getServer()->getMaxPlayers()]);
			$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.players.list', [$onlineCount, $sender->getServer()->getMaxPlayers()]));
			$sender->sendMessage(substr($online, 0, -2));
			return true;
		}

}
