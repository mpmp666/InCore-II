<?php

namespace pocketmine\command\defaults;

class ExtractPharCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, $this, $this);
			$this->setPermission('pocketmine.command.extractphar');
			return;
		}

	public function execute($sender = null, $commandLabel = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return false;
			}
			if ((count($args) === 0)) {
				$sender->sendMessage(((\pocketmine\utils\TextFormat::RED . $this) . $this->usageMessage));
				return true;
			}
			if ((!(isset($args[0])) || !(file_exists($args[0])))) {
				return false;
			}
			$folderPath = (((($sender->getServer()->getPluginPath() . \DIRECTORY_SEPARATOR) . 'InCore-II') . \DIRECTORY_SEPARATOR) . basename($args[0]));
			if (file_exists($folderPath)) {
				$sender->sendMessage($this);
			} else {
				mkdir($folderPath);
			}
			$pharPath = $t37;
			new \RecursiveDirectoryIterator($pharPath);
			new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($pharPath));
			foreach (new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($pharPath)) as $fInfo) {
				$path = $fInfo->getPathname();
				mkdir(dirname(($folderPath . str_replace($pharPath, '', $path))), 493, true);
				file_put_contents(($folderPath . str_replace($pharPath, '', $path)), file_get_contents($path));
				/* goto */
			}
			$sender->sendMessage(($this . $folderPath));
		}

}
