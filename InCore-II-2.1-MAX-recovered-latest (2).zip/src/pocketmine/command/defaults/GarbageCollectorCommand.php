<?php

namespace pocketmine\command\defaults;

class GarbageCollectorCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.gc.description', '%pocketmine.command.gc.usage');
			$this->setPermission('pocketmine.command.gc');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			$chunksCollected = 0;
			$entitiesCollected = 0;
			$tilesCollected = 0;
			$memory = memory_get_usage();
			foreach ($sender->getServer()->getLevels() as $level) {
				$diff = [count($level->getChunks()), count($level->getEntities()), count($level->getTiles())];
				$level->doChunkGarbageCollection();
				$level->unloadChunks(true);
				$chunksCollected += ($diff[0] - count($level->getChunks()));
				$entitiesCollected += ($diff[1] - count($level->getEntities()));
				$tilesCollected += ($diff[2] - count($level->getTiles()));
				$level->clearCache(true);
				/* goto */
			}
			$cyclesCollected = $sender->getServer()->getMemoryManager()->triggerGarbageCollector();
			$sender->sendMessage((((((\pocketmine\utils\TextFormat::GREEN . $this) . \pocketmine\utils\TextFormat::WHITE) . '%pocketmine.command.gc.title') . \pocketmine\utils\TextFormat::GREEN) . $this));
			$sender->sendMessage((((\pocketmine\utils\TextFormat::GOLD . '%pocketmine.command.gc.chunks') . \pocketmine\utils\TextFormat::RED) . number_format($chunksCollected)));
			$sender->sendMessage((((\pocketmine\utils\TextFormat::GOLD . '%pocketmine.command.gc.entities') . \pocketmine\utils\TextFormat::RED) . number_format($entitiesCollected)));
			$sender->sendMessage((((\pocketmine\utils\TextFormat::GOLD . '%pocketmine.command.gc.tiles') . \pocketmine\utils\TextFormat::RED) . number_format($tilesCollected)));
			$sender->sendMessage((((\pocketmine\utils\TextFormat::GOLD . '%pocketmine.command.gc.cycles') . \pocketmine\utils\TextFormat::RED) . number_format($cyclesCollected)));
			$sender->sendMessage(((((\pocketmine\utils\TextFormat::GOLD . '%pocketmine.command.gc.memory') . \pocketmine\utils\TextFormat::RED) . number_format(round(((($memory - memory_get_usage()) / 1024) / 1024), 2))) . $this));
			return true;
		}

}
