<?php

namespace pocketmine\command\defaults;

class NoticeCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, "\xe5\x8f\x91\xe9\x80\x81\xe5\x85\xac\xe5\x91\x8a", $this);
			$this->setPermission('pocketmine.command.say');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if ((count($args) === 0)) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return false;
			}
			$sender->getServer()->broadcastMessage(("\xc2\xa7e" . implode($this, $args)));
			return true;
		}

}
