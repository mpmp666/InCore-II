<?php

namespace pocketmine\command\defaults;

class MakeServerCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, $this, $this);
			$this->setPermission('pocketmine.command.makeserver');
			return;
		}

	public function execute($sender = null, $commandLabel = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return false;
			}
			$server = $sender->getServer();
			$pharPath = (((((((\pocketmine\Server::getInstance()->getPluginPath() . \DIRECTORY_SEPARATOR) . 'InCore-II') . \DIRECTORY_SEPARATOR) . $server->getName()) . '_') . $server->getPocketMineVersion()) . '.phar');
			if (file_exists($pharPath)) {
				$sender->sendMessage($this);
				unlink($pharPath);
			}
			new \Phar($pharPath);
			$phar = new \Phar($pharPath);
			$phar->setMetadata([$server->getName(), $server->getPocketMineVersion(), $server->getApiVersion(), $server->getGeniApiVersion(), $server->getVersion(), \pocketmine\network\protocol\Info::CURRENT_PROTOCOL, $this, time()]);
			$phar->setStub($this);
			$phar->setSignatureAlgorithm(\Phar::SHA1);
			$phar->startBuffering();
			if ((substr(\pocketmine\PATH, 0, 7) === 'phar://')) {
			} else {
			}
			$filePath = (realpath(\pocketmine\PATH) . '/');
			$filePath = (rtrim(str_replace('\\', '/', $filePath), '/') . '/');
			new \RecursiveDirectoryIterator(($filePath . 'src'));
			new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator(($filePath . 'src')));
			foreach (new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator(($filePath . 'src'))) as $file) {
				$path = ltrim(str_replace(['\\', $filePath], ['__array_ptr' => '2aaaadd5d508'], $file), '/');
				if (((($path[0] === '.') || (strpos($path, '/.') !== false)) || (substr($path, 0, 4) !== 'src/'))) {
					/* goto */
				}
				$phar->addFile($file, $path);
				$sender->sendMessage($t78);
				/* goto */
			}
			foreach ($phar as $file => $finfo) {
				if ((524288 < $finfo->getSize())) {
					$finfo->compress(\Phar::GZ);
				}
				/* goto */
			}
			if ((!(isset($args[0])) || (isset($args[0]) && ($args[0] != 'nogz')))) {
				$phar->compressFiles(\Phar::GZ);
			}
			$phar->stopBuffering();
			$sender->sendMessage((((($server->getName() . $this) . $server->getPocketMineVersion()) . $this) . $pharPath));
			return true;
		}

}
