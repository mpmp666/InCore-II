<?php

namespace pocketmine\command\defaults;

class TimingsCommand extends \pocketmine\command\defaults\VanillaCommand {
	public static $timingStart = 0;

	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.timings.description', '%pocketmine.command.timings.usage');
			$this->setPermission('pocketmine.command.timings');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if ((count($args) !== 1)) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return true;
			}
			$mode = strtolower($args[0]);
			if (($mode === 'on')) {
				$sender->getServer()->getPluginManager()->setUseTimings(true);
				\pocketmine\event\TimingsHandler::reload();
				new \pocketmine\event\TranslationContainer('pocketmine.command.timings.enable');
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('pocketmine.command.timings.enable'));
				return true;
			} else {
				if (($mode === 'off')) {
					$sender->getServer()->getPluginManager()->setUseTimings(false);
					new \pocketmine\event\TranslationContainer('pocketmine.command.timings.disable');
					$sender->sendMessage(new \pocketmine\event\TranslationContainer('pocketmine.command.timings.disable'));
					return true;
				}
			}
			if (!($sender->getServer()->getPluginManager()->useTimings())) {
				new \pocketmine\event\TranslationContainer('pocketmine.command.timings.timingsDisabled');
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('pocketmine.command.timings.timingsDisabled'));
				return true;
			}
			$paste = ($mode === 'paste');
			if (($mode === 'reset')) {
				\pocketmine\event\TimingsHandler::reload();
				new \pocketmine\event\TranslationContainer('pocketmine.command.timings.reset');
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('pocketmine.command.timings.reset'));
			} else {
				if (((($mode === 'merged') || ($mode === 'report')) || $paste)) {
					$sampleTime = (microtime(true) - self::$timingStart);
					$index = 0;
					$timingFolder = ($sender->getServer()->getDataPath() . 'timings/');
					if (!(file_exists($timingFolder))) {
						mkdir($timingFolder, 511);
					}
					$timings = ($timingFolder . 'timings.txt');
					while (file_exists($timings)) {
						$index++;
						$timings = ((($timingFolder . 'timings') . $index) . '.txt');
					}
					if ($paste) {
					} else {
					}
					$fileTimings = fopen($timings, 'a+b');
					\pocketmine\event\TimingsHandler::printTimings($fileTimings);
					fwrite($fileTimings, ((((($this . round(($sampleTime * 1000000000))) . $this) . $sampleTime) . 's)') . \PHP_EOL));
					if ($paste) {
						fseek($fileTimings, 0);
						$data = ['text', $sender->getServer()->getName(), stream_get_contents($fileTimings)];
						$ch = curl_init('http://paste.ubuntu.com/');
						curl_setopt($ch, \CURLOPT_POST, 1);
						curl_setopt($ch, \CURLOPT_SSL_VERIFYPEER, false);
						curl_setopt($ch, \CURLOPT_SSL_VERIFYHOST, 2);
						curl_setopt($ch, \CURLOPT_FORBID_REUSE, 1);
						curl_setopt($ch, \CURLOPT_FRESH_CONNECT, 1);
						curl_setopt($ch, \CURLOPT_POSTFIELDS, $data);
						curl_setopt($ch, \CURLOPT_AUTOREFERER, false);
						curl_setopt($ch, \CURLOPT_FOLLOWLOCATION, false);
						curl_setopt($ch, \CURLOPT_HEADER, true);
						curl_setopt($ch, \CURLOPT_HTTPHEADER, [((($this . $this->getName()) . $this) . $sender->getServer()->getPocketMineVersion())]);
						curl_setopt($ch, \CURLOPT_RETURNTRANSFER, true);
						$data = curl_exec($ch);
						curl_close($ch);
						if ((preg_match($this, $data, $matches) == 0)) {
							new \pocketmine\event\TranslationContainer('pocketmine.command.timings.pasteError');
							$sender->sendMessage(new \pocketmine\event\TranslationContainer('pocketmine.command.timings.pasteError'));
							return true;
						}
						new \pocketmine\event\TranslationContainer('pocketmine.command.timings.timingsUpload', [(('http://paste.ubuntu.com/' . $matches[1]) . '/')]);
						$sender->sendMessage(new \pocketmine\event\TranslationContainer('pocketmine.command.timings.timingsUpload', [(('http://paste.ubuntu.com/' . $matches[1]) . '/')]));
						new \pocketmine\event\TranslationContainer('pocketmine.command.timings.timingsRead', [('http://timings.aikar.co/?url=' . $matches[1])]);
						$sender->sendMessage(new \pocketmine\event\TranslationContainer('pocketmine.command.timings.timingsRead', [('http://timings.aikar.co/?url=' . $matches[1])]));
						fclose($fileTimings);
					} else {
						fclose($fileTimings);
						new \pocketmine\event\TranslationContainer('pocketmine.command.timings.timingsWrite', [$timings]);
						$sender->sendMessage(new \pocketmine\event\TranslationContainer('pocketmine.command.timings.timingsWrite', [$timings]));
					}
				}
			}
			return true;
		}

}
