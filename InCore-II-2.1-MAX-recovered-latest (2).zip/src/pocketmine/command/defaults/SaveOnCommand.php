<?php

namespace pocketmine\command\defaults;

class SaveOnCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.saveon.description', '%commands.save-on.usage');
			$this->setPermission('pocketmine.command.save.enable');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			$sender->getServer()->setAutoSave(true);
			new \pocketmine\event\TranslationContainer('commands.save.enabled');
			\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('commands.save.enabled'));
			return true;
		}

}
