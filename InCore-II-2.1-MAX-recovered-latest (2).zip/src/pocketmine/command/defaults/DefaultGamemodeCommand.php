<?php

namespace pocketmine\command\defaults;

class DefaultGamemodeCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.defaultgamemode.description', '%commands.defaultgamemode.usage');
			$this->setPermission('pocketmine.command.defaultgamemode');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if ((count($args) === 0)) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return false;
			}
			$gameMode = \pocketmine\Server::getGamemodeFromString($args[0]);
			if (($gameMode !== -1)) {
				$sender->getServer()->setConfigInt('gamemode', $gameMode);
				new \pocketmine\event\TranslationContainer('commands.defaultgamemode.success', [\pocketmine\Server::getGamemodeString($gameMode)]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.defaultgamemode.success', [\pocketmine\Server::getGamemodeString($gameMode)]));
			} else {
				$sender->sendMessage($this);
			}
			return true;
		}

}
