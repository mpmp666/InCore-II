<?php

namespace pocketmine\command\defaults;

class OplistCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, "\xe5\x88\x97\xe5\x87\xba\xe7\xae\xa1\xe7\x90\x86\xe5\x91\x98\xe5\x88\x97\xe8\xa1\xa8", '/oplist', ['__array_ptr' => '2aaaadd5d428']);
			$this->setPermission('pocketmine.command.plugins');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if ((!($sender->getServer()->getConfigString('player-list-ops')) && !($this->testPermission($sender)))) {
				return true;
			}
			$arr = $sender->getServer()->OPlist();
			$i = 0;
			while (($arr[$i] != '')) {
				$sender->sendMessage(($arr[$i] . "\x0a"));
				$i++;
			}
			return true;
		}

}
