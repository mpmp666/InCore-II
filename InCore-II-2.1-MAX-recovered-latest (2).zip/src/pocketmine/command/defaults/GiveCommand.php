<?php

namespace pocketmine\command\defaults;

class GiveCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.give.description', '%pocketmine.command.give.usage');
			$this->setPermission('pocketmine.command.give');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if ((count($args) < 2)) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return true;
			}
			$player = $sender->getServer()->getPlayer($args[0]);
			$item = \pocketmine\item\Item::fromString($args[1]);
			if (!(isset($args[2]))) {
				$item->setCount($item->getMaxStackSize());
			} else {
				$item->setCount(($args[2]));
			}
			if (isset($args[3])) {
				$exception = null;
				$tags = $exception;
				$data = implode($this, array_slice($args, 3));
				$tags = \pocketmine\nbt\NBT::parseJSON($data);
				/* jump */
				$exception = $ex;
				if ((!($tags instanceof \pocketmine\nbt\tag\CompoundTag) || ($exception !== null))) {
					if (($exception !== null)) {
					} else {
					}
					new \pocketmine\event\TranslationContainer('commands.give.tagError', [$this]);
					$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.give.tagError', [$this]));
					return true;
				}
				$item->setNamedTag($tags);
			}
			if ($player instanceof \pocketmine\Player) {
				if (($item->getId() === 0)) {
					new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.give.item.notFound'), [$args[1]]);
					$sender->sendMessage(new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.give.item.notFound'), [$args[1]]));
					return true;
				}
				$player->getInventory()->addItem(clone $item);
			} else {
				new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.player.notFound'));
				$sender->sendMessage(new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.player.notFound')));
				return true;
			}
			new \pocketmine\event\TranslationContainer('%commands.give.success', [((((($item->getName() . $this) . $item->getId()) . ':') . $item->getDamage()) . ')'), ($item->getCount()), $player->getName()]);
			\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('%commands.give.success', [((((($item->getName() . $this) . $item->getId()) . ':') . $item->getDamage()) . ')'), ($item->getCount()), $player->getName()]));
			return true;
		}

}
