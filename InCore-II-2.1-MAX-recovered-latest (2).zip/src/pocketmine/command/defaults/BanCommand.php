<?php

namespace pocketmine\command\defaults;

class BanCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.ban.player.description', '%commands.ban.usage');
			$this->setPermission('pocketmine.command.ban.player');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if ((count($args) === 0)) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return false;
			}
			$name = array_shift($args);
			if ((isset($args[0]) && isset($args[1]))) {
				$reason = $args[0];
				if ((($args[1] != null) && is_numeric($args[1]))) {
					$until = (($args[1] * 86400) + time());
				} else {
					$until = null;
				}
				$sender->getServer()->getNameBans()->addBan($name, $reason, $until, $sender->getName());
			}
			$reason = implode($this, $args);
			$sender->getServer()->getNameBans()->addBan($name, $reason, null, $sender->getName());
			$player = $sender->getServer()->getPlayerExact($name);
			if ($player instanceof \pocketmine\Player) {
				if (($reason !== '')) {
				} else {
				}
				$player->kick("\xe8\xa2\xab\xe5\xb0\x81\xe7\xa6\x81\xe8\xb8\xa2\xe5\x87\xba\xe6\xb8\xb8\xe6\x88\x8f");
			}
			if (($player !== null)) {
			} else {
			}
			new \pocketmine\event\TranslationContainer('%commands.ban.success', [$name]);
			\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('%commands.ban.success', [$name]));
			return true;
		}

}
