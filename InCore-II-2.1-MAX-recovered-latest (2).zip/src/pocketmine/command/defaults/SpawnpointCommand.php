<?php

namespace pocketmine\command\defaults;

class SpawnpointCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.spawnpoint.description', '%commands.spawnpoint.usage');
			$this->setPermission('pocketmine.command.spawnpoint');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			$target = null;
			if ((count($args) === 0)) {
				if ($sender instanceof \pocketmine\Player) {
					$target = $sender;
				} else {
					$sender->sendMessage((\pocketmine\utils\TextFormat::RED . $this));
					return true;
				}
			} else {
				$target = $sender->getServer()->getPlayer($args[0]);
				if (($target === null)) {
					new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.player.notFound'));
					$sender->sendMessage(new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.player.notFound')));
					return true;
				}
			}
			$level = $target->getLevel();
			if ((count($args) === 4)) {
				if (($level !== null)) {
					if ($sender instanceof \pocketmine\Player) {
					} else {
					}
					$pos = $level->getSpawnLocation();
					$x = ($this->getRelativeDouble($pos->x, $sender, $args[1]));
					$y = $this->getRelativeDouble($pos->y, $sender, $args[2], 0, 128);
					$z = $this->getRelativeDouble($pos->z, $sender, $args[3]);
					new \pocketmine\level\Position($x, $y, $z, $level);
					$target->setSpawn(new \pocketmine\level\Position($x, $y, $z, $level));
					new \pocketmine\event\TranslationContainer('commands.spawnpoint.success', [$target->getName(), round($x, 2), round($y, 2), round($z, 2)]);
					\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('commands.spawnpoint.success', [$target->getName(), round($x, 2), round($y, 2), round($z, 2)]));
					return true;
				}
			} else {
				if ((count($args) <= 1)) {
					if ($sender instanceof \pocketmine\Player) {
						new \pocketmine\level\Position(($sender->x), ($sender->y), ($sender->z), $sender->getLevel());
						$pos = new \pocketmine\level\Position(($sender->x), ($sender->y), ($sender->z), $sender->getLevel());
						$target->setSpawn($pos);
						new \pocketmine\event\TranslationContainer('commands.spawnpoint.success', [$target->getName(), round($pos->x, 2), round($pos->y, 2), round($pos->z, 2)]);
						\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('commands.spawnpoint.success', [$target->getName(), round($pos->x, 2), round($pos->y, 2), round($pos->z, 2)]));
						return true;
					} else {
						$sender->sendMessage((\pocketmine\utils\TextFormat::RED . $this));
						return true;
					}
				}
			}
			new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
			$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
			return true;
		}

}
