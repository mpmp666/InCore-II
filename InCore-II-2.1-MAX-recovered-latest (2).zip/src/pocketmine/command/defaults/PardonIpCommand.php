<?php

namespace pocketmine\command\defaults;

class PardonIpCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.unban.ip.description', '%commands.unbanip.usage');
			$this->setPermission('pocketmine.command.unban.ip');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if ((count($args) !== 1)) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return false;
			}
			if (preg_match('/^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])$/', $args[0])) {
				$sender->getServer()->getIPBans()->remove($args[0]);
				new \pocketmine\event\TranslationContainer('commands.unbanip.success', [$args[0]]);
				\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('commands.unbanip.success', [$args[0]]));
			} else {
				new \pocketmine\event\TranslationContainer('commands.unbanip.invalid');
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.unbanip.invalid'));
			}
			return true;
		}

}
