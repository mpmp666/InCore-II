<?php

namespace pocketmine\command\defaults;

class SetWorldSpawnCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.setworldspawn.description', '%commands.setworldspawn.usage', ['__array_ptr' => '2aaaadd5d460']);
			$this->setPermission('pocketmine.command.setworldspawn');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if ((count($args) === 0)) {
				if ($sender instanceof \pocketmine\Player) {
					$level = $sender->getLevel();
					new \pocketmine\math\Vector3($sender->x, $sender->y, $sender->z);
					$pos = (new \pocketmine\math\Vector3($sender->x, $sender->y, $sender->z))->round();
				} else {
					$sender->sendMessage((\pocketmine\utils\TextFormat::RED . $this));
					return true;
				}
			} else {
				if ((count($args) === 3)) {
					$level = $sender->getServer()->getDefaultLevel();
					new \pocketmine\math\Vector3($this->getInteger($sender, $args[0]), $this->getInteger($sender, $args[1]), $this->getInteger($sender, $args[2]));
					$pos = new \pocketmine\math\Vector3($this->getInteger($sender, $args[0]), $this->getInteger($sender, $args[1]), $this->getInteger($sender, $args[2]));
				} else {
					new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
					$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
					return true;
				}
			}
			$level->setSpawnLocation($pos);
			new \pocketmine\event\TranslationContainer('commands.setworldspawn.success', [round($pos->x, 2), round($pos->y, 2), round($pos->z, 2)]);
			\pocketmine\command\Command::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('commands.setworldspawn.success', [round($pos->x, 2), round($pos->y, 2), round($pos->z, 2)]));
			return true;
		}

}
