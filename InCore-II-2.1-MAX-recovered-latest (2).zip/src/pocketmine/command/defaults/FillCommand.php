<?php

namespace pocketmine\command\defaults;

class FillCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.fill.description', $this);
			$this->setPermission('pocketmine.command.fill');
			return;
		}

	public function execute($sender = null, $label = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			$a = 0;
			while (($a < 6)) {
				if (isset($args[$a])) {
					if ((is_numeric($args[$a]) && is_integer(($args[$a] + 0)))) {
						$item = \pocketmine\item\Item::fromString($args[6]);
						if ($item instanceof \pocketmine\item\ItemBlock) {
							$xmin = min(($args[0] + 0), ($args[3] + 0));
							$xmax = max(($args[0] + 0), ($args[3] + 0));
							$ymin = min(($args[1] + 0), ($args[4] + 0));
							$ymax = max(($args[1] + 0), ($args[4] + 0));
							$zmin = min(($args[2] + 0), ($args[5] + 0));
							$zmax = max(($args[2] + 0), ($args[5] + 0));
							if ($sender instanceof \pocketmine\Player) {
							} else {
							}
							$level = $sender->getServer()->getDefaultLevel();
							$n = 0;
							$nmax = (((($xmax - $xmin) + 1) * (($ymax - $ymin) + 1)) * (($zmax - $zmin) + 1));
							$x = $xmin;
							while (($x <= $xmax)) {
								$y = $ymin;
								while (($y <= $ymax)) {
									$z = $zmin;
									while (($z <= $zmax)) {
										new \pocketmine\math\Vector3($x, $y, $z);
										if (isset($args[7])) {
										} else {
										}
										if ($this->setBlock(new \pocketmine\math\Vector3($x, $y, $z), $level, $item, 0)) {
											$n++;
											if (is_int(($n / 10000))) {
												new \pocketmine\event\TranslationContainer(($n . $z), ['__array_ptr' => '2aaaac9fc9a0']);
												$sender->sendMessage(new \pocketmine\event\TranslationContainer(($n . $z), ['__array_ptr' => '2aaaac9fc9a0']));
											}
										} else {
											new \pocketmine\event\TranslationContainer(($this . $this), ['__array_ptr' => '2aaaac9fc9a0']);
											$sender->sendMessage((\pocketmine\utils\TextFormat::RED . new \pocketmine\event\TranslationContainer(($this . $this), ['__array_ptr' => '2aaaac9fc9a0'])));
											return false;
										}
										$z++;
									}
									$y++;
								}
								$x++;
							}
							new \pocketmine\event\TranslationContainer(($this . $this), ['__array_ptr' => '2aaaac9fc9a0']);
							$sender->sendMessage(new \pocketmine\event\TranslationContainer(($this . $this), ['__array_ptr' => '2aaaac9fc9a0']));
							return true;
						}
						new \pocketmine\event\TranslationContainer(($args[6] . $this), ['__array_ptr' => '2aaaac9fc9a0']);
						$sender->sendMessage((\pocketmine\utils\TextFormat::RED . new \pocketmine\event\TranslationContainer(($args[6] . $this), ['__array_ptr' => '2aaaac9fc9a0'])));
						return false;
					}
					new \pocketmine\event\TranslationContainer(($args[$a] . $this), ['__array_ptr' => '2aaaac9fc9a0']);
					$sender->sendMessage((\pocketmine\utils\TextFormat::RED . new \pocketmine\event\TranslationContainer(($args[$a] . $this), ['__array_ptr' => '2aaaac9fc9a0'])));
					new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
					$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
					return false;
				}
				new \pocketmine\event\TranslationContainer("\xe5\x8f\x82\xe6\x95\xb0\xe9\x94\x99\xe8\xaf\xaf", ['__array_ptr' => '2aaaac9fc9a0']);
				$sender->sendMessage((\pocketmine\utils\TextFormat::RED . new \pocketmine\event\TranslationContainer("\xe5\x8f\x82\xe6\x95\xb0\xe9\x94\x99\xe8\xaf\xaf", ['__array_ptr' => '2aaaac9fc9a0'])));
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return false;
				$a++;
			}
		}

	private function setBlock($p = null, $lvl = null, $b = null, $meta = null) {
			/* decompiled (structured CF) */
			$block = $b->getBlock();
			$block->setDamage($meta);
			$lvl->setBlock($p, $block);
			return true;
		}

}
