<?php

namespace pocketmine\command\defaults;

class EffectCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.effect.description', '%commands.effect.usage');
			$this->setPermission('pocketmine.command.effect;pocketmine.command.effect.other');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if ((count($args) < 2)) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return true;
			}
			$player = $sender->getServer()->getPlayer($args[0]);
			if (($player === null)) {
				new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.player.notFound'));
				$sender->sendMessage(new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.player.notFound')));
				return true;
			}
			if ((($player->getName() != $sender->getName()) && !($sender->hasPermission('pocketmine.command.effect.other')))) {
				$sender->sendMessage($this);
				return true;
			}
			if ((strtolower($args[1]) === 'clear')) {
				foreach ($player->getEffects() as $effect) {
					$player->removeEffect($effect->getId());
					/* goto */
				}
				new \pocketmine\event\TranslationContainer('commands.effect.success.removed.all', [$player->getDisplayName()]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.effect.success.removed.all', [$player->getDisplayName()]));
				return true;
			}
			$effect = \pocketmine\entity\Effect::getEffectByName($args[1]);
			if (($effect === null)) {
				$effect = \pocketmine\entity\Effect::getEffect(($args[1]));
			}
			if (($effect === null)) {
				new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.effect.notFound'), [($args[1])]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.effect.notFound'), [($args[1])]));
				return true;
			}
			$duration = 300;
			$amplification = 0;
			if ((3 <= count($args))) {
				$duration = ($args[2]);
				if (!($effect instanceof \pocketmine\entity\InstantEffect)) {
					$duration *= 20;
				}
			} else {
				if ($effect instanceof \pocketmine\entity\InstantEffect) {
					$duration = 1;
				}
			}
			if ((4 <= count($args))) {
				$amplification = ($args[3]);
			}
			if ((5 <= count($args))) {
				$v = strtolower($args[4]);
				if ((((($v === 'on') || ($v === 'true')) || ($v === 't')) || ($v === '1'))) {
					$effect->setVisible(false);
				}
			}
			if (($duration === 0)) {
				if (!($player->hasEffect($effect->getId()))) {
					if ((count($player->getEffects()) === 0)) {
						new \pocketmine\event\TranslationContainer('commands.effect.failure.notActive.all', [$player->getDisplayName()]);
						$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.effect.failure.notActive.all', [$player->getDisplayName()]));
					} else {
						new \pocketmine\event\TranslationContainer('commands.effect.failure.notActive', [$effect->getName(), $player->getDisplayName()]);
						$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.effect.failure.notActive', [$effect->getName(), $player->getDisplayName()]));
					}
					return true;
				}
				$player->removeEffect($effect->getId());
				new \pocketmine\event\TranslationContainer('commands.effect.success.removed', [$effect->getName(), $player->getDisplayName()]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.effect.success.removed', [$effect->getName(), $player->getDisplayName()]));
			} else {
				$effect->setDuration($duration)->setAmplifier($amplification);
				$player->addEffect($effect);
				new \pocketmine\event\TranslationContainer('%commands.effect.success', [$effect->getName(), $effect->getId(), $effect->getAmplifier(), $player->getDisplayName(), ($effect->getDuration() / 20)]);
				self::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('%commands.effect.success', [$effect->getName(), $effect->getId(), $effect->getAmplifier(), $player->getDisplayName(), ($effect->getDuration() / 20)]));
			}
			return true;
		}

}
