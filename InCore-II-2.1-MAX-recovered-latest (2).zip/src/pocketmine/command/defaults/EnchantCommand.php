<?php

namespace pocketmine\command\defaults;

class EnchantCommand extends \pocketmine\command\defaults\VanillaCommand {
	public function __construct($name = null) {
			parent::__construct($name, '%pocketmine.command.enchant.description', '%commands.enchant.usage');
			$this->setPermission('pocketmine.command.enchant');
			return;
		}

	public function execute($sender = null, $currentAlias = null, $args = null) {
			/* decompiled (structured CF) */
			if (!($this->testPermission($sender))) {
				return true;
			}
			if ((count($args) < 2)) {
				new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.generic.usage', [$this->usageMessage]));
				return true;
			}
			$player = $sender->getServer()->getPlayer($args[0]);
			if (($player === null)) {
				new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.player.notFound'));
				$sender->sendMessage(new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.player.notFound')));
				return true;
			}
			$enchantId = ($args[1]);
			if (isset($args[2])) {
			} else {
			}
			$enchantLevel = 1;
			$enchantment = \pocketmine\item\enchantment\Enchantment::getEnchantment($enchantId);
			if (($enchantment->getId() === \pocketmine\item\enchantment\Enchantment::TYPE_INVALID)) {
				new \pocketmine\event\TranslationContainer('commands.enchant.notFound', [$enchantId]);
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.enchant.notFound', [$enchantId]));
				return true;
			}
			$enchantment->setLevel($enchantLevel);
			$item = $player->getInventory()->getItemInHand();
			if (($item->getId() <= 0)) {
				new \pocketmine\event\TranslationContainer('commands.enchant.noItem');
				$sender->sendMessage(new \pocketmine\event\TranslationContainer('commands.enchant.noItem'));
				return true;
			}
			$item->addEnchantment($enchantment);
			$player->getInventory()->setItemInHand($item);
			new \pocketmine\event\TranslationContainer('%commands.enchant.success');
			self::broadcastCommandMessage($sender, new \pocketmine\event\TranslationContainer('%commands.enchant.success'));
			return true;
		}

}
