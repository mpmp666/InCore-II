<?php

namespace pocketmine\command;

class SimpleCommandMap implements \pocketmine\command\CommandMap {
	protected $knownCommands = array (
);
	private $server = NULL;

	public function __construct($server = null) {
			$this->server = $server;
			$this->setDefaultCommands();
			return;
		}

	private function setDefaultCommands() {
			/* decompiled (structured CF) */
			new \pocketmine\command\defaults\WeatherCommand('weather');
			$this->register('pocketmine', new \pocketmine\command\defaults\WeatherCommand('weather'));
			new \pocketmine\command\defaults\BanCidCommand('bancid');
			$this->register('pocketmine', new \pocketmine\command\defaults\BanCidCommand('bancid'));
			new \pocketmine\command\defaults\PardonCidCommand('pardoncid');
			$this->register('pocketmine', new \pocketmine\command\defaults\PardonCidCommand('pardoncid'));
			new \pocketmine\command\defaults\BancidbynameCommand('bancidbyname');
			$this->register('pocketmine', new \pocketmine\command\defaults\BancidbynameCommand('bancidbyname'));
			new \pocketmine\command\defaults\BanipbynameCommand('banipbyname');
			$this->register('pocketmine', new \pocketmine\command\defaults\BanipbynameCommand('banipbyname'));
			new \pocketmine\command\defaults\ExtractPharCommand('extractphar');
			$this->register('pocketmine', new \pocketmine\command\defaults\ExtractPharCommand('extractphar'));
			new \pocketmine\command\defaults\ExtractPluginCommand('extractplugin');
			$this->register('pocketmine', new \pocketmine\command\defaults\ExtractPluginCommand('extractplugin'));
			new \pocketmine\command\defaults\MakePluginCommand('makeplugin');
			$this->register('pocketmine', new \pocketmine\command\defaults\MakePluginCommand('makeplugin'));
			new \pocketmine\command\defaults\MakeServerCommand('ms');
			$this->register('pocketmine', new \pocketmine\command\defaults\MakeServerCommand('ms'));
			new \pocketmine\command\defaults\MakeServerCommand('makeserver');
			$this->register('pocketmine', new \pocketmine\command\defaults\MakeServerCommand('makeserver'));
			new \pocketmine\command\defaults\ExtractPluginCommand('ep');
			$this->register('pocketmine', new \pocketmine\command\defaults\ExtractPluginCommand('ep'));
			new \pocketmine\command\defaults\MakePluginCommand('mp');
			$this->register('pocketmine', new \pocketmine\command\defaults\MakePluginCommand('mp'));
			new \pocketmine\command\defaults\LoadPluginCommand('loadplugin');
			$this->register('pocketmine', new \pocketmine\command\defaults\LoadPluginCommand('loadplugin'));
			new \pocketmine\command\defaults\LvdatCommand('lvdat');
			$this->register('pocketmine', new \pocketmine\command\defaults\LvdatCommand('lvdat'));
			new \pocketmine\command\defaults\BiomeCommand('biome');
			$this->register('pocketmine', new \pocketmine\command\defaults\BiomeCommand('biome'));
			new \pocketmine\command\defaults\FindBiomeCommand('findbiome');
			$this->register('pocketmine', new \pocketmine\command\defaults\FindBiomeCommand('findbiome'));
			new \pocketmine\command\defaults\CaveCommand('cave');
			$this->register('pocketmine', new \pocketmine\command\defaults\CaveCommand('cave'));
			new \pocketmine\command\defaults\ChunkInfoCommand('chunkinfo');
			$this->register('pocketmine', new \pocketmine\command\defaults\ChunkInfoCommand('chunkinfo'));
			new \pocketmine\command\defaults\VersionCommand('version');
			$this->register('pocketmine', new \pocketmine\command\defaults\VersionCommand('version'));
			new \pocketmine\command\defaults\FillCommand('fill');
			$this->register('pocketmine', new \pocketmine\command\defaults\FillCommand('fill'));
			new \pocketmine\command\defaults\PluginsCommand('plugins');
			$this->register('pocketmine', new \pocketmine\command\defaults\PluginsCommand('plugins'));
			new \pocketmine\command\defaults\SeedCommand('seed');
			$this->register('pocketmine', new \pocketmine\command\defaults\SeedCommand('seed'));
			new \pocketmine\command\defaults\HelpCommand('help');
			$this->register('pocketmine', new \pocketmine\command\defaults\HelpCommand('help'));
			new \pocketmine\command\defaults\StopCommand('stop');
			$this->register('pocketmine', new \pocketmine\command\defaults\StopCommand('stop'));
			new \pocketmine\command\defaults\TellCommand('tell');
			$this->register('pocketmine', new \pocketmine\command\defaults\TellCommand('tell'));
			new \pocketmine\command\defaults\DefaultGamemodeCommand('defaultgamemode');
			$this->register('pocketmine', new \pocketmine\command\defaults\DefaultGamemodeCommand('defaultgamemode'));
			new \pocketmine\command\defaults\BanCommand('ban');
			$this->register('pocketmine', new \pocketmine\command\defaults\BanCommand('ban'));
			new \pocketmine\command\defaults\BanIpCommand('ban-ip');
			$this->register('pocketmine', new \pocketmine\command\defaults\BanIpCommand('ban-ip'));
			new \pocketmine\command\defaults\BanListCommand('banlist');
			$this->register('pocketmine', new \pocketmine\command\defaults\BanListCommand('banlist'));
			new \pocketmine\command\defaults\PardonCommand('pardon');
			$this->register('pocketmine', new \pocketmine\command\defaults\PardonCommand('pardon'));
			new \pocketmine\command\defaults\PardonIpCommand('pardon-ip');
			$this->register('pocketmine', new \pocketmine\command\defaults\PardonIpCommand('pardon-ip'));
			new \pocketmine\command\defaults\SayCommand('say');
			$this->register('pocketmine', new \pocketmine\command\defaults\SayCommand('say'));
			new \pocketmine\command\defaults\MeCommand('me');
			$this->register('pocketmine', new \pocketmine\command\defaults\MeCommand('me'));
			new \pocketmine\command\defaults\ListCommand('list');
			$this->register('pocketmine', new \pocketmine\command\defaults\ListCommand('list'));
			new \pocketmine\command\defaults\DifficultyCommand('difficulty');
			$this->register('pocketmine', new \pocketmine\command\defaults\DifficultyCommand('difficulty'));
			new \pocketmine\command\defaults\KickCommand('kick');
			$this->register('pocketmine', new \pocketmine\command\defaults\KickCommand('kick'));
			new \pocketmine\command\defaults\OpCommand('op');
			$this->register('pocketmine', new \pocketmine\command\defaults\OpCommand('op'));
			new \pocketmine\command\defaults\DeopCommand('deop');
			$this->register('pocketmine', new \pocketmine\command\defaults\DeopCommand('deop'));
			new \pocketmine\command\defaults\WhitelistCommand('whitelist');
			$this->register('pocketmine', new \pocketmine\command\defaults\WhitelistCommand('whitelist'));
			new \pocketmine\command\defaults\SaveOnCommand('save-on');
			$this->register('pocketmine', new \pocketmine\command\defaults\SaveOnCommand('save-on'));
			new \pocketmine\command\defaults\SaveOffCommand('save-off');
			$this->register('pocketmine', new \pocketmine\command\defaults\SaveOffCommand('save-off'));
			new \pocketmine\command\defaults\SaveCommand('save-all');
			$this->register('pocketmine', new \pocketmine\command\defaults\SaveCommand('save-all'));
			new \pocketmine\command\defaults\GiveCommand('give');
			$this->register('pocketmine', new \pocketmine\command\defaults\GiveCommand('give'));
			new \pocketmine\command\defaults\EffectCommand('effect');
			$this->register('pocketmine', new \pocketmine\command\defaults\EffectCommand('effect'));
			new \pocketmine\command\defaults\EnchantCommand('enchant');
			$this->register('pocketmine', new \pocketmine\command\defaults\EnchantCommand('enchant'));
			new \pocketmine\command\defaults\ParticleCommand('particle');
			$this->register('pocketmine', new \pocketmine\command\defaults\ParticleCommand('particle'));
			new \pocketmine\command\defaults\GameruleCommand('gamerule');
			$this->register('pocketmine', new \pocketmine\command\defaults\GameruleCommand('gamerule'));
			new \pocketmine\command\defaults\GamemodeCommand('gamemode');
			$this->register('pocketmine', new \pocketmine\command\defaults\GamemodeCommand('gamemode'));
			new \pocketmine\command\defaults\KillCommand('kill');
			$this->register('pocketmine', new \pocketmine\command\defaults\KillCommand('kill'));
			new \pocketmine\command\defaults\SpawnpointCommand('spawnpoint');
			$this->register('pocketmine', new \pocketmine\command\defaults\SpawnpointCommand('spawnpoint'));
			new \pocketmine\command\defaults\SetWorldSpawnCommand('setworldspawn');
			$this->register('pocketmine', new \pocketmine\command\defaults\SetWorldSpawnCommand('setworldspawn'));
			new \pocketmine\command\defaults\SummonCommand('summon');
			$this->register('pocketmine', new \pocketmine\command\defaults\SummonCommand('summon'));
			new \pocketmine\command\defaults\TeleportCommand('tp');
			$this->register('pocketmine', new \pocketmine\command\defaults\TeleportCommand('tp'));
			new \pocketmine\command\defaults\TimeCommand('time');
			$this->register('pocketmine', new \pocketmine\command\defaults\TimeCommand('time'));
			new \pocketmine\command\defaults\TimingsCommand('timings');
			$this->register('pocketmine', new \pocketmine\command\defaults\TimingsCommand('timings'));
			new \pocketmine\command\defaults\ReloadCommand('reload');
			$this->register('pocketmine', new \pocketmine\command\defaults\ReloadCommand('reload'));
			new \pocketmine\command\defaults\XpCommand('xp');
			$this->register('pocketmine', new \pocketmine\command\defaults\XpCommand('xp'));
			new \pocketmine\command\defaults\SetBlockCommand('setblock');
			$this->register('pocketmine', new \pocketmine\command\defaults\SetBlockCommand('setblock'));
			new \pocketmine\command\defaults\OplistCommand('oplist');
			$this->register('pocketmine', new \pocketmine\command\defaults\OplistCommand('oplist'));
			new \pocketmine\command\defaults\ClearbagCommand('clearbag');
			$this->register('pocketmine', new \pocketmine\command\defaults\ClearbagCommand('clearbag'));
			new \pocketmine\command\defaults\EmojiCommand('emoji');
			$this->register('pocketmine', new \pocketmine\command\defaults\EmojiCommand('emoji'));
			new \pocketmine\command\defaults\PingCommand('ping');
			$this->register('pocketmine', new \pocketmine\command\defaults\PingCommand('ping'));
			new \pocketmine\command\defaults\NoticeCommand('notice');
			$this->register('pocketmine', new \pocketmine\command\defaults\NoticeCommand('notice'));
			if ($this->server->getProperty('debug.commands', false)) {
				new \pocketmine\command\defaults\StatusCommand('status');
				$this->register('pocketmine', new \pocketmine\command\defaults\StatusCommand('status'));
				new \pocketmine\command\defaults\GarbageCollectorCommand('gc');
				$this->register('pocketmine', new \pocketmine\command\defaults\GarbageCollectorCommand('gc'));
				new \pocketmine\command\defaults\DumpMemoryCommand('dumpmemory');
				$this->register('pocketmine', new \pocketmine\command\defaults\DumpMemoryCommand('dumpmemory'));
			}
			return null;
		}

	public function registerAll($fallbackPrefix = null, $commands = null) {
			/* decompiled (structured CF) */
			foreach ($commands as $command) {
				$this->register($fallbackPrefix, $command);
				/* goto */
			}
			return null;
		}

	public function register($fallbackPrefix = null, $command = null, $label = null) {
			/* decompiled (structured CF) */
			if (($label === null)) {
				$label = $command->getName();
			}
			$label = strtolower(trim($label));
			$fallbackPrefix = strtolower(trim($fallbackPrefix));
			$registered = $this->registerAlias($command, false, $fallbackPrefix, $label);
			$aliases = $command->getAliases();
			foreach ($aliases as $index => $alias) {
				if (!($this->registerAlias($command, true, $fallbackPrefix, $alias))) {
				}
				/* goto */
			}
			$command->setAliases($aliases);
			if (!($registered)) {
				$command->setLabel((($fallbackPrefix . ':') . $label));
			}
			$command->register($this);
			return $registered;
		}

	private function registerAlias($command = null, $isAlias = null, $fallbackPrefix = null, $label = null) {
			/* decompiled (structured CF) */
			$this->knownCommands[(($fallbackPrefix . ':') . $label)] = $command;
			if ((($command instanceof \pocketmine\command\defaults\VanillaCommand || $isAlias) && isset($this->knownCommands[$label]))) {
				return false;
			}
			if (((isset($this->knownCommands[$label]) && ($this->knownCommands[$label]->getLabel() !== null)) && ($label === $this->knownCommands[$label]->getLabel()))) {
				return false;
			}
			if (!($isAlias)) {
				$command->setLabel($label);
			}
			$this->knownCommands[$label] = $command;
			return true;
		}

	private function dispatchAdvanced($sender = null, $command = null, $label = null, $args = null, $offset = null) {
			/* decompiled (structured CF) */
			if (isset($args[$offset])) {
				$argsTemp = $args;
				switch ($args[$offset]) {
					case '@a':
					$p = $this->server->getOnlinePlayers();
					if ((count($p) <= 0)) {
						$sender->sendMessage((\pocketmine\utils\TextFormat::RED . "\xe6\xb2\xa1\xe6\x9c\x89\xe7\x8e\xa9\xe5\xae\xb6\xe5\x9c\xa8\xe7\xba\xbf"));
					} else {
						foreach ($p as $player) {
							$argsTemp[$offset] = $player->getName();
							$this->dispatchAdvanced($sender, $command, $label, $argsTemp, ($offset + 1));
							/* goto */
						}
					}
					break;
					case '@r':
					$players = $this->server->getOnlinePlayers();
					if ((0 < count($players))) {
						$argsTemp[$offset] = $players[array_rand($players)]->getName();
						$this->dispatchAdvanced($sender, $command, $label, $argsTemp, ($offset + 1));
					}
					break;
					case '@s':
					if ($sender instanceof \pocketmine\Player) {
						$argsTemp[$offset] = $sender->getName();
						$this->dispatchAdvanced($sender, $command, $label, $argsTemp, ($offset + 1));
					} else {
						$sender->sendMessage((\pocketmine\utils\TextFormat::RED . "\xe4\xbd\xa0\xe5\xbf\x85\xe9\xa1\xbb\xe6\x98\xaf\xe7\x8e\xa9\xe5\xae\xb6\xef\xbc\x81"));
					}
					break;
					case '@p':
					if ($sender instanceof \pocketmine\Player) {
						$distance = 5;
						$nearestPlayer = $sender;
						foreach ($sender->getLevel()->getPlayers() as $p) {
							$dis = $p->distance($sender);
							if ((($p != $sender) && ($dis < $distance))) {
								$distance = $dis;
								$nearestPlayer = $p;
							}
							/* goto */
						}
						if (($distance != 5)) {
							$argsTemp[$offset] = $nearestPlayer->getName();
							$this->dispatchAdvanced($sender, $command, $label, $argsTemp, ($offset + 1));
						} else {
							$sender->sendMessage((\pocketmine\utils\TextFormat::RED . "\xe6\xb2\xa1\xe6\x9c\x89\xe7\x8e\xa9\xe5\xae\xb6\xe5\x9c\xa8\xe4\xbd\xa0\xe9\x99\x84\xe8\xbf\x91"));
						}
					} else {
						$sender->sendMessage((\pocketmine\utils\TextFormat::RED . "\xe4\xbd\xa0\xe5\xbf\x85\xe9\xa1\xbb\xe6\x98\xaf\xe7\x8e\xa9\xe5\xae\xb6\xef\xbc\x81"));
					}
					break;
					$this->dispatchAdvanced($sender, $command, $label, $argsTemp, ($offset + 1));
				}
			} else {
				$command->execute($sender, $label, $args);
			}
			return null;
		}

	public function dispatch($sender = null, $commandLine = null) {
			/* decompiled (structured CF) */
			$args = explode($this, $commandLine);
			if ((count($args) === 0)) {
				return false;
			}
			$sentCommandLabel = strtolower(array_shift($args));
			$target = $this->getCommand($sentCommandLabel);
			if (($target === null)) {
				return false;
			}
			$target->timings->startTiming();
			if ($this->server->advancedCommandSelector) {
				$this->dispatchAdvanced($sender, $target, $sentCommandLabel, $args);
			} else {
				$target->execute($sender, $sentCommandLabel, $args);
			}
			/* jump */
			new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.exception'));
			$sender->sendMessage(new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.exception')));
			$this->server->getLogger()->critical($this->server->getLanguage()->translateString('pocketmine.command.exception', [$commandLine, ($target), $e->getMessage()]));
			$logger = $sender->getServer()->getLogger();
			if ($logger instanceof \pocketmine\utils\MainLogger) {
				$logger->logException($e);
			}
			$target->timings->stopTiming();
			return true;
		}

	public function clearCommands() {
			/* decompiled (structured CF) */
			foreach ($this->knownCommands as $command) {
				$command->unregister($this);
				/* goto */
			}
			$this->knownCommands = ['__array_ptr' => '2aaaac9fc9a0'];
			$this->setDefaultCommands();
			return null;
		}

	public function getCommand($name = null) {
			if (isset($this->knownCommands[$name])) {
				return $this->knownCommands[$name];
			}
		}

	public function getCommands() {
			return $this->knownCommands;
		}

	public function registerServerAliases() {
			/* decompiled (structured CF) */
			$values = $this->server->getCommandAliases();
			foreach ($values as $alias => $commandStrings) {
				if (((strpos($alias, ':') !== false) || (strpos($alias, $this) !== false))) {
					$this->server->getLogger()->warning($this->server->getLanguage()->translateString('pocketmine.command.alias.illegal', [$alias]));
					/* goto */
				}
				$targets = ['__array_ptr' => '2aaaac9fc9a0'];
				$bad = '';
				foreach ($commandStrings as $commandString) {
					$args = explode($this, $commandString);
					$command = $this->getCommand($args[0]);
					if (($command === null)) {
						if ((0 < strlen($bad))) {
							$bad .= $this;
						}
						$bad .= $commandString;
					} else {
						$targets[] = $commandString;
					}
					/* goto */
				}
				if ((0 < strlen($bad))) {
					$this->server->getLogger()->warning($this->server->getLanguage()->translateString('pocketmine.command.alias.notFound', [$alias, $bad]));
					/* goto */
				}
				if ((0 < count($targets))) {
					new \pocketmine\command\FormattedCommandAlias(strtolower($alias), $targets);
					$this->knownCommands[strtolower($alias)] = new \pocketmine\command\FormattedCommandAlias(strtolower($alias), $targets);
				} else {
				}
				/* goto */
			}
			return null;
		}

}
