<?php

namespace pocketmine\command;

abstract class Command implements \Stringable {
	private $name = NULL;
	private $nextLabel = NULL;
	private $label = NULL;
	private $aliases = array (
);
	private $activeAliases = array (
);
	private $commandMap = NULL;
	protected $description = '';
	protected $usageMessage = NULL;
	private $permission = NULL;
	private $permissionMessage = NULL;
	public $timings = NULL;

	public function __construct($name = null, $description = null, $usageMessage = null, $aliases = null) {
			/* decompiled (structured CF) */
			$this->name = $name;
			$this->nextLabel = $name;
			$this->label = $name;
			$this->description = $description;
			if (($usageMessage === null)) {
			} else {
			}
			$this->usageMessage = $usageMessage;
			$this->aliases = $aliases;
			$this->activeAliases = ($aliases);
			new \pocketmine\event\TimingsHandler(($this . $name));
			$this->timings = new \pocketmine\event\TimingsHandler(($this . $name));
			return;
		}

	public abstract function execute($sender = null, $commandLabel = null, $args = null);

	public function getName() {
			return $this->name;
		}

	public function getPermission() {
			return $this->permission;
		}

	public function setPermission($permission = null) {
			$this->permission = $permission;
		}

	public function testPermission($target = null) {
			/* decompiled (structured CF) */
			if ($this->testPermissionSilent($target)) {
				return true;
			}
			if (($this->permissionMessage === null)) {
				new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.permission'));
				$target->sendMessage(new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::RED . '%commands.generic.permission')));
			} else {
				if (($this->permissionMessage !== '')) {
					$target->sendMessage(str_replace('<permission>', $this->permission, $this->permissionMessage));
				}
			}
			return false;
		}

	public function testPermissionSilent($target = null) {
			/* decompiled (structured CF) */
			if ((($this->permission === null) || ($this->permission === ''))) {
				return true;
			}
			foreach (explode(';', $this->permission) as $permission) {
				if ($target->hasPermission($permission)) {
					return true;
				}
				/* goto */
			}
			return false;
		}

	public function getLabel() {
			return $this->label;
		}

	public function setLabel($name = null) {
			/* decompiled (structured CF) */
			$this->nextLabel = $name;
			if (!($this->isRegistered())) {
				new \pocketmine\event\TimingsHandler(($this . $name));
				$this->timings = new \pocketmine\event\TimingsHandler(($this . $name));
				$this->label = $name;
				return true;
			}
			return false;
		}

	public function register($commandMap = null) {
			/* decompiled (structured CF) */
			if ($this->allowChangesFrom($commandMap)) {
				$this->commandMap = $commandMap;
				return true;
			}
			return false;
		}

	public function unregister($commandMap = null) {
			/* decompiled (structured CF) */
			if ($this->allowChangesFrom($commandMap)) {
				$this->commandMap = null;
				$this->activeAliases = $this->aliases;
				$this->label = $this->nextLabel;
				return true;
			}
			return false;
		}

	private function allowChangesFrom($commandMap = null) {
			return (($this->commandMap === null) || ($commandMap === $this->commandMap));
		}

	public function isRegistered() {
			return ($this->commandMap !== null);
		}

	public function getAliases() {
			return $this->activeAliases;
		}

	public function getPermissionMessage() {
			return $this->permissionMessage;
		}

	public function getDescription() {
			return $this->description;
		}

	public function getUsage() {
			return $this->usageMessage;
		}

	public function setAliases($aliases = null) {
			/* decompiled (structured CF) */
			$this->aliases = $aliases;
			if (!($this->isRegistered())) {
				$this->activeAliases = ($aliases);
			}
			return null;
		}

	public function setDescription($description = null) {
			$this->description = $description;
		}

	public function setPermissionMessage($permissionMessage = null) {
			$this->permissionMessage = $permissionMessage;
		}

	public function setUsage($usage = null) {
			$this->usageMessage = $usage;
		}

	public static function broadcastCommandMessage($source = null, $message = null, $sendToSource = null) {
			/* decompiled (structured CF) */
			if ($message instanceof \pocketmine\event\TextContainer) {
				$m = clone $message;
				if (($source->getServer()->getLanguage()->get($m->getText()) !== $m->getText())) {
				} else {
				}
				$result = ((((('[' . $source->getName()) . $this) . '') . $m->getText()) . ']');
				$users = $source->getServer()->getPluginManager()->getPermissionSubscriptions(\pocketmine\Server::BROADCAST_CHANNEL_ADMINISTRATIVE);
				$colored = ((\pocketmine\utils\TextFormat::GRAY . \pocketmine\utils\TextFormat::ITALIC) . $result);
				$m->setText($result);
				$result = clone $m;
				$m->setText($colored);
				$colored = clone $m;
			} else {
				$users = $source->getServer()->getPluginManager()->getPermissionSubscriptions(\pocketmine\Server::BROADCAST_CHANNEL_ADMINISTRATIVE);
				new \pocketmine\event\TranslationContainer('chat.type.admin', [$source->getName(), $message]);
				$result = new \pocketmine\event\TranslationContainer('chat.type.admin', [$source->getName(), $message]);
				new \pocketmine\event\TranslationContainer(((\pocketmine\utils\TextFormat::GRAY . \pocketmine\utils\TextFormat::ITALIC) . '%chat.type.admin'), [$source->getName(), $message]);
				$colored = new \pocketmine\event\TranslationContainer(((\pocketmine\utils\TextFormat::GRAY . \pocketmine\utils\TextFormat::ITALIC) . '%chat.type.admin'), [$source->getName(), $message]);
			}
			if ((($sendToSource === true) && !($source instanceof \pocketmine\command\ConsoleCommandSender))) {
				$source->sendMessage($message);
			}
			foreach ($users as $user) {
				if ($user instanceof \pocketmine\command\CommandSender) {
					if ($user instanceof \pocketmine\command\ConsoleCommandSender) {
						$user->sendMessage($result);
					} else {
						if (($user !== $source)) {
							$user->sendMessage($colored);
						}
					}
				}
				/* goto */
			}
			return null;
		}

	public function __toString() {
			return $this->name;
		}

}
