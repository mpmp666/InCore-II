<?php

namespace pocketmine\command;

class ConsoleCommandSender implements \pocketmine\command\CommandSender {
	private $perm = NULL;

	public function __construct() {
			new \pocketmine\permission\PermissibleBase($this);
			$this->perm = new \pocketmine\permission\PermissibleBase($this);
			return;
		}

	public function isPermissionSet($name = null) {
			return $this->perm->isPermissionSet($name);
		}

	public function hasPermission($name = null) {
			return $this->perm->hasPermission($name);
		}

	public function addAttachment($plugin = null, $name = null, $value = null) {
			return $this->perm->addAttachment($plugin, $name, $value);
		}

	public function removeAttachment($attachment = null) {
			$this->perm->removeAttachment($attachment);
			return null;
		}

	public function recalculatePermissions() {
			$this->perm->recalculatePermissions();
			return null;
		}

	public function getEffectivePermissions() {
			return $this->perm->getEffectivePermissions();
		}

	public function isPlayer() {
			return false;
		}

	public function getServer() {
			return \pocketmine\Server::getInstance();
		}

	public function sendMessage($message = null) {
			/* decompiled (structured CF) */
			if ($message instanceof \pocketmine\event\TextContainer) {
				$message = $this->getServer()->getLanguage()->translate($message);
			} else {
				$message = $this->getServer()->getLanguage()->translateString($message);
			}
			foreach (explode("\x0a", trim($message)) as $line) {
				\pocketmine\utils\MainLogger::getLogger()->info($line);
				/* goto */
			}
			return null;
		}

	public function getName() {
			return 'CONSOLE';
		}

	public function isOp() {
			return true;
		}

	public function setOp($value = null) {
			return null;
		}

}
