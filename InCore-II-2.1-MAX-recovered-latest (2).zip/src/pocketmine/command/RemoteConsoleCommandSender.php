<?php

namespace pocketmine\command;

class RemoteConsoleCommandSender extends \pocketmine\command\ConsoleCommandSender {
	private $messages = '';

	public function sendMessage($message = null) {
			/* decompiled (structured CF) */
			if ($message instanceof \pocketmine\event\TextContainer) {
				$message = $this->getServer()->getLanguage()->translate($message);
			} else {
				$message = $this->getServer()->getLanguage()->translateString($message);
			}
			$this->messages .= (trim($message, "\x0d\x0a") . "\x0a");
			return null;
		}

	public function getMessage() {
			return $this->messages;
		}

	public function getName() {
			return 'Rcon';
		}

}
