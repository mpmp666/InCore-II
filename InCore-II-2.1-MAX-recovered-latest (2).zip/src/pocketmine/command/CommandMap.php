<?php

namespace pocketmine\command;

interface CommandMap {
	public function registerAll($fallbackPrefix, array $commands);

	public function register($fallbackPrefix, pocketmine\command\Command $command, $label = NULL);

	public function dispatch(pocketmine\command\CommandSender $sender, $cmdLine);

	public function clearCommands();

	public function getCommand($name);

}
