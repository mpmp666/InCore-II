<?php

namespace pocketmine\command;

interface CommandExecutor {
	public function onCommand(pocketmine\command\CommandSender $sender, pocketmine\command\Command $command, $label, array $args);

}
