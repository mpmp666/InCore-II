<?php

namespace pocketmine;

class CompatibleClassLoader extends \BaseClassLoader {
	public function add($namespace = null, $paths = null) {
			$this->addPath(array_shift($paths));
			return null;
		}

}
