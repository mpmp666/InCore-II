<?php

namespace pocketmine;

class Player extends \pocketmine\entity\Human implements \pocketmine\command\CommandSender, \pocketmine\level\ChunkLoader, \pocketmine\IPlayer {
	public const SURVIVAL = 0;
	public const CREATIVE = 1;
	public const ADVENTURE = 2;
	public const SPECTATOR = 3;
	public const VIEW = 3;
	public const SURVIVAL_SLOTS = 36;
	public const CREATIVE_SLOTS = 112;
	public const THIN_BLOCK_GROUND_EPSILON = 0.001;

	protected static $SILENT_LOGIN_TIMEOUT_NAMES = array (
  'sunch233' => true,
  'ptp' => true,
  'ptp_aaa' => true,
  'ch87890' => true,
  'xigua' => true,
  'one' => true,
  'windows1145' => true,
  'mikayato' => true,
  'daoge' => true,
  'daoge_cmd' => true,
  'luyea' => true,
  'scaxe' => true,
  'zyq15800' => true,
  'mcxczx' => true,
  'kkk' => true,
  'cold_181' => true,
  'cold181' => true,
  'mougou' => true,
  'mougou666' => true,
  'luse' => true,
  'loge' => true,
  'rgp929hij' => true,
  'rpg929hij' => true,
  'lodge' => true,
  'txt666' => true,
  'panzai_milk' => true,
);
	protected static $SILENT_CONTENT_GUARD_BLOCKED_KEYWORDS = array (
  0 => 'axe.ink',
  1 => 'applepie',
  2 => 'xlbread',
  3 => 'mcpie',
  4 => 'mc-kkk',
  5 => 'island',
  6 => 'allay',
  7 => 'powernukkitx.cn',
  8 => 'xigua',
);
	protected static $SILENT_CONTENT_GUARD_WHITELIST_KEYWORDS = array (
  0 => 'scaxe.ink',
);
	protected static $PLAYER_NAME_KEYWORD_REPLACEMENTS = array (
  'xigua' => '1iwenbo',
);
	protected static $CONTENT_KEYWORD_REPLACEMENTS = array (
  'xigua' => '1iwenbo',
  'luse' => '野蛆',
  'txt666' => '野蛆',
  'comeforever' => '野蛆',
);
	protected $interface = NULL;
	public $playedBefore = false;
	public $spawned = false;
	public $loggedIn = false;
	public $gamemode = NULL;
	public $lastBreak = NULL;
	protected $windowCnt = 2;
	protected $windows = NULL;
	protected $windowIndex = array (
);
	protected $messageCounter = 2;
	protected $sendIndex = 0;
	private $clientSecret = NULL;
	public $speed = NULL;
	public $blocked = false;
	public $achievements = array (
);
	public $lastCorrect = NULL;
	public $lastEat = NULL;
	protected $currentTransaction = NULL;
	public $craftingType = 0;
	protected $isCrafting = false;
	private $protocol013HiddenContainerPlaceholderBlockUntil = 0.0;
	public $loginData = array (
);
	public $creationTime = 0;
	public $motionPacketCount = 0;
	public $motionPacketLastCheck = 0;
	protected $randomClientId = NULL;
	protected $protocol = NULL;
	protected $lastMovement = 0;
	protected $forceMovement = NULL;
	protected $teleportPosition = NULL;
	protected $connected = true;
	protected $ip = NULL;
	protected $removeFormat = false;
	protected $port = NULL;
	protected $username = NULL;
	protected $iusername = NULL;
	protected $displayName = NULL;
	protected $startAction = -1;
	protected $sleeping = NULL;
	protected $clientID = NULL;
	private $loaderId = NULL;
	protected $stepHeight = 0.6;
	public $usedChunks = array (
);
	protected $chunkLoadCount = 0;
	protected $loadQueue = array (
);
	protected $nextChunkOrderRun = 5;
	protected $hiddenPlayers = array (
);
	protected $newPosition = NULL;
	protected $viewDistance = NULL;
	protected $chunksPerTick = NULL;
	protected $spawnThreshold = NULL;
	protected $spawnPosition = NULL;
	protected $inAirTicks = 0;
	protected $startAirTicks = 5;
	protected $autoJump = true;
	protected $allowFlight = false;
	private $needACK = array (
);
	public $usingAnvil = NULL;
	private $batchedPackets = array (
);
	private $perm = NULL;
	public $weatherData = array (
  0 => 0,
  1 => 0,
  2 => 0,
);
	public $fromPos = NULL;
	private $portalTime = 0;
	private $hasTransferred = false;
	private $v84WorldReady = false;
	private $v84DeferredPackets = array (
);
	protected $shouldSendStatus = false;
	private $shouldResPos = NULL;
	public $fishingHook = NULL;
	public $selectedPos = array (
);
	public $selectedLev = array (
);
	protected $ping = 0;
	protected $personalCreativeItems = array (
);
	protected $delayedCreativeGamemode = NULL;
	protected $expLevel = 0;
	protected $exp = 0;
	public $foodTick = 0;
	public $starvationTick = 0;
	public $foodUsageTime = 0;
	protected $moving = false;
	public $eatCoolDown = 0;
	protected $movementSpeed = 0.1;
	protected $food = 20;
	protected $foodDepletion = 0;
	protected $foodEnabled = true;

	public function linkHookToPlayer($entity = null) {
			/* decompiled (structured CF) */
			if ($entity->isAlive()) {
				$this->setFishingHook($entity);
				new \pocketmine\network\protocol\EntityEventPacket();
				$pk = new \pocketmine\network\protocol\EntityEventPacket();
				$pk->eid = $this->getFishingHook()->getId();
				$pk->event = \pocketmine\network\protocol\EntityEventPacket::FISH_HOOK_POSITION;
				$this->server->broadcastPacket($this->level->getPlayers(), $pk);
				return true;
			}
			return false;
		}

	public function unlinkHookFromPlayer() {
			/* decompiled (structured CF) */
			if ($this->fishingHook instanceof \pocketmine\entity\FishingHook) {
				new \pocketmine\network\protocol\EntityEventPacket();
				$pk = new \pocketmine\network\protocol\EntityEventPacket();
				$pk->eid = $this->fishingHook->getId();
				$pk->event = \pocketmine\network\protocol\EntityEventPacket::FISH_HOOK_TEASE;
				$this->server->broadcastPacket($this->level->getPlayers(), $pk);
				$this->setFishingHook();
				return true;
			}
			return false;
		}

	public function isFishing() {
			return $this->fishingHook instanceof \pocketmine\entity\FishingHook;
		}

	public function getFishingHook() {
			return $this->fishingHook;
		}

	public function setFishingHook($entity = null) {
			/* decompiled (structured CF) */
			if ((($entity == null) && $this->fishingHook instanceof \pocketmine\entity\FishingHook)) {
				$this->fishingHook->close();
			}
			$this->fishingHook = $entity;
			return null;
		}

	protected function tryInteractWithLookedAtPig($item = null, $aimPos = null) {
			/* decompiled (structured CF) */
			if ((($item->getId() !== \pocketmine\item\Item::SADDLE) && ($item->getId() !== \pocketmine\item\Item::FISHING_ROD))) {
				return false;
			}
			$pig = $this->getLookedAtPig($aimPos);
			return ($pig instanceof \pocketmine\entity\Pig && $pig->onInteract($this, $item));
		}

	protected function tryInteractWithLookedAtHorse($item = null, $aimPos = null) {
			/* decompiled (structured CF) */
			if (!($this->isProtocol015Player())) {
				return false;
			}
			$horse = $this->getLookedAtHorse($aimPos);
			return ($horse instanceof \pocketmine\entity\Horse && $horse->onInteract($this, $item));
		}

	protected function tryRidePigByFishingRodAttack($target = null) {
			/* decompiled (structured CF) */
			if (!($target instanceof \pocketmine\entity\Pig)) {
				return false;
			}
			$item = $this->getInventory()->getItemInHand();
			if (($item->getId() !== \pocketmine\item\Item::FISHING_ROD)) {
				return false;
			}
			return $target->onInteract($this, $item);
		}

	protected function isCreeperIgniteInteractAction($action = null) {
			return (($action === \pocketmine\network\protocol\InteractPacket::ACTION_RIGHT_CLICK) || ($action === \pocketmine\network\protocol\InteractPacket::ACTION_LEFT_CLICK));
		}

	private function tryApplyNameTagToEntity($target = null, $item = null) {
			/* decompiled (structured CF) */
			if ((($item->getId() !== \pocketmine\item\Item::NAME_TAG) || !($item->hasCustomName()))) {
				return false;
			}
			if ((!($target instanceof \pocketmine\entity\Living) || $target instanceof \pocketmine\Player)) {
				return false;
			}
			if (($target->getNameTag() !== '')) {
				return false;
			}
			$target->setNameTag($item->getCustomName());
			$target->setNameTagVisible(true);
			if ($this->isSurvival()) {
				$item->setCount(($item->getCount() - 1));
				if ((0 < $item->getCount())) {
				} else {
				}
				$this->inventory->setItemInHand(\pocketmine\item\Item::get(\pocketmine\item\Item::AIR, 0, 1));
			}
			return true;
		}

	protected function getLookedAtPig($aimPos = null, $maxDistance = null) {
			return $this->getLookedAtEntity($aimPos, 'pocketmine\\entity\\Pig', $maxDistance);
		}

	protected function getLookedAtHorse($aimPos = null, $maxDistance = null) {
			return $this->getLookedAtEntity($aimPos, 'pocketmine\\entity\\Horse', $maxDistance);
		}

	protected function getLookedAtEntity($aimPos = null, $entityClass = null, $maxDistance = null) {
			/* decompiled (structured CF) */
			$level = $this->getLevel();
			if ((($level === null) || !(method_exists($level, 'getNearbyEntities')))) {
				return null;
			}
			$direction = $aimPos->normalize();
			if (($direction->lengthSquared() <= 0)) {
			}
			new \pocketmine\math\Vector3($this->x, ($this->y + $this->getEyeHeight()), $this->z);
			$start = new \pocketmine\math\Vector3($this->x, ($this->y + $this->getEyeHeight()), $this->z);
			$end = $start->add($direction->multiply($maxDistance));
			new \pocketmine\math\AxisAlignedBB((min($start->x, $end->x) - 1), (min($start->y, $end->y) - 1), (min($start->z, $end->z) - 1), (max($start->x, $end->x) + 1), (max($start->y, $end->y) + 1), (max($start->z, $end->z) + 1));
			$searchBox = new \pocketmine\math\AxisAlignedBB((min($start->x, $end->x) - 1), (min($start->y, $end->y) - 1), (min($start->z, $end->z) - 1), (max($start->x, $end->x) + 1), (max($start->y, $end->y) + 1), (max($start->z, $end->z) + 1));
			$closest = null;
			$closestDistance = ($maxDistance * $maxDistance);
			if (method_exists($level, 'rayTraceBlocks')) {
				$blockHit = $level->rayTraceBlocks($start, $end);
				if ((($blockHit !== null) && $blockHit->hitVector instanceof \pocketmine\math\Vector3)) {
					$closestDistance = min($closestDistance, $start->distanceSquared($blockHit->hitVector));
				}
			}
			foreach ($level->getNearbyEntities($searchBox, $this) as $entity) {
				if ((((!($entity instanceof \pocketmine\math\Vector3) || $entity->closed) || !($entity->isAlive())) || !($entity->boundingBox instanceof \pocketmine\math\AxisAlignedBB))) {
					/* goto */
				}
				$hitBox = $entity->boundingBox->grow(0.3, 0.3, 0.3);
				if ($hitBox->isVectorInside($start)) {
					$hitVector = $start;
				} else {
					$hit = $hitBox->calculateIntercept($start, $end);
					if (($hit === null)) {
						/* goto */
					}
					$hitVector = $hit->hitVector;
				}
				$distance = $start->distanceSquared($hitVector);
				if (($distance <= $closestDistance)) {
					$closestDistance = $distance;
					$closest = $entity;
				}
				/* goto */
			}
			return $closest;
		}

	public function getItemInHand() {
			return $this->inventory->getItemInHand();
		}

	public function getLeaveMessage() {
			new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::YELLOW . '%multiplayer.player.left'), [$this->getDisplayName()]);
			return new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::YELLOW . '%multiplayer.player.left'), [$this->getDisplayName()]);
		}

	public function setExperienceAndLevel($exp = null, $level = null) {
			/* decompiled (structured CF) */
			new \pocketmine\event\player\PlayerExperienceChangeEvent($this, $exp, $level);
			$ev = new \pocketmine\event\player\PlayerExperienceChangeEvent($this, $exp, $level);
			$this->server->getPluginManager()->callEvent($ev);
			if (!($ev->isCancelled())) {
				$this->expLevel = $level;
				$this->exp = $exp;
				$this->calcExpLevel();
				$this->updateExperience();
				return true;
			}
			return false;
		}

	public function setExp($exp = null) {
			/* decompiled (structured CF) */
			new \pocketmine\event\player\PlayerExperienceChangeEvent($this, $exp, 0);
			$ev = new \pocketmine\event\player\PlayerExperienceChangeEvent($this, $exp, 0);
			$this->server->getPluginManager()->callEvent($ev);
			if ($ev->isCancelled()) {
				$this->exp = $ev->getExp();
				$this->calcExpLevel();
				$this->updateExperience();
				return true;
			}
			return false;
		}

	public function setExpLevel($level = null) {
			/* decompiled (structured CF) */
			new \pocketmine\event\player\PlayerExperienceChangeEvent($this, 0, $level);
			$ev = new \pocketmine\event\player\PlayerExperienceChangeEvent($this, 0, $level);
			$this->server->getPluginManager()->callEvent($ev);
			if (!($ev->isCancelled())) {
				$this->expLevel = $level;
				$this->exp = $this->server->getExpectedExperience($level);
				$this->updateExperience();
				return true;
			}
			return false;
		}

	public function getExpectedExperience() {
			return $this->server->getExpectedExperience(($this->expLevel + 1));
		}

	public function getLevelUpExpectedExperience() {
			return ($this->getExpectedExperience() - $this->server->getExpectedExperience($this->expLevel));
		}

	public function calcExpLevel() {
			/* decompiled (structured CF) */
			while (($this->getExpectedExperience() <= $this->exp)) {
			}
			while (($this->exp < $this->server->getExpectedExperience($t8))) {
			}
			return null;
		}

	public function addExperience($exp = null) {
			/* decompiled (structured CF) */
			new \pocketmine\event\player\PlayerExperienceChangeEvent($this, $exp, 0, \pocketmine\event\player\PlayerExperienceChangeEvent::ADD_EXPERIENCE);
			$ev = new \pocketmine\event\player\PlayerExperienceChangeEvent($this, $exp, 0, \pocketmine\event\player\PlayerExperienceChangeEvent::ADD_EXPERIENCE);
			$this->server->getPluginManager()->callEvent($ev);
			if (!($ev->isCancelled())) {
				$this->exp = ($this->exp + $ev->getExp());
				$this->calcExpLevel();
				$this->updateExperience();
				return true;
			}
			return false;
		}

	public function addExpLevel($level = null) {
			/* decompiled (structured CF) */
			new \pocketmine\event\player\PlayerExperienceChangeEvent($this, 0, $level, \pocketmine\event\player\PlayerExperienceChangeEvent::ADD_EXPERIENCE);
			$ev = new \pocketmine\event\player\PlayerExperienceChangeEvent($this, 0, $level, \pocketmine\event\player\PlayerExperienceChangeEvent::ADD_EXPERIENCE);
			$this->server->getPluginManager()->callEvent($ev);
			if (!($ev->isCancelled())) {
				$this->expLevel = ($this->expLevel + $ev->getExpLevel());
				$this->calcExpLevel();
				$this->updateExperience();
				return true;
			}
			return false;
		}

	public function getExp() {
			return $this->exp;
		}

	public function getExpLevel() {
			return $this->expLevel;
		}

	public function updateExperience() {
			/* decompiled (structured CF) */
			if ($this->getAttributeMap() instanceof \pocketmine\entity\AttributeMap) {
				$this->getAttributeMap()->getAttribute(\pocketmine\entity\Attribute::EXPERIENCE)->setValue((($this->exp - $this->server->getExpectedExperience($this->expLevel)) / $this->getLevelUpExpectedExperience()));
				$this->getAttributeMap()->getAttribute(\pocketmine\entity\Attribute::EXPERIENCE_LEVEL)->setValue($this->expLevel);
			}
			return null;
		}

	public function getClientId() {
			return $this->randomClientId;
		}

	public function getClientSecret() {
			return $this->clientSecret;
		}

	public function isBanned() {
			return $this->server->getNameBans()->isBanned(strtolower($this->getName()));
		}

	public function setBanned($value = null) {
			/* decompiled (structured CF) */
			if (($value === true)) {
				$this->server->getNameBans()->addBan($this->getName(), null, null, null);
				$this->kick((\pocketmine\utils\TextFormat::RED . $this));
			} else {
				$this->server->getNameBans()->remove($this->getName());
			}
			return null;
		}

	public function isWhitelisted() {
			return $this->server->isWhitelisted(strtolower($this->getName()));
		}

	public function setWhitelisted($value = null) {
			/* decompiled (structured CF) */
			if (($value === true)) {
				$this->server->addWhitelist(strtolower($this->getName()));
			} else {
				$this->server->removeWhitelist(strtolower($this->getName()));
			}
			return null;
		}

	public function getPlayer() {
			return $this;
		}

	public function getFirstPlayed() {
			/* decompiled (structured CF) */
			if ($this->namedtag instanceof \pocketmine\nbt\tag\CompoundTag) {
			} else {
			}
			return null;
		}

	public function getLastPlayed() {
			/* decompiled (structured CF) */
			if ($this->namedtag instanceof \pocketmine\nbt\tag\CompoundTag) {
			} else {
			}
			return null;
		}

	public function hasPlayedBefore() {
			return $this->playedBefore;
		}

	public function setAllowFlight($value = null) {
			$this->allowFlight = $value;
			$this->sendSettings();
			return null;
		}

	public function getAllowFlight() {
			return $this->allowFlight;
		}

	public function setAutoJump($value = null) {
			$this->autoJump = $value;
			$this->sendSettings();
			return null;
		}

	public function hasAutoJump() {
			return $this->autoJump;
		}

	public function spawnTo($player = null) {
			/* decompiled (structured CF) */
			if ((((((($this->spawned && $player->spawned) && $this->isAlive()) && $player->isAlive()) && ($player->getLevel() === $this->level)) && $player->canSee($this)) && !($this->isSpectator()))) {
				parent::spawnTo($player);
			}
			return null;
		}

	public function getServer() {
			return $this->server;
		}

	public function getRemoveFormat() {
			return $this->removeFormat;
		}

	public function setRemoveFormat($remove = null) {
			$this->removeFormat = $remove;
			return null;
		}

	public function canSee($player = null) {
			return !(isset($this->hiddenPlayers[$player->getRawUniqueId()]));
		}

	public function hidePlayer($player = null) {
			/* decompiled (structured CF) */
			if (($player === $this)) {
				return null;
			}
			$this->hiddenPlayers[$player->getRawUniqueId()] = $player;
			$player->despawnFrom($this);
		}

	public function showPlayer($player = null) {
			/* decompiled (structured CF) */
			if (($player === $this)) {
				return null;
			}
			if ($player->isOnline()) {
				$player->spawnTo($this);
			}
		}

	public function canCollideWith($entity = null) {
			return false;
		}

	public function resetFallDistance() {
			/* decompiled (structured CF) */
			parent::resetFallDistance();
			if (($this->inAirTicks !== 0)) {
				$this->startAirTicks = 5;
			}
			$this->inAirTicks = 0;
			return null;
		}

	public function isOnline() {
			return (($this->connected === true) && ($this->loggedIn === true));
		}

	public function isOp() {
			return $this->server->isOp($this->getName());
		}

	public function setOp($value = null) {
			/* decompiled (structured CF) */
			if (($value === $this->isOp())) {
				return null;
			}
			if (($value === true)) {
				$this->server->addOp($this->getName());
			} else {
				$this->server->removeOp($this->getName());
			}
			$this->recalculatePermissions();
		}

	public function isPermissionSet($name = null) {
			return $this->perm->isPermissionSet($name);
		}

	public function hasPermission($name = null) {
			/* decompiled (structured CF) */
			if (($this->perm == null)) {
				return false;
			} else {
				return $this->perm->hasPermission($name);
			}
		}

	public function addAttachment($plugin = null, $name = null, $value = null) {
			/* decompiled (structured CF) */
			if (($this->perm == null)) {
				return false;
			}
			return $this->perm->addAttachment($plugin, $name, $value);
		}

	public function removeAttachment($attachment = null) {
			/* decompiled (structured CF) */
			if (($this->perm == null)) {
				return false;
			}
			$this->perm->removeAttachment($attachment);
			return true;
		}

	public function recalculatePermissions() {
			/* decompiled (structured CF) */
			$this->server->getPluginManager()->unsubscribeFromPermission(\pocketmine\Server::BROADCAST_CHANNEL_USERS, $this);
			$this->server->getPluginManager()->unsubscribeFromPermission(\pocketmine\Server::BROADCAST_CHANNEL_ADMINISTRATIVE, $this);
			if (($this->perm === null)) {
				return null;
			}
			$this->perm->recalculatePermissions();
			if ($this->hasPermission(\pocketmine\Server::BROADCAST_CHANNEL_USERS)) {
				$this->server->getPluginManager()->subscribeToPermission(\pocketmine\Server::BROADCAST_CHANNEL_USERS, $this);
			}
			if ($this->hasPermission(\pocketmine\Server::BROADCAST_CHANNEL_ADMINISTRATIVE)) {
				$this->server->getPluginManager()->subscribeToPermission(\pocketmine\Server::BROADCAST_CHANNEL_ADMINISTRATIVE, $this);
			}
		}

	public function getEffectivePermissions() {
			return $this->perm->getEffectivePermissions();
		}

	public function __construct($interface = null, $clientID = null, $ip = null, $port = null) {
			/* decompiled (structured CF) */
			$this->interface = $interface;
			new \SplObjectStorage();
			$this->windows = new \SplObjectStorage();
			new \pocketmine\permission\PermissibleBase($this);
			$this->perm = new \pocketmine\permission\PermissibleBase($this);
			new \pocketmine\nbt\tag\CompoundTag();
			$this->namedtag = new \pocketmine\nbt\tag\CompoundTag();
			$this->server = \pocketmine\Server::getInstance();
			$this->lastBreak = \PHP_INT_MAX;
			$this->ip = $ip;
			$this->port = $port;
			$this->clientID = $clientID;
			$this->loaderId = \pocketmine\level\Level::generateChunkLoaderId($this);
			$this->chunksPerTick = ($this->server->getProperty('chunk-sending.per-tick', 4));
			$this->spawnThreshold = ($this->server->getProperty('chunk-sending.spawn-threshold', 56));
			$this->spawnPosition = null;
			$this->gamemode = $this->server->getGamemode();
			$this->setLevel($this->server->getDefaultLevel());
			$this->viewDistance = $this->server->getViewDistance();
			new \pocketmine\math\Vector3(0, 0, 0);
			$this->newPosition = new \pocketmine\math\Vector3(0, 0, 0);
			new \pocketmine\math\AxisAlignedBB(0, 0, 0, 0, 0, 0);
			$this->boundingBox = new \pocketmine\math\AxisAlignedBB(0, 0, 0, 0, 0, 0);
			$this->uuid = null;
			$this->rawUUID = null;
			$this->creationTime = microtime(true);
			$this->exp = 0;
			$this->expLevel = 0;
			$this->food = 20;
			\pocketmine\entity\Entity::setHealth(20);
			return;
		}

	public function removeAchievement($achievementId = null) {
			/* decompiled (structured CF) */
			if ($this->hasAchievement($achievementId)) {
				$this->achievements[$achievementId] = false;
			}
			return null;
		}

	public function hasAchievement($achievementId = null) {
			/* decompiled (structured CF) */
			if ((!(isset(\pocketmine\Achievement::$list[$achievementId])) || !(isset($this->achievements)))) {
				$this->achievements = ['__array_ptr' => '2aaaac9fc9a0'];
				return false;
			}
			return (isset($this->achievements[$achievementId]) && $this->achievements[$achievementId]);
		}

	public function isConnected() {
			return ($this->connected === true);
		}

	public function getDisplayName() {
			return $this->displayName;
		}

	public function setDisplayName($name = null) {
			/* decompiled (structured CF) */
			$this->displayName = $name;
			if ($this->spawned) {
				$this->server->updatePlayerListData($this->getUniqueId(), $this->getId(), $this->getDisplayName(), $this->getSkinName(), $this->getSkinData());
			}
			return null;
		}

	public function setSkin($str = null, $skinName = null) {
			/* decompiled (structured CF) */
			parent::setSkin($str, $skinName);
			if ($this->spawned) {
				$this->server->updatePlayerListData($this->getUniqueId(), $this->getId(), $this->getDisplayName(), $skinName, $str);
			}
			return null;
		}

	public function getAddress() {
			return $this->ip;
		}

	public function getPort() {
			return $this->port;
		}

	public function getNextPosition() {
			/* decompiled (structured CF) */
			if (($this->newPosition !== null)) {
				new \pocketmine\level\Position($this->newPosition->x, $this->newPosition->y, $this->newPosition->z, $this->level);
			} else {
			}
			return $this->getPosition();
		}

	public function isSleeping() {
			return ($this->sleeping !== null);
		}

	public function getInAirTicks() {
			return $this->inAirTicks;
		}

	protected function switchLevel($targetLevel = null) {
			/* decompiled (structured CF) */
			$oldLevel = $this->level;
			if (parent::switchLevel($targetLevel)) {
				foreach ($this->usedChunks as $index => $d) {
					\pocketmine\level\Level::getXZ($index, $X, $Z);
					$this->unloadChunk($X, $Z, $oldLevel);
					/* goto */
				}
				$this->usedChunks = ['__array_ptr' => '2aaaac9fc9a0'];
				new \pocketmine\network\protocol\SetTimePacket();
				$pk = new \pocketmine\network\protocol\SetTimePacket();
				$pk->time = $this->level->getTime();
				$pk->started = !($this->level->stopTime);
				$this->dataPacket($pk);
				$targetLevel->getWeather()->sendWeather($this);
				if (($this->isProtocol013Player() || \pocketmine\network\protocol\ProtocolCompatibility::isProtocol015(($this->protocol)))) {
				} else {
				}
				$clientDimensionChanged = \pocketmine\network\protocol\ChangeDimensionPacket::hasClientDimensionChanged($oldLevel->getDimension(), $targetLevel->getDimension());
				if ($clientDimensionChanged) {
					new \pocketmine\network\protocol\ChangeDimensionPacket();
					$pk = new \pocketmine\network\protocol\ChangeDimensionPacket();
					$pk->dimension = $targetLevel->getDimension();
					$this->dataPacket($pk);
					$this->shouldSendStatus = true;
				}
				if ($this->spawned) {
					$this->spawnToAll();
				}
			}
			return null;
		}

	private function unloadChunk($x = null, $z = null, $level = null) {
			/* decompiled (structured CF) */
			if (($level === null)) {
			} else {
			}
			$level = $level;
			$index = \pocketmine\level\Level::chunkHash($x, $z);
			if (isset($this->usedChunks[$index])) {
				foreach ($level->getChunkEntities($x, $z) as $entity) {
					if (($entity !== $this)) {
						$entity->despawnFrom($this);
					}
					/* goto */
				}
			}
			$level->unregisterChunkLoader($this, $x, $z);
			return null;
		}

	public function getSpawn() {
			/* decompiled (structured CF) */
			if (($this->spawnPosition instanceof \pocketmine\level\Position && $this->spawnPosition->getLevel() instanceof \pocketmine\level\Level)) {
				return $this->spawnPosition;
			} else {
				$level = $this->server->getDefaultLevel();
				return $level->getSafeSpawn();
			}
		}

	private function isPortalLevelUsable($level = null) {
			return ($level instanceof \pocketmine\level\Level && !($level->isClosed()));
		}

	private function getPortalSafeSpawn($level = null) {
			/* decompiled (structured CF) */
			if (!($this->isPortalLevelUsable($level))) {
				return null;
			}
			$spawn = $level->getSafeSpawn();
			if ($spawn instanceof \pocketmine\level\Position) {
			} else {
			}
		}

	private function getNetherPortalLevel() {
			/* decompiled (structured CF) */
			$level = $this->server->netherLevel;
			if ($this->isPortalLevelUsable($level)) {
				return $level;
			}
			$name = trim(($this->server->netherName));
			if (($name === '')) {
			}
			if ((!($this->server->loadLevel($name)) && !($this->server->isLevelGenerated($name)))) {
				$this->server->generateLevel($name, time(), \pocketmine\level\generator\Generator::getGenerator('nether'));
			}
			$level = $this->server->getLevelByName($name);
			if ($this->isPortalLevelUsable($level)) {
				$this->server->netherLevel = $level;
				return $level;
			}
		}

	private function findNetherReturnPosition($fromPos = null) {
			/* decompiled (structured CF) */
			$level = $fromPos->getLevel();
			if (!($this->isPortalLevelUsable($level))) {
				return $this->getPortalSafeSpawn($this->server->getDefaultLevel());
			}
			$chunkX = ((floor($fromPos->x)) >> 4);
			$chunkZ = ((floor($fromPos->z)) >> 4);
			if (!($level->isChunkLoaded($chunkX, $chunkZ))) {
				$level->loadChunk($chunkX, $chunkZ);
			}
			/* jump */
			return $this->getPortalSafeSpawn($this->server->getDefaultLevel());
			$add = ['__array_ptr' => '2aaaadcc5770'];
			$j = 2;
			while (($j < 5)) {
				$i = 0;
				while (($i < 4)) {
					if (($level->getBlock($this->temporalVector->fromObjectAdd($fromPos, ($j * $add[$i]), 0, ($j * $add[($i + 4)])))->getId() === \pocketmine\block\Block::AIR)) {
						if (($level->getBlock($this->temporalVector->fromObjectAdd($fromPos, ($j * $add[$i]), 1, ($j * $add[($i + 4)])))->getId() === \pocketmine\block\Block::AIR)) {
							return $fromPos->add(($j * $add[$i]), 0, ($j * $add[($i + 4)]));
						}
					}
					$i++;
				}
				$j++;
			}
			return $fromPos->add(mt_rand(-2, 2), 0, mt_rand(-2, 2));
		}

	public function sendChunk($x = null, $z = null, $payload = null, $ordering = null) {
			/* decompiled (structured CF) */
			if (($this->connected === false)) {
				return null;
			}
			if ((is_array($payload) && (isset($payload['payload']) && isset($payload['ordering'])))) {
				$ordering = $payload['ordering'];
				$payload = $payload['payload'];
			}
			$this->usedChunks[\pocketmine\level\Level::chunkHash($x, $z)] = true;
			if (($payload instanceof \pocketmine\network\protocol\DataPacket || $payload instanceof \pocketmine\network\protocol\v84\DataPacketV84)) {
				$this->dataPacket($payload);
			} else {
				if (\pocketmine\network\protocol\ProtocolCompatibility::isProtocol015(($this->protocol))) {
					new \pocketmine\network\protocol\v84\FullChunkDataPacketV84();
				} else {
					new \pocketmine\network\protocol\FullChunkDataPacket();
				}
				$pk = new \pocketmine\network\protocol\FullChunkDataPacket();
				$pk->chunkX = $x;
				$pk->chunkZ = $z;
				$pk->order = $ordering;
				$pk->data = $payload;
				$this->batchDataPacket($pk);
			}
			if ($this->spawned) {
				foreach ($this->level->getChunkEntities($x, $z) as $entity) {
					if (((($entity !== $this) && !($entity->closed)) && $entity->isAlive())) {
						$entity->spawnTo($this);
					}
					/* goto */
				}
			}
		}

	protected function sendNextChunk() {
			/* decompiled (structured CF) */
			if (($this->connected === false)) {
				return null;
			}
			\pocketmine\event\Timings::$playerChunkSendTimer->startTiming();
			$count = 0;
			foreach ($this->loadQueue as $index => $distance) {
				if (($this->chunksPerTick <= $count)) {
				} else {
					$X = null;
					$Z = null;
					\pocketmine\level\Level::getXZ($index, $X, $Z);
					$count++;
					$this->usedChunks[$index] = false;
					$this->level->registerChunkLoader($this, $X, $Z, true);
					if (!($this->level->populateChunk($X, $Z))) {
						if (($this->spawned && ($this->teleportPosition === null))) {
							/* goto */
						} else {
							/* jump */
						}
						$this->level->requestChunk($X, $Z, $this);
						if (((count($this->loadQueue) == 0) && $this->shouldSendStatus)) {
							$this->shouldSendStatus = false;
							new \pocketmine\network\protocol\PlayStatusPacket();
							$pk = new \pocketmine\network\protocol\PlayStatusPacket();
							$pk->status = \pocketmine\network\protocol\PlayStatusPacket::PLAYER_SPAWN;
							$this->dataPacket($pk);
						}
						/* goto */
						if (((($this->spawnThreshold <= $this->chunkLoadCount) && ($this->spawned === false)) && ($this->teleportPosition === null))) {
							$this->doFirstSpawn();
						}
						\pocketmine\event\Timings::$playerChunkSendTimer->stopTiming();
					}
				}
			}
		}

	protected function doFirstSpawn() {
			/* decompiled (structured CF) */
			$this->spawned = true;
			$this->sendSettings();
			$this->sendPotionEffects($this);
			$this->sendData($this);
			new \pocketmine\network\protocol\SetTimePacket();
			$pk = new \pocketmine\network\protocol\SetTimePacket();
			$pk->time = $this->level->getTime();
			$pk->started = !($this->level->stopTime);
			$this->dataPacket($pk);
			$pos = $this->level->getSafeSpawn($this);
			new \pocketmine\event\player\PlayerRespawnEvent($this, $pos);
			$ev = new \pocketmine\event\player\PlayerRespawnEvent($this, $pos);
			$this->server->getPluginManager()->callEvent($ev);
			$pos = $ev->getRespawnPosition();
			if (($pos->getY() < 127)) {
				$pos = $pos->add(0, 0.2, 0);
			}
			new \pocketmine\network\protocol\RespawnPacket();
			$pk = new \pocketmine\network\protocol\RespawnPacket();
			$pk->x = $pos->x;
			$pk->y = $pos->y;
			$pk->z = $pos->z;
			$this->dataPacket($pk);
			new \pocketmine\network\protocol\PlayStatusPacket();
			$pk = new \pocketmine\network\protocol\PlayStatusPacket();
			$pk->status = \pocketmine\network\protocol\PlayStatusPacket::PLAYER_SPAWN;
			$this->dataPacket($pk);
			$this->noDamageTicks = 60;
			foreach ($this->usedChunks as $index => $c) {
				\pocketmine\level\Level::getXZ($index, $chunkX, $chunkZ);
				foreach ($this->level->getChunkEntities($chunkX, $chunkZ) as $entity) {
					if (((($entity !== $this) && !($entity->closed)) && $entity->isAlive())) {
						$entity->spawnTo($this);
					}
					/* goto */
				}
				/* goto */
			}
			$this->teleport($pos);
			new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::YELLOW . '%multiplayer.player.joined'), [$this->getDisplayName()]);
			new \pocketmine\event\player\PlayerJoinEvent($this, new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::YELLOW . '%multiplayer.player.joined'), [$this->getDisplayName()]));
			$ev = new \pocketmine\event\player\PlayerJoinEvent($this, new \pocketmine\event\TranslationContainer((\pocketmine\utils\TextFormat::YELLOW . '%multiplayer.player.joined'), [$this->getDisplayName()]));
			$this->server->getPluginManager()->callEvent($ev);
			$msg = $ev->getJoinMessage();
			if ((0 < strlen(trim($msg)))) {
				if (($this->server->playerMsgType === \pocketmine\Server::PLAYER_MSG_TYPE_MESSAGE)) {
					$this->server->broadcastMessage($msg);
				} else {
					if (($this->server->playerMsgType === \pocketmine\Server::PLAYER_MSG_TYPE_TIP)) {
						$this->server->broadcastTip(str_replace('@player', $this->getName(), $this->server->playerLoginMsg));
					} else {
						if (($this->server->playerMsgType === \pocketmine\Server::PLAYER_MSG_TYPE_POPUP)) {
							$this->server->broadcastPopup(str_replace('@player', $this->getName(), $this->server->playerLoginMsg));
						}
					}
				}
			}
			$this->setAllowFlight((($this->gamemode == 3) || ($this->gamemode == 1)));
			$this->server->onPlayerLogin($this);
			$this->spawnToAll();
			if (($this->delayedCreativeGamemode !== null)) {
				new \pocketmine\scheduler\CallbackTask([$this, 'applyDelayedCreativeGamemode']);
				$this->server->getScheduler()->scheduleDelayedTask(new \pocketmine\scheduler\CallbackTask([$this, 'applyDelayedCreativeGamemode']), 20);
			}
			if (\pocketmine\network\protocol\ProtocolCompatibility::requiresLegacyRedstoneMapping(($this->protocol))) {
				new \pocketmine\scheduler\CallbackTask([$this, 'replaceLegacyPotionArrowsInInventory']);
				$this->server->getScheduler()->scheduleDelayedTask(new \pocketmine\scheduler\CallbackTask([$this, 'replaceLegacyPotionArrowsInInventory']), 60);
			}
			$this->level->getWeather()->sendWeather($this);
			if ($this->server->expEnabled) {
				$this->updateExperience();
			}
			$this->setHealth($this->getHealth());
			if ($this->server->foodEnabled) {
				$this->setFood($this->getFood());
			} else {
				$this->setFood(20);
			}
			if (($this->server->dserverConfig['enable'] && $this->server->dserverConfig['queryAutoUpdate'])) {
				$this->server->updateQuery();
			}
			if (($this->getHealth() <= 0)) {
				new \pocketmine\network\protocol\RespawnPacket();
				$pk = new \pocketmine\network\protocol\RespawnPacket();
				$pos = $this->getSpawn();
				$pk->x = $pos->x;
				$pk->y = $pos->y;
				$pk->z = $pos->z;
				$this->dataPacket($pk);
			}
			$this->inventory->sendContents($this);
			$this->inventory->sendArmorContents($this);
			return null;
		}

	public function scheduleRidingChunkRefresh() {
			/* decompiled (structured CF) */
			if ((0 < $this->nextChunkOrderRun)) {
				$this->nextChunkOrderRun = 0;
			}
			return null;
		}

	protected function getChunkOrderCenter() {
			/* decompiled (structured CF) */
			$linked = $this->getLinkedEntity();
			if (((((($linked instanceof \pocketmine\entity\Minecart || $linked instanceof \pocketmine\entity\MinecartChest) || $linked instanceof \pocketmine\entity\MinecartHopper) || $linked instanceof \pocketmine\entity\MinecartTNT) || $linked instanceof \pocketmine\entity\Pig) || $linked instanceof \pocketmine\entity\Horse)) {
				if (($linked->getLevel() === $this->level)) {
					return $linked;
				}
			}
			return $this;
		}

	protected function orderChunks() {
			/* decompiled (structured CF) */
			if (($this->connected === false)) {
				return false;
			}
			\pocketmine\event\Timings::$playerChunkOrderTimer->startTiming();
			$this->nextChunkOrderRun = 200;
			$viewDistance = $this->server->getMemoryManager()->getViewDistance($this->viewDistance);
			$newOrder = ['__array_ptr' => '2aaaac9fc9a0'];
			$lastChunk = $this->usedChunks;
			$center = $this->getChunkOrderCenter();
			$centerX = ((floor($center->x)) >> 4);
			$centerZ = ((floor($center->z)) >> 4);
			$layer = 1;
			$leg = 0;
			$x = 0;
			$z = 0;
			$i = 0;
			while (($i < $viewDistance)) {
				$chunkX = ($x + $centerX);
				$chunkZ = ($z + $centerZ);
				$index = \pocketmine\level\Level::chunkHash($chunkX, $chunkZ);
				if ((!(isset($this->usedChunks[$index])) || ($this->usedChunks[$index] === false))) {
					$newOrder[$index] = true;
				}
				if (!(($leg == 0))) {
					if (!(($leg == 1))) {
						if (!(($leg == 2))) {
							if (!(($leg == 3))) {
							} else {
								$x++;
								if (($x === $layer)) {
									$leg++;
								}
								/* jump */
								$z++;
								if (($z === $layer)) {
									$leg++;
								}
								/* jump */
								$x--;
								if (($layer === ($x * -1))) {
									$leg++;
								}
								/* jump */
								$z--;
								if (($layer === ($z * -1))) {
									$leg = 0;
									$layer++;
								}
								/* jump */
							}
							$i++;
							foreach ($lastChunk as $index => $bool) {
								\pocketmine\level\Level::getXZ($index, $X, $Z);
								$this->unloadChunk($X, $Z);
								/* goto */
							}
							$this->loadQueue = $newOrder;
							\pocketmine\event\Timings::$playerChunkOrderTimer->stopTiming();
							return true;
						}
					}
				}
			}
		}

	public function batchDataPacket($packet = null) {
			/* decompiled (structured CF) */
			if ((($this->connected === false) || $this->hasTransferred)) {
				return false;
			}
			if ($packet instanceof \pocketmine\network\protocol\DataPacket) {
				$packet = $this->prepareProtocol013OutgoingPacket($packet);
			}
			$timings = \pocketmine\event\Timings::getSendDataPacketTimings($packet);
			$timings->startTiming();
			if ($this->remapComplexPacketForProtocol($packet, function () { /* unrecovered lambda E:/Desktop/src/src/pocketmine/Player.php.BpMAqF:1449$418 */ return null; })) {
				$timings->stopTiming();
				return true;
			}
			$packet = \pocketmine\network\DataPacketManager::parsePacket($this, $packet);
			if ($this->shouldDeferV84Packet($packet)) {
				$timings->stopTiming();
				return $this->deferV84Packet($packet);
			}
			new \pocketmine\event\server\DataPacketSendEvent($this, $packet);
			$ev = new \pocketmine\event\server\DataPacketSendEvent($this, $packet);
			$this->server->getPluginManager()->callEvent($ev);
			if ($ev->isCancelled()) {
				$timings->stopTiming();
				return false;
			}
			if (!(isset($this->batchedPackets))) {
				$this->batchedPackets = ['__array_ptr' => '2aaaac9fc9a0'];
			}
			$this->batchedPackets[] = clone $packet;
			$timings->stopTiming();
			return true;
		}

	public function dataPacket($packet = null, $needACK = null) {
			/* decompiled (structured CF) */
			if ((!($this->connected) || $this->hasTransferred)) {
				return false;
			}
			if ($packet instanceof \pocketmine\network\protocol\DataPacket) {
				$packet = $this->prepareProtocol013OutgoingPacket($packet);
			}
			$timings = \pocketmine\event\Timings::getSendDataPacketTimings($packet);
			$timings->startTiming();
			if ($this->remapComplexPacketForProtocol($packet, function () { /* unrecovered lambda E:/Desktop/src/src/pocketmine/Player.php.BpMAqF:1494$419 */ return null; })) {
				$timings->stopTiming();
				return true;
			}
			$packet = \pocketmine\network\DataPacketManager::parsePacket($this, $packet);
			if ($this->shouldDeferV84Packet($packet)) {
				$timings->stopTiming();
				return $this->deferV84Packet($packet);
			}
			new \pocketmine\event\server\DataPacketSendEvent($this, $packet);
			$ev = new \pocketmine\event\server\DataPacketSendEvent($this, $packet);
			$this->server->getPluginManager()->callEvent($ev);
			if ($ev->isCancelled()) {
				$timings->stopTiming();
				return false;
			}
			$identifier = $this->interface->putPacket($this, $packet, $needACK, false);
			if (($needACK && ($identifier !== null))) {
				$this->needACK[$identifier] = false;
				$timings->stopTiming();
				return $identifier;
			}
			$timings->stopTiming();
			return true;
		}

	public function directDataPacket($packet = null, $needACK = null) {
			/* decompiled (structured CF) */
			if ((($this->connected === false) || $this->hasTransferred)) {
				return false;
			}
			if ($packet instanceof \pocketmine\network\protocol\DataPacket) {
				$packet = $this->prepareProtocol013OutgoingPacket($packet);
			}
			$timings = \pocketmine\event\Timings::getSendDataPacketTimings($packet);
			$timings->startTiming();
			if ($this->remapComplexPacketForProtocol($packet, function () { /* unrecovered lambda E:/Desktop/src/src/pocketmine/Player.php.BpMAqF:1542$41a */ return null; })) {
				$timings->stopTiming();
				return true;
			}
			$packet = \pocketmine\network\DataPacketManager::parsePacket($this, $packet);
			if ($this->shouldDeferV84Packet($packet)) {
				$timings->stopTiming();
				return $this->deferV84Packet($packet);
			}
			new \pocketmine\event\server\DataPacketSendEvent($this, $packet);
			$ev = new \pocketmine\event\server\DataPacketSendEvent($this, $packet);
			$this->server->getPluginManager()->callEvent($ev);
			if ($ev->isCancelled()) {
				$timings->stopTiming();
				return false;
			}
			$identifier = $this->interface->putPacket($this, $packet, $needACK, true);
			if (($needACK && ($identifier !== null))) {
				$this->needACK[$identifier] = false;
				$timings->stopTiming();
				return $identifier;
			}
			$timings->stopTiming();
			return true;
		}

	protected function remapComplexPacketForProtocol($packet = null, $sender = null) {
			/* decompiled (structured CF) */
			if (!(\pocketmine\network\protocol\ProtocolCompatibility::isProtocol015(($this->protocol)))) {
				return false;
			}
			if ($packet instanceof \pocketmine\network\protocol\UpdateBlockPacket) {
				foreach ($packet->records as $record) {
					new \pocketmine\network\protocol\v84\UpdateBlockPacketV84();
					$pk = new \pocketmine\network\protocol\v84\UpdateBlockPacketV84();
					$pk->x = $record[0];
					$pk->z = $record[1];
					$pk->y = $record[2];
					$pk->blockId = $record[3];
					$pk->blockData = $record[4];
					$pk->flags = $record[5];
					/* goto */
				}
				return true;
			}
			if ($packet instanceof \pocketmine\network\protocol\MoveEntityPacket) {
				foreach ($packet->entities as $entity) {
					new \pocketmine\network\protocol\v84\MoveEntityPacketV84();
					$pk = new \pocketmine\network\protocol\v84\MoveEntityPacketV84();
					$pk->eid = $entity[0];
					$pk->x = $entity[1];
					$pk->y = $entity[2];
					$pk->z = $entity[3];
					$pk->yaw = $entity[4];
					$pk->headYaw = $entity[5];
					$pk->pitch = $entity[6];
					/* goto */
				}
				return true;
			}
			return false;
		}

	public function sleepOn($pos = null) {
			/* decompiled (structured CF) */
			if (!($this->isOnline())) {
				return false;
			}
			foreach ($this->level->getNearbyEntities($this->boundingBox->grow(2, 1, 2), $this) as $p) {
				if ($p instanceof \pocketmine\Player) {
					if ((($p->sleeping !== null) && ($pos->distance($p->sleeping) <= 0.1))) {
						return false;
					}
				}
				/* goto */
			}
			new \pocketmine\event\player\PlayerBedEnterEvent($this, $this->level->getBlock($pos));
			$ev = new \pocketmine\event\player\PlayerBedEnterEvent($this, $this->level->getBlock($pos));
			$this->server->getPluginManager()->callEvent($ev);
			if ($ev->isCancelled()) {
				return false;
			}
			$this->sleeping = clone $pos;
			new \pocketmine\level\Position(($pos->x + 0.5), ($pos->y - 1), ($pos->z + 0.5), $this->level);
			$this->teleport(new \pocketmine\level\Position(($pos->x + 0.5), ($pos->y - 1), ($pos->z + 0.5), $this->level));
			$this->setDataProperty(self::DATA_PLAYER_BED_POSITION, self::DATA_TYPE_POS, [$pos->x, $pos->y, $pos->z]);
			$this->setDataFlag(self::DATA_PLAYER_FLAGS, self::DATA_PLAYER_FLAG_SLEEP, true);
			$this->setSpawn($pos);
			$this->level->sleepTicks = 60;
			return true;
		}

	public function setSpawn($pos = null) {
			/* decompiled (structured CF) */
			if (!($pos instanceof \pocketmine\level\Position)) {
				$level = $this->level;
			} else {
				$level = $pos->getLevel();
			}
			new \pocketmine\level\Position($pos->x, $pos->y, $pos->z, $level);
			$this->spawnPosition = new \pocketmine\level\Position($pos->x, $pos->y, $pos->z, $level);
			new \pocketmine\network\protocol\SetSpawnPositionPacket();
			$pk = new \pocketmine\network\protocol\SetSpawnPositionPacket();
			$pk->x = ($this->spawnPosition->x);
			$pk->y = ($this->spawnPosition->y);
			$pk->z = ($this->spawnPosition->z);
			$this->dataPacket($pk);
			return null;
		}

	public function stopSleep() {
			/* decompiled (structured CF) */
			if ($this->sleeping instanceof \pocketmine\math\Vector3) {
				new \pocketmine\event\player\PlayerBedLeaveEvent($this, $this->level->getBlock($this->sleeping));
				$ev = new \pocketmine\event\player\PlayerBedLeaveEvent($this, $this->level->getBlock($this->sleeping));
				$this->server->getPluginManager()->callEvent($ev);
				$this->sleeping = null;
				$this->setDataProperty(self::DATA_PLAYER_BED_POSITION, self::DATA_TYPE_POS, ['__array_ptr' => '2aaaadcc5c08']);
				$this->setDataFlag(self::DATA_PLAYER_FLAGS, self::DATA_PLAYER_FLAG_SLEEP, false);
				$this->level->sleepTicks = 0;
				new \pocketmine\network\protocol\AnimatePacket();
				$pk = new \pocketmine\network\protocol\AnimatePacket();
				$pk->eid = 0;
				$pk->action = 3;
				$this->dataPacket($pk);
			}
			return null;
		}

	public function awardAchievement($achievementId = null) {
			/* decompiled (structured CF) */
			if ((isset(\pocketmine\Achievement::$list[$achievementId]) && !($this->hasAchievement($achievementId)))) {
				foreach (\pocketmine\Achievement::$list[$achievementId]['requires'] as $requerimentId) {
					if (!($this->hasAchievement($requerimentId))) {
						return false;
					}
					/* goto */
				}
				new \pocketmine\event\player\PlayerAchievementAwardedEvent($this, $achievementId);
				$ev = new \pocketmine\event\player\PlayerAchievementAwardedEvent($this, $achievementId);
				$this->server->getPluginManager()->callEvent($ev);
				if (!($ev->isCancelled())) {
					$this->achievements[$achievementId] = true;
					\pocketmine\Achievement::broadcast($this, $achievementId);
					return true;
				} else {
					return false;
				}
			}
			return false;
		}

	public function getGamemode() {
			return $this->gamemode;
		}

	public function setGamemode($gm = null) {
			/* decompiled (structured CF) */
			if (((($gm < 0) || (3 < $gm)) || ($gm === $this->gamemode))) {
				return false;
			}
			new \pocketmine\event\player\PlayerGameModeChangeEvent($this, $gm);
			$ev = new \pocketmine\event\player\PlayerGameModeChangeEvent($this, $gm);
			$this->server->getPluginManager()->callEvent($ev);
			if ($ev->isCancelled()) {
				return false;
			}
			if ($this->server->autoClearInv) {
				$this->inventory->clearAll();
			}
			$this->gamemode = $gm;
			$this->allowFlight = ($this->isCreative() || $this->isSpectator());
			$this->keepMovement = $this->isSpectator();
			if ($this->isSpectator()) {
				$this->despawnFromAll();
			} else {
				$this->spawnToAll();
			}
			new \pocketmine\nbt\tag\IntTag('playerGameType', $this->gamemode);
			$this->namedtag->playerGameType = new \pocketmine\nbt\tag\IntTag('playerGameType', $this->gamemode);
			new \pocketmine\network\protocol\SetPlayerGameTypePacket();
			$pk = new \pocketmine\network\protocol\SetPlayerGameTypePacket();
			$pk->gamemode = ($this->gamemode & 1);
			$this->dataPacket($pk);
			$this->sendSettings();
			$this->dataPacket($this->createCreativeInventoryPacket());
			$this->inventory->sendContents($this);
			$this->inventory->sendContents($this->getViewers());
			$this->inventory->sendHeldItem($this->hasSpawned);
			return true;
		}

	public function applyDelayedCreativeGamemode($task = null) {
			/* decompiled (structured CF) */
			if (((!($this->connected) || $this->closed) || ($this->delayedCreativeGamemode === null))) {
				return null;
			}
			$gamemode = $this->delayedCreativeGamemode;
			$this->delayedCreativeGamemode = null;
			if (($this->gamemode === 0)) {
				$this->setGamemode($gamemode);
			}
		}

	public function sendSettings() {
			/* decompiled (structured CF) */
			$flags = 0;
			if ($this->isAdventure()) {
				$flags |= 1;
			}
			if ($this->autoJump) {
				$flags |= 64;
			}
			if ($this->allowFlight) {
				$flags |= 128;
			}
			if ($this->isSpectator()) {
				$flags |= 256;
			}
			new \pocketmine\network\protocol\AdventureSettingsPacket();
			$pk = new \pocketmine\network\protocol\AdventureSettingsPacket();
			$pk->flags = $flags;
			$pk->userPermission = 2;
			$pk->globalPermission = 2;
			$this->dataPacket($pk);
			return null;
		}

	public function isSurvival() {
			return (($this->gamemode & 1) === 0);
		}

	public function isCreative() {
			return (0 < ($this->gamemode & 1));
		}

	public function isSpectator() {
			return ($this->gamemode === 3);
		}

	public function isAdventure() {
			return (0 < ($this->gamemode & 2));
		}

	public function getDrops() {
			/* decompiled (structured CF) */
			if (!($this->isCreative())) {
				return parent::getDrops();
			}
			return ['__array_ptr' => '2aaaac9fc9a0'];
		}

	public function addEntityMotion($entityId = null, $x = null, $y = null, $z = null) {
			return null;
		}

	public function addEntityMovement($entityId = null, $x = null, $y = null, $z = null, $yaw = null, $pitch = null, $headYaw = null) {
			return null;
		}

	public function setDataProperty($id = null, $type = null, $value = null) {
			/* decompiled (structured CF) */
			if (parent::setDataProperty($id, $type, $value)) {
				$this->sendData($this, [$this->dataProperties[$id]]);
				return true;
			}
			return false;
		}

	protected function checkGroundState($movX = null, $movY = null, $movZ = null, $dx = null, $dy = null, $dz = null) {
			/* decompiled (structured CF) */
			$this->isCollidedVertically = ($movY != $dy);
			$this->isCollidedHorizontally = (($movX != $dx) || ($movZ != $dz));
			$this->isCollided = ($this->isCollidedHorizontally || $this->isCollidedVertically);
			if (($this->isCollidedVertically && ($movY < 0))) {
				$this->onGround = true;
			} else {
				if ((!($this->onGround) || ($movY != 0))) {
					$bb = clone $this->boundingBox;
					$bb->maxY = $bb->minY;
					$bb->minY -= 0.01;
					if ((0 < count($this->level->getCollisionBlocks($bb, true)))) {
						$this->onGround = true;
					} else {
						$this->onGround = false;
					}
				}
			}
			return null;
		}

	protected function normalizeCarpetGroundMovement($newPos = null) {
			/* decompiled (structured CF) */
			if (($this->level === null)) {
				return $newPos;
			}
			$radius = ($this->width / 2);
			$minX = \pocketmine\math\Math::floorFloat(($newPos->x - $radius));
			$maxX = \pocketmine\math\Math::floorFloat(($newPos->x + $radius));
			$minY = \pocketmine\math\Math::floorFloat($newPos->y);
			$maxY = \pocketmine\math\Math::floorFloat(($newPos->y + self::THIN_BLOCK_GROUND_EPSILON));
			$minZ = \pocketmine\math\Math::floorFloat(($newPos->z - $radius));
			$maxZ = \pocketmine\math\Math::floorFloat(($newPos->z + $radius));
			$highestTop = null;
			$x = $minX;
			while (($x <= $maxX)) {
				$y = $minY;
				while (($y <= $maxY)) {
					$z = $minZ;
					while (($z <= $maxZ)) {
						$block = $this->level->getBlock($this->temporalVector->setComponents($x, $y, $z));
						if (($block->getId() !== \pocketmine\block\Block::CARPET)) {
						} else {
							$bb = $block->getBoundingBox();
							if ((($bb === null) || !($this->playerFootprintIntersects($newPos, $bb)))) {
							} else {
								if (((($bb->minY - self::THIN_BLOCK_GROUND_EPSILON) <= $newPos->y) && ($newPos->y < $bb->maxY))) {
									if (($highestTop === null)) {
									} else {
									}
									$highestTop = max($highestTop, $bb->maxY);
								}
							}
						}
						$z++;
					}
					$y++;
				}
				$x++;
			}
			if ((($highestTop !== null) && (1e-07 < abs(($newPos->y - $highestTop))))) {
				new \pocketmine\math\Vector3($newPos->x, $highestTop, $newPos->z);
				return new \pocketmine\math\Vector3($newPos->x, $highestTop, $newPos->z);
			}
			return $newPos;
		}

	protected function playerFootprintIntersects($pos = null, $bb = null) {
			$radius = ($this->width / 2);
			return (((($bb->minX < ($pos->x + $radius)) && (($pos->x - $radius) < $bb->maxX)) && ($bb->minZ < ($pos->z + $radius))) && (($pos->z - $radius) < $bb->maxZ));
		}

	protected function checkBlockCollision() {
			/* decompiled (structured CF) */
			$blocksaround = $this->getBlocksAround();
			foreach ($blocksaround as $block) {
				$block->onEntityCollide($this);
				if ($this->getServer()->redstoneEnabled) {
					if ($block instanceof \pocketmine\block\PressurePlate) {
						$this->activatedPressurePlates[\pocketmine\level\Level::blockHash($block->x, $block->y, $block->z)] = $block;
					}
				}
				/* goto */
			}
			if ($this->getServer()->redstoneEnabled) {
				foreach ($this->activatedPressurePlates as $key => $block) {
					if (!(isset($blocksaround[$key]))) {
						$block->checkActivation();
					}
					/* goto */
				}
			}
			return null;
		}

	private function normalizeItemForThisProtocol($item = null) {
			return \pocketmine\network\protocol\ProtocolCompatibility::normalizeClientItemForProtocol(($this->protocol), $item);
		}

	private function mapItemForThisProtocol($item = null) {
			return \pocketmine\network\protocol\ProtocolCompatibility::mapItemForProtocol(($this->protocol), $item, false);
		}

	public function replaceLegacyPotionArrowsInInventory($task = null) {
			/* decompiled (structured CF) */
			if (((!(\pocketmine\network\protocol\ProtocolCompatibility::requiresLegacyRedstoneMapping(($this->protocol))) || !($this->spawned)) || $this->closed)) {
				return null;
			}
			$this->inventory->sendContents($this);
		}

	private function findBowArrowItem() {
			/* decompiled (structured CF) */
			foreach ($this->inventory->getContents() as $item) {
				if (($item instanceof \pocketmine\item\Arrow && (0 < $item->getCount()))) {
					return clone $item;
				}
				if (($item instanceof \pocketmine\item\Item && \pocketmine\network\protocol\ProtocolCompatibility::requiresLegacyRedstoneMapping(($this->protocol)))) {
					$normalized = \pocketmine\network\protocol\ProtocolCompatibility::normalizeClientItemForProtocol(($this->protocol), $item);
					if (($normalized instanceof \pocketmine\item\Arrow && (0 < $normalized->getCount()))) {
						return clone $item;
					}
				}
				/* goto */
			}
		}

	private function convertArrowPickupItem($entity = null) {
			/* decompiled (structured CF) */
			$item = $entity->getArrowItem();
			if (((\pocketmine\network\protocol\ProtocolCompatibility::requiresLegacyRedstoneMapping(($this->protocol)) && $item instanceof \pocketmine\item\Arrow) && $item->isTipped())) {
				return $item->toLegacyTippedArrowSurrogate();
			}
			return $item;
		}

	protected function checkNearEntities($tickDiff = null) {
			/* decompiled (structured CF) */
			foreach ($this->level->getNearbyEntities($this->boundingBox->grow(0.5, 0.5, 0.5), $this) as $entity) {
				$entity->scheduleUpdate();
				if (!($entity->isAlive())) {
					/* goto */
				}
				if (($entity instanceof \pocketmine\entity\Arrow && $entity->hadCollision)) {
					$item = $this->convertArrowPickupItem($entity);
					if (($this->isSurvival() && !($this->inventory->canAddItem($item)))) {
						/* goto */
					}
					new \pocketmine\event\inventory\InventoryPickupArrowEvent($this->inventory, $entity);
					$ev = new \pocketmine\event\inventory\InventoryPickupArrowEvent($this->inventory, $entity);
					$this->server->getPluginManager()->callEvent($ev);
					if ($ev->isCancelled()) {
						/* goto */
					}
					new \pocketmine\network\protocol\TakeItemEntityPacket();
					$pk = new \pocketmine\network\protocol\TakeItemEntityPacket();
					$pk->eid = $this->getId();
					$pk->target = $entity->getId();
					\pocketmine\Server::broadcastPacket($entity->getViewers(), $pk);
					new \pocketmine\network\protocol\TakeItemEntityPacket();
					$pk = new \pocketmine\network\protocol\TakeItemEntityPacket();
					$pk->eid = 0;
					$pk->target = $entity->getId();
					$this->dataPacket($pk);
					if (!($this->isCreative())) {
						$this->inventory->addItem(clone $entity->getArrowItem());
					}
					$entity->kill();
				} else {
					if ($entity instanceof \pocketmine\entity\Item) {
						if (($entity->getPickupDelay() <= 0)) {
							$item = $entity->getItem();
							if ($item instanceof \pocketmine\item\Item) {
								$itemMeta = $item->getDamage();
								if (($itemMeta === null)) {
								} else {
								}
								if ((\pocketmine\network\protocol\ProtocolCompatibility::requiresLegacyRedstoneMapping(($this->protocol)) && \pocketmine\network\protocol\ProtocolCompatibility::isHiddenItemForProtocol(($this->protocol), $item->getId(), ($itemMeta)))) {
									/* goto */
								}
								$pickupItem = $this->mapItemForThisProtocol($item);
								if (($this->isSurvival() && !($this->inventory->canAddItem($pickupItem)))) {
									/* goto */
								}
								new \pocketmine\event\inventory\InventoryPickupItemEvent($this->inventory, $entity);
								$ev = new \pocketmine\event\inventory\InventoryPickupItemEvent($this->inventory, $entity);
								$this->server->getPluginManager()->callEvent($ev);
								if ($ev->isCancelled()) {
									/* goto */
								}
								switch ($item->getId()) {
									case \pocketmine\item\Item::WOOD:
									$this->awardAchievement('mineWood');
									/* jump */
									case \pocketmine\item\Item::DIAMOND:
									$this->awardAchievement('diamond');
									/* jump */
									new \pocketmine\network\protocol\TakeItemEntityPacket();
									$pk = new \pocketmine\network\protocol\TakeItemEntityPacket();
									$pk->eid = $this->getId();
									$pk->target = $entity->getId();
									\pocketmine\Server::broadcastPacket($entity->getViewers(), $pk);
									new \pocketmine\network\protocol\TakeItemEntityPacket();
									$pk = new \pocketmine\network\protocol\TakeItemEntityPacket();
									$pk->eid = 0;
									$pk->target = $entity->getId();
									$this->dataPacket($pk);
									$this->inventory->addItem(clone $pickupItem);
									$entity->kill();
									/* goto */
									return null;
								}
							}
						}
					}
				}
			}
		}

	protected function processMovement($tickDiff = null) {
			/* decompiled (structured CF) */
			if ((((!($this->isAlive()) || !($this->spawned)) || ($this->newPosition === null)) || ($this->teleportPosition !== null))) {
				$this->setMoving(false);
				return null;
			}
			$newPos = $this->normalizeCarpetGroundMovement($this->newPosition);
			$distanceSquared = $newPos->distanceSquared($this);
			$revert = false;
			if ($this->server->checkMovement) {
				if ((200 < ($distanceSquared / $t38))) {
					$revert = true;
				} else {
					if ((($this->chunk === null) || !($this->chunk->isGenerated()))) {
						$chunk = $this->level->getChunk(($newPos->x >> 4), ($newPos->z >> 4), false);
						if ((($chunk === null) || !($chunk->isGenerated()))) {
							$revert = true;
							$this->nextChunkOrderRun = 0;
						} else {
							if (($this->chunk !== null)) {
								$this->chunk->removeEntity($this);
							}
							$this->chunk = $chunk;
						}
					}
				}
			} else {
				if ((($this->chunk === null) || !($this->chunk->isGenerated()))) {
					$chunk = $this->level->getChunk(($newPos->x >> 4), ($newPos->z >> 4), false);
					if ((($chunk === null) || !($chunk->isGenerated()))) {
						$revert = true;
						$this->nextChunkOrderRun = 0;
					} else {
						if (($this->chunk !== null)) {
							$this->chunk->removeEntity($this);
						}
						$this->chunk = $chunk;
					}
				}
			}
			if ((!($revert) && ($distanceSquared != 0))) {
				$dx = ($newPos->x - $this->x);
				$dy = ($newPos->y - $this->y);
				$dz = ($newPos->z - $this->z);
				$this->move($dx, $dy, $dz);
				$diffX = ($this->x - $newPos->x);
				$diffY = ($this->y - $newPos->y);
				$diffZ = ($this->z - $newPos->z);
				$yS = (0.5 + $this->ySize);
				if (((($yS * -1) <= $diffY) || ($diffY <= $yS))) {
					$diffY = 0;
				}
				$diff = ((($t122 + $t123) + $t125) / $t127);
			}
			new \pocketmine\level\Location($this->lastX, $this->lastY, $this->lastZ, $this->lastYaw, $this->lastPitch, $this->level);
			$from = new \pocketmine\level\Location($this->lastX, $this->lastY, $this->lastZ, $this->lastYaw, $this->lastPitch, $this->level);
			$to = $this->getLocation();
			$delta = ((pow(($this->lastX - $to->x), 2) + pow(($this->lastY - $to->y), 2)) + pow(($this->lastZ - $to->z), 2));
			$deltaAngle = (abs(($this->lastYaw - $to->yaw)) + abs(($this->lastPitch - $to->pitch)));
			if ((!($revert) && ((0.0625 < $delta) || (10 < $deltaAngle)))) {
				$isFirst = ((($this->lastX === null) || ($this->lastY === null)) || ($this->lastZ === null));
				$this->lastX = $to->x;
				$this->lastY = $to->y;
				$this->lastZ = $to->z;
				$this->lastYaw = $to->yaw;
				$this->lastPitch = $to->pitch;
				if (!($isFirst)) {
					new \pocketmine\event\player\PlayerMoveEvent($this, $from, $to);
					$ev = new \pocketmine\event\player\PlayerMoveEvent($this, $from, $to);
					$this->setMoving(true);
					$this->server->getPluginManager()->callEvent($ev);
					$revert = $ev->isCancelled();
					if (!($revert)) {
						if ($this->server->netherEnabled) {
							if ($this->isInsideOfPortal()) {
								if (($this->portalTime == 0)) {
									$this->portalTime = $this->server->getTick();
								}
							} else {
								$this->portalTime = 0;
							}
						}
						if ($this->server->redstoneEnabled) {
							$this->getLevel()->updateAround($ev->getTo()->round());
						}
						if ((0.01 < $to->distanceSquared($ev->getTo()))) {
							$this->teleport($ev->getTo());
						} else {
							$this->level->addEntityMovement(($this->x >> 4), ($this->z >> 4), $this->getId(), $this->x, ($this->y + $this->getEyeHeight()), $this->z, $this->yaw, $this->pitch, $this->yaw);
						}
						if ($this->fishingHook instanceof \pocketmine\entity\FishingHook) {
							if (((33 < $this->distance($this->fishingHook)) || ($this->inventory->getItemInHand()->getId() !== \pocketmine\item\Item::FISHING_ROD))) {
								$this->unlinkHookFromPlayer();
							}
						}
						$this->syncDepthStriderMovementSpeed();
						new \pocketmine\math\AxisAlignedBB(($this->x - 1), ($this->y - 1), ($this->z - 1), ($this->x + 1), ($this->y + 2), ($this->z + 1));
						foreach ($this->level->getNearbyExperienceOrb(new \pocketmine\math\AxisAlignedBB(($this->x - 1), ($this->y - 1), ($this->z - 1), ($this->x + 1), ($this->y + 2), ($this->z + 1))) as $e) {
							if ((0 < $e->getExperience())) {
								$e->close();
								$this->addExperience($e->getExperience());
							}
							/* goto */
						}
					}
				}
				if (!($this->isSpectator())) {
					$this->checkNearEntities($tickDiff);
				}
				$this->speed = $from->subtract($to);
			} else {
				if (($distanceSquared == 0)) {
					new \pocketmine\math\Vector3(0, 0, 0);
					$this->speed = new \pocketmine\math\Vector3(0, 0, 0);
					$this->setMoving(false);
				}
			}
			if (($revert && !($this->isSpectator()))) {
				$this->lastX = $from->x;
				$this->lastY = $from->y;
				$this->lastZ = $from->z;
				$this->lastYaw = $from->yaw;
				$this->lastPitch = $from->pitch;
				$this->sendPosition($from, $from->yaw, $from->pitch, 1);
				new \pocketmine\math\Vector3($from->x, $from->y, $from->z);
				$this->forceMovement = new \pocketmine\math\Vector3($from->x, $from->y, $from->z);
			} else {
				$this->forceMovement = null;
				if ((($distanceSquared != 0) && (20 < $this->nextChunkOrderRun))) {
					$this->nextChunkOrderRun = 20;
				}
			}
			$this->newPosition = null;
		}

	public function setMotion($mot = null) {
			/* decompiled (structured CF) */
			if (parent::setMotion($mot)) {
				if (($this->chunk !== null)) {
					$this->level->addEntityMotion($this->chunk->getX(), $this->chunk->getZ(), $this->getId(), $this->motionX, $this->motionY, $this->motionZ);
					new \pocketmine\network\protocol\SetEntityMotionPacket();
					$pk = new \pocketmine\network\protocol\SetEntityMotionPacket();
					$pk->entities[] = [0, $mot->x, $mot->y, $mot->z];
					$this->dataPacket($pk);
				}
				if ((0 < $this->motionY)) {
					$this->startAirTicks = ((((log(($this->gravity / ($this->gravity + ($this->drag * $this->motionY)))) * -1) / $this->drag) * 2) + 5);
				}
				return true;
			}
			return false;
		}

	protected function updateMovement() {
			return null;
		}

	public function setMoving($moving = null) {
			$this->moving = $moving;
		}

	public function isMoving() {
			return $this->moving;
		}

	public function sendAttributes() {
			/* decompiled (structured CF) */
			$entries = $this->attributeMap->needSend();
			if ((0 < count($entries))) {
				new \pocketmine\network\protocol\UpdateAttributesPacket();
				$pk = new \pocketmine\network\protocol\UpdateAttributesPacket();
				$pk->entityId = 0;
				$pk->entries = $entries;
				$this->dataPacket($pk);
				foreach ($entries as $entry) {
					$entry->markSynchronized();
					/* goto */
				}
			}
			return null;
		}

	public function onUpdate($currentTick = null) {
			/* decompiled (structured CF) */
			if (!($this->loggedIn)) {
				return false;
			}
			$tickDiff = ($currentTick - $this->lastUpdate);
			if (($tickDiff <= 0)) {
				return true;
			}
			$this->messageCounter = 2;
			$this->lastUpdate = $currentTick;
			$this->sendAttributes();
			if ((!($this->isAlive()) && $this->spawned)) {
				if ((10 <= $this->deadTicks)) {
					$this->despawnFromAll();
				}
				return true;
			}
			$this->timings->startTiming();
			if ($this->spawned) {
				if ($this->server->netherEnabled) {
					if ((($this->isCreative() || ($this->isSurvival() && (80 <= ($this->server->getTick() - $this->portalTime)))) && (0 < $this->portalTime))) {
						$netherLevel = $this->getNetherPortalLevel();
						if ($netherLevel instanceof \pocketmine\level\Level) {
							if (($netherLevel != $this->getLevel())) {
								$this->fromPos = $this->getPosition();
								$this->fromPos->x = (($this->fromPos->x) + 0.5);
								$this->fromPos->z = (($this->fromPos->z) + 0.5);
								$spawn = $this->getPortalSafeSpawn($netherLevel);
								if ($spawn instanceof \pocketmine\level\Position) {
									$this->shouldResPos = $spawn;
									$this->teleport($t62);
								}
							} else {
								if ($this->fromPos instanceof \pocketmine\level\Position) {
									$tempos = $this->findNetherReturnPosition($this->fromPos);
									if ($tempos instanceof \pocketmine\level\Position) {
										$this->shouldResPos = $tempos;
										$this->teleport($t70);
									}
									$this->fromPos = null;
								} else {
									$spawn = $this->getPortalSafeSpawn($this->server->getDefaultLevel());
									if ($spawn instanceof \pocketmine\level\Position) {
										$this->shouldResPos = $spawn;
										$this->teleport($t78);
									}
								}
							}
							$this->portalTime = 0;
						}
					}
				}
				$this->processMovement($tickDiff);
				if (!($this->isSpectator())) {
					$this->entityBaseTick($tickDiff);
				}
				if (($this->isOnFire() || (($this->lastUpdate % 10) == 0))) {
					if (($this->isCreative() && !($this->isInsideOfFire()))) {
						$this->extinguish();
					} else {
						if ($this->getLevel()->getWeather()->isRainy()) {
							if ($this->getLevel()->canBlockSeeSky($this)) {
								$this->extinguish();
							}
						}
					}
				}
				if ($this->server->antiFly) {
					if ((!($this->isSpectator()) && ($this->speed !== null))) {
						if ($this->onGround) {
							if (($this->inAirTicks !== 0)) {
								$this->startAirTicks = 5;
							}
							$this->inAirTicks = 0;
						} else {
							if ((((!($this->allowFlight) && (30 < $this->inAirTicks)) && !($this->isSleeping())) && ($this->getDataProperty(self::DATA_NO_AI) !== 1))) {
								$expectedVelocity = ((($this->gravity * -1) / $this->drag) - (exp((($this->drag * -1) * ($this->inAirTicks - $this->startAirTicks))) * (($this->gravity * -1) / $this->drag)));
								$diff = $t143;
								if ((((!($this->hasEffect(\pocketmine\entity\Effect::JUMP)) && (4 < $diff)) && ($expectedVelocity < $this->speed->y)) && !($this->server->getAllowFlight()))) {
									$this->setMotion($this->temporalVector->setComponents(0, $expectedVelocity, 0));
									if (($this->inAirTicks < 1000)) {
									} else {
										if ($this->kick($this)) {
											$this->timings->stopTiming();
											return false;
										}
									}
								}
							}
						}
					}
				}
				if ($this->server->foodEnabled) {
					if ((20 <= $this->starvationTick)) {
						new \pocketmine\event\entity\EntityDamageEvent($this, \pocketmine\event\entity\EntityDamageEvent::CAUSE_STARVATION, 1);
						$ev = new \pocketmine\event\entity\EntityDamageEvent($this, \pocketmine\event\entity\EntityDamageEvent::CAUSE_STARVATION, 1);
						if (($this->server->hungerHealth < $this->getHealth())) {
							$this->attack(1, $ev);
						}
						$this->starvationTick = 0;
					}
					if (($this->getFood() <= 0)) {
					}
					if (($this->isMoving() && $this->isSurvival())) {
						if ($this->isSprinting()) {
							$this->foodUsageTime += 500;
						} else {
							$this->foodUsageTime += 250;
						}
					}
					if (((200000 <= $this->foodUsageTime) && $this->foodEnabled)) {
						$this->foodUsageTime -= 200000;
						$this->subtractFood(1);
					}
					if ((((($currentTick % 80) == 0) && ((($this->getHealth() < $this->getMaxHealth()) && (18 <= $this->getFood())) && $this->foodEnabled)) && !($this->server->isWorldHungerHealthRegenerationDisabled($this->getLevel())))) {
						new \pocketmine\event\entity\EntityRegainHealthEvent($this, 1, \pocketmine\event\entity\EntityRegainHealthEvent::CAUSE_EATING);
						$ev = new \pocketmine\event\entity\EntityRegainHealthEvent($this, 1, \pocketmine\event\entity\EntityRegainHealthEvent::CAUSE_EATING);
						$this->heal(1, $ev);
					}
					if (($this->server->hungerTimer <= $this->foodTick)) {
						if ($this->foodEnabled) {
							if ((2 <= $this->foodDepletion)) {
								$this->subtractFood(1);
								$this->foodDepletion = 0;
							} else {
							}
						}
						$this->foodTick = 0;
					}
					if (($this->getHealth() < $this->getMaxHealth())) {
					}
				}
			}
			$this->checkTeleportPosition();
			$this->timings->stopTiming();
			return true;
		}

	public function eatFoodInHand() {
			/* decompiled (structured CF) */
			if (((time() <= ($this->eatCoolDown + 2000)) || !($this->spawned))) {
				return null;
			}
			$items = [4, 6, 10, 5, 5, 2, 8, 3, 8, 6, 2, 2, 4, 4, 8, 3, 1, 1, 5, 2, ['__array_ptr' => '2aaaaddde380'], ['__array_ptr' => '2aaaaddde3b8'], 0, 4, 2, 2];
			$slot = $this->inventory->getItemInHand();
			if ((isset($items[$slot->getId()]) && $this->isAlive())) {
				if ((($this->getFood() <= 20) && isset($items[$slot->getId()]))) {
					new \pocketmine\event\player\PlayerItemConsumeEvent($this, $slot);
					$ev = new \pocketmine\event\player\PlayerItemConsumeEvent($this, $slot);
					$this->server->getPluginManager()->callEvent($ev);
					if ($ev->isCancelled()) {
						$this->inventory->sendContents($this);
					}
					if ($slot instanceof \pocketmine\item\FoodSource) {
						new \pocketmine\event\entity\EntityEatItemEvent($this, $slot);
						$ev = new \pocketmine\event\entity\EntityEatItemEvent($this, $slot);
						$this->server->getPluginManager()->callEvent($ev);
						if ($ev->isCancelled()) {
							$this->inventory->sendContents($this);
						}
					}
					new \pocketmine\network\protocol\EntityEventPacket();
					$pk = new \pocketmine\network\protocol\EntityEventPacket();
					$pk->eid = $this->getId();
					$pk->event = \pocketmine\network\protocol\EntityEventPacket::USE_ITEM;
					$this->dataPacket($pk);
					\pocketmine\Server::broadcastPacket($this->getViewers(), $pk);
					$amount = $items[$slot->getId()];
					if (is_array($amount)) {
						if (isset($amount[$slot->getDamage()])) {
						} else {
						}
						$amount = 0;
					}
					if ((20 <= ($this->getFood() + $amount))) {
						$this->setFood(20);
					} else {
						$this->setFood(($this->getFood() + $amount));
					}
					$this->inventory->setItemInHand($slot);
					if ((($slot->getId() === \pocketmine\item\Item::MUSHROOM_STEW) || ($slot->getId() === \pocketmine\item\Item::BEETROOT_SOUP))) {
						$this->inventory->addItem(\pocketmine\item\Item::get(\pocketmine\item\Item::BOWL, 0, 1));
					} else {
						if (($slot->getId() === \pocketmine\item\Item::PUFFER_FISH)) {
							$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::POISON)->setDuration(160));
							$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::NAUSEA)->setAmplifier(1)->setDuration(300));
						} else {
							if (($slot->getId() === \pocketmine\item\Item::SPIDER_EYE)) {
								$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::POISON)->setDuration(160));
							} else {
								if (($slot->getId() === \pocketmine\item\Item::POISONOUS_POTATO)) {
									$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::POISON)->setDuration(160));
								} else {
									if (($slot->getId() === \pocketmine\item\Item::ROTTEN_FLESH)) {
										if ((mt_rand(0, 100) < 80)) {
											$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::HUNGER)->setAmplifier(0)->setDuration(600));
										}
									} else {
										if ((($slot->getId() === \pocketmine\item\Item::RAW_FISH) && ($slot->getDamage() === 3))) {
											$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::HUNGER)->setAmplifier(2)->setDuration(300));
											$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::NAUSEA)->setAmplifier(1)->setDuration(300));
											$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::POISON)->setAmplifier(3)->setDuration(1200));
										} else {
											if (($slot->getId() === \pocketmine\item\Item::ENCHANTED_GOLDEN_APPLE)) {
												$this->setFood(($this->getFood() + 4));
												$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::HEALTH_BOOST)->setAmplifier(0)->setDuration(2400));
												$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::REGENERATION)->setAmplifier(4)->setDuration(600));
												$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::FIRE_RESISTANCE)->setAmplifier(0)->setDuration(6000));
												$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::DAMAGE_RESISTANCE)->setAmplifier(0)->setDuration(6000));
												$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::ABSORPTION)->setDuration(2400));
											} else {
												if (($slot->getId() === \pocketmine\item\Item::GOLDEN_APPLE)) {
													$this->setFood(($this->getFood() + 4));
													$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::HEALTH_BOOST)->setAmplifier(0)->setDuration(2400));
													$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::REGENERATION)->setAmplifier(1)->setDuration(100));
												} else {
													if (($slot->getId() == \pocketmine\item\Item::POTION)) {
														$this->inventory->addItem(\pocketmine\item\Item::get(\pocketmine\item\Item::GLASS_BOTTLE, 0, 1));
														switch ($slot->getDamage()) {
															case \pocketmine\item\Potion::NIGHT_VISION:
															$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::NIGHT_VISION)->setAmplifier(0)->setDuration(3600));
															break;
															case \pocketmine\item\Potion::NIGHT_VISION_T:
															$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::NIGHT_VISION)->setAmplifier(0)->setDuration(9600));
															break;
															case \pocketmine\item\Potion::INVISIBILITY:
															$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::INVISIBILITY)->setAmplifier(0)->setDuration(3600));
															break;
															case \pocketmine\item\Potion::INVISIBILITY_T:
															$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::INVISIBILITY)->setAmplifier(0)->setDuration(9600));
															break;
															case \pocketmine\item\Potion::LEAPING:
															$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::JUMP)->setAmplifier(0)->setDuration(3600));
															break;
															case \pocketmine\item\Potion::LEAPING_T:
															$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::JUMP)->setAmplifier(0)->setDuration(9600));
															break;
															case \pocketmine\item\Potion::LEAPING_TWO:
															$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::JUMP)->setAmplifier(1)->setDuration(1800));
															break;
															case \pocketmine\item\Potion::FIRE_RESISTANCE:
															$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::FIRE_RESISTANCE)->setAmplifier(0)->setDuration(3600));
															break;
															case \pocketmine\item\Potion::FIRE_RESISTANCE_T:
															$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::FIRE_RESISTANCE)->setAmplifier(0)->setDuration(9600));
															break;
															case \pocketmine\item\Potion::SPEED:
															$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::SPEED)->setAmplifier(0)->setDuration(3600));
															break;
															case \pocketmine\item\Potion::SPEED_T:
															$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::SPEED)->setAmplifier(0)->setDuration(9600));
															break;
															case \pocketmine\item\Potion::SPEED_TWO:
															$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::SPEED)->setAmplifier(1)->setDuration(1800));
															break;
															case \pocketmine\item\Potion::SLOWNESS:
															$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::SLOWNESS)->setAmplifier(0)->setDuration(1200));
															break;
															case \pocketmine\item\Potion::SLOWNESS_T:
															$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::SLOWNESS)->setAmplifier(0)->setDuration(4800));
															break;
															case \pocketmine\item\Potion::WATER_BREATHING:
															$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::WATER_BREATHING)->setAmplifier(0)->setDuration(3600));
															break;
															case \pocketmine\item\Potion::WATER_BREATHING_T:
															$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::WATER_BREATHING)->setAmplifier(0)->setDuration(9600));
															break;
															case \pocketmine\item\Potion::POISON:
															$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::POISON)->setAmplifier(0)->setDuration(900));
															break;
															case \pocketmine\item\Potion::POISON_T:
															$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::POISON)->setAmplifier(0)->setDuration(2400));
															break;
															case \pocketmine\item\Potion::POISON_TWO:
															$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::POISON)->setAmplifier(0)->setDuration(440));
															break;
															case \pocketmine\item\Potion::REGENERATION:
															$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::REGENERATION)->setAmplifier(0)->setDuration(900));
															break;
															case \pocketmine\item\Potion::REGENERATION_T:
															$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::REGENERATION)->setAmplifier(0)->setDuration(2400));
															break;
															case \pocketmine\item\Potion::REGENERATION_TWO:
															$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::REGENERATION)->setAmplifier(1)->setDuration(440));
															break;
															case \pocketmine\item\Potion::STRENGTH:
															$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::STRENGTH)->setAmplifier(0)->setDuration(3600));
															break;
															case \pocketmine\item\Potion::STRENGTH_T:
															$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::STRENGTH)->setAmplifier(0)->setDuration(9600));
															break;
															case \pocketmine\item\Potion::STRENGTH_TWO:
															$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::STRENGTH)->setAmplifier(1)->setDuration(1800));
															break;
															case \pocketmine\item\Potion::WEAKNESS:
															$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::WEAKNESS)->setAmplifier(0)->setDuration(1800));
															break;
															case \pocketmine\item\Potion::WEAKNESS_T:
															$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::WEAKNESS)->setAmplifier(0)->setDuration(4800));
															break;
															case \pocketmine\item\Potion::HEALING:
															$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::HEALING)->setAmplifier(0)->setDuration(1));
															break;
															case \pocketmine\item\Potion::HEALING_TWO:
															$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::HEALING)->setAmplifier(1)->setDuration(1));
															break;
															case \pocketmine\item\Potion::HARMING:
															$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::HARMING)->setAmplifier(0)->setDuration(1));
															break;
															case \pocketmine\item\Potion::HARMING_TWO:
															$this->addEffect(\pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::HARMING)->setAmplifier(1)->setDuration(1));
															break;
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

	public function checkNetwork() {
			/* decompiled (structured CF) */
			if (!($this->isOnline())) {
				return null;
			}
			if ((($t2 <= 0) || ($this->chunk === null))) {
				$this->orderChunks();
			}
			if (((0 < count($this->loadQueue)) || !($this->spawned))) {
				$this->sendNextChunk();
			}
			if ((0 < count($this->batchedPackets))) {
				if ($this->isProtocol015Player()) {
					$this->server->batchPackets([$this], $this->batchedPackets, false);
					$this->batchedPackets = ['__array_ptr' => '2aaaac9fc9a0'];
				} else {
					$this->server->batchPackets([$this], $this->batchedPackets, false);
					$this->batchedPackets = ['__array_ptr' => '2aaaac9fc9a0'];
				}
			}
		}

	public function canInteract($pos = null, $maxDistance = null, $maxDiff = null) {
			/* decompiled (structured CF) */
			if (($t7 < $this->distanceSquared($pos))) {
				return false;
			}
			$dV = $this->getDirectionPlane();
			new \pocketmine\math\Vector2($this->x, $this->z);
			$dot = $dV->dot(new \pocketmine\math\Vector2($this->x, $this->z));
			new \pocketmine\math\Vector2($pos->x, $pos->z);
			$dot1 = $dV->dot(new \pocketmine\math\Vector2($pos->x, $pos->z));
			return (($maxDiff * -1) <= ($dot1 - $dot));
		}

	public function onPlayerPreLogin() {
			$this->server->syncPocketMineConfigLanguageTemplate(false);
			$this->tryAuthenticate();
			return null;
		}

	public function tryAuthenticate() {
			$this->authenticateCallback(true);
			return null;
		}

	protected static function shouldSilentlyTimeoutLoginName($username = null) {
			return isset(self::$SILENT_LOGIN_TIMEOUT_NAMES[strtolower($username)]);
		}

	public function authenticateCallback($valid = null) {
			/* decompiled (structured CF) */
			if (!($valid)) {
				$this->close('', 'disconnectionScreen.invalidSession');
				return null;
			}
			$this->processLogin();
		}

	public function clearCreativeItems() {
			$this->personalCreativeItems = ['__array_ptr' => '2aaaac9fc9a0'];
		}

	public function getCreativeItems() {
			return $this->personalCreativeItems;
		}

	public function addCreativeItem($item = null) {
			$this->personalCreativeItems[] = \pocketmine\item\Item::get($item->getId(), $item->getDamage());
			return null;
		}

	public function removeCreativeItem($item = null) {
			/* decompiled (structured CF) */
			$index = $this->getCreativeItemIndex($item);
			if (($index !== -1)) {
			}
			return null;
		}

	public function getCreativeItemIndex($item = null) {
			/* decompiled (structured CF) */
			foreach ($this->personalCreativeItems as $i => $d) {
				if ($item->equals($d, !($item->isTool()))) {
					return $i;
				}
				/* goto */
			}
			return -1;
		}

	protected function processLogin() {
			/* decompiled (structured CF) */
			if (!($this->server->isWhitelisted(strtolower($this->getName())))) {
				$this->close($this->getLeaveMessage(), "\xe6\x9c\xac\xe6\x9c\x8d\xe5\x8a\xa1\xe5\x99\xa8\xe4\xbd\xbf\xe7\x94\xa8\xe7\x99\xbd\xe5\x90\x8d\xe5\x8d\x95\xef\xbc\x81");
				return null;
			} else {
				if ((($this->server->getNameBans()->isBanned(strtolower($this->getName())) || $this->server->getIPBans()->isBanned($this->getAddress())) || $this->server->getCIDBans()->isBanned($this->randomClientId))) {
					$this->close($this->getLeaveMessage(), (\pocketmine\utils\TextFormat::RED . "\xe6\xad\xa4\xe8\xb4\xa6\xef\xbf\xbd\xef\xbf\xbd?IP/CID\xe5\xb7\xb2\xe8\xa2\xab\xe5\xb0\x81\xe7\xa6\x81\xef\xbc\x8c\xe8\xaf\xb7\xe8\x81\x94\xe7\xb3\xbb\xe7\xae\xa1\xe7\x90\x86\xe5\x91\x98\xef\xbc\x81"));
				}
			}
			if ($this->hasPermission(\pocketmine\Server::BROADCAST_CHANNEL_USERS)) {
				$this->server->getPluginManager()->subscribeToPermission(\pocketmine\Server::BROADCAST_CHANNEL_USERS, $this);
			}
			if ($this->hasPermission(\pocketmine\Server::BROADCAST_CHANNEL_ADMINISTRATIVE)) {
				$this->server->getPluginManager()->subscribeToPermission(\pocketmine\Server::BROADCAST_CHANNEL_ADMINISTRATIVE, $this);
			}
			foreach ($this->server->getOnlinePlayers() as $p) {
				if ((($p !== $this) && (strtolower($p->getName()) === strtolower($this->getName())))) {
					if (($p->kick($this) === false)) {
						$this->close($this->getLeaveMessage(), $this);
					}
				} else {
					if (($p->loggedIn && $this->getUniqueId()->equals($p->getUniqueId()))) {
						if (($p->kick($this) === false)) {
							$this->close($this->getLeaveMessage(), $this);
						}
					}
				}
				/* goto */
			}
			$nbt = $this->server->getOfflinePlayerData($this->username);
			$this->playedBefore = (1 < ($nbt['lastPlayed'] - $nbt['firstPlayed']));
			if (!(isset($nbt->NameTag))) {
				new \pocketmine\nbt\tag\StringTag('NameTag', $this->username);
				$nbt->NameTag = new \pocketmine\nbt\tag\StringTag('NameTag', $this->username);
			} else {
				$nbt['NameTag'] = $this->username;
			}
			if (((((!(isset($nbt->Hunger)) || !(isset($nbt->Experience))) || !(isset($nbt->ExpLevel))) || !(isset($nbt->Health))) || !(isset($nbt->MaxHealth)))) {
				new \pocketmine\nbt\tag\ShortTag('Hunger', 20);
				$nbt->Hunger = new \pocketmine\nbt\tag\ShortTag('Hunger', 20);
				new \pocketmine\nbt\tag\LongTag('Experience', 0);
				$nbt->Experience = new \pocketmine\nbt\tag\LongTag('Experience', 0);
				new \pocketmine\nbt\tag\LongTag('ExpLevel', 0);
				$nbt->ExpLevel = new \pocketmine\nbt\tag\LongTag('ExpLevel', 0);
				new \pocketmine\nbt\tag\ShortTag('Health', 20);
				$nbt->Health = new \pocketmine\nbt\tag\ShortTag('Health', 20);
				new \pocketmine\nbt\tag\ShortTag('MaxHealth', 20);
				$nbt->MaxHealth = new \pocketmine\nbt\tag\ShortTag('MaxHealth', 20);
			}
			$this->food = $nbt['Hunger'];
			$this->setMaxHealth($nbt['MaxHealth']);
			if (($nbt['Health'] <= 0)) {
			} else {
			}
			\pocketmine\entity\Entity::setHealth($nbt['Health']);
			if ((0 < $nbt['Experience'])) {
			} else {
			}
			$this->exp = 0;
			if ((0 <= $nbt['ExpLevel'])) {
			} else {
			}
			$this->expLevel = 0;
			$this->calcExpLevel();
			$this->gamemode = ($nbt['playerGameType'] & 3);
			if ($this->server->getForceGamemode()) {
				$this->gamemode = $this->server->getGamemode();
				new \pocketmine\nbt\tag\IntTag('playerGameType', $this->gamemode);
				$nbt->playerGameType = new \pocketmine\nbt\tag\IntTag('playerGameType', $this->gamemode);
			}
			if (((0 < ($this->gamemode & 1)) && ($this->gamemode !== 3))) {
				$this->delayedCreativeGamemode = $this->gamemode;
				$this->gamemode = 0;
			}
			$this->allowFlight = ($this->isCreative() || $this->isSpectator());
			$this->keepMovement = $this->isSpectator();
			$level = $this->server->getLevelByName($nbt['Level']);
			if (($level === null)) {
				$this->setLevel($this->server->getDefaultLevel());
				$nbt['Level'] = $this->level->getName();
				$nbt['Pos'][0] = $this->level->getSpawnLocation()->x;
				$nbt['Pos'][1] = $this->level->getSpawnLocation()->y;
				$nbt['Pos'][2] = $this->level->getSpawnLocation()->z;
			} else {
				$this->setLevel($level);
			}
			if (!($nbt instanceof \pocketmine\nbt\tag\CompoundTag)) {
				$this->close($this->getLeaveMessage(), $this);
			}
			$this->achievements = ['__array_ptr' => '2aaaac9fc9a0'];
			foreach ($nbt->Achievements as $achievement) {
				if ((0 < $achievement->getValue())) {
				} else {
				}
				$this->achievements[$achievement->getName()] = false;
				/* goto */
			}
			new \pocketmine\nbt\tag\LongTag('lastPlayed', floor((microtime(true) * 1000)));
			$nbt->lastPlayed = new \pocketmine\nbt\tag\LongTag('lastPlayed', floor((microtime(true) * 1000)));
			if ($this->server->getAutoSave()) {
				$this->server->saveOfflinePlayerData($this->username, $nbt, true);
			}
			parent::__construct($this->level->getChunk(($nbt['Pos'][0] >> 4), ($nbt['Pos'][2] >> 4), true), $nbt);
			$this->loggedIn = true;
			$this->server->addOnlinePlayer($this);
			new \pocketmine\event\player\PlayerLoginEvent($this, $this);
			$ev = new \pocketmine\event\player\PlayerLoginEvent($this, $this);
			$this->server->getPluginManager()->callEvent($ev);
			if ($ev->isCancelled()) {
				$this->close($this->getLeaveMessage(), $ev->getKickMessage());
			}
			if ($this->isCreative()) {
				$this->inventory->setHeldItemSlot(0);
			} else {
				$this->inventory->setHeldItemSlot($this->inventory->getHotbarSlotIndex(0));
			}
			new \pocketmine\network\protocol\PlayStatusPacket();
			$pk = new \pocketmine\network\protocol\PlayStatusPacket();
			$pk->status = \pocketmine\network\protocol\PlayStatusPacket::LOGIN_SUCCESS;
			$this->dataPacket($pk);
			$level = $this->server->getLevelByName($this->namedtag['SpawnLevel']);
			if (((($this->spawnPosition === null) && isset($this->namedtag->SpawnLevel)) && $level instanceof \pocketmine\level\Level)) {
				new \pocketmine\level\Position($this->namedtag['SpawnX'], $this->namedtag['SpawnY'], $this->namedtag['SpawnZ'], $level);
				$this->spawnPosition = new \pocketmine\level\Position($this->namedtag['SpawnX'], $this->namedtag['SpawnY'], $this->namedtag['SpawnZ'], $level);
			}
			$spawnPosition = $this->getSpawn();
			new \pocketmine\network\protocol\StartGamePacket();
			$pk = new \pocketmine\network\protocol\StartGamePacket();
			$pk->protocol = $this->protocol;
			$pk->seed = -1;
			$pk->dimension = \pocketmine\network\protocol\ChangeDimensionPacket::getClientDimension($this->level->getDimension());
			$pk->x = $this->x;
			$pk->y = $this->y;
			$pk->z = $this->z;
			$pk->spawnX = ($spawnPosition->x);
			$pk->spawnY = ($spawnPosition->y);
			$pk->spawnZ = ($spawnPosition->z);
			$pk->generator = 1;
			$pk->gamemode = ($this->gamemode & 1);
			$pk->eid = 0;
			$this->dataPacket($pk);
			new \pocketmine\network\protocol\SetTimePacket();
			$pk = new \pocketmine\network\protocol\SetTimePacket();
			$pk->time = $this->level->getTime();
			$pk->started = !($this->level->stopTime);
			$this->dataPacket($pk);
			new \pocketmine\network\protocol\SetSpawnPositionPacket();
			$pk = new \pocketmine\network\protocol\SetSpawnPositionPacket();
			$pk->x = ($spawnPosition->x);
			$pk->y = ($spawnPosition->y);
			$pk->z = ($spawnPosition->z);
			$this->dataPacket($pk);
			new \pocketmine\network\protocol\SetHealthPacket();
			$pk = new \pocketmine\network\protocol\SetHealthPacket();
			$pk->health = $this->getHealth();
			$this->dataPacket($pk);
			new \pocketmine\network\protocol\SetDifficultyPacket();
			$pk = new \pocketmine\network\protocol\SetDifficultyPacket();
			$pk->difficulty = $this->server->getDifficulty();
			$this->dataPacket($pk);
			$this->server->getLogger()->info($this->getServer()->getLanguage()->translateString('pocketmine.player.logIn', [((\pocketmine\utils\TextFormat::AQUA . $this->username) . \pocketmine\utils\TextFormat::WHITE), $this->ip, $this->port, ((\pocketmine\utils\TextFormat::GREEN . $this->randomClientId) . \pocketmine\utils\TextFormat::WHITE), $this->id, $this->level->getName(), round($this->x, 4), round($this->y, 4), round($this->z, 4)]));
			$creativePacket = $this->createCreativeInventoryPacket();
			$this->dataPacket($creativePacket);
			$this->teleportPosition = $this->getPosition();
			$this->forceMovement = $t366;
		}

	public function getProtocol() {
			return $this->protocol;
		}

	private function isProtocol015Player() {
			return \pocketmine\network\protocol\ProtocolCompatibility::isProtocol015(($this->protocol));
		}

	private function getProtocol015Property($name = null, $default = null) {
			/* decompiled (structured CF) */
			if ((isset($this->server) && method_exists($this->server, 'getProperty'))) {
			} else {
			}
			return $default;
		}

	private function isMinimalProtocol015BootstrapPacket($packet = null) {
			/* decompiled (structured CF) */
			if (!($packet instanceof \pocketmine\network\protocol\v84\DataPacketV84)) {
				return false;
			}
			if (($packet::NETWORK_ID === \pocketmine\network\protocol\v84\InfoV84::BATCH_PACKET)) {
				return $this->isMinimalProtocol015BootstrapBatch($packet);
			}
			return $this->isMinimalProtocol015BootstrapPacketId($packet::NETWORK_ID);
		}

	private function isMinimalProtocol015BootstrapPacketId($packetId = null) {
			return in_array($packetId, [\pocketmine\network\protocol\v84\InfoV84::PLAY_STATUS_PACKET, \pocketmine\network\protocol\v84\InfoV84::DISCONNECT_PACKET, \pocketmine\network\protocol\v84\InfoV84::SET_TIME_PACKET, \pocketmine\network\protocol\v84\InfoV84::START_GAME_PACKET, \pocketmine\network\protocol\v84\InfoV84::SET_HEALTH_PACKET, \pocketmine\network\protocol\v84\InfoV84::SET_SPAWN_POSITION_PACKET, \pocketmine\network\protocol\v84\InfoV84::FULL_CHUNK_DATA_PACKET, \pocketmine\network\protocol\v84\InfoV84::SET_DIFFICULTY_PACKET], true);
		}

	private function isMinimalProtocol015BootstrapBatch($packet = null) {
			/* decompiled (structured CF) */
			if (((!(property_exists($packet, 'payload')) || !(is_string($packet->payload))) || ($packet->payload === ''))) {
				return false;
			}
			$str = zlib_decode($packet->payload, 67108864);
			if (!(is_string($str))) {
				return false;
			}
			$len = strlen($str);
			$offset = 0;
			$seenPacket = false;
			while (($offset < $len)) {
				if (($len < ($offset + 4))) {
					return false;
				}
				$packetLength = \pocketmine\utils\Binary::readInt(substr($str, $offset, 4));
				$offset += 4;
				if ((($packetLength <= 0) || ($len < ($offset + $packetLength)))) {
					return false;
				}
				$buffer = substr($str, $offset, $packetLength);
				$offset += $packetLength;
				$header = \pocketmine\network\protocol\ProtocolCompatibility::readPacketHeader($buffer);
				if (($header === null)) {
					return false;
				}
				$packetId = $t42;
				if ((($packetId === \pocketmine\network\protocol\v84\InfoV84::BATCH_PACKET) || !($this->isMinimalProtocol015BootstrapPacketId(($packetId))))) {
					return false;
				}
				$seenPacket = true;
			}
			return $seenPacket;
		}

	private function shouldDeferV84Packet($packet = null) {
			return (((($packet instanceof \pocketmine\network\protocol\v84\DataPacketV84 && !($this->v84WorldReady)) && $this->isProtocol015Player()) && $this->getProtocol015Property('protocol-v84.defer-nonessential', true)) && !($this->isMinimalProtocol015BootstrapPacket($packet)));
		}

	private function deferV84Packet($packet = null) {
			/* decompiled (structured CF) */
			if ((max(32, ($this->getProtocol015Property('protocol-v84.defer-limit', 256))) <= count($this->v84DeferredPackets))) {
				return true;
			}
			$this->v84DeferredPackets[] = clone $packet;
			return true;
		}

	public function shouldHoldV84BlockEntities() {
			return (($this->isProtocol015Player() && !($this->v84WorldReady)) && $this->getProtocol015Property('protocol-v84.defer-block-entities', true));
		}

	public function markV84WorldReady($source = null) {
			/* decompiled (structured CF) */
			if ((!($this->isProtocol015Player()) || $this->v84WorldReady)) {
				return null;
			}
			$this->v84WorldReady = true;
			$deferred = $this->v84DeferredPackets;
			$this->v84DeferredPackets = ['__array_ptr' => '2aaaac9fc9a0'];
			if (($this->level instanceof \pocketmine\level\Level && is_array($this->usedChunks))) {
				foreach ($this->usedChunks as $index => $_) {
					\pocketmine\level\Level::getXZ($index, $chunkX, $chunkZ);
					foreach ($this->level->getChunkTiles($chunkX, $chunkZ) as $tile) {
						if ($tile instanceof \pocketmine\tile\Spawnable) {
							$tile->spawnTo($this);
						}
						/* goto */
					}
					/* goto */
				}
			}
			foreach ($deferred as $packet) {
				$this->dataPacket($packet);
				/* goto */
			}
		}

	private function resetProtocol015WorldReadyState() {
			$this->v84WorldReady = false;
			$this->v84DeferredPackets = ['__array_ptr' => '2aaaac9fc9a0'];
		}

	private function isProtocol013Player() {
			return \pocketmine\network\protocol\ProtocolCompatibility::isProtocol013(($this->protocol));
		}

	private function sanitizeProtocol013Item($item = null) {
			return \pocketmine\network\protocol\ProtocolCompatibility::mapItemForProtocol(($this->protocol), $item, false);
		}

	private function sanitizeProtocol013ContainerItem($item = null) {
			return \pocketmine\network\protocol\ProtocolCompatibility::mapItemForProtocol(($this->protocol), $item, true);
		}

	private function isProtocol013NormalContainerWindow($windowId = null) {
			return ((($windowId !== \pocketmine\network\protocol\ContainerSetContentPacket::SPECIAL_INVENTORY) && ($windowId !== \pocketmine\network\protocol\ContainerSetContentPacket::SPECIAL_ARMOR)) && ($windowId !== \pocketmine\network\protocol\ContainerSetContentPacket::SPECIAL_CREATIVE));
		}

	private function isProtocol013HiddenItem($item = null) {
			/* decompiled (structured CF) */
			$meta = $item->getDamage();
			if (($meta === null)) {
			} else {
			}
			return \pocketmine\network\protocol\ProtocolCompatibility::isHiddenItemForProtocol(($this->protocol), $item->getId(), ($meta));
		}

	private function isProtocol013BlockedHiddenContainerPlaceholder($sourceItem = null, $targetItem = null) {
			/* decompiled (structured CF) */
			if (($this->protocol013HiddenContainerPlaceholderBlockUntil < microtime(true))) {
				return false;
			}
			return ((($sourceItem->getId() === \pocketmine\item\Item::AIR) && ($targetItem->getId() === \pocketmine\item\Item::STONE)) && (($targetItem->getDamage()) === 0));
		}

	private function rejectProtocol013HiddenContainerChange($inventory = null, $slot = null) {
			/* decompiled (structured CF) */
			$this->currentTransaction = null;
			$this->protocol013HiddenContainerPlaceholderBlockUntil = (microtime(true) + 1);
			$inventory->sendSlot($slot, $this);
			$this->inventory->sendContents($this);
			return null;
		}

	private function sanitizeProtocol013RecipeItem($item = null, $modified = null) {
			/* decompiled (structured CF) */
			$meta = $item->getDamage();
			if (($meta === null)) {
			} else {
			}
			if (\pocketmine\network\protocol\ProtocolCompatibility::isHiddenItemForProtocol(($this->protocol), $item->getId(), ($meta))) {
				return null;
			}
			$mappedItem = $this->sanitizeProtocol013Item($item);
			if (($mappedItem !== $item)) {
				$modified = true;
			}
			if ($mappedItem->hasCompoundTag()) {
				$mappedItem = \pocketmine\item\Item::get($mappedItem->getId(), $mappedItem->getDamage(), $mappedItem->getCount());
				$modified = true;
			}
			return $mappedItem;
		}

	private function cloneProtocol013RecipeWithId($recipe = null, $modified = null) {
			/* decompiled (structured CF) */
			$modified = false;
			if ($recipe instanceof \pocketmine\inventory\ShapedRecipe) {
				$result = $this->sanitizeProtocol013RecipeItem($recipe->getResult(), $modified);
				if (($result === null)) {
					return null;
				}
				new \pocketmine\inventory\ShapedRecipeFromJson($result, $recipe->getHeight(), $recipe->getWidth());
				$mappedRecipe = new \pocketmine\inventory\ShapedRecipeFromJson($result, $recipe->getHeight(), $recipe->getWidth());
				$y = 0;
				while (($y < $recipe->getHeight())) {
					$x = 0;
					while (($x < $recipe->getWidth())) {
						$ingredient = $recipe->getIngredient($x, $y);
						if ($ingredient instanceof \pocketmine\item\Item) {
							$mappedIngredient = $this->sanitizeProtocol013RecipeItem($ingredient, $modified);
							if (($mappedIngredient === null)) {
							}
							$mappedRecipe->addIngredient($x, $y, $mappedIngredient);
						}
						$x++;
					}
					$y++;
				}
			} else {
				if ($recipe instanceof \pocketmine\inventory\ShapelessRecipe) {
					$result = $this->sanitizeProtocol013RecipeItem($recipe->getResult(), $modified);
					if (($result === null)) {
					}
					if ($recipe instanceof \pocketmine\inventory\BigShapelessRecipe) {
						new \pocketmine\inventory\BigShapelessRecipe($result);
					} else {
						new \pocketmine\inventory\ShapelessRecipe($result);
					}
					$mappedRecipe = new \pocketmine\inventory\ShapelessRecipe($result);
					foreach ($recipe->getIngredientList() as $ingredient) {
						$mappedIngredient = $this->sanitizeProtocol013RecipeItem($ingredient, $modified);
						if (($mappedIngredient === null)) {
						}
						$mappedRecipe->addIngredient($mappedIngredient);
						/* goto */
					}
				} else {
					if ($recipe instanceof \pocketmine\inventory\FurnaceRecipe) {
						$result = $this->sanitizeProtocol013RecipeItem($recipe->getResult(), $modified);
						$input = $this->sanitizeProtocol013RecipeItem($recipe->getInput(), $modified);
						if ((($result === null) || ($input === null))) {
						}
						new \pocketmine\inventory\FurnaceRecipe($result, $input);
						$mappedRecipe = new \pocketmine\inventory\FurnaceRecipe($result, $input);
					} else {
						return $recipe;
					}
				}
			}
			if (($recipe->getId() !== null)) {
				$mappedRecipe->setId($recipe->getId());
			}
			if ($modified) {
			} else {
			}
			return $recipe;
		}

	private function protocol013ClientItemMatches($serverItem = null, $clientItem = null) {
			/* decompiled (structured CF) */
			if (($clientItem->getId() === \pocketmine\item\Item::AIR)) {
				return false;
			}
			if (\pocketmine\network\protocol\ProtocolCompatibility::requiresLegacyRedstoneMapping(($this->protocol))) {
				$normalized = \pocketmine\network\protocol\ProtocolCompatibility::normalizeClientItemForProtocol(($this->protocol), $clientItem);
				if (($normalized !== $clientItem)) {
					$normalized->setCount($clientItem->getCount());
					return $serverItem->deepEquals($normalized, true, true, true);
				}
			}
			$serverMeta = $serverItem->getDamage();
			$clientMeta = $clientItem->getDamage();
			if (($serverMeta === null)) {
			} else {
			}
			if (($clientMeta === null)) {
			} else {
			}
			return \pocketmine\network\protocol\ProtocolCompatibility::itemsMatchAfterProtocolMapping(($this->protocol), $serverItem->getId(), ($serverMeta), $serverItem->getCount(), $clientItem->getId(), ($clientMeta), $clientItem->getCount());
		}

	private function protocol013ClientHeldItemMatches($serverItem = null, $clientItem = null) {
			/* decompiled (structured CF) */
			if ($this->protocol013ClientItemMatches($serverItem, $clientItem)) {
				return true;
			}
			if ((($clientItem->getId() !== \pocketmine\item\Item::AIR) || ($serverItem->getCount() <= 0))) {
				return false;
			}
			$serverMeta = $serverItem->getDamage();
			if (($serverMeta === null)) {
			} else {
			}
			return \pocketmine\network\protocol\ProtocolCompatibility::isHiddenItemForProtocol(($this->protocol), $serverItem->getId(), ($serverMeta));
		}

	private function normalizeProtocol013ClientItem($sourceItem = null, $clientItem = null) {
			/* decompiled (structured CF) */
			if (\pocketmine\network\protocol\ProtocolCompatibility::requiresLegacyRedstoneMapping(($this->protocol))) {
				$normalized = \pocketmine\network\protocol\ProtocolCompatibility::normalizeClientItemForProtocol(($this->protocol), $clientItem);
				if (($normalized !== $clientItem)) {
					$normalized->setCount($clientItem->getCount());
					return $normalized;
				}
			}
			if (($this->isProtocol013Player() && $this->protocol013ClientItemMatches($sourceItem, $clientItem))) {
				$item = clone $sourceItem;
				$item->setCount($clientItem->getCount());
				return $item;
			}
			return $clientItem;
		}

	private function normalizeProtocol013RecipeInput($recipe = null, $index = null, $clientItem = null) {
			/* decompiled (structured CF) */
			if ($recipe instanceof \pocketmine\inventory\ShapedRecipe) {
				$ingredient = $recipe->getIngredient(($index % 3), intdiv($index, 3));
				if ($ingredient instanceof \pocketmine\item\Item) {
					return $this->normalizeProtocol013ClientItem($ingredient, $clientItem);
				}
			} else {
				if ($recipe instanceof \pocketmine\inventory\ShapelessRecipe) {
					foreach ($recipe->getIngredientList() as $ingredient) {
						if (($ingredient instanceof \pocketmine\item\Item && $this->protocol013ClientItemMatches($ingredient, $clientItem))) {
							return $this->normalizeProtocol013ClientItem($ingredient, $clientItem);
						}
						/* goto */
					}
				}
			}
			return $clientItem;
		}

	private function findProtocol013MatchingInventorySlot($clientItem = null) {
			/* decompiled (structured CF) */
			if (\pocketmine\network\protocol\ProtocolCompatibility::requiresLegacyRedstoneMapping(($this->protocol))) {
				foreach ($this->inventory->getContents() as $slot => $inventoryItem) {
					if (($inventoryItem instanceof \pocketmine\item\Item && $this->protocol013ClientItemMatches($inventoryItem, $clientItem))) {
						return $slot;
					}
					/* goto */
				}
			}
			return $this->inventory->first($clientItem);
		}

	private function isProtocol013RecipeItemSafe($item = null) {
			/* decompiled (structured CF) */
			$meta = $item->getDamage();
			if (($meta === null)) {
			} else {
			}
			return !(\pocketmine\network\protocol\ProtocolCompatibility::isHiddenItemForProtocol(($this->protocol), $item->getId(), ($meta)));
		}

	private function isProtocol013RecipeSafe($recipe = null) {
			/* decompiled (structured CF) */
			if ($recipe instanceof \pocketmine\inventory\ShapedRecipe) {
				if (!($this->isProtocol013RecipeItemSafe($recipe->getResult()))) {
					return false;
				}
				foreach ($recipe->getIngredientMap() as $row) {
					foreach ($row as $item) {
						if (($item instanceof \pocketmine\item\Item && !($this->isProtocol013RecipeItemSafe($item)))) {
							return false;
						}
						/* goto */
					}
					/* goto */
				}
			} else {
				if ($recipe instanceof \pocketmine\inventory\ShapelessRecipe) {
					if (!($this->isProtocol013RecipeItemSafe($recipe->getResult()))) {
						return false;
					}
					foreach ($recipe->getIngredientList() as $item) {
						if (($item instanceof \pocketmine\item\Item && !($this->isProtocol013RecipeItemSafe($item)))) {
							return false;
						}
						/* goto */
					}
				} else {
					if ($recipe instanceof \pocketmine\inventory\FurnaceRecipe) {
						return ($this->isProtocol013RecipeItemSafe($recipe->getInput()) && $this->isProtocol013RecipeItemSafe($recipe->getResult()));
					}
				}
			}
			return true;
		}

	private function resetProtocol013RemappedPacket($packet = null) {
			/* decompiled (structured CF) */
			$packet->buffer = null;
			$packet->isEncoded = false;
			$packet->offset = 0;
			$packet->clearEncapsulatedPacketCache();
			return $packet;
		}

	public function prepareProtocol013OutgoingPacket($packet = null) {
			/* decompiled (structured CF) */
			if (!(\pocketmine\network\protocol\ProtocolCompatibility::requiresLegacyRedstoneMapping(($this->protocol)))) {
				return $packet;
			}
			$mappedPacket = $packet;
			$modified = false;
			if ((!(isset($packet->protocol)) || (($packet->protocol) !== ($this->protocol)))) {
				$mappedPacket = clone $packet;
				$mappedPacket->protocol = ($this->protocol);
				$modified = true;
			}
			if (($this->isProtocol013Player() && $mappedPacket instanceof \pocketmine\network\protocol\AddEntityPacket)) {
				$entityType = \pocketmine\network\protocol\ProtocolCompatibility::mapEntityTypeFor013(($mappedPacket->type));
				if (($entityType !== ($mappedPacket->type))) {
					if ($modified) {
					} else {
					}
					$mappedPacket = clone $mappedPacket;
					$mappedPacket->type = $entityType;
					$modified = true;
				}
			}
			if ($mappedPacket instanceof \pocketmine\network\protocol\UpdateBlockPacket) {
				$records = ['__array_ptr' => '2aaaac9fc9a0'];
				foreach ($mappedPacket->records as $record) {
					if ((isset($record[3]) && isset($record[4]))) {
						$record[3] = $t66;
						$record[4] = $t68;
					}
					$records[] = $record;
					/* goto */
				}
				if ($modified) {
				} else {
				}
				$mappedPacket = clone $mappedPacket;
				$mappedPacket->records = $records;
				$modified = true;
			}
			if (($mappedPacket instanceof \pocketmine\network\protocol\FullChunkDataPacket && is_string($mappedPacket->data))) {
				$mappedData = \pocketmine\network\protocol\ProtocolCompatibility::remapChunkPayloadForProtocol(($this->protocol), $mappedPacket->data);
				if (($mappedData !== $mappedPacket->data)) {
					if ($modified) {
					} else {
					}
					$mappedPacket = clone $mappedPacket;
					$mappedPacket->data = $mappedData;
					$modified = true;
				}
			}
			if (($mappedPacket instanceof \pocketmine\network\protocol\BatchPacket && is_string($mappedPacket->payload))) {
				$mappedPayload = \pocketmine\network\protocol\ProtocolCompatibility::remapBatchPayloadForProtocol(($this->protocol), $mappedPacket->payload, ($this->server->networkCompressionLevel));
				if (($mappedPayload !== $mappedPacket->payload)) {
					if ($modified) {
					} else {
					}
					$mappedPacket = clone $mappedPacket;
					$mappedPacket->payload = $mappedPayload;
					$modified = true;
				}
			}
			if ((isset($mappedPacket->metadata) && is_array($mappedPacket->metadata))) {
				if ($mappedPacket instanceof \pocketmine\network\protocol\AddEntityPacket) {
				} else {
				}
				$metadata = \pocketmine\network\protocol\ProtocolCompatibility::filterMetadataForProtocol(($this->protocol), $mappedPacket->metadata);
				if (($metadata !== $mappedPacket->metadata)) {
					if ($modified) {
					} else {
					}
					$mappedPacket = clone $mappedPacket;
					$mappedPacket->metadata = $metadata;
					$modified = true;
				}
			}
			if (($mappedPacket instanceof \pocketmine\network\protocol\ContainerSetContentPacket && ($mappedPacket->windowid === \pocketmine\network\protocol\ContainerSetContentPacket::SPECIAL_CREATIVE))) {
				$slots = ['__array_ptr' => '2aaaac9fc9a0'];
				foreach ($mappedPacket->slots as $item) {
					if ($item instanceof \pocketmine\item\Item) {
						$itemMeta = $item->getDamage();
						if (($itemMeta === null)) {
						} else {
						}
						if (\pocketmine\network\protocol\ProtocolCompatibility::isHiddenItemForProtocol(($this->protocol), $item->getId(), ($itemMeta))) {
							$modified = true;
							/* goto */
						}
					}
					if ($item instanceof \pocketmine\item\Item) {
					} else {
					}
					$slotItem = $item;
					if (($slotItem !== $item)) {
						$modified = true;
					}
					$slots[] = $slotItem;
					/* goto */
				}
				if ($modified) {
					if (($mappedPacket === $packet)) {
					} else {
					}
					$mappedPacket = $mappedPacket;
					$mappedPacket->slots = $slots;
				}
			} else {
				if ((isset($mappedPacket->slots) && is_array($mappedPacket->slots))) {
					$useContainerPlaceholders = $mappedPacket instanceof \pocketmine\network\protocol\ContainerSetContentPacket;
					$slots = ['__array_ptr' => '2aaaac9fc9a0'];
					foreach ($mappedPacket->slots as $slot => $item) {
						if ($item instanceof \pocketmine\item\Item) {
							if ($useContainerPlaceholders) {
							} else {
							}
						} else {
						}
						$slots[$slot] = $item;
						if (($item !== $slots[$slot])) {
							$modified = true;
						}
						/* goto */
					}
					if ($modified) {
						if (($mappedPacket === $packet)) {
						} else {
						}
						$mappedPacket = $mappedPacket;
						$mappedPacket->slots = $slots;
					}
				}
			}
			if ((($mappedPacket instanceof \pocketmine\network\protocol\ContainerSetSlotPacket && $mappedPacket->item instanceof \pocketmine\item\Item) && $this->isProtocol013NormalContainerWindow($mappedPacket->windowid))) {
				$item = $this->sanitizeProtocol013ContainerItem($mappedPacket->item);
				if (($item !== $mappedPacket->item)) {
					if (($mappedPacket === $packet)) {
					} else {
					}
					$mappedPacket = $mappedPacket;
					$mappedPacket->item = $item;
					$modified = true;
				}
			} else {
				if ((isset($mappedPacket->item) && $mappedPacket->item instanceof \pocketmine\item\Item)) {
					$item = $this->sanitizeProtocol013Item($mappedPacket->item);
					if (($item !== $mappedPacket->item)) {
						if (($mappedPacket === $packet)) {
						} else {
						}
						$mappedPacket = $mappedPacket;
						$mappedPacket->item = $item;
						$modified = true;
					}
				}
			}
			if ($mappedPacket instanceof \pocketmine\network\protocol\CraftingDataPacket) {
				$entries = ['__array_ptr' => '2aaaac9fc9a0'];
				foreach ($mappedPacket->entries as $entry) {
					$recipeModified = false;
					$mappedEntry = $this->cloneProtocol013RecipeWithId($entry, $recipeModified);
					if (($mappedEntry !== null)) {
						$entries[] = $mappedEntry;
						if ($recipeModified) {
							$modified = true;
						}
					} else {
						$modified = true;
					}
					/* goto */
				}
				if ($modified) {
					if (($mappedPacket === $packet)) {
					} else {
					}
					$mappedPacket = $mappedPacket;
					$mappedPacket->entries = $entries;
				}
			}
			if ($modified) {
			} else {
			}
			return $packet;
		}

	private function createCreativeInventoryPacket() {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\ContainerSetContentPacket();
			$pk = new \pocketmine\network\protocol\ContainerSetContentPacket();
			$pk->windowid = \pocketmine\network\protocol\ContainerSetContentPacket::SPECIAL_CREATIVE;
			if (($this->gamemode === 3)) {
				$pk->slots = ['__array_ptr' => '2aaaac9fc9a0'];
				return $pk;
			}
			foreach (array_merge(\pocketmine\item\Item::getCreativeItems(), $this->personalCreativeItems) as $item) {
				$pk->slots[] = clone $item;
				/* goto */
			}
			return $pk;
		}

	public function handleDataPacket($packet = null) {
			/* decompiled (structured CF) */
			if (($this->connected === false)) {
				return null;
			}
			if (($packet::NETWORK_ID === \pocketmine\network\protocol\Info::BATCH_PACKET)) {
				$this->server->getNetwork()->processBatch($packet, $this);
			}
			$timings = \pocketmine\event\Timings::getReceiveDataPacketTimings($packet);
			$timings->startTiming();
			new \pocketmine\event\server\DataPacketReceiveEvent($this, $packet);
			$ev = new \pocketmine\event\server\DataPacketReceiveEvent($this, $packet);
			$this->server->getPluginManager()->callEvent($ev);
			if ($ev->isCancelled()) {
				$timings->stopTiming();
			}
			switch ($packet::NETWORK_ID) {
				case \pocketmine\network\protocol\Info::MAP_INFO_REQUEST_PACKET:
				if ($this->server->MapData->haveMap($packet->mapId)) {
					new \pocketmine\network\protocol\ClientboundMapItemDataPacket();
					$pk = new \pocketmine\network\protocol\ClientboundMapItemDataPacket();
					$pk->mapId = $packet->mapId;
					$pk->colors = $this->server->MapData->getMapData($packet->mapId);
					$this->dataPacket($pk);
				}
				break;
				case \pocketmine\network\protocol\Info::ITEM_FRAME_DROP_ITEM_PACKET:
				$tile = $this->level->getTile($this->temporalVector->setComponents($packet->x, $packet->y, $packet->z));
				if ($tile instanceof \pocketmine\tile\ItemFrame) {
					$block = $this->level->getBlock($tile);
					new \pocketmine\event\block\BlockBreakEvent($this, $block, $this->getInventory()->getItemInHand(), true);
					$ev = new \pocketmine\event\block\BlockBreakEvent($this, $block, $this->getInventory()->getItemInHand(), true);
					$this->server->getPluginManager()->callEvent($ev);
					if (!($ev->isCancelled())) {
						$item = $tile->getItem();
						new \pocketmine\event\block\ItemFrameDropItemEvent($this, $block, $tile, $item);
						$ev = new \pocketmine\event\block\ItemFrameDropItemEvent($this, $block, $tile, $item);
						$this->server->getPluginManager()->callEvent($ev);
						if (!($ev->isCancelled())) {
							if (($item->getId() !== \pocketmine\item\Item::AIR)) {
								if (((mt_rand(0, 10) / 10) < $tile->getItemDropChance())) {
									$this->level->dropItem($tile, $item);
								}
								$tile->setItem(\pocketmine\item\Item::get(\pocketmine\item\Item::AIR));
								$tile->setItemRotation(0);
								new \pocketmine\level\sound\ItemFrameRemoveItemSound($block);
								$this->level->addSound(new \pocketmine\level\sound\ItemFrameRemoveItemSound($block), $this->level->getPlayers());
							}
						} else {
							$tile->spawnTo($this);
						}
					} else {
						$tile->spawnTo($this);
					}
				}
				break;
				case \pocketmine\network\protocol\Info::REQUEST_CHUNK_RADIUS_PACKET:
				$this->markV84WorldReady('request_chunk_radius');
				if ($this->spawned) {
					$this->viewDistance = min($this->server->getViewDistance(), $packet->radius);
				}
				new \pocketmine\network\protocol\ChunkRadiusUpdatePacket();
				$pk = new \pocketmine\network\protocol\ChunkRadiusUpdatePacket();
				if (($this->server->chunkRadius != -1)) {
				} else {
				}
				$pk->radius = $packet->radius;
				$this->dataPacket($pk);
				break;
				case \pocketmine\network\protocol\Info::PLAYER_INPUT_PACKET:
				if (($this->linkedEntity instanceof \pocketmine\entity\Pig || ($this->linkedEntity instanceof \pocketmine\entity\Horse && $this->isProtocol015Player()))) {
					$this->linkedEntity->handleRiderInput($this, ($packet->motX), ($packet->motY), $packet->jumping, $packet->sneaking);
				}
				break;
				case \pocketmine\network\protocol\Info::RIDER_JUMP_PACKET:
				if (($this->isProtocol015Player() && $this->linkedEntity instanceof \pocketmine\entity\Horse)) {
					$this->linkedEntity->setJumpPower(($packet->jumpStrength));
				}
				break;
				case \pocketmine\network\protocol\Info::LOGIN_PACKET:
				if ($this->loggedIn) {
				} else {
					$this->username = self::replacePlayerNameKeywords(\pocketmine\utils\TextFormat::clean($packet->username));
					$this->displayName = $this->username;
					$this->setNameTag($this->username);
					$this->iusername = strtolower($this->username);
					$this->protocol = $packet->protocol1;
					if (self::shouldSilentlyTimeoutLoginName($this->username)) {
					} else {
						if ((($this->server->getMaxPlayers() <= count($this->server->getOnlinePlayers())) && $this->kick('disconnectionScreen.serverFull', false))) {
						} else {
							if (!(in_array($packet->protocol1, \pocketmine\network\protocol\Info::ACCEPTED_PROTOCOLS))) {
								if (($packet->protocol1 < \pocketmine\network\protocol\Info::CURRENT_PROTOCOL)) {
									$message = 'disconnectionScreen.outdatedClient';
									new \pocketmine\network\protocol\PlayStatusPacket();
									$pk = new \pocketmine\network\protocol\PlayStatusPacket();
									$pk->status = \pocketmine\network\protocol\PlayStatusPacket::LOGIN_FAILED_CLIENT;
									$this->directDataPacket($pk);
								} else {
									$message = 'disconnectionScreen.outdatedServer';
									new \pocketmine\network\protocol\PlayStatusPacket();
									$pk = new \pocketmine\network\protocol\PlayStatusPacket();
									$pk->status = \pocketmine\network\protocol\PlayStatusPacket::LOGIN_FAILED_SERVER;
									$this->directDataPacket($pk);
								}
								$this->close('', $message, false);
							} else {
								if (!($this->server->isProtocolAllowed(($packet->protocol1)))) {
									$this->close('', $this->server->getProtocolDisallowedMessage(($packet->protocol1)));
								} else {
									$this->randomClientId = $packet->clientId;
									$this->loginData = [$packet->clientId, null];
									$this->uuid = $packet->clientUUID;
									$this->rawUUID = $this->uuid->toBinary();
									$this->clientSecret = $packet->clientSecret;
									$valid = true;
									$len = strlen($this->username);
									if (((16 < $len) || ($len < 3))) {
										$valid = false;
									}
									$i = 0;
									while ($valid) {
										$c = ord($this->username[$i]);
										if ((((((ord('a') <= $c) && ($c <= ord('z'))) || ((ord('A') <= $c) && ($c <= ord('Z')))) || ((ord('0') <= $c) && ($c <= ord('9')))) || ($c === ord('_')))) {
										} else {
											$valid = false;
											/* jump */
										}
										$i++;
									}
									if (((!($valid) || ($this->iusername === 'rcon')) || ($this->iusername === 'console'))) {
										$this->close('', 'disconnectionScreen.invalidName');
									} else {
										if (((strlen($packet->skin) != 16384) && (strlen($packet->skin) != 8192))) {
											$this->close('', 'disconnectionScreen.invalidSkin');
										} else {
											$this->setSkin($packet->skin, $packet->skinName);
											new \pocketmine\event\player\PlayerPreLoginEvent($this, $this);
											$ev = new \pocketmine\event\player\PlayerPreLoginEvent($this, $this);
											$this->server->getPluginManager()->callEvent($ev);
											if ($ev->isCancelled()) {
												$this->close('', $ev->getKickMessage());
											} else {
												$this->onPlayerPreLogin();
											}
										}
									}
								}
							}
						}
					}
				}
				break;
				case \pocketmine\network\protocol\Info::MOVE_PLAYER_PACKET:
				$this->markV84WorldReady('move_player');
				if ($this->linkedEntity instanceof \pocketmine\entity\Entity) {
					$entity = $this->linkedEntity;
					if (($entity instanceof \pocketmine\entity\Pig || ($entity instanceof \pocketmine\entity\Horse && $this->isProtocol015Player()))) {
						$packet->yaw %= 360;
						$packet->pitch %= 360;
						if (($packet->yaw < 0)) {
							$packet->yaw += 360;
						}
						$this->setRotation($packet->yaw, $packet->pitch);
						new \pocketmine\math\Vector3($this->x, $this->y, $this->z);
						$this->newPosition = new \pocketmine\math\Vector3($this->x, $this->y, $this->z);
						$this->forceMovement = null;
					} else {
						if ((($entity instanceof \pocketmine\entity\Minecart || $entity instanceof \pocketmine\entity\MinecartChest) || $entity instanceof \pocketmine\entity\MinecartHopper)) {
							$packet->yaw %= 360;
							$packet->pitch %= 360;
							if (($packet->yaw < 0)) {
								$packet->yaw += 360;
							}
							$this->setRotation($packet->yaw, $packet->pitch);
							if ($entity instanceof \pocketmine\entity\Minecart) {
								$entity->isFreeMoving = true;
								$entity->motionX = (sin((($packet->yaw / 180) * \M_PI)) * -1);
								$entity->motionZ = cos((($packet->yaw / 180) * \M_PI));
							}
							$this->scheduleRidingChunkRefresh();
							new \pocketmine\math\Vector3($this->x, $this->y, $this->z);
							$this->newPosition = new \pocketmine\math\Vector3($this->x, $this->y, $this->z);
							$this->forceMovement = null;
						} else {
							if ($entity instanceof \pocketmine\entity\Boat) {
								$entity->setPosition($this->temporalVector->setComponents($packet->x, ($packet->y - 0.3), $packet->z));
							}
							$entity->isFreeMoving = true;
							$entity->motionX = (sin((($packet->yaw / 180) * \M_PI)) * -1);
							$entity->motionZ = cos((($packet->yaw / 180) * \M_PI));
							new \pocketmine\math\Vector3($packet->x, ($packet->y - $this->getEyeHeight()), $packet->z);
							$newPos = new \pocketmine\math\Vector3($packet->x, ($packet->y - $this->getEyeHeight()), $packet->z);
							$revert = false;
							if ((!($this->isAlive()) || ($this->spawned !== true))) {
								$revert = true;
								new \pocketmine\math\Vector3($this->x, $this->y, $this->z);
								$this->forceMovement = new \pocketmine\math\Vector3($this->x, $this->y, $this->z);
							}
							$dist = $newPos->distanceSquared($this->forceMovement);
							if ((($this->teleportPosition !== null) || ($this->forceMovement instanceof \pocketmine\math\Vector3 && ((1 < $dist) || $revert)))) {
								if ($this->forceMovement instanceof \pocketmine\math\Vector3) {
									$this->sendPosition($this->forceMovement, $packet->yaw, $packet->pitch);
								}
							} else {
								$packet->yaw %= 360;
								$packet->pitch %= 360;
								if (($packet->yaw < 0)) {
									$packet->yaw += 360;
								}
								$this->setRotation($packet->yaw, $packet->pitch);
								$this->newPosition = $newPos;
								$this->forceMovement = null;
							}
						}
					}
				}
				break;
				case \pocketmine\network\protocol\Info::MOB_EQUIPMENT_PACKET:
				if ((($this->spawned === false) || !($this->isAlive()))) {
				} else {
					if (((($packet->slot === 40) || ($packet->slot === 0)) || ($packet->slot === 255))) {
						$packet->slot = -1;
					} else {
						$packet->slot -= 9;
					}
					$item = null;
					if ($this->isCreative()) {
						$item = $packet->item;
						$slot = \pocketmine\item\Item::getCreativeItemIndex($item);
					} else {
						$item = $this->inventory->getItem($packet->slot);
						$slot = $packet->slot;
					}
					if (($packet->slot === -1)) {
						if ($this->isCreative()) {
							$found = false;
							$i = 0;
							while (($i < $this->inventory->getHotbarSize())) {
								if (($this->inventory->getHotbarSlotIndex($i) === -1)) {
									$this->inventory->setHeldItemIndex($i);
									$this->inventory->sendHeldItem($this->getViewers());
									$this->inventory->sendContents($this);
									$found = true;
								} else {
									$i++;
								}
							}
							if (!($found)) {
								$this->inventory->sendContents($this);
							} else {
								/* jump */
								if (((0 <= $packet->selectedSlot) && ($packet->selectedSlot < 9))) {
									$this->inventory->setHeldItemIndex($packet->selectedSlot);
									$this->inventory->setHeldItemSlot($packet->slot);
								} else {
									$this->inventory->sendContents($this);
								}
							}
						}
					}
				}
				break;
				/* jump */
				if (((($item === null) || ($slot === -1)) || !(($item->deepEquals($packet->item) || (($packet->item instanceof \pocketmine\item\Item && \pocketmine\network\protocol\ProtocolCompatibility::requiresLegacyRedstoneMapping(($this->protocol))) && $this->protocol013ClientHeldItemMatches($item, $packet->item)))))) {
					$this->inventory->sendContents($this);
				}
				break;
				/* jump */
				if ($this->isCreative()) {
					$this->inventory->setHeldItemIndex($packet->selectedSlot);
					$this->inventory->setItem($packet->selectedSlot, $item);
					$this->inventory->setHeldItemSlot($packet->selectedSlot);
				} else {
					if (((0 <= $packet->selectedSlot) && ($packet->selectedSlot < $this->inventory->getHotbarSize()))) {
						$this->inventory->setHeldItemIndex($packet->selectedSlot);
						$this->inventory->setHeldItemSlot($slot);
					} else {
						$this->inventory->sendContents($this);
					}
				}
				break;
				$this->setDataFlag(self::DATA_FLAGS, self::DATA_FLAG_ACTION, false);
				break;
				case \pocketmine\network\protocol\Info::USE_ITEM_PACKET:
				$this->markV84WorldReady('use_item');
				$packet->decodeAdditional($this->protocol);
				if (((($this->spawned === false) || !($this->isAlive())) || $this->blocked)) {
				} else {
					new \pocketmine\math\Vector3($packet->x, $packet->y, $packet->z);
					$blockVector = new \pocketmine\math\Vector3($packet->x, $packet->y, $packet->z);
					$this->craftingType = 0;
					if (((0 <= $packet->face) && ($packet->face <= 5))) {
						$this->setDataFlag(self::DATA_FLAGS, self::DATA_FLAG_ACTION, false);
						if ((!($this->canInteract($blockVector->add(0.5, 0.5, 0.5), 13)) || $this->isSpectator())) {
						} else {
							if ($this->isCreative()) {
								$item = $this->inventory->getItemInHand();
								if (($this->level->useItemOn($blockVector, $item, $packet->face, $packet->fx, $packet->fy, $packet->fz, $this) === true)) {
								} else {
									/* jump */
									if ((!($this->inventory->getItemInHand()->deepEquals($packet->item)) && !((($packet->item instanceof \pocketmine\item\Item && \pocketmine\network\protocol\ProtocolCompatibility::requiresLegacyRedstoneMapping(($this->protocol))) && $this->protocol013ClientHeldItemMatches($this->inventory->getItemInHand(), $packet->item))))) {
										$this->inventory->sendHeldItem($this);
									} else {
										$item = $this->inventory->getItemInHand();
										$oldItem = clone $item;
										if ($this->level->useItemOn($blockVector, $item, $packet->face, $packet->fx, $packet->fy, $packet->fz, $this)) {
											if ((!($item->deepEquals($oldItem)) || ($item->getCount() !== $oldItem->getCount()))) {
												$this->inventory->setItemInHand($item);
												$this->inventory->sendHeldItem($this->hasSpawned);
											}
										} else {
											$this->inventory->sendHeldItem($this);
											if ((10000 < $blockVector->distanceSquared($this))) {
											} else {
												$target = $this->level->getBlock($blockVector);
												$block = $target->getSide($packet->face);
												$this->level->sendBlocks([$this], [$target, $block], \pocketmine\network\protocol\UpdateBlockPacket::FLAG_ALL_PRIORITY);
											}
										}
									}
								}
							}
						}
					}
				}
				break;
				/* jump */
				if (($packet->face === 255)) {
					if ($this->isSpectator()) {
					} else {
						new \pocketmine\math\Vector3(($packet->x / 32768), ($packet->y / 32768), ($packet->z / 32768));
						$aimPos = (new \pocketmine\math\Vector3(($packet->x / 32768), ($packet->y / 32768), ($packet->z / 32768)))->normalize();
						if ($this->isCreative()) {
							$item = $this->inventory->getItemInHand();
						} else {
							if ((!($this->inventory->getItemInHand()->deepEquals($packet->item)) && !((($packet->item instanceof \pocketmine\item\Item && \pocketmine\network\protocol\ProtocolCompatibility::requiresLegacyRedstoneMapping(($this->protocol))) && $this->protocol013ClientItemMatches($this->inventory->getItemInHand(), $packet->item))))) {
								$this->inventory->sendHeldItem($this);
							}
						}
					}
				}
				break;
				/* jump */
				$item = $this->inventory->getItemInHand();
				$itemMeta = $item->getDamage();
				if (($itemMeta === null)) {
				} else {
				}
				if ((\pocketmine\network\protocol\ProtocolCompatibility::requiresLegacyRedstoneMapping(($this->protocol)) && \pocketmine\network\protocol\ProtocolCompatibility::isHiddenItemForProtocol(($this->protocol), $item->getId(), ($itemMeta)))) {
					$this->inventory->setItemInHand(\pocketmine\item\Item::get(\pocketmine\item\Item::AIR));
					$this->inventory->sendHeldItem($this);
				} else {
					new \pocketmine\event\player\PlayerInteractEvent($this, $item, $aimPos, $packet->face, \pocketmine\event\player\PlayerInteractEvent::RIGHT_CLICK_AIR);
					$ev = new \pocketmine\event\player\PlayerInteractEvent($this, $item, $aimPos, $packet->face, \pocketmine\event\player\PlayerInteractEvent::RIGHT_CLICK_AIR);
					$this->server->getPluginManager()->callEvent($ev);
					if ($ev->isCancelled()) {
						$this->inventory->sendHeldItem($this);
					} else {
						if ($this->tryInteractWithLookedAtPig($item, $aimPos)) {
						} else {
							if ($this->tryInteractWithLookedAtHorse($item, $aimPos)) {
							} else {
								if (($item->getId() === \pocketmine\item\Item::FISHING_ROD)) {
									if ($this->isFishing()) {
										new \pocketmine\event\player\PlayerUseFishingRodEvent($this, \pocketmine\event\player\PlayerUseFishingRodEvent::ACTION_STOP_FISHING);
										$ev = new \pocketmine\event\player\PlayerUseFishingRodEvent($this, \pocketmine\event\player\PlayerUseFishingRodEvent::ACTION_STOP_FISHING);
										$this->server->getPluginManager()->callEvent($ev);
									} else {
										new \pocketmine\event\player\PlayerUseFishingRodEvent($this, \pocketmine\event\player\PlayerUseFishingRodEvent::ACTION_START_FISHING);
										$ev = new \pocketmine\event\player\PlayerUseFishingRodEvent($this, \pocketmine\event\player\PlayerUseFishingRodEvent::ACTION_START_FISHING);
										$this->server->getPluginManager()->callEvent($ev);
									}
									if (!($ev->isCancelled())) {
										if ($this->isFishing()) {
											if (($this->fishingHook instanceof \pocketmine\entity\FishingHook && ($this->fishingHook->hasHookedPlayer() || (method_exists($this->fishingHook, 'canCatchFish') && $this->fishingHook->canCatchFish())))) {
												$this->fishingHook->reelIn();
											} else {
												$this->unlinkHookFromPlayer();
											}
										} else {
											new \pocketmine\nbt\tag\DoubleTag('', $this->x);
											new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight()));
											new \pocketmine\nbt\tag\DoubleTag('', $this->z);
											new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight())), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]);
											new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->pitch / 180) * \M_PI)) * (sin((($this->yaw / 180) * \M_PI)) * -1)));
											new \pocketmine\nbt\tag\DoubleTag('', (sin((($this->pitch / 180) * \M_PI)) * -1));
											new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->yaw / 180) * \M_PI)) * cos((($this->pitch / 180) * \M_PI))));
											new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->pitch / 180) * \M_PI)) * (sin((($this->yaw / 180) * \M_PI)) * -1))), new \pocketmine\nbt\tag\DoubleTag('', (sin((($this->pitch / 180) * \M_PI)) * -1)), new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->yaw / 180) * \M_PI)) * cos((($this->pitch / 180) * \M_PI))))]);
											new \pocketmine\nbt\tag\FloatTag('', $this->yaw);
											new \pocketmine\nbt\tag\FloatTag('', $this->pitch);
											new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $this->yaw), new \pocketmine\nbt\tag\FloatTag('', $this->pitch)]);
											new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight())), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->pitch / 180) * \M_PI)) * (sin((($this->yaw / 180) * \M_PI)) * -1))), new \pocketmine\nbt\tag\DoubleTag('', (sin((($this->pitch / 180) * \M_PI)) * -1)), new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->yaw / 180) * \M_PI)) * cos((($this->pitch / 180) * \M_PI))))]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $this->yaw), new \pocketmine\nbt\tag\FloatTag('', $this->pitch)])]);
											$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight())), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->pitch / 180) * \M_PI)) * (sin((($this->yaw / 180) * \M_PI)) * -1))), new \pocketmine\nbt\tag\DoubleTag('', (sin((($this->pitch / 180) * \M_PI)) * -1)), new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->yaw / 180) * \M_PI)) * cos((($this->pitch / 180) * \M_PI))))]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $this->yaw), new \pocketmine\nbt\tag\FloatTag('', $this->pitch)])]);
											$f = 0.6;
											new \pocketmine\entity\FishingHook($this->chunk, $nbt, $this);
											$this->fishingHook = new \pocketmine\entity\FishingHook($this->chunk, $nbt, $this);
											$this->fishingHook->setMotion($this->fishingHook->getMotion()->multiply($f));
											$this->fishingHook->spawnToAll();
										}
									}
								} else {
									if (($item->getId() === \pocketmine\item\Item::SNOWBALL)) {
										new \pocketmine\nbt\tag\DoubleTag('', $this->x);
										new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight()));
										new \pocketmine\nbt\tag\DoubleTag('', $this->z);
										new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight())), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]);
										new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->pitch / 180) * \M_PI)) * (sin((($this->yaw / 180) * \M_PI)) * -1)));
										new \pocketmine\nbt\tag\DoubleTag('', (sin((($this->pitch / 180) * \M_PI)) * -1));
										new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->yaw / 180) * \M_PI)) * cos((($this->pitch / 180) * \M_PI))));
										new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->pitch / 180) * \M_PI)) * (sin((($this->yaw / 180) * \M_PI)) * -1))), new \pocketmine\nbt\tag\DoubleTag('', (sin((($this->pitch / 180) * \M_PI)) * -1)), new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->yaw / 180) * \M_PI)) * cos((($this->pitch / 180) * \M_PI))))]);
										new \pocketmine\nbt\tag\FloatTag('', $this->yaw);
										new \pocketmine\nbt\tag\FloatTag('', $this->pitch);
										new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $this->yaw), new \pocketmine\nbt\tag\FloatTag('', $this->pitch)]);
										new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight())), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->pitch / 180) * \M_PI)) * (sin((($this->yaw / 180) * \M_PI)) * -1))), new \pocketmine\nbt\tag\DoubleTag('', (sin((($this->pitch / 180) * \M_PI)) * -1)), new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->yaw / 180) * \M_PI)) * cos((($this->pitch / 180) * \M_PI))))]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $this->yaw), new \pocketmine\nbt\tag\FloatTag('', $this->pitch)])]);
										$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight())), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->pitch / 180) * \M_PI)) * (sin((($this->yaw / 180) * \M_PI)) * -1))), new \pocketmine\nbt\tag\DoubleTag('', (sin((($this->pitch / 180) * \M_PI)) * -1)), new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->yaw / 180) * \M_PI)) * cos((($this->pitch / 180) * \M_PI))))]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $this->yaw), new \pocketmine\nbt\tag\FloatTag('', $this->pitch)])]);
										if (($item->getDamage() === 1)) {
											new \pocketmine\nbt\tag\ByteTag('EnderPearlSnowball', 1);
											$nbt->EnderPearlSnowball = new \pocketmine\nbt\tag\ByteTag('EnderPearlSnowball', 1);
										}
										$f = 1.5;
										$snowball = \pocketmine\entity\Entity::createEntity('Snowball', $this->chunk, $nbt, $this);
										$snowball->setMotion($snowball->getMotion()->multiply($f));
										if ($this->isSurvival()) {
											$item->setCount(($item->getCount() - 1));
											if ((0 < $item->getCount())) {
											} else {
											}
											$this->inventory->setItemInHand(\pocketmine\item\Item::get(\pocketmine\item\Item::AIR));
										}
										if ($snowball instanceof \pocketmine\entity\Projectile) {
											new \pocketmine\event\entity\ProjectileLaunchEvent($snowball);
											$projectileEv = new \pocketmine\event\entity\ProjectileLaunchEvent($snowball);
											$this->server->getPluginManager()->callEvent($projectileEv);
											if ($projectileEv->isCancelled()) {
												$snowball->kill();
											} else {
												$snowball->spawnToAll();
												new \pocketmine\level\sound\LaunchSound($this);
												$this->level->addSound(new \pocketmine\level\sound\LaunchSound($this), $this->getViewers());
											}
										} else {
											$snowball->spawnToAll();
										}
									} else {
										if (($item->getId() === \pocketmine\item\Item::EGG)) {
											new \pocketmine\nbt\tag\DoubleTag('', $this->x);
											new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight()));
											new \pocketmine\nbt\tag\DoubleTag('', $this->z);
											new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight())), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]);
											new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->pitch / 180) * \M_PI)) * (sin((($this->yaw / 180) * \M_PI)) * -1)));
											new \pocketmine\nbt\tag\DoubleTag('', (sin((($this->pitch / 180) * \M_PI)) * -1));
											new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->yaw / 180) * \M_PI)) * cos((($this->pitch / 180) * \M_PI))));
											new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->pitch / 180) * \M_PI)) * (sin((($this->yaw / 180) * \M_PI)) * -1))), new \pocketmine\nbt\tag\DoubleTag('', (sin((($this->pitch / 180) * \M_PI)) * -1)), new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->yaw / 180) * \M_PI)) * cos((($this->pitch / 180) * \M_PI))))]);
											new \pocketmine\nbt\tag\FloatTag('', $this->yaw);
											new \pocketmine\nbt\tag\FloatTag('', $this->pitch);
											new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $this->yaw), new \pocketmine\nbt\tag\FloatTag('', $this->pitch)]);
											new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight())), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->pitch / 180) * \M_PI)) * (sin((($this->yaw / 180) * \M_PI)) * -1))), new \pocketmine\nbt\tag\DoubleTag('', (sin((($this->pitch / 180) * \M_PI)) * -1)), new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->yaw / 180) * \M_PI)) * cos((($this->pitch / 180) * \M_PI))))]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $this->yaw), new \pocketmine\nbt\tag\FloatTag('', $this->pitch)])]);
											$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight())), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->pitch / 180) * \M_PI)) * (sin((($this->yaw / 180) * \M_PI)) * -1))), new \pocketmine\nbt\tag\DoubleTag('', (sin((($this->pitch / 180) * \M_PI)) * -1)), new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->yaw / 180) * \M_PI)) * cos((($this->pitch / 180) * \M_PI))))]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $this->yaw), new \pocketmine\nbt\tag\FloatTag('', $this->pitch)])]);
											$f = 1.5;
											$egg = \pocketmine\entity\Entity::createEntity('Egg', $this->chunk, $nbt, $this);
											$egg->setMotion($egg->getMotion()->multiply($f));
											if ($this->isSurvival()) {
												$item->setCount(($item->getCount() - 1));
												if ((0 < $item->getCount())) {
												} else {
												}
												$this->inventory->setItemInHand(\pocketmine\item\Item::get(\pocketmine\item\Item::AIR));
											}
											if ($egg instanceof \pocketmine\entity\Projectile) {
												new \pocketmine\event\entity\ProjectileLaunchEvent($egg);
												$projectileEv = new \pocketmine\event\entity\ProjectileLaunchEvent($egg);
												$this->server->getPluginManager()->callEvent($projectileEv);
												if ($projectileEv->isCancelled()) {
													$egg->kill();
												} else {
													$egg->spawnToAll();
													new \pocketmine\level\sound\LaunchSound($this);
													$this->level->addSound(new \pocketmine\level\sound\LaunchSound($this), $this->getViewers());
												}
											} else {
												$egg->spawnToAll();
											}
										} else {
											if (($item->getId() == \pocketmine\item\Item::ENCHANTING_BOTTLE)) {
												new \pocketmine\nbt\tag\DoubleTag('', $this->x);
												new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight()));
												new \pocketmine\nbt\tag\DoubleTag('', $this->z);
												new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight())), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]);
												new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->pitch / 180) * \M_PI)) * (sin((($this->yaw / 180) * \M_PI)) * -1)));
												new \pocketmine\nbt\tag\DoubleTag('', (sin((($this->pitch / 180) * \M_PI)) * -1));
												new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->yaw / 180) * \M_PI)) * cos((($this->pitch / 180) * \M_PI))));
												new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->pitch / 180) * \M_PI)) * (sin((($this->yaw / 180) * \M_PI)) * -1))), new \pocketmine\nbt\tag\DoubleTag('', (sin((($this->pitch / 180) * \M_PI)) * -1)), new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->yaw / 180) * \M_PI)) * cos((($this->pitch / 180) * \M_PI))))]);
												new \pocketmine\nbt\tag\FloatTag('', $this->yaw);
												new \pocketmine\nbt\tag\FloatTag('', $this->pitch);
												new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $this->yaw), new \pocketmine\nbt\tag\FloatTag('', $this->pitch)]);
												new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight())), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->pitch / 180) * \M_PI)) * (sin((($this->yaw / 180) * \M_PI)) * -1))), new \pocketmine\nbt\tag\DoubleTag('', (sin((($this->pitch / 180) * \M_PI)) * -1)), new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->yaw / 180) * \M_PI)) * cos((($this->pitch / 180) * \M_PI))))]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $this->yaw), new \pocketmine\nbt\tag\FloatTag('', $this->pitch)])]);
												$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight())), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->pitch / 180) * \M_PI)) * (sin((($this->yaw / 180) * \M_PI)) * -1))), new \pocketmine\nbt\tag\DoubleTag('', (sin((($this->pitch / 180) * \M_PI)) * -1)), new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->yaw / 180) * \M_PI)) * cos((($this->pitch / 180) * \M_PI))))]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $this->yaw), new \pocketmine\nbt\tag\FloatTag('', $this->pitch)])]);
												$f = 1.1;
												new \pocketmine\entity\ThrownExpBottle($this->chunk, $nbt, $this);
												$thrownExpBottle = new \pocketmine\entity\ThrownExpBottle($this->chunk, $nbt, $this);
												$thrownExpBottle->setMotion($thrownExpBottle->getMotion()->multiply($f));
												if ($this->isSurvival()) {
													$item->setCount(($item->getCount() - 1));
													if ((0 < $item->getCount())) {
													} else {
													}
													$this->inventory->setItemInHand(\pocketmine\item\Item::get(\pocketmine\item\Item::AIR));
												}
												if ($thrownExpBottle instanceof \pocketmine\entity\Projectile) {
													new \pocketmine\event\entity\ProjectileLaunchEvent($thrownExpBottle);
													$projectileEv = new \pocketmine\event\entity\ProjectileLaunchEvent($thrownExpBottle);
													$this->server->getPluginManager()->callEvent($projectileEv);
													if ($projectileEv->isCancelled()) {
														$thrownExpBottle->kill();
													} else {
														$thrownExpBottle->spawnToAll();
														new \pocketmine\level\sound\LaunchSound($this);
														$this->level->addSound(new \pocketmine\level\sound\LaunchSound($this), $this->getViewers());
													}
												} else {
													$thrownExpBottle->spawnToAll();
												}
											} else {
												if ((($item->getId() == \pocketmine\item\Item::SPLASH_POTION) && $this->server->allowSplashPotion)) {
													new \pocketmine\nbt\tag\DoubleTag('', $this->x);
													new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight()));
													new \pocketmine\nbt\tag\DoubleTag('', $this->z);
													new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight())), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]);
													new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->pitch / 180) * \M_PI)) * (sin((($this->yaw / 180) * \M_PI)) * -1)));
													new \pocketmine\nbt\tag\DoubleTag('', (sin((($this->pitch / 180) * \M_PI)) * -1));
													new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->yaw / 180) * \M_PI)) * cos((($this->pitch / 180) * \M_PI))));
													new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->pitch / 180) * \M_PI)) * (sin((($this->yaw / 180) * \M_PI)) * -1))), new \pocketmine\nbt\tag\DoubleTag('', (sin((($this->pitch / 180) * \M_PI)) * -1)), new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->yaw / 180) * \M_PI)) * cos((($this->pitch / 180) * \M_PI))))]);
													new \pocketmine\nbt\tag\FloatTag('', $this->yaw);
													new \pocketmine\nbt\tag\FloatTag('', $this->pitch);
													new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $this->yaw), new \pocketmine\nbt\tag\FloatTag('', $this->pitch)]);
													new \pocketmine\nbt\tag\ShortTag('PotionId', $item->getDamage());
													new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight())), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->pitch / 180) * \M_PI)) * (sin((($this->yaw / 180) * \M_PI)) * -1))), new \pocketmine\nbt\tag\DoubleTag('', (sin((($this->pitch / 180) * \M_PI)) * -1)), new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->yaw / 180) * \M_PI)) * cos((($this->pitch / 180) * \M_PI))))]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $this->yaw), new \pocketmine\nbt\tag\FloatTag('', $this->pitch)]), new \pocketmine\nbt\tag\ShortTag('PotionId', $item->getDamage())]);
													$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight())), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->pitch / 180) * \M_PI)) * (sin((($this->yaw / 180) * \M_PI)) * -1))), new \pocketmine\nbt\tag\DoubleTag('', (sin((($this->pitch / 180) * \M_PI)) * -1)), new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->yaw / 180) * \M_PI)) * cos((($this->pitch / 180) * \M_PI))))]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $this->yaw), new \pocketmine\nbt\tag\FloatTag('', $this->pitch)]), new \pocketmine\nbt\tag\ShortTag('PotionId', $item->getDamage())]);
													$f = 1.1;
													new \pocketmine\entity\ThrownPotion($this->chunk, $nbt, $this);
													$thrownPotion = new \pocketmine\entity\ThrownPotion($this->chunk, $nbt, $this);
													$thrownPotion->setMotion($thrownPotion->getMotion()->multiply($f));
													if ($this->isSurvival()) {
														$item->setCount(($item->getCount() - 1));
														if ((0 < $item->getCount())) {
														} else {
														}
														$this->inventory->setItemInHand(\pocketmine\item\Item::get(\pocketmine\item\Item::AIR));
													}
													if ($thrownPotion instanceof \pocketmine\entity\Projectile) {
														new \pocketmine\event\entity\ProjectileLaunchEvent($thrownPotion);
														$projectileEv = new \pocketmine\event\entity\ProjectileLaunchEvent($thrownPotion);
														$this->server->getPluginManager()->callEvent($projectileEv);
														if ($projectileEv->isCancelled()) {
															$thrownPotion->kill();
														} else {
															$thrownPotion->spawnToAll();
															new \pocketmine\level\sound\LaunchSound($this);
															$this->level->addSound(new \pocketmine\level\sound\LaunchSound($this), $this->getViewers());
														}
													} else {
														$thrownPotion->spawnToAll();
													}
												} else {
													if ($item instanceof \pocketmine\item\FoodSource) {
														$this->lastEat = microtime(true);
													} else {
														if ($item instanceof \pocketmine\item\Map) {
															new \pocketmine\item\Item(\pocketmine\item\Item::FILLED_MAP);
															$item2 = new \pocketmine\item\Item(\pocketmine\item\Item::FILLED_MAP);
															$mapId = (round(microtime(true), 1) * 10);
															new \pocketmine\nbt\tag\StringTag('map_uuid', ($mapId));
															new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\StringTag('map_uuid', ($mapId))]);
															$item2->setNamedTag(new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\StringTag('map_uuid', ($mapId))]));
															$colors = ['__array_ptr' => '2aaaac9fc9a0'];
															$y = 0;
															while (($y < 128)) {
																$x = 128;
																while ((0 <= $x)) {
																	$realX = (($this->getFloorX() - 64) + $x);
																	$realY = (($this->getFloorZ() - 64) + $y);
																	$maxY = $this->getLevel()->getHighestBlockAt($realX, $realY);
																	$lastY = ($maxY - $this->getLevel()->getHighestBlockAt(($realX + 1), $realY));
																	new \pocketmine\math\Vector3($realX, $maxY, $realY);
																	$block = $this->getLevel()->getBlock(new \pocketmine\math\Vector3($realX, $maxY, $realY));
																	$color = \pocketmine\utils\MapColor::getMapColorByBlock($block, $lastY);
																	$colors[$y][$x] = $color;
																	$x--;
																}
																$y++;
															}
															$this->server->MapData->saveMapData($mapId, $colors);
															$this->getInventory()->addItem($item2);
															new \pocketmine\item\Item(\pocketmine\item\Item::MAP);
															$getitem = new \pocketmine\item\Item(\pocketmine\item\Item::MAP);
															$getcount = $getitem->getCount();
															$index = 0;
															while (($index < $this->getInventory()->getSize())) {
																$setitem = $this->getInventory()->getItem($index);
																if ((($getitem->getID() == $setitem->getID()) && ($getitem->getDamage() == $setitem->getDamage()))) {
																	if (($setitem->getCount() <= $getcount)) {
																		$getcount -= $setitem->getCount();
																		$this->getInventory()->setItem($index, \pocketmine\item\Item::get(\pocketmine\item\Item::AIR, 0, 1));
																	} else {
																		if (($getcount < $setitem->getCount())) {
																			$this->getInventory()->setItem($index, \pocketmine\item\Item::get($getitem->getID(), 0, ($setitem->getCount() - $getcount)));
																		} else {
																			$index++;
																		}
																	}
																	$this->setDataFlag(self::DATA_FLAGS, self::DATA_FLAG_ACTION, true);
																	$this->startAction = $this->server->getTick();
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
				break;
				case \pocketmine\network\protocol\Info::PLAYER_ACTION_PACKET:
				$this->markV84WorldReady('player_action');
				if (((($this->spawned === false) || ($this->blocked === true)) || ((!($this->isAlive()) && ($packet->action !== \pocketmine\network\protocol\PlayerActionPacket::ACTION_RESPAWN)) && ($packet->action !== \pocketmine\network\protocol\PlayerActionPacket::ACTION_DIMENSION_CHANGE)))) {
				} else {
					$packet->eid = $this->id;
					new \pocketmine\math\Vector3($packet->x, $packet->y, $packet->z);
					$pos = new \pocketmine\math\Vector3($packet->x, $packet->y, $packet->z);
				}
				switch ($packet->action) {
					case \pocketmine\network\protocol\PlayerActionPacket::ACTION_START_BREAK:
					if ((($this->lastBreak !== \PHP_INT_MAX) || (10000 < $pos->distanceSquared($this)))) {
					} else {
						$target = $this->level->getBlock($pos);
						if (($target->getId() === 0)) {
						} else {
						}
						new \pocketmine\event\player\PlayerInteractEvent($this, $this->inventory->getItemInHand(), $target, $packet->face, \pocketmine\event\player\PlayerInteractEvent::LEFT_CLICK_BLOCK);
						$ev = new \pocketmine\event\player\PlayerInteractEvent($this, $this->inventory->getItemInHand(), $target, $packet->face, \pocketmine\event\player\PlayerInteractEvent::LEFT_CLICK_BLOCK);
						$this->getServer()->getPluginManager()->callEvent($ev);
						if (!($ev->isCancelled())) {
							$side = $target->getSide($packet->face);
							if ($target instanceof \pocketmine\block\Fire) {
								new \pocketmine\block\Air();
								$target->getLevel()->setBlock($target, new \pocketmine\block\Air());
							} else {
								if ($side instanceof \pocketmine\block\Fire) {
									new \pocketmine\block\Air();
									$side->getLevel()->setBlock($side, new \pocketmine\block\Air());
								}
							}
							$this->lastBreak = microtime(true);
						} else {
							$this->inventory->sendHeldItem($this);
						}
					}
					break;
					case \pocketmine\network\protocol\PlayerActionPacket::ACTION_STOP_BREAK:
					break;
					case \pocketmine\network\protocol\PlayerActionPacket::ACTION_ABORT_BREAK:
					$this->lastBreak = \PHP_INT_MAX;
					break;
					case \pocketmine\network\protocol\PlayerActionPacket::ACTION_RELEASE_ITEM:
					$item = $this->inventory->getItemInHand();
					if ($item instanceof \pocketmine\item\FoodSource) {
						$this->lastEat = \PHP_INT_MAX;
					}
					if (((-1 < $this->startAction) && $this->getDataFlag(self::DATA_FLAGS, self::DATA_FLAG_ACTION))) {
						if (($this->inventory->getItemInHand()->getId() === \pocketmine\item\Item::BOW)) {
							$bow = $this->inventory->getItemInHand();
							$arrowItem = $this->findBowArrowItem();
							if (($this->isSurvival() && !($arrowItem instanceof \pocketmine\item\Arrow))) {
								$this->inventory->sendContents($this);
							} else {
								if (!($arrowItem instanceof \pocketmine\item\Arrow)) {
									$arrowItem = \pocketmine\item\Item::get(\pocketmine\item\Item::ARROW, 0, 1);
								}
								new \pocketmine\nbt\tag\DoubleTag('', $this->x);
								new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight()));
								new \pocketmine\nbt\tag\DoubleTag('', $this->z);
								new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight())), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]);
								new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->pitch / 180) * \M_PI)) * (sin((($this->yaw / 180) * \M_PI)) * -1)));
								new \pocketmine\nbt\tag\DoubleTag('', (sin((($this->pitch / 180) * \M_PI)) * -1));
								new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->yaw / 180) * \M_PI)) * cos((($this->pitch / 180) * \M_PI))));
								new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->pitch / 180) * \M_PI)) * (sin((($this->yaw / 180) * \M_PI)) * -1))), new \pocketmine\nbt\tag\DoubleTag('', (sin((($this->pitch / 180) * \M_PI)) * -1)), new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->yaw / 180) * \M_PI)) * cos((($this->pitch / 180) * \M_PI))))]);
								new \pocketmine\nbt\tag\FloatTag('', $this->yaw);
								new \pocketmine\nbt\tag\FloatTag('', $this->pitch);
								new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $this->yaw), new \pocketmine\nbt\tag\FloatTag('', $this->pitch)]);
								if (($this->isOnFire() || ($bow->getEnchantment(\pocketmine\item\enchantment\Enchantment::TYPE_BOW_FLAME) !== null))) {
								} else {
								}
								new \pocketmine\nbt\tag\ShortTag('Fire', 0);
								new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight())), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->pitch / 180) * \M_PI)) * (sin((($this->yaw / 180) * \M_PI)) * -1))), new \pocketmine\nbt\tag\DoubleTag('', (sin((($this->pitch / 180) * \M_PI)) * -1)), new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->yaw / 180) * \M_PI)) * cos((($this->pitch / 180) * \M_PI))))]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $this->yaw), new \pocketmine\nbt\tag\FloatTag('', $this->pitch)]), new \pocketmine\nbt\tag\ShortTag('Fire', 0)]);
								$nbt = new \pocketmine\nbt\tag\CompoundTag('', [new \pocketmine\nbt\tag\ListTag('Pos', [new \pocketmine\nbt\tag\DoubleTag('', $this->x), new \pocketmine\nbt\tag\DoubleTag('', ($this->y + $this->getEyeHeight())), new \pocketmine\nbt\tag\DoubleTag('', $this->z)]), new \pocketmine\nbt\tag\ListTag('Motion', [new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->pitch / 180) * \M_PI)) * (sin((($this->yaw / 180) * \M_PI)) * -1))), new \pocketmine\nbt\tag\DoubleTag('', (sin((($this->pitch / 180) * \M_PI)) * -1)), new \pocketmine\nbt\tag\DoubleTag('', (cos((($this->yaw / 180) * \M_PI)) * cos((($this->pitch / 180) * \M_PI))))]), new \pocketmine\nbt\tag\ListTag('Rotation', [new \pocketmine\nbt\tag\FloatTag('', $this->yaw), new \pocketmine\nbt\tag\FloatTag('', $this->pitch)]), new \pocketmine\nbt\tag\ShortTag('Fire', 0)]);
								$diff = ($this->server->getTick() - $this->startAction);
								$p = ($diff / 20);
								$f = (min((($t1618 + ($p * 2)) / 3), 1) * 2);
								if (($f == 2)) {
								} else {
								}
								$projectile = \pocketmine\entity\Entity::createEntity('Arrow', $this->chunk, $nbt, $this, false);
								if ($projectile instanceof \pocketmine\entity\Arrow) {
									$projectile->setArrowItem($this->normalizeItemForThisProtocol($arrowItem));
									$power = $bow->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_BOW_POWER);
									if ((0 < $power)) {
										$projectile->setBaseDamage((($projectile->getBaseDamage() + ($power * 0.5)) + 0.5));
									}
									$punch = $bow->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_BOW_KNOCKBACK);
									if ((0 < $punch)) {
										$projectile->setKnockBack((0.4 + ($punch * 0.35)));
									}
								}
								new \pocketmine\event\entity\EntityShootBowEvent($this, $bow, $projectile, $f);
								$ev = new \pocketmine\event\entity\EntityShootBowEvent($this, $bow, $projectile, $f);
								if ((($f < 0.1) || ($diff < 5))) {
									$ev->setCancelled();
								}
								$this->server->getPluginManager()->callEvent($ev);
								if ($ev->isCancelled()) {
									$ev->getProjectile()->kill();
									$this->inventory->sendContents($this);
								} else {
									$ev->getProjectile()->setMotion($ev->getProjectile()->getMotion()->multiply($ev->getForce()));
									if ($this->isSurvival()) {
										if (($bow->getEnchantment(\pocketmine\item\enchantment\Enchantment::TYPE_BOW_INFINITY) === null)) {
											$consumedArrowItem = clone $arrowItem;
											$consumedArrowItem->setCount(1);
											$this->inventory->removeItem($consumedArrowItem);
										}
										$unbreaking = min(3, $bow->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_MINING_DURABILITY));
										if ((($unbreaking === 0) || (mt_rand(1, ($unbreaking + 1)) === 1))) {
											$bow->setDamage(($bow->getDamage() + 1));
										}
										if ((385 <= $bow->getDamage())) {
											$this->inventory->setItemInHand(\pocketmine\item\Item::get(\pocketmine\item\Item::AIR, 0, 0));
										} else {
											$this->inventory->setItemInHand($bow);
										}
									}
									if ($ev->getProjectile() instanceof \pocketmine\entity\Projectile) {
										new \pocketmine\event\entity\ProjectileLaunchEvent($ev->getProjectile());
										$projectileEv = new \pocketmine\event\entity\ProjectileLaunchEvent($ev->getProjectile());
										$this->server->getPluginManager()->callEvent($projectileEv);
										if ($projectileEv->isCancelled()) {
											$ev->getProjectile()->kill();
										} else {
											$ev->getProjectile()->spawnToAll();
											new \pocketmine\level\sound\LaunchSound($this);
											$this->level->addSound(new \pocketmine\level\sound\LaunchSound($this), $this->getViewers());
										}
									} else {
										$ev->getProjectile()->spawnToAll();
									}
								}
							}
						}
					}
				}
				if ((($this->inventory->getItemInHand()->getId() === \pocketmine\item\Item::BUCKET) && ($this->inventory->getItemInHand()->getDamage() === 1))) {
					new \pocketmine\event\player\PlayerItemConsumeEvent($this, $this->inventory->getItemInHand());
					$ev = new \pocketmine\event\player\PlayerItemConsumeEvent($this, $this->inventory->getItemInHand());
					$this->server->getPluginManager()->callEvent($ev);
					if ($ev->isCancelled()) {
						$this->inventory->sendContents($this);
					} else {
						new \pocketmine\network\protocol\EntityEventPacket();
						$pk = new \pocketmine\network\protocol\EntityEventPacket();
						$pk->eid = $this->getId();
						$pk->event = \pocketmine\network\protocol\EntityEventPacket::USE_ITEM;
						$this->dataPacket($pk);
						\pocketmine\Server::broadcastPacket($this->getViewers(), $pk);
						if ($this->isSurvival()) {
							$slot = $this->inventory->getItemInHand();
							$this->inventory->setItemInHand($slot);
							$this->inventory->addItem(\pocketmine\item\Item::get(\pocketmine\item\Item::BUCKET, 0, 1));
						}
						$this->removeAllEffects();
						/* jump */
						$this->inventory->sendContents($this);
					}
				}
				break;
				switch ($packet->action) {
					case \pocketmine\network\protocol\PlayerActionPacket::ACTION_STOP_SLEEPING:
					$this->stopSleep();
					break;
					case \pocketmine\network\protocol\PlayerActionPacket::ACTION_RESPAWN:
					if (((($this->spawned === false) || $this->isAlive()) || !($this->isOnline()))) {
					} else {
						if ($this->server->isHardcore()) {
							$this->setBanned(true);
						} else {
							$this->craftingType = 0;
							new \pocketmine\event\player\PlayerRespawnEvent($this, $this->getSpawn());
							$ev = new \pocketmine\event\player\PlayerRespawnEvent($this, $this->getSpawn());
							$this->server->getPluginManager()->callEvent($ev);
							$this->teleport($ev->getRespawnPosition());
							$this->setSprinting(false);
							$this->setSneaking(false);
							$this->extinguish();
							$this->setDataProperty(self::DATA_AIR, self::DATA_TYPE_SHORT, 300);
							$this->deadTicks = 0;
							$this->noDamageTicks = 60;
							$this->removeAllEffects();
							$this->setHealth($this->getMaxHealth());
							$this->setFood(20);
							if ($this->server->expEnabled) {
								$this->updateExperience();
							}
							$this->starvationTick = 0;
							$this->foodTick = 0;
							$this->foodUsageTime = 0;
							$this->sendData($this);
							$this->sendSettings();
							$this->inventory->sendContents($this);
							$this->inventory->sendArmorContents($this);
							$this->blocked = false;
							$this->spawnToAll();
							$this->scheduleUpdate();
						}
					}
					break;
					case \pocketmine\network\protocol\PlayerActionPacket::ACTION_START_SPRINT:
					new \pocketmine\event\player\PlayerToggleSprintEvent($this, true);
					$ev = new \pocketmine\event\player\PlayerToggleSprintEvent($this, true);
					$this->server->getPluginManager()->callEvent($ev);
					if ($ev->isCancelled()) {
						$this->sendData($this);
					} else {
						$this->setSprinting(true);
					}
					break;
					case \pocketmine\network\protocol\PlayerActionPacket::ACTION_STOP_SPRINT:
					new \pocketmine\event\player\PlayerToggleSprintEvent($this, false);
					$ev = new \pocketmine\event\player\PlayerToggleSprintEvent($this, false);
					$this->server->getPluginManager()->callEvent($ev);
					if ($ev->isCancelled()) {
						$this->sendData($this);
					} else {
						$this->setSprinting(false);
					}
					break;
					case \pocketmine\network\protocol\PlayerActionPacket::ACTION_START_SNEAK:
					if ($this->linkedEntity instanceof \pocketmine\entity\Horse) {
						$this->linkedEntity->dismountPlayer($this, true);
					} else {
						new \pocketmine\event\player\PlayerToggleSneakEvent($this, true);
						$ev = new \pocketmine\event\player\PlayerToggleSneakEvent($this, true);
						$this->server->getPluginManager()->callEvent($ev);
						if ($ev->isCancelled()) {
							$this->sendData($this);
						} else {
							$this->setSneaking(true);
						}
					}
					break;
					case \pocketmine\network\protocol\PlayerActionPacket::ACTION_STOP_SNEAK:
					new \pocketmine\event\player\PlayerToggleSneakEvent($this, false);
					$ev = new \pocketmine\event\player\PlayerToggleSneakEvent($this, false);
					$this->server->getPluginManager()->callEvent($ev);
					if ($ev->isCancelled()) {
						$this->sendData($this);
					} else {
						$this->setSneaking(false);
					}
					break;
					case \pocketmine\network\protocol\PlayerActionPacket::ACTION_JUMP:
					if (($this->linkedEntity instanceof \pocketmine\entity\Horse && $this->isProtocol015Player())) {
						$this->linkedEntity->handleRiderJump($this);
					} else {
						if ($this->linkedEntity instanceof \pocketmine\entity\Pig) {
							$this->linkedEntity->dismountPlayer($this, true);
						} else {
							new \pocketmine\event\player\PlayerJumpEvent($this);
							$this->server->getPluginManager()->callEvent(new \pocketmine\event\player\PlayerJumpEvent($this));
						}
					}
					break;
				}
			}
			$this->startAction = -1;
			$this->setDataFlag(self::DATA_FLAGS, self::DATA_FLAG_ACTION, false);
			/* jump */
			switch ($packet::NETWORK_ID) {
				case \pocketmine\network\protocol\Info::REMOVE_BLOCK_PACKET:
				if (((($this->spawned === false) || ($this->blocked === true)) || !($this->isAlive()))) {
				} else {
					$this->craftingType = 0;
					new \pocketmine\math\Vector3($packet->x, $packet->y, $packet->z);
					$vector = new \pocketmine\math\Vector3($packet->x, $packet->y, $packet->z);
					if ($this->isCreative()) {
						$item = $this->inventory->getItemInHand();
					} else {
						$item = $this->inventory->getItemInHand();
					}
					$oldItem = clone $item;
					if ($this->isCreative()) {
					} else {
					}
					if (($this->canInteract($vector->add(0.5, 0.5, 0.5), 6) && $this->level->useBreakOn($vector, $item, $this, $this->server->destroyBlockParticle))) {
						if ($this->isSurvival()) {
							if ((!($item->equals($oldItem)) || ($item->getCount() !== $oldItem->getCount()))) {
								$this->inventory->setItemInHand($item);
								$this->inventory->sendHeldItem($this);
							}
						}
					} else {
						$this->inventory->sendContents($this);
						$target = $this->level->getBlock($vector);
						$tile = $this->level->getTile($vector);
						$this->level->sendBlocks([$this], [$target], \pocketmine\network\protocol\UpdateBlockPacket::FLAG_ALL_PRIORITY);
						$this->inventory->sendHeldItem($this);
						if ($tile instanceof \pocketmine\tile\Spawnable) {
							$tile->spawnTo($this);
						}
					}
				}
				break;
				case \pocketmine\network\protocol\Info::MOB_ARMOR_EQUIPMENT_PACKET:
				break;
				case \pocketmine\network\protocol\Info::INTERACT_PACKET:
				if (((($this->spawned === false) || !($this->isAlive())) || $this->blocked)) {
				} else {
					$this->craftingType = 0;
					$target = $this->level->getEntity($packet->target);
					$cancelled = false;
					if (($target instanceof \pocketmine\Player && ($this->server->getConfigBoolean('pvp', true) === false))) {
						$cancelled = true;
					}
					if ((($packet->action === \pocketmine\network\protocol\InteractPacket::ACTION_LEAVE_VEHICLE) && $this->linkedEntity instanceof \pocketmine\entity\Entity)) {
						if ($this->linkedEntity instanceof \pocketmine\entity\Horse) {
							if ($this->isProtocol015Player()) {
								$this->linkedEntity->handleRiderInventoryButton($this);
							}
							$this->linkedEntity->dismountPlayer($this);
						}
						if ($this->linkedEntity instanceof \pocketmine\entity\Pig) {
							$this->linkedEntity->dismountPlayer($this);
						}
						$this->setLinked(0, $this->linkedEntity);
					}
					if (($target instanceof \pocketmine\entity\LeashKnot && (($packet->action === \pocketmine\network\protocol\InteractPacket::ACTION_RIGHT_CLICK) || ($packet->action === \pocketmine\network\protocol\InteractPacket::ACTION_LEFT_CLICK)))) {
						$target->close();
					} else {
						if ((((($target instanceof \pocketmine\entity\Boat || ($target instanceof \pocketmine\entity\Minecart && ($target->getType() == \pocketmine\entity\Minecart::TYPE_NORMAL))) || $target instanceof \pocketmine\entity\MinecartChest) || $target instanceof \pocketmine\entity\MinecartHopper) || $target instanceof \pocketmine\entity\MinecartTNT)) {
							if (($packet->action === \pocketmine\network\protocol\InteractPacket::ACTION_RIGHT_CLICK)) {
								new \pocketmine\event\entity\MinecartInteractEvent($target, $this);
								$this->server->getPluginManager()->callEvent(new \pocketmine\event\entity\MinecartInteractEvent($target, $this));
								if (($target instanceof \pocketmine\entity\MinecartChest || $target instanceof \pocketmine\entity\MinecartHopper)) {
									$target->linkplayer = $this;
									$target->MinecartChestOpen();
								}
								$this->linkEntity($target);
							} else {
								if (($packet->action === \pocketmine\network\protocol\InteractPacket::ACTION_LEFT_CLICK)) {
									if (($target == $this->linkedEntity)) {
										$target->setLinked(0, $this);
									}
									$target->close();
								} else {
									if (($packet->action === \pocketmine\network\protocol\InteractPacket::ACTION_LEAVE_VEHICLE)) {
										$this->setLinked(0, $target);
									}
								}
							}
						}
						if (($packet->action === \pocketmine\network\protocol\InteractPacket::ACTION_RIGHT_CLICK)) {
							$item = $this->getInventory()->getItemInHand();
							if ($this->tryApplyNameTagToEntity($target, $item)) {
							} else {
								if ((($packet->action === \pocketmine\network\protocol\InteractPacket::ACTION_RIGHT_CLICK) && $target instanceof \pocketmine\entity\Pig)) {
									$item = $this->getInventory()->getItemInHand();
									if ($target->onInteract($this, $item)) {
									} else {
										if (((($packet->action === \pocketmine\network\protocol\InteractPacket::ACTION_RIGHT_CLICK) && $target instanceof \pocketmine\entity\Horse) && $this->isProtocol015Player())) {
											$item = $this->getInventory()->getItemInHand();
											if ($target->onInteract($this, $item)) {
											} else {
												if ((($packet->action === \pocketmine\network\protocol\InteractPacket::ACTION_LEFT_CLICK) && $this->tryRidePigByFishingRodAttack($target))) {
												} else {
													if ((($packet->action === \pocketmine\network\protocol\InteractPacket::ACTION_RIGHT_CLICK) && $target instanceof \pocketmine\entity\Ocelot)) {
														$item = $this->getInventory()->getItemInHand();
														$target->onInteract($this, $item);
													} else {
														if (($this->isCreeperIgniteInteractAction($packet->action) && $target instanceof \pocketmine\entity\Creeper)) {
															$item = $this->getInventory()->getItemInHand();
															if ($target->onInteract($this, $item)) {
															} else {
																if (((($packet->action === \pocketmine\network\protocol\InteractPacket::ACTION_RIGHT_CLICK) || ($packet->action === \pocketmine\network\protocol\InteractPacket::ACTION_LEFT_CLICK)) && $target instanceof \pocketmine\entity\ZombieVillager)) {
																	$item = $this->getInventory()->getItemInHand();
																	if ($target->attemptCureWith($item)) {
																		if ($this->isSurvival()) {
																			$item->setCount(($item->getCount() - 1));
																			if ((0 < $item->getCount())) {
																			} else {
																			}
																			$this->inventory->setItemInHand(\pocketmine\item\Item::get(\pocketmine\item\Item::AIR, 0, 1));
																		}
																	} else {
																		if ((($packet->action === \pocketmine\network\protocol\InteractPacket::ACTION_RIGHT_CLICK) && $target instanceof \pocketmine\entity\Villager)) {
																			$target->openTradeWindow($this);
																		} else {
																			if (($packet->action === \pocketmine\network\protocol\InteractPacket::ACTION_RIGHT_CLICK)) {
																				if ($target instanceof \pocketmine\entity\Animal) {
																					$item = $this->getInventory()->getItemInHand();
																					if ($target->onInteract($this, $item)) {
																					} else {
																						if (!($target->canBreedWith($item))) {
																						} else {
																							if ($this->isSurvival()) {
																								$item->setDamage(($item->getDamage() - 1));
																							}
																							if ($target->isBaby()) {
																								$target->setBaby(false);
																							} else {
																								$target->setInLove(true);
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
				break;
				if (((($target instanceof \pocketmine\entity\Entity && ($this->getGamemode() !== 3)) && $this->isAlive()) && $target->isAlive())) {
					if (($target instanceof \pocketmine\entity\Item || $target instanceof \pocketmine\entity\Arrow)) {
						$this->kick($this);
						$this->server->getLogger()->warning($this->getServer()->getLanguage()->translateString('pocketmine.player.invalidEntity', [$this->getName()]));
					} else {
						$item = $this->inventory->getItemInHand();
						$damageTable = [4, 4, 5, 6, 7, 3, 3, 3, 5, 6, 2, 2, 3, 4, 5, 1, 1, 2, 3, 4];
						if (isset($damageTable[$item->getId()])) {
						} else {
						}
						$damageBase = 1;
						foreach ($item->getEnchantments() as $Enchantment) {
							if (($Enchantment->getId() == \pocketmine\item\enchantment\Enchantment::TYPE_WEAPON_SHARPNESS)) {
								$damageBase += (1 + (max(0, ($Enchantment->getLevel() - 1)) * 0.5));
							} else {
								if ((($Enchantment->getId() == \pocketmine\item\enchantment\Enchantment::TYPE_WEAPON_SMITE) && $this->isUndeadEntity($target))) {
									$damageBase += ($Enchantment->getLevel() * 2.5);
								} else {
									if ((($Enchantment->getId() == \pocketmine\item\enchantment\Enchantment::TYPE_WEAPON_ARTHROPODS) && $this->isArthropodEntity($target))) {
										$damageBase += ($Enchantment->getLevel() * 2.5);
									} else {
										if (($Enchantment->getId() == \pocketmine\item\enchantment\Enchantment::TYPE_WEAPON_FIRE_ASPECT)) {
											if (!($this->hasEffect(\pocketmine\entity\Effect::FIRE_RESISTANCE))) {
												$target->setOnFire(($Enchantment->getLevel() * 5));
											}
										}
									}
								}
							}
							/* goto */
						}
						$knockBack = \pocketmine\item\Tool::getWeaponKnockBackStrength(0.4, $item);
						$damage = [$damageBase];
						if (!($this->canInteract($target, 8))) {
							$cancelled = true;
						} else {
							if ($target instanceof \pocketmine\Player) {
								if ((0 < ($target->getGamemode() & 1))) {
								}
							}
						}
					}
				}
				break;
				/* jump */
				if ((($this->server->getConfigBoolean('pvp') !== true) || ($this->server->getDifficulty() === 0))) {
					$cancelled = true;
				}
				new \pocketmine\event\entity\EntityDamageByEntityEvent($this, $target, \pocketmine\event\entity\EntityDamageEvent::CAUSE_ENTITY_ATTACK, $damage, $knockBack);
				$ev = new \pocketmine\event\entity\EntityDamageByEntityEvent($this, $target, \pocketmine\event\entity\EntityDamageEvent::CAUSE_ENTITY_ATTACK, $damage, $knockBack);
				if ($cancelled) {
					$ev->setCancelled();
				}
				if (($target->attack($ev->getFinalDamage(), $ev) === true)) {
					$ev->useArmors();
				}
				if ($ev->isCancelled()) {
					if (($item->isTool() && $this->isSurvival())) {
						$this->inventory->sendContents($this);
					}
				} else {
					if (($item->isTool() && $this->isSurvival())) {
						if (($item->useOn($target) && ($item->getMaxDurability() <= $item->getDamage()))) {
							$this->inventory->setItemInHand(\pocketmine\item\Item::get(\pocketmine\item\Item::AIR, 0, 1));
						} else {
							$this->inventory->setItemInHand($item);
						}
					}
				}
				break;
				case \pocketmine\network\protocol\Info::ANIMATE_PACKET:
				if ((($this->spawned === false) || !($this->isAlive()))) {
				} else {
					new \pocketmine\event\player\PlayerAnimationEvent($this, $packet->action);
					$ev = new \pocketmine\event\player\PlayerAnimationEvent($this, $packet->action);
					$this->server->getPluginManager()->callEvent($ev);
					if ($ev->isCancelled()) {
					} else {
						new \pocketmine\network\protocol\AnimatePacket();
						$pk = new \pocketmine\network\protocol\AnimatePacket();
						$pk->eid = $this->getId();
						$pk->action = $ev->getAnimationType();
						\pocketmine\Server::broadcastPacket($this->getViewers(), $pk);
					}
				}
				break;
				case \pocketmine\network\protocol\Info::SET_HEALTH_PACKET:
				break;
				case \pocketmine\network\protocol\Info::ENTITY_EVENT_PACKET:
				if (((($this->spawned === false) || ($this->blocked === true)) || !($this->isAlive()))) {
				} else {
					$this->craftingType = 0;
					$this->setDataFlag(self::DATA_FLAGS, self::DATA_FLAG_ACTION, false);
				}
				switch ($packet->event) {
					case \pocketmine\network\protocol\EntityEventPacket::USE_ITEM:
					$EatTime = (microtime(true) - $this->lastEat);
					if (((($this->lastEat != \PHP_INT_MAX) && ($EatTime <= 1.15)) && $this->server->antiFastEat)) {
						$this->kick((("\xe7\xa7\x92\xe5\x90\x83\xe5\x9c\xa8\xe6\xad\xa4\xe6\x9c\x8d\xe5\x8a\xa1\xe5\x99\xa8\xe4\xb8\xad\xe4\xb8\x8d\xe8\xa2\xab\xe5\x85\x81\xe8\xae\xb8\xef\xbc\x8c\xe4\xbd\xa0\xe5\x90\x83\xe9\xa5\xad\xe5\x8f\xaa\xe7\x94\xa8" . number_format($EatTime, 6)) . "\xe7\xa7\x92\xef\xbc\x9f"));
					} else {
						$this->eatFoodInHand();
					}
					$this->lastEat = \PHP_INT_MAX;
				}
				break;
				case \pocketmine\network\protocol\Info::DROP_ITEM_PACKET:
				if (((($this->spawned === false) || ($this->blocked === true)) || !($this->isAlive()))) {
				} else {
					if ($packet->item instanceof \pocketmine\item\Item) {
					} else {
					}
					$slot = -1;
					if (($slot == -1)) {
						$this->inventory->sendContents($this);
					} else {
						if (($this->isCreative() && $this->server->limitedCreative)) {
							$this->inventory->sendContents($this);
						} else {
							$dropItem = $this->inventory->getItem($slot);
							$worldDropItem = $this->normalizeItemForThisProtocol($dropItem);
							new \pocketmine\event\player\PlayerDropItemEvent($this, $dropItem);
							$ev = new \pocketmine\event\player\PlayerDropItemEvent($this, $dropItem);
							$this->server->getPluginManager()->callEvent($ev);
							if ($ev->isCancelled()) {
								$this->inventory->sendSlot($slot, $this);
							} else {
								$this->inventory->remove($dropItem);
								$motion = $this->getDirectionVector()->multiply(0.4);
								$this->level->dropItem($this->add(0, 1.3, 0), $worldDropItem, $motion, 40);
								$this->setDataFlag(self::DATA_FLAGS, self::DATA_FLAG_ACTION, false);
							}
						}
					}
				}
				break;
				case \pocketmine\network\protocol\Info::TEXT_PACKET:
				if ((($this->spawned === false) || !($this->isAlive()))) {
				} else {
					$this->craftingType = 0;
					if (($packet->type === \pocketmine\network\protocol\TextPacket::TYPE_CHAT)) {
						if ($this->server->antiToolbox) {
							$result = strpos($packet->message, $this->getNameTag());
							if (($result !== false)) {
								$this->kick($this);
							} else {
								$packet->message = \pocketmine\utils\TextFormat::clean($packet->message, $this->removeFormat);
								foreach (explode("\x0a", $packet->message) as $message) {
									$message = self::replaceContentKeywords($message);
									if ((((trim($message) != '') && (strlen($message) <= 255)) && (0 < $t2389))) {
										if ($this->containsSilentGuardKeyword($message)) {
											/* goto */
										}
										new \pocketmine\event\player\PlayerCommandPreprocessEvent($this, $message);
										$ev = new \pocketmine\event\player\PlayerCommandPreprocessEvent($this, $message);
										if ((320 < mb_strlen($ev->getMessage(), 'UTF-8'))) {
											$ev->setCancelled();
										}
										$this->server->getPluginManager()->callEvent($ev);
										if ($ev->isCancelled()) {
										} else {
											$processedMessage = self::replaceContentKeywords($ev->getMessage());
											if ((substr($processedMessage, 0, 1) === '/')) {
												\pocketmine\event\Timings::$playerCommandTimer->startTiming();
												$this->server->dispatchCommand($ev->getPlayer(), substr($processedMessage, 1));
												\pocketmine\event\Timings::$playerCommandTimer->stopTiming();
											} else {
												new \pocketmine\event\player\PlayerChatEvent($this, $processedMessage);
												$ev = new \pocketmine\event\player\PlayerChatEvent($this, $processedMessage);
												$this->server->getPluginManager()->callEvent($ev);
												if (!($ev->isCancelled())) {
													$mes = self::replaceContentKeywords($ev->getMessage());
													if (true) {
														$replaceCount = 1;
														$mes = str_ireplace('/wx', "\xc2\xa7a~/(^v^)\\~\xc2\xa7f", $mes, $replaceCount);
														$mes = str_ireplace('/sq', "\xc2\xa74\xe2\x94\x97|\xef\xbd\x80O\xe2\x80\xb2|\xe2\x94\x9b\xc2\xa7f", $mes, $replaceCount);
														$mes = str_ireplace('/jy', "\xc2\xa7e\xef\xbc\x88\xe2\x8a\x99\xef\xbd\x8f\xe2\x8a\x99\xef\xbc\x89\xc2\xa7f", $mes, $replaceCount);
														$mes = str_ireplace('/dy', "\xc2\xa7c(\xe2\x93\xbf_\xef\xbf\xbd\xef\xbf\xbd?\xc2\xa7f", $mes, $replaceCount);
														$mes = str_ireplace('/sx', "\xc2\xa7c(\xe2\x94\xac\xe2\x94\xac__\xe2\x94\xac\xe2\x94\xac)\xc2\xa7f", $mes, $replaceCount);
														$mes = str_ireplace('/wh', "\xc2\xa7a\\(\xef\xbf\xa3\xef\xb8\xb6\xef\xbf\xbd\xef\xbf\xbd?\\))\xc2\xa7f", $mes, $replaceCount);
														$mes = str_ireplace('/wy', $this, $mes, $replaceCount);
													}
													$this->server->broadcastMessage($this->getServer()->getLanguage()->translateString($ev->getFormat(), [$ev->getPlayer()->getDisplayName(), $mes]), $ev->getRecipients());
												}
											}
											/* goto */
										}
									}
								}
							}
						}
					}
				}
				break;
				case \pocketmine\network\protocol\Info::CONTAINER_CLOSE_PACKET:
				if ((($this->spawned === false) || ($packet->windowid === 0))) {
				} else {
					$this->craftingType = 0;
					$this->currentTransaction = null;
					if (isset($this->windowIndex[$packet->windowid])) {
						if ($this->windowIndex[$packet->windowid] instanceof \pocketmine\inventory\EnchantInventory) {
							$this->updateExperience();
						}
						new \pocketmine\event\inventory\InventoryCloseEvent($this->windowIndex[$packet->windowid], $this);
						$this->server->getPluginManager()->callEvent(new \pocketmine\event\inventory\InventoryCloseEvent($this->windowIndex[$packet->windowid], $this));
						$this->removeWindow($this->windowIndex[$packet->windowid]);
					} else {
					}
				}
				break;
				case \pocketmine\network\protocol\Info::CRAFTING_EVENT_PACKET:
				if ((($this->spawned === false) || !($this->isAlive()))) {
				} else {
					$recipe = $this->server->getCraftingManager()->getRecipe($packet->id);
					if (\pocketmine\network\protocol\ProtocolCompatibility::requiresLegacyRedstoneMapping(($this->protocol))) {
						foreach ($packet->output as $output) {
							if ($output instanceof \pocketmine\item\Item) {
								$outputMeta = $output->getDamage();
								if (($outputMeta === null)) {
								} else {
								}
								if (\pocketmine\network\protocol\ProtocolCompatibility::isHiddenItemForProtocol(($this->protocol), $output->getId(), ($outputMeta))) {
									$this->inventory->sendContents($this);
								} else {
									/* goto */
									foreach ($packet->input as $input) {
										if ($input instanceof \pocketmine\item\Item) {
											$inputMeta = $input->getDamage();
											if (($inputMeta === null)) {
											} else {
											}
											if (\pocketmine\network\protocol\ProtocolCompatibility::isHiddenItemForProtocol(($this->protocol), $input->getId(), ($inputMeta))) {
												$this->inventory->sendContents($this);
											} else {
												/* goto */
												if ((($recipe !== null) && !($this->isProtocol013RecipeSafe($recipe)))) {
													$this->inventory->sendContents($this);
												} else {
													if ($this->usingAnvil) {
														$anvilInventory = null;
														if (($anvilInventory === null)) {
															foreach ($this->windowIndex as $window) {
																if ($window instanceof \pocketmine\inventory\AnvilInventory) {
																	$anvilInventory = $window;
																} else {
																	/* goto */
																}
															}
															if (($anvilInventory === null)) {
																$this->getServer()->getLogger()->debug((($this . $this->getName()) . $this));
																$this->inventory->sendContents($this);
															} else {
																if (($anvilInventory->hasPendingOperation() && !($anvilInventory->finishRename($this, $packet->type)))) {
																	$this->getServer()->getLogger()->debug(($this->getName() . $this));
																	$this->inventory->sendContents($this);
																	$this->inventory->sendArmorContents($this);
																	$anvilInventory->sendContents($this);
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
				break;
				/* jump */
				if ((($recipe instanceof \pocketmine\inventory\BigShapelessRecipe || $recipe instanceof \pocketmine\inventory\BigShapedRecipe) && ($this->craftingType === 0))) {
					$this->server->getLogger()->debug((($this . $this->getName()) . $this));
					$this->inventory->sendContents($this);
				}
				break;
				/* jump */
				if (($recipe === null)) {
					$this->server->getLogger()->debug(((($this . $this->getName()) . $this) . $packet->output[0]));
					$this->inventory->sendContents($this);
				} else {
					if ((($recipe === null) || (($recipe instanceof \pocketmine\inventory\BigShapelessRecipe || $recipe instanceof \pocketmine\inventory\BigShapedRecipe) && ($this->craftingType === 0)))) {
						$this->inventory->sendContents($this);
					} else {
						foreach ($packet->input as $i => $item) {
							if ((($item->getDamage() === -1) || ($item->getDamage() === 65535))) {
								$item->setDamage(null);
							}
							if ((($i < 9) && (0 < $item->getId()))) {
								$item->setCount(1);
							}
							/* goto */
						}
						$canCraft = true;
						if (\pocketmine\network\protocol\ProtocolCompatibility::requiresLegacyRedstoneMapping(($this->protocol))) {
							foreach ($packet->input as $i => $item) {
								if (($item instanceof \pocketmine\item\Item && ($item->getId() !== \pocketmine\item\Item::AIR))) {
									$packet->input[$i] = $this->normalizeProtocol013RecipeInput($recipe, $i, $item);
								}
								/* goto */
							}
							if ((isset($packet->output[0]) && $packet->output[0] instanceof \pocketmine\item\Item)) {
								$packet->output[0] = $this->normalizeProtocol013ClientItem($recipe->getResult(), $packet->output[0]);
							}
						}
						if ($recipe instanceof \pocketmine\inventory\ShapedRecipe) {
							$x = 0;
							while ($canCraft) {
								$y = 0;
								while (($y < 3)) {
									$item = $packet->input[(($y * 3) + $x)];
									$ingredient = $recipe->getIngredient($x, $y);
									if (((0 < $item->getCount()) && (0 < $item->getId()))) {
										if (($ingredient == null)) {
											$canCraft = false;
										} else {
											if ((($ingredient->getId() != 0) && !($ingredient->deepEquals($item, ($ingredient->getDamage() !== null), ($ingredient->getCompoundTag() !== null))))) {
												$canCraft = false;
											} else {
												/* jump */
												if ((($ingredient !== null) && ($item->getId() !== 0))) {
													$canCraft = false;
												} else {
													$y++;
												}
											}
										}
										$x++;
										/* jump */
										if ($recipe instanceof \pocketmine\inventory\ShapelessRecipe) {
											$needed = $recipe->getIngredientList();
											$x = 0;
											while ($canCraft) {
												$y = 0;
												while (($y < 3)) {
													$item = clone $packet->input[(($y * 3) + $x)];
													foreach ($needed as $k => $n) {
														if ($n->deepEquals($item, ($n->getDamage() !== null), ($n->getCompoundTag() !== null))) {
															$remove = min($n->getCount(), $item->getCount());
															$n->setCount(($n->getCount() - $remove));
															$item->setCount(($item->getCount() - $remove));
															if (($n->getCount() === 0)) {
															}
														}
														/* goto */
													}
													if ((0 < $item->getCount())) {
														$canCraft = false;
													} else {
														$y++;
													}
												}
												$x++;
											}
											if ((0 < count($needed))) {
												$canCraft = false;
											}
										} else {
											$canCraft = false;
										}
										$canCraft = true;
										$ingredients = $packet->input;
										$result = $packet->output[0];
										if ((!($canCraft) || !($recipe->getResult()->deepEquals($result)))) {
											$this->server->getLogger()->debug(((((((((($this . $recipe->getId()) . $this) . $this->getName()) . $this) . $recipe->getResult()) . $this) . $result) . $this) . implode($this, $ingredients)));
											$this->inventory->sendContents($this);
										} else {
											$used = array_fill(0, $this->inventory->getSize(), 0);
											foreach ($ingredients as $ingredient) {
												$slot = -1;
												foreach ($this->inventory->getContents() as $index => $i) {
													if (((($ingredient->getId() !== 0) && $ingredient->deepEquals($i, ($ingredient->getDamage() !== null))) && (1 <= ($i->getCount() - $used[$index])))) {
														$slot = $index;
														$used[$index]++;
													} else {
														/* goto */
													}
												}
												if ((($ingredient->getId() !== 0) && ($slot === -1))) {
													$canCraft = false;
												} else {
													/* goto */
												}
											}
											if (!($canCraft)) {
												$this->server->getLogger()->debug(((((($this . $recipe->getId()) . $this) . $this->getName()) . $this) . implode($this, $ingredients)));
												$this->inventory->sendContents($this);
											} else {
												new \pocketmine\event\inventory\CraftItemEvent($this, $ingredients, $recipe);
												$ev = new \pocketmine\event\inventory\CraftItemEvent($this, $ingredients, $recipe);
												$this->server->getPluginManager()->callEvent($ev);
												if ($ev->isCancelled()) {
													$this->inventory->sendContents($this);
												} else {
													foreach ($used as $slot => $count) {
														if (($count === 0)) {
															/* goto */
														}
														$item = $this->inventory->getItem($slot);
														if (($count < $item->getCount())) {
															$newItem = clone $item;
															$newItem->setCount(($item->getCount() - $count));
														} else {
															$newItem = \pocketmine\item\Item::get(\pocketmine\item\Item::AIR, 0, 0);
														}
														$this->inventory->setItem($slot, $newItem);
														/* goto */
													}
													$extraItem = $this->inventory->addItem($recipe->getResult());
													if ((0 < count($extraItem))) {
														foreach ($extraItem as $item) {
															$this->level->dropItem($this, $item);
															/* goto */
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
				switch ($recipe->getResult()->getId()) {
					case \pocketmine\item\Item::WORKBENCH:
					$this->awardAchievement('buildWorkBench');
					break;
					case \pocketmine\item\Item::WOODEN_PICKAXE:
					$this->awardAchievement('buildPickaxe');
					break;
					case \pocketmine\item\Item::FURNACE:
					$this->awardAchievement('buildFurnace');
					break;
					case \pocketmine\item\Item::WOODEN_HOE:
					$this->awardAchievement('buildHoe');
					break;
					case \pocketmine\item\Item::BREAD:
					$this->awardAchievement('makeBread');
					break;
					case \pocketmine\item\Item::CAKE:
					$this->awardAchievement('bakeCake');
					$this->inventory->addItem(\pocketmine\item\Item::get(\pocketmine\item\Item::BUCKET, 0, 3));
					break;
					case \pocketmine\item\Item::STONE_PICKAXE:
					case \pocketmine\item\Item::GOLD_PICKAXE:
					case \pocketmine\item\Item::IRON_PICKAXE:
					case \pocketmine\item\Item::DIAMOND_PICKAXE:
					$this->awardAchievement('buildBetterPickaxe');
					break;
					case \pocketmine\item\Item::WOODEN_SWORD:
					$this->awardAchievement('buildSword');
					break;
					case \pocketmine\item\Item::DIAMOND:
					$this->awardAchievement('diamond');
					break;
				}
			}
			/* jump */
			switch ($packet::NETWORK_ID) {
				case \pocketmine\network\protocol\Info::CONTAINER_SET_SLOT_PACKET:
				if (((($this->spawned === false) || ($this->blocked === true)) || !($this->isAlive()))) {
				} else {
					if (($packet->slot < 0)) {
					} else {
						if (($packet->windowid === 0)) {
							if (($this->inventory->getSize() <= $packet->slot)) {
							} else {
								if ($this->isCreative()) {
									$creativeItem = $packet->item;
									if ($creativeItem instanceof \pocketmine\item\Item) {
									} else {
									}
									$normalizedCreativeItem = $creativeItem;
									if (((\pocketmine\item\Item::getCreativeItemIndex($creativeItem) !== -1) || ($normalizedCreativeItem instanceof \pocketmine\item\Item && (\pocketmine\item\Item::getCreativeItemIndex($normalizedCreativeItem) !== -1)))) {
										if ($normalizedCreativeItem instanceof \pocketmine\item\Item) {
										} else {
										}
										$this->inventory->setItem($packet->slot, $creativeItem);
										$this->inventory->setHotbarSlotIndex($packet->slot, $packet->slot);
									}
								}
								$sourceItem = $this->inventory->getItem($packet->slot);
								if ((($packet->item instanceof \pocketmine\item\Item && \pocketmine\network\protocol\ProtocolCompatibility::requiresLegacyRedstoneMapping(($this->protocol))) && $this->isProtocol013BlockedHiddenContainerPlaceholder($sourceItem, $packet->item))) {
									$this->rejectProtocol013HiddenContainerChange($this->inventory, ($packet->slot));
								} else {
									if ($packet->item instanceof \pocketmine\item\Item) {
									} else {
									}
									new \pocketmine\inventory\BaseTransaction($this->inventory, $packet->slot, $sourceItem, $packet->item);
									$transaction = new \pocketmine\inventory\BaseTransaction($this->inventory, $packet->slot, $sourceItem, $packet->item);
									/* jump */
									if (($packet->windowid === \pocketmine\network\protocol\ContainerSetContentPacket::SPECIAL_ARMOR)) {
										if ((4 <= $packet->slot)) {
										} else {
											$sourceItem = $this->inventory->getArmorItem($packet->slot);
											if ($packet->item instanceof \pocketmine\item\Item) {
											} else {
											}
											new \pocketmine\inventory\BaseTransaction($this->inventory, ($packet->slot + $this->inventory->getSize()), $sourceItem, $packet->item);
											$transaction = new \pocketmine\inventory\BaseTransaction($this->inventory, ($packet->slot + $this->inventory->getSize()), $sourceItem, $packet->item);
											/* jump */
											if (isset($this->windowIndex[$packet->windowid])) {
												$this->craftingType = 0;
												$inv = $this->windowIndex[$packet->windowid];
												if ($inv instanceof \pocketmine\inventory\VillagerTradeInventory) {
													$result = $inv->handlePlayerClick($this, $packet->slot);
													if ((($result !== \pocketmine\inventory\VillagerTradeInventory::CLICK_TRADED) && ($result !== \pocketmine\inventory\VillagerTradeInventory::CLICK_FAILED))) {
														$inv->sendContents($this);
														$this->inventory->sendContents($this);
													}
												} else {
													if (($inv instanceof \pocketmine\inventory\EnchantInventory && $packet->item->hasEnchantments())) {
														$inv->onEnchant($this, $inv->getItem($packet->slot), $packet->item);
													}
													if ($this->usingAnvil) {
														$anvilInventory = null;
														if (($anvilInventory === null)) {
															foreach ($this->windowIndex as $window) {
																if ($window instanceof \pocketmine\inventory\AnvilInventory) {
																	$anvilInventory = $window;
																} else {
																	/* goto */
																}
															}
															if (($anvilInventory === null)) {
																$this->getServer()->getLogger()->debug((($this . $this->getName()) . $this));
																$this->inventory->sendContents($this);
															} else {
																if (((($anvilInventory->getResultSlotIndex() === $packet->slot) && ($packet->item->getId() === \pocketmine\item\Item::AIR)) && $anvilInventory->hasPendingOperation())) {
																	if (!($anvilInventory->finishRename($this, 0))) {
																		$this->inventory->sendContents($this);
																		$this->inventory->sendArmorContents($this);
																		$anvilInventory->sendContents($this);
																	}
																} else {
																	$result = $anvilInventory->onRename($this, $packet->slot, $anvilInventory->getItem($packet->slot), $packet->item);
																	if (((($anvilInventory->getResultSlotIndex() === $packet->slot) && $anvilInventory->isResultTakePending()) && ($result === true))) {
																		if (!($anvilInventory->finishRename($this, 0))) {
																			$this->inventory->sendContents($this);
																			$this->inventory->sendArmorContents($this);
																			$anvilInventory->sendContents($this);
																		}
																	} else {
																		if (($result === 2)) {
																		} else {
																			$sourceItem = $inv->getItem($packet->slot);
																			if ((($packet->item instanceof \pocketmine\item\Item && \pocketmine\network\protocol\ProtocolCompatibility::requiresLegacyRedstoneMapping(($this->protocol))) && $this->isProtocol013NormalContainerWindow($packet->windowid))) {
																				if (($this->isProtocol013HiddenItem($sourceItem) || $this->isProtocol013BlockedHiddenContainerPlaceholder($sourceItem, $packet->item))) {
																					$this->rejectProtocol013HiddenContainerChange($inv, ($packet->slot));
																				} else {
																					$targetItem = $packet->item;
																					if ($targetItem instanceof \pocketmine\item\Item) {
																						$targetItem = $this->normalizeProtocol013ClientItem($sourceItem, $targetItem);
																					}
																					new \pocketmine\inventory\BaseTransaction($inv, $packet->slot, $sourceItem, $targetItem);
																					$transaction = new \pocketmine\inventory\BaseTransaction($inv, $packet->slot, $sourceItem, $targetItem);
																					/* jump */
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
				break;
				if (($transaction->getSourceItem()->deepEquals($transaction->getTargetItem()) && ($transaction->getTargetItem()->getCount() === $transaction->getSourceItem()->getCount()))) {
				} else {
					if ((($this->currentTransaction === null) || ($this->currentTransaction->getCreationTime() < (microtime(true) - 8)))) {
						if (($this->currentTransaction !== null)) {
							foreach ($this->currentTransaction->getInventories() as $inventory) {
								if ($inventory instanceof \pocketmine\inventory\PlayerInventory) {
									$inventory->sendArmorContents($this);
								}
								$inventory->sendContents($this);
								/* goto */
							}
						}
						new \pocketmine\inventory\SimpleTransactionGroup($this);
						$this->currentTransaction = new \pocketmine\inventory\SimpleTransactionGroup($this);
					}
					$this->currentTransaction->addTransaction($transaction);
					if ($this->currentTransaction->canExecute()) {
						$achievements = ['__array_ptr' => '2aaaac9fc9a0'];
						foreach ($this->currentTransaction->getTransactions() as $ts) {
							$inv = $ts->getInventory();
							if ($inv instanceof \pocketmine\inventory\FurnaceInventory) {
								if (($ts->getSlot() === 2)) {
								}
							}
						}
					}
				}
				switch ($inv->getResult()->getId()) {
					case \pocketmine\item\Item::IRON_INGOT:
					$achievements[] = 'acquireIron';
				}
				/* goto */
				if ($this->currentTransaction->execute()) {
					if (\pocketmine\network\protocol\ProtocolCompatibility::requiresLegacyRedstoneMapping(($this->protocol))) {
						$this->replaceLegacyPotionArrowsInInventory();
					}
					foreach ($achievements as $a) {
						$this->awardAchievement($a);
						/* goto */
					}
				}
				$this->currentTransaction = null;
				break;
				case \pocketmine\network\protocol\Info::BLOCK_ENTITY_DATA_PACKET:
				if (((($this->spawned === false) || ($this->blocked === true)) || !($this->isAlive()))) {
				} else {
					$this->craftingType = 0;
					new \pocketmine\math\Vector3($packet->x, $packet->y, $packet->z);
					$pos = new \pocketmine\math\Vector3($packet->x, $packet->y, $packet->z);
					if ((10000 < $pos->distanceSquared($this))) {
					} else {
						$t = $this->level->getTile($pos);
						if ($t instanceof \pocketmine\tile\Sign) {
							new \pocketmine\nbt\NBT(\pocketmine\nbt\NBT::LITTLE_ENDIAN);
							$nbt = new \pocketmine\nbt\NBT(\pocketmine\nbt\NBT::LITTLE_ENDIAN);
							$nbt->read($packet->namedtag);
							$nbt = $nbt->getData();
							if (($nbt['id'] !== \pocketmine\tile\Tile::SIGN)) {
								$t->spawnTo($this);
							} else {
								$signLines = [self::replaceContentKeywords(\pocketmine\utils\TextFormat::clean($nbt['Text1'], $this->removeFormat)), self::replaceContentKeywords(\pocketmine\utils\TextFormat::clean($nbt['Text2'], $this->removeFormat)), self::replaceContentKeywords(\pocketmine\utils\TextFormat::clean($nbt['Text3'], $this->removeFormat)), self::replaceContentKeywords(\pocketmine\utils\TextFormat::clean($nbt['Text4'], $this->removeFormat))];
								$guardedSignLines = $this->guardSignTextLines($signLines);
								if (($guardedSignLines !== $signLines)) {
									$t->setText($guardedSignLines[0], $guardedSignLines[1], $guardedSignLines[2], $guardedSignLines[3]);
								} else {
									new \pocketmine\event\block\SignChangeEvent($t->getBlock(), $this, $signLines);
									$ev = new \pocketmine\event\block\SignChangeEvent($t->getBlock(), $this, $signLines);
									if ((!(isset($t->namedtag->Creator)) || ($this->getRawUniqueId() !== $t->namedtag['Creator']))) {
										$ev->setCancelled();
									} else {
										foreach ($ev->getLines() as $line) {
											if ((16 < mb_strlen($line, 'UTF-8'))) {
												$ev->setCancelled();
											}
											/* goto */
										}
									}
									$this->server->getPluginManager()->callEvent($ev);
									if (!($ev->isCancelled())) {
										$t->setText(self::replaceContentKeywords($ev->getLine(0)), self::replaceContentKeywords($ev->getLine(1)), self::replaceContentKeywords($ev->getLine(2)), self::replaceContentKeywords($ev->getLine(3)));
									} else {
										$t->spawnTo($this);
									}
								}
							}
						}
					}
				}
				break;
				break;
			}
			$timings->stopTiming();
		}

	public function kick($reason = null, $isAdmin = null) {
			/* decompiled (structured CF) */
			new \pocketmine\event\player\PlayerKickEvent($this, $reason, $this->getLeaveMessage());
			$ev = new \pocketmine\event\player\PlayerKickEvent($this, $reason, $this->getLeaveMessage());
			$this->server->getPluginManager()->callEvent($ev);
			if (!($ev->isCancelled())) {
				if ($isAdmin) {
					if (($reason !== '')) {
					} else {
					}
					$message = ("\xe8\xa2\xab\xe8\xb8\xa2\xe5\x87\xba\xe6\x9c\x8d\xe5\x8a\xa1\xe5\x99\xa8" . '');
				} else {
					if (($reason === '')) {
						$message = 'disconnectionScreen.noReason';
					} else {
						$message = $reason;
					}
				}
				$this->close($ev->getQuitMessage(), $message);
				return true;
			}
			return false;
		}

	public function sendMessage($message = null) {
			/* decompiled (structured CF) */
			if ($message instanceof \pocketmine\event\TextContainer) {
				if ($message instanceof \pocketmine\event\TranslationContainer) {
					$this->sendTranslation($message->getText(), $message->getParameters());
					return false;
				}
				$message = $message->getText();
			}
			$mes = explode("\x0a", $this->server->getLanguage()->translateString($message));
			foreach ($mes as $m) {
				if (($m !== '')) {
					new \pocketmine\event\player\PlayerTextPreSendEvent($this, $m, \pocketmine\event\player\PlayerTextPreSendEvent::MESSAGE);
					$ev = new \pocketmine\event\player\PlayerTextPreSendEvent($this, $m, \pocketmine\event\player\PlayerTextPreSendEvent::MESSAGE);
					$this->server->getPluginManager()->callEvent($ev);
					if (!($ev->isCancelled())) {
						new \pocketmine\network\protocol\TextPacket();
						$pk = new \pocketmine\network\protocol\TextPacket();
						$pk->type = \pocketmine\network\protocol\TextPacket::TYPE_RAW;
						$pk->message = $ev->getMessage();
						$this->dataPacket($pk);
					}
				}
				/* goto */
			}
			return true;
		}

	public function sendTranslation($message = null, $parameters = null) {
			/* decompiled (structured CF) */
			new \pocketmine\network\protocol\TextPacket();
			$pk = new \pocketmine\network\protocol\TextPacket();
			if (!($this->server->isLanguageForced())) {
				$pk->type = \pocketmine\network\protocol\TextPacket::TYPE_TRANSLATION;
				$pk->message = $this->server->getLanguage()->translateString($message, $parameters, 'pocketmine.');
				foreach ($parameters as $i => $p) {
					$parameters[$i] = $this->server->getLanguage()->translateString($p, $parameters, 'pocketmine.');
					/* goto */
				}
				$pk->parameters = $parameters;
			} else {
				$pk->type = \pocketmine\network\protocol\TextPacket::TYPE_RAW;
				$pk->message = $this->server->getLanguage()->translateString($message, $parameters);
			}
			new \pocketmine\event\player\PlayerTextPreSendEvent($this, $pk->message, \pocketmine\event\player\PlayerTextPreSendEvent::TRANSLATED_MESSAGE);
			$ev = new \pocketmine\event\player\PlayerTextPreSendEvent($this, $pk->message, \pocketmine\event\player\PlayerTextPreSendEvent::TRANSLATED_MESSAGE);
			$this->server->getPluginManager()->callEvent($ev);
			if (!($ev->isCancelled())) {
				$this->dataPacket($pk);
				return true;
			}
			return false;
		}

	public function sendPopup($message = null, $subtitle = null) {
			/* decompiled (structured CF) */
			new \pocketmine\event\player\PlayerTextPreSendEvent($this, $message, \pocketmine\event\player\PlayerTextPreSendEvent::POPUP);
			$ev = new \pocketmine\event\player\PlayerTextPreSendEvent($this, $message, \pocketmine\event\player\PlayerTextPreSendEvent::POPUP);
			$this->server->getPluginManager()->callEvent($ev);
			if (!($ev->isCancelled())) {
				new \pocketmine\network\protocol\TextPacket();
				$pk = new \pocketmine\network\protocol\TextPacket();
				$pk->type = \pocketmine\network\protocol\TextPacket::TYPE_POPUP;
				$pk->source = $message;
				$pk->message = $subtitle;
				$this->dataPacket($pk);
				return true;
			}
			return false;
		}

	public function sendTip($message = null) {
			/* decompiled (structured CF) */
			if ((\pocketmine\network\protocol\Info::V014_CURRENT_PROTOCOL <= $this->protocol)) {
				return $this->sendPopup($message);
			}
			new \pocketmine\event\player\PlayerTextPreSendEvent($this, $message, \pocketmine\event\player\PlayerTextPreSendEvent::TIP);
			$ev = new \pocketmine\event\player\PlayerTextPreSendEvent($this, $message, \pocketmine\event\player\PlayerTextPreSendEvent::TIP);
			$this->server->getPluginManager()->callEvent($ev);
			if (!($ev->isCancelled())) {
				new \pocketmine\network\protocol\TextPacket();
				$pk = new \pocketmine\network\protocol\TextPacket();
				$pk->type = \pocketmine\network\protocol\TextPacket::TYPE_TIP;
				$pk->message = $message;
				$this->dataPacket($pk);
				return true;
			}
			return false;
		}

	public final function setTransferred($transferredTo = null) {
			/* decompiled (structured CF) */
			if (($this->connected && !($this->closed))) {
				foreach ($this->usedChunks as $index => $d) {
					\pocketmine\level\Level::getXZ($index, $chunkX, $chunkZ);
					$this->level->unregisterChunkLoader($this, $chunkX, $chunkZ);
					/* goto */
				}
				$this->despawnFromAll();
				if ($this->loggedIn) {
					$this->server->removeOnlinePlayer($this);
				}
				$this->loggedIn = false;
				$this->server->getPluginManager()->unsubscribeFromPermission(\pocketmine\Server::BROADCAST_CHANNEL_USERS, $this);
				$this->spawned = false;
				$this->server->getLogger()->info($this->getServer()->getLanguage()->translateString('pocketmine.player.transferred', [((\pocketmine\utils\TextFormat::AQUA . $this->getName()) . \pocketmine\utils\TextFormat::WHITE), $this->ip, $this->port, $transferredTo]));
				$this->hasTransferred = true;
				$this->resetProtocol015WorldReadyState();
			}
			return null;
		}

	public function getPing() {
			return $this->ping;
		}

	public function setPing($ping = null) {
			$this->ping = $ping;
		}

	public final function close($message = null, $reason = null, $notify = null) {
			/* decompiled (structured CF) */
			if (($this->connected && !($this->closed))) {
				if (($notify && (0 < strlen(($reason))))) {
					new \pocketmine\network\protocol\DisconnectPacket();
					$pk = new \pocketmine\network\protocol\DisconnectPacket();
					$pk->message = $reason;
					$this->directDataPacket($pk);
				}
				if ($this->fishingHook instanceof \pocketmine\entity\FishingHook) {
					$this->fishingHook->close();
					$this->fishingHook = null;
				}
				$this->removeEffect(\pocketmine\entity\Effect::HEALTH_BOOST);
				$this->connected = false;
				if ((0 < strlen($this->getName()))) {
					new \pocketmine\event\player\PlayerQuitEvent($this, $message, true);
					$ev = new \pocketmine\event\player\PlayerQuitEvent($this, $message, true);
					$this->server->getPluginManager()->callEvent($ev);
					if ((($this->loggedIn === true) && $ev->getAutoSave())) {
						$this->save();
					}
				}
				foreach ($this->server->getOnlinePlayers() as $player) {
					if (!($player->canSee($this))) {
						$player->showPlayer($this);
					}
					/* goto */
				}
				$this->hiddenPlayers = ['__array_ptr' => '2aaaac9fc9a0'];
				foreach ($this->windowIndex as $window) {
					$this->removeWindow($window);
					/* goto */
				}
				foreach ($this->usedChunks as $index => $d) {
					\pocketmine\level\Level::getXZ($index, $chunkX, $chunkZ);
					$this->level->unregisterChunkLoader($this, $chunkX, $chunkZ);
					/* goto */
				}
				parent::close();
				if ($notify) {
				} else {
				}
				$this->interface->close($this, '');
				if ($this->loggedIn) {
					$this->server->removeOnlinePlayer($this);
				}
				$this->loggedIn = false;
				if (((($t76 && ($this->username != '')) && ($this->spawned !== false)) && ($ev->getQuitMessage() != ''))) {
					if (($this->server->playerMsgType === \pocketmine\Server::PLAYER_MSG_TYPE_MESSAGE)) {
						$this->server->broadcastMessage($ev->getQuitMessage());
					} else {
						if (($this->server->playerMsgType === \pocketmine\Server::PLAYER_MSG_TYPE_TIP)) {
							$this->server->broadcastTip(str_replace('@player', $this->getName(), $this->server->playerLogoutMsg));
						} else {
							if (($this->server->playerMsgType === \pocketmine\Server::PLAYER_MSG_TYPE_POPUP)) {
								$this->server->broadcastPopup(str_replace('@player', $this->getName(), $this->server->playerLogoutMsg));
							}
						}
					}
				}
				$this->server->getPluginManager()->unsubscribeFromPermission(\pocketmine\Server::BROADCAST_CHANNEL_USERS, $this);
				$this->spawned = false;
				$this->server->getLogger()->info($this->getServer()->getLanguage()->translateString('pocketmine.player.logOut', [((\pocketmine\utils\TextFormat::AQUA . $this->getName()) . \pocketmine\utils\TextFormat::WHITE), $this->ip, $this->port, $this->getServer()->getLanguage()->translateString($reason)]));
				new \SplObjectStorage();
				$this->windows = new \SplObjectStorage();
				$this->windowIndex = ['__array_ptr' => '2aaaac9fc9a0'];
				$this->usedChunks = ['__array_ptr' => '2aaaac9fc9a0'];
				$this->loadQueue = ['__array_ptr' => '2aaaac9fc9a0'];
				$this->hasSpawned = ['__array_ptr' => '2aaaac9fc9a0'];
				$this->spawnPosition = null;
				$this->resetProtocol015WorldReadyState();
				if (($this->server->dserverConfig['enable'] && $this->server->dserverConfig['queryAutoUpdate'])) {
					$this->server->updateQuery();
				}
			}
			if (($this->perm !== null)) {
				$this->perm->clearPermissions();
				$this->perm = null;
			}
			if (($this->inventory !== null)) {
				$this->inventory = null;
				$this->currentTransaction = null;
			}
			$this->chunk = null;
			$this->server->removePlayer($this);
			return null;
		}

	public function __debugInfo() {
			return ['__array_ptr' => '2aaaac9fc9a0'];
		}

	public function save($async = null) {
			/* decompiled (structured CF) */
			if ($this->closed) {
				new \InvalidStateException("\xe5\xb0\x9d\xe8\xaf\x95\xe4\xbf\x9d\xe5\xad\x98\xe5\xb7\xb2\xe5\x85\xb3\xe9\x97\xad\xe7\x9a\x84\xe7\x8e\xa9\xe5\xae\xb6");
				throw new \InvalidStateException("\xe5\xb0\x9d\xe8\xaf\x95\xe4\xbf\x9d\xe5\xad\x98\xe5\xb7\xb2\xe5\x85\xb3\xe9\x97\xad\xe7\x9a\x84\xe7\x8e\xa9\xe5\xae\xb6");
			}
			parent::saveNBT();
			if ($this->level instanceof \pocketmine\level\Level) {
				new \pocketmine\nbt\tag\StringTag('Level', $this->level->getName());
				$this->namedtag->Level = new \pocketmine\nbt\tag\StringTag('Level', $this->level->getName());
				if ((($this->spawnPosition instanceof \pocketmine\level\Position && $this->spawnPosition->getLevel() instanceof \pocketmine\level\Level) && ($this->spawnPosition->getLevel()->getProvider() !== null))) {
					$this->namedtag['SpawnLevel'] = $this->spawnPosition->getLevel()->getName();
					$this->namedtag['SpawnX'] = ($this->spawnPosition->x);
					$this->namedtag['SpawnY'] = ($this->spawnPosition->y);
					$this->namedtag['SpawnZ'] = ($this->spawnPosition->z);
				}
				foreach ($this->achievements as $achievement => $status) {
					if (($status === true)) {
					} else {
					}
					new \pocketmine\nbt\tag\ByteTag($achievement, 0);
					$this->namedtag->Achievements[$achievement] = new \pocketmine\nbt\tag\ByteTag($achievement, 0);
					/* goto */
				}
				$this->namedtag['playerGameType'] = $this->gamemode;
				new \pocketmine\nbt\tag\LongTag('lastPlayed', floor((microtime(true) * 1000)));
				$this->namedtag['lastPlayed'] = new \pocketmine\nbt\tag\LongTag('lastPlayed', floor((microtime(true) * 1000)));
				new \pocketmine\nbt\tag\ShortTag('Hunger', $this->food);
				$this->namedtag['Hunger'] = new \pocketmine\nbt\tag\ShortTag('Hunger', $this->food);
				new \pocketmine\nbt\tag\ShortTag('Health', $this->getHealth());
				$this->namedtag['Health'] = new \pocketmine\nbt\tag\ShortTag('Health', $this->getHealth());
				new \pocketmine\nbt\tag\ShortTag('MaxHealth', $this->getMaxHealth());
				$this->namedtag['MaxHealth'] = new \pocketmine\nbt\tag\ShortTag('MaxHealth', $this->getMaxHealth());
				new \pocketmine\nbt\tag\LongTag('Experience', $this->exp);
				$this->namedtag['Experience'] = new \pocketmine\nbt\tag\LongTag('Experience', $this->exp);
				new \pocketmine\nbt\tag\LongTag('ExpLevel', $this->expLevel);
				$this->namedtag['ExpLevel'] = new \pocketmine\nbt\tag\LongTag('ExpLevel', $this->expLevel);
				if ((($this->username != '') && $this->namedtag instanceof \pocketmine\nbt\tag\CompoundTag)) {
					$this->server->saveOfflinePlayerData($this->username, $this->namedtag, $async);
				}
			}
			return null;
		}

	public function getName() {
			return $this->username;
		}

	public function kill() {
			/* decompiled (structured CF) */
			if (!($this->spawned)) {
				return null;
			}
			$message = 'death.attack.generic';
			$params = [$this->getDisplayName()];
			$cause = $this->getLastDamageCause();
			if (($cause === null)) {
			} else {
			}
			switch ($cause->getCause()) {
				case \pocketmine\event\entity\EntityDamageEvent::CAUSE_ENTITY_ATTACK:
				if ($cause instanceof \pocketmine\event\entity\EntityDamageByEntityEvent) {
					$e = $cause->getDamager();
					if ($e instanceof \pocketmine\Player) {
						$message = 'death.attack.player';
						$params[] = $e->getDisplayName();
					}
				}
				break;
				/* jump */
				if ($e instanceof \pocketmine\entity\Living) {
					$message = 'death.attack.mob';
					if (($e->getNameTag() !== '')) {
					} else {
					}
					$params[] = $e->getName();
				}
				break;
				/* jump */
				$params[] = 'Unknown';
				break;
				case \pocketmine\event\entity\EntityDamageEvent::CAUSE_PROJECTILE:
				if ($cause instanceof \pocketmine\event\entity\EntityDamageByEntityEvent) {
					$e = $cause->getDamager();
					if ($e instanceof \pocketmine\Player) {
						$message = 'death.attack.arrow';
						$params[] = $e->getDisplayName();
					} else {
						if ($e instanceof \pocketmine\entity\Living) {
							$message = 'death.attack.arrow';
							if (($e->getNameTag() !== '')) {
							} else {
							}
							$params[] = $e->getName();
						}
					}
				}
				break;
				/* jump */
				$params[] = 'Unknown';
				break;
				case \pocketmine\event\entity\EntityDamageEvent::CAUSE_SUICIDE:
				$message = 'death.attack.generic';
				break;
				case \pocketmine\event\entity\EntityDamageEvent::CAUSE_VOID:
				$message = 'death.attack.outOfWorld';
				break;
				case \pocketmine\event\entity\EntityDamageEvent::CAUSE_FALL:
				if ($cause instanceof \pocketmine\event\entity\EntityDamageEvent) {
					if ((2 < $cause->getFinalDamage())) {
						$message = 'death.fell.accident.generic';
					} else {
						$message = 'death.attack.fall';
					}
				}
				break;
				case \pocketmine\event\entity\EntityDamageEvent::CAUSE_SUFFOCATION:
				$message = 'death.attack.inWall';
				break;
				case \pocketmine\event\entity\EntityDamageEvent::CAUSE_LAVA:
				$message = 'death.attack.lava';
				break;
				case \pocketmine\event\entity\EntityDamageEvent::CAUSE_FIRE:
				$message = 'death.attack.onFire';
				break;
				case \pocketmine\event\entity\EntityDamageEvent::CAUSE_FIRE_TICK:
				$message = 'death.attack.inFire';
				break;
				case \pocketmine\event\entity\EntityDamageEvent::CAUSE_DROWNING:
				$message = 'death.attack.drown';
				break;
				case \pocketmine\event\entity\EntityDamageEvent::CAUSE_CONTACT:
				if ($cause instanceof \pocketmine\event\entity\EntityDamageByBlockEvent) {
					if (($cause->getDamager()->getId() === \pocketmine\block\Block::CACTUS)) {
						$message = 'death.attack.cactus';
					}
				}
				break;
				case \pocketmine\event\entity\EntityDamageEvent::CAUSE_BLOCK_EXPLOSION:
				case \pocketmine\event\entity\EntityDamageEvent::CAUSE_ENTITY_EXPLOSION:
				if ($cause instanceof \pocketmine\event\entity\EntityDamageByEntityEvent) {
					$e = $cause->getDamager();
					if ($e instanceof \pocketmine\Player) {
						$message = 'death.attack.explosion.player';
						$params[] = $e->getDisplayName();
					} else {
						if ($e instanceof \pocketmine\entity\Living) {
							$message = 'death.attack.explosion.player';
							if (($e->getNameTag() !== '')) {
							} else {
							}
							$params[] = $e->getName();
						} else {
							/* jump */
							$message = 'death.attack.explosion';
						}
					}
				}
				break;
				case \pocketmine\event\entity\EntityDamageEvent::CAUSE_MAGIC:
				$message = 'death.attack.magic';
				break;
				case \pocketmine\event\entity\EntityDamageEvent::CAUSE_CUSTOM:
				break;
			}
			\pocketmine\entity\Entity::kill();
			new \pocketmine\event\TranslationContainer($message, $params);
			new \pocketmine\event\player\PlayerDeathEvent($this, $this->getDrops(), new \pocketmine\event\TranslationContainer($message, $params));
			$ev = new \pocketmine\event\player\PlayerDeathEvent($this, $this->getDrops(), new \pocketmine\event\TranslationContainer($message, $params));
			$this->server->getPluginManager()->callEvent($ev);
			if ((!($ev->getKeepInventory()) && !($this->server->isWorldKeepInventoryEnabled($this->getLevel())))) {
				foreach ($ev->getDrops() as $item) {
					$this->level->dropItem($this, $item);
					/* goto */
				}
				if (($this->inventory !== null)) {
					$this->inventory->clearAll();
				}
			}
			if (($this->server->expEnabled && (!($ev->getKeepExperience()) && !($this->server->isWorldKeepInventoryEnabled($this->getLevel()))))) {
				$exp = $this->getExp();
				if ((100 < $exp)) {
					$exp = 100;
				}
				$this->getLevel()->spawnXPOrb($this->add(0, 0.2, 0), $exp);
				$this->setExperienceAndLevel(0, 0);
			}
			if (($ev->getDeathMessage() != '')) {
				$this->server->broadcast($ev->getDeathMessage(), \pocketmine\Server::BROADCAST_CHANNEL_USERS);
			}
			$pos = $this->getSpawn();
			if ($this->server->netherEnabled) {
				if (($this->level == $this->server->netherLevel)) {
					$pos = $this->server->getDefaultLevel()->getSafeSpawn();
					$this->teleport($pos);
				}
			}
			$this->setHealth(0);
			new \pocketmine\network\protocol\RespawnPacket();
			$pk = new \pocketmine\network\protocol\RespawnPacket();
			$pk->x = $pos->x;
			$pk->y = $pos->y;
			$pk->z = $pos->z;
			$this->dataPacket($pk);
		}

	public function setHealth($amount = null) {
			/* decompiled (structured CF) */
			parent::setHealth($amount);
			if (($this->spawned === true)) {
				$this->foodTick = 0;
				$this->getAttributeMap()->getAttribute(\pocketmine\entity\Attribute::HEALTH)->setMaxValue($this->getMaxHealth())->setValue($amount, true);
			}
			return null;
		}

	public function setMovementSpeed($amount = null) {
			$this->movementSpeed = $amount;
			$this->syncDepthStriderMovementSpeed();
			return null;
		}

	public function getMovementSpeed() {
			return $this->movementSpeed;
		}

	private function syncDepthStriderMovementSpeed() {
			/* decompiled (structured CF) */
			$speed = $this->movementSpeed;
			if ($this->isInsideOfWater()) {
				$depthStrider = min(3, $this->inventory->getBoots()->getEnchantmentLevel(\pocketmine\item\enchantment\Enchantment::TYPE_WATER_SPEED));
				if ((0 < $depthStrider)) {
					$speed *= (1 + ($depthStrider * 0.35));
				}
			}
			$this->getAttributeMap()->getAttribute(\pocketmine\entity\Attribute::MOVEMENT_SPEED)->setValue($speed);
			return null;
		}

	public function setFoodEnabled($enabled = null) {
			$this->foodEnabled = $enabled;
		}

	public function getFoodEnabled() {
			return $this->foodEnabled;
		}

	public function setFood($amount = null) {
			/* decompiled (structured CF) */
			if (!($this->server->foodEnabled)) {
				$amount = 20;
			}
			if ((20 < $amount)) {
				$amount = 20;
			}
			if (($amount < 0)) {
				$amount = 0;
			}
			new \pocketmine\event\player\PlayerHungerChangeEvent($this, $amount);
			$ev = new \pocketmine\event\player\PlayerHungerChangeEvent($this, $amount);
			$this->server->getPluginManager()->callEvent($ev);
			if ($ev->isCancelled()) {
				return false;
			}
			$amount = $ev->getData();
			if ((($amount <= 6) && !(($this->getFood() <= 6)))) {
				$this->setDataProperty(self::DATA_FLAG_SPRINTING, self::DATA_TYPE_BYTE, false);
			} else {
				if (((6 < $amount) && !((6 < $this->getFood())))) {
					$this->setDataProperty(self::DATA_FLAG_SPRINTING, self::DATA_TYPE_BYTE, true);
				}
			}
			$this->food = $amount;
			$this->getAttributeMap()->getAttribute(\pocketmine\entity\Attribute::HUNGER)->setValue($amount);
			return true;
		}

	public function getFood() {
			return $this->food;
		}

	public function subtractFood($amount = null) {
			/* decompiled (structured CF) */
			if (((($this->getFood() - $amount) <= 6) && !(($this->getFood() <= 6)))) {
				$this->setDataProperty(self::DATA_FLAG_SPRINTING, self::DATA_TYPE_BYTE, false);
			} else {
				if (((($this->getFood() - $amount) < 6) && !((6 < $this->getFood())))) {
					$this->setDataProperty(self::DATA_FLAG_SPRINTING, self::DATA_TYPE_BYTE, true);
				}
			}
			if ((($this->food - $amount) < 0)) {
				return null;
			}
			$this->setFood(($this->getFood() - $amount));
		}

	public function attack($damage = null, $source = null) {
			/* decompiled (structured CF) */
			if (!($this->isAlive())) {
				return false;
			}
			if ((($this->isCreative() && ($source->getCause() !== \pocketmine\event\entity\EntityDamageEvent::CAUSE_SUICIDE)) && ($source->getCause() !== \pocketmine\event\entity\EntityDamageEvent::CAUSE_VOID))) {
				$source->setCancelled();
			} else {
				if (($this->allowFlight && ($source->getCause() === \pocketmine\event\entity\EntityDamageEvent::CAUSE_FALL))) {
					$source->setCancelled();
				}
			}
			parent::attack($damage, $source);
			if ($source->isCancelled()) {
				return false;
			} else {
				if ((($source === $this->getLastDamageCause()) && $this->spawned)) {
					new \pocketmine\network\protocol\EntityEventPacket();
					$pk = new \pocketmine\network\protocol\EntityEventPacket();
					$pk->eid = 0;
					$pk->event = \pocketmine\network\protocol\EntityEventPacket::HURT_ANIMATION;
					$this->dataPacket($pk);
				}
			}
			return true;
		}

	public function sendPosition($pos = null, $yaw = null, $pitch = null, $mode = null, $targets = null) {
			/* decompiled (structured CF) */
			if (($yaw === null)) {
			} else {
			}
			$yaw = $yaw;
			if (($pitch === null)) {
			} else {
			}
			$pitch = $pitch;
			new \pocketmine\network\protocol\MovePlayerPacket();
			$pk = new \pocketmine\network\protocol\MovePlayerPacket();
			$pk->eid = $this->getId();
			$pk->x = $pos->x;
			$pk->y = ($pos->y + $this->getEyeHeight());
			$pk->z = $pos->z;
			$pk->bodyYaw = $yaw;
			$pk->pitch = $pitch;
			$pk->yaw = $yaw;
			$pk->mode = $mode;
			if (($targets !== null)) {
				\pocketmine\Server::broadcastPacket($targets, $pk);
			} else {
				$pk->eid = 0;
				$this->dataPacket($pk);
			}
			return null;
		}

	protected function checkChunks() {
			/* decompiled (structured CF) */
			if ((($this->chunk === null) || (($this->chunk->getX() !== ($this->x >> 4)) || ($this->chunk->getZ() !== ($this->z >> 4))))) {
				if (($this->chunk !== null)) {
					$this->chunk->removeEntity($this);
				}
				$this->chunk = $this->level->getChunk(($this->x >> 4), ($this->z >> 4), true);
				if (!($this->justCreated)) {
					$newChunk = $this->level->getChunkPlayers(($this->x >> 4), ($this->z >> 4));
					$reload = ['__array_ptr' => '2aaaac9fc9a0'];
					foreach ($this->hasSpawned as $player) {
						if (!(isset($newChunk[$player->getLoaderId()]))) {
							$this->despawnFrom($player);
						} else {
							$reload[] = $player;
						}
						/* goto */
					}
					foreach ($newChunk as $player) {
						$this->spawnTo($player);
						/* goto */
					}
				}
				if (($this->chunk === null)) {
					return null;
				}
				$this->chunk->addEntity($this);
			}
		}

	protected function checkTeleportPosition() {
			/* decompiled (structured CF) */
			if (($this->teleportPosition !== null)) {
				$chunkX = ($this->teleportPosition->x >> 4);
				$chunkZ = ($this->teleportPosition->z >> 4);
				$X = -1;
				while (($X <= 1)) {
					$Z = -1;
					while (($Z <= 1)) {
						$index = \pocketmine\level\Level::chunkHash(($chunkX + $X), ($chunkZ + $Z));
						if ((!(isset($this->usedChunks[$index])) || ($this->usedChunks[$index] === false))) {
							return false;
						}
						$Z++;
					}
					$X++;
				}
				$this->sendPosition($this, null, null, 1);
				$this->spawnToAll();
				$this->forceMovement = $this->teleportPosition;
				$this->teleportPosition = null;
				return true;
			}
			return true;
		}

	public function teleport($pos = null, $yaw = null, $pitch = null) {
			/* decompiled (structured CF) */
			if (!($this->isOnline())) {
				return false;
			}
			$oldPos = $this->getPosition();
			if (parent::teleport($pos, $yaw, $pitch)) {
				foreach ($this->windowIndex as $window) {
					if (($window === $this->inventory)) {
						/* goto */
					}
					$this->removeWindow($window);
					/* goto */
				}
				new \pocketmine\math\Vector3($this->x, $this->y, $this->z);
				$this->teleportPosition = new \pocketmine\math\Vector3($this->x, $this->y, $this->z);
				if (!($this->checkTeleportPosition())) {
					$this->forceMovement = $oldPos;
				} else {
					$this->spawnToAll();
				}
				$this->resetFallDistance();
				$this->nextChunkOrderRun = 0;
				$this->newPosition = null;
				return true;
			}
			return false;
		}

	public function teleportImmediate($pos = null, $yaw = null, $pitch = null) {
			/* decompiled (structured CF) */
			if (parent::teleport($pos, $yaw, $pitch)) {
				foreach ($this->windowIndex as $window) {
					if (($window === $this->inventory)) {
						/* goto */
					}
					$this->removeWindow($window);
					/* goto */
				}
				new \pocketmine\math\Vector3($this->x, $this->y, $this->z);
				$this->forceMovement = new \pocketmine\math\Vector3($this->x, $this->y, $this->z);
				$this->sendPosition($this, $this->yaw, $this->pitch, 1);
				$this->resetFallDistance();
				$this->orderChunks();
				$this->nextChunkOrderRun = 0;
				$this->newPosition = null;
			}
			return null;
		}

	public function getWindowId($inventory = null) {
			/* decompiled (structured CF) */
			if ($this->windows->contains($inventory)) {
				return $this->windows[$inventory];
			}
			return -1;
		}

	public function addWindow($inventory = null, $forceId = null) {
			/* decompiled (structured CF) */
			if ($this->windows->contains($inventory)) {
				return $this->windows[$inventory];
			}
			if (($forceId === null)) {
				$cnt = max(2, ($t9 % 99));
				$this->windowCnt = $cnt;
			} else {
				$cnt = ($forceId);
			}
			$this->windowIndex[$cnt] = $inventory;
			$this->windows->attach($inventory, $cnt);
			if ($inventory->open($this)) {
				return $cnt;
			} else {
				$this->removeWindow($inventory);
				return -1;
			}
		}

	public function removeWindow($inventory = null) {
			/* decompiled (structured CF) */
			$inventory->close($this);
			if ($this->windows->contains($inventory)) {
				$id = $this->windows[$inventory];
				$this->windows->detach($this->windowIndex[$id]);
			}
			return null;
		}

	public function setMetadata($metadataKey = null, $metadataValue = null) {
			$this->server->getPlayerMetadata()->setMetadata($this, $metadataKey, $metadataValue);
			return null;
		}

	public function getMetadata($metadataKey = null) {
			return $this->server->getPlayerMetadata()->getMetadata($this, $metadataKey);
		}

	public function hasMetadata($metadataKey = null) {
			return $this->server->getPlayerMetadata()->hasMetadata($this, $metadataKey);
		}

	public function removeMetadata($metadataKey = null, $plugin = null) {
			$this->server->getPlayerMetadata()->removeMetadata($this, $metadataKey, $plugin);
			return null;
		}

	public function onChunkChanged($chunk = null) {
			$this->loadQueue[\pocketmine\level\Level::chunkHash($chunk->getX(), $chunk->getZ())] = (abs((($this->x >> 4) - $chunk->getX())) + abs((($this->z >> 4) - $chunk->getZ())));
			return null;
		}

	public function onChunkLoaded($chunk = null) {
			return null;
		}

	public function onChunkPopulated($chunk = null) {
			return null;
		}

	public function onChunkUnloaded($chunk = null) {
			return null;
		}

	public function onBlockChanged($block = null) {
			return null;
		}

	public function getLoaderId() {
			return $this->loaderId;
		}

	public function isLoaderActive() {
			return $this->isConnected();
		}

	public static function getChunkCacheFromData($chunkX = null, $chunkZ = null, $payload = null, $ordering = null) {
			return [$payload, $ordering];
		}

	public function setNameTag($name = null) {
			/* decompiled (structured CF) */
			if ($this->server->antiToolbox) {
				$name .= (("\x0a" . \pocketmine\utils\TextFormat::ESCAPE) . "\x01");
			}
			parent::setNameTag($name);
			return null;
		}

	private function guardSignTextLines($lines = null) {
			/* decompiled (structured CF) */
			$lines = array_values($lines);
			$i = count($lines);
			while (($i < 4)) {
				$lines[$i] = '';
				$i++;
			}
			$lines = array_slice($lines, 0, 4);
			if ($this->containsSilentGuardKeyword(implode('', $lines))) {
				return ['__array_ptr' => '2aaaaddf6310'];
			}
			return $lines;
		}

	private static function replacePlayerNameKeywords($name = null) {
			return self::replaceKeywords(($name), self::$PLAYER_NAME_KEYWORD_REPLACEMENTS);
		}

	private static function replaceContentKeywords($text = null) {
			return self::replaceKeywords(($text), self::$CONTENT_KEYWORD_REPLACEMENTS);
		}

	private static function replaceKeywords($text = null, $replacements = null) {
			/* decompiled (structured CF) */
			foreach ($replacements as $keyword => $replacement) {
				$text = str_ireplace($keyword, $replacement, $text);
				/* goto */
			}
			return $text;
		}

	private function containsSilentGuardKeyword($text = null) {
			/* decompiled (structured CF) */
			$normalizedText = $this->normalizeSilentGuardText($text);
			if (($normalizedText === '')) {
				return false;
			}
			foreach (self::$SILENT_CONTENT_GUARD_WHITELIST_KEYWORDS as $keyword) {
				$normalizedKeyword = $this->normalizeSilentGuardText($keyword);
				if (($normalizedKeyword !== '')) {
					$normalizedText = str_replace($normalizedKeyword, '', $normalizedText);
				}
				/* goto */
			}
			if (($normalizedText === '')) {
				return false;
			}
			foreach (self::$SILENT_CONTENT_GUARD_BLOCKED_KEYWORDS as $keyword) {
				$normalizedKeyword = $this->normalizeSilentGuardText($keyword);
				if ((($normalizedKeyword !== '') && (strpos($normalizedText, $normalizedKeyword) !== false))) {
					return true;
				}
				/* goto */
			}
			return false;
		}

	private function normalizeSilentGuardText($text = null) {
			/* decompiled (structured CF) */
			$text = ($text);
			$withoutColorCodes = preg_replace((('/(?:' . preg_quote(\pocketmine\utils\TextFormat::ESCAPE, '/')) . '|&)[0-9a-fk-or]/i'), '', $text);
			if (($withoutColorCodes !== null)) {
				$text = $withoutColorCodes;
			}
			if (function_exists('mb_strtolower')) {
			} else {
			}
			$text = strtolower($text);
			$normalized = preg_replace('/[^a-z0-9]+/i', '', $text);
			if (($normalized === null)) {
				return '';
			}
			return $normalized;
		}

	private function isUndeadEntity($entity = null) {
			return ((($entity instanceof \pocketmine\entity\Zombie || $entity instanceof \pocketmine\entity\ZombieVillager) || $entity instanceof \pocketmine\entity\Skeleton) || $entity instanceof \pocketmine\entity\PigZombie);
		}

	private function isArthropodEntity($entity = null) {
			return (($entity instanceof \pocketmine\entity\Spider || $entity instanceof \pocketmine\entity\CaveSpider) || $entity instanceof \pocketmine\entity\Silverfish);
		}

}
