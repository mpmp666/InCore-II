<?php

namespace pocketmine;

abstract class Achievement {
	public static $list = array (
  'mineWood' => 
  array (
    'name' => '获取木材 -获取原木',
    'requires' => 
    array (
    ),
  ),
  'buildWorkBench' => 
  array (
    'name' => '制作工作台 -用四块木板合成工作台',
    'requires' => 
    array (
      0 => 'mineWood',
    ),
  ),
  'buildPickaxe' => 
  array (
    'name' => '采矿时间到! -制作木稿',
    'requires' => 
    array (
      0 => 'buildWorkBench',
    ),
  ),
  'buildFurnace' => 
  array (
    'name' => '热门话题 -制作熔炉',
    'requires' => 
    array (
      0 => 'buildPickaxe',
    ),
  ),
  'acquireIron' => 
  array (
    'name' => '来硬的 -炼出铁锭',
    'requires' => 
    array (
      0 => 'buildFurnace',
    ),
  ),
  'buildHoe' => 
  array (
    'name' => '耕种时间到! -制作木锄',
    'requires' => 
    array (
      0 => 'buildWorkBench',
    ),
  ),
  'makeBread' => 
  array (
    'name' => '烤面包 -制作一个面包',
    'requires' => 
    array (
      0 => 'buildHoe',
    ),
  ),
  'bakeCake' => 
  array (
    'name' => '蛋糕是个谎言 -制作一个蛋糕',
    'requires' => 
    array (
      0 => 'buildHoe',
    ),
  ),
  'buildBetterPickaxe' => 
  array (
    'name' => '获得升级 -制作石稿',
    'requires' => 
    array (
      0 => 'buildPickaxe',
    ),
  ),
  'buildSword' => 
  array (
    'name' => '出击时间到! -做出木剑',
    'requires' => 
    array (
      0 => 'buildWorkBench',
    ),
  ),
  'diamonds' => 
  array (
    'name' => '是钻石! -获取钻石',
    'requires' => 
    array (
      0 => 'acquireIron',
    ),
  ),
);

	public static function broadcast($player = null, $achievementId = null) {
			/* decompiled (structured CF) */
			if (isset(\pocketmine\Achievement::$list[$achievementId])) {
				new \pocketmine\event\TranslationContainer('chat.type.achievement', [$player->getDisplayName(), (\pocketmine\utils\TextFormat::GREEN . \pocketmine\Achievement::$list[$achievementId]['name'])]);
				$translation = new \pocketmine\event\TranslationContainer('chat.type.achievement', [$player->getDisplayName(), (\pocketmine\utils\TextFormat::GREEN . \pocketmine\Achievement::$list[$achievementId]['name'])]);
				if ((\pocketmine\Server::getInstance()->getConfigString('announce-player-achievements', true) === true)) {
					\pocketmine\Server::getInstance()->broadcastMessage($translation);
				} else {
					$player->sendMessage($translation);
				}
				return true;
			}
			return false;
		}

	public static function add($achievementId = null, $achievementName = null, $requires = null) {
			/* decompiled (structured CF) */
			if (!(isset(\pocketmine\Achievement::$list[$achievementId]))) {
				\pocketmine\Achievement::$list[$achievementId] = [$achievementName, $requires];
				return true;
			}
			return false;
		}

}
