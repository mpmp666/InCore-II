InCore-II 2.1-MAX — recovered source package (latest)
====================================================
Work root: tmp/incore-ii-sg-re-fresh/
Built: 2026-07-22 (Asia/Shanghai)

Contents
--------
- src/          Recovered PHP tree (decompile + stub merge + transplants)
- RECOVERED.md  Pipeline / coverage notes (if present)

This wave
---------
1. Full PHAR re-extract + batch dump: 1303 files, ok=1292, fail=11
2. Fail transplants from runnable_pure into recovered_core/src:
   - pocketmine/PocketMine.php          (entry bootstrap from pure)
   - pocketmine/level/generator/object/BigTree.php  (+ canPlaceObject $random=null)
   - pocketmine/plugin/PluginLogger.php
   - SPL interfaces forced where needed (Logger / AttachableLogger / ClassLoader)

NOT included (cannot boot alone)
--------------------------------
- server.properties / worlds / plugins runtime env
- bin/php (need ZTS + pthreads)
- pthreads_shim (only if your PHP lacks real pthreads)

Boot: deliver runnable_pure/ or merge this src into an env shell + matching PHP.

Windows / classic pthreads note (2026-07-22)
--------------------------------------------
PocketMine.php no longer unconditionally requires pthreads_shim.php.
- If your PHP has classic **pthreads** (common Windows PocketMine bin): shim is skipped.
- If your PHP has **pmmpthread** only: src/pocketmine/pthreads_shim.php is loaded when present.
Still need: PHP >= 8.0 ZTS + pthreads/pmmpthread + yaml/sockets/curl/sqlite3/zlib.
Source-only zip still needs server.properties / worlds env to fully boot.

AttachableThreadedLogger fix (2026-07-22)
-----------------------------------------
Removed wrong non-abstract shadow file: src/AttachableThreadedLogger.php
Forced pure abstract class at: src/spl/AttachableThreadedLogger.php
(ThreadedLogger / Logger interfaces also re-synced from runnable_pure)
